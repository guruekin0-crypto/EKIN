import * as XLSX from 'xlsx';
import {
  TeachingDocument,
  TeachingDocType,
  TeachingReferenceDoc,
  AppSettings,
  TeacherProfile
} from '../types';
import { REGULASI_RESMI_BKPDM } from './printDocumentHelper';

export interface ParsedFileResult {
  fileName: string;
  fileType: string;
  fileSizeKb: number;
  dataUrl: string;
  extractedText: string;
  extractedRows: Array<{
    no: number;
    col1: string;
    col2: string;
    col3: string;
    col4?: string;
  }>;
}

/**
 * Extracts plain text from a .docx ArrayBuffer by locating word/document.xml
 * inside the ZIP structure and decompressing it using DecompressionStream('deflate-raw').
 */
async function extractDocxText(buffer: ArrayBuffer): Promise<string> {
  try {
    const bytes = new Uint8Array(buffer);
    const view = new DataView(buffer);
    const decoder = new TextDecoder('utf-8');

    let offset = 0;
    while (offset + 30 < bytes.length) {
      const sig = view.getUint32(offset, true);
      if (sig !== 0x04034b50) {
        offset++;
        continue;
      }

      const compressionMethod = view.getUint16(offset + 8, true);
      const compressedSize = view.getUint32(offset + 18, true);
      const fileNameLength = view.getUint16(offset + 26, true);
      const extraFieldLength = view.getUint16(offset + 28, true);

      const nameBytes = bytes.slice(offset + 30, offset + 30 + fileNameLength);
      const entryName = decoder.decode(nameBytes);
      const dataStart = offset + 30 + fileNameLength + extraFieldLength;

      if (entryName === 'word/document.xml' && compressedSize > 0 && dataStart + compressedSize <= bytes.length) {
        const compressedData = bytes.slice(dataStart, dataStart + compressedSize);
        let xmlString = '';

        if (compressionMethod === 0) {
          xmlString = decoder.decode(compressedData);
        } else if (compressionMethod === 8 && typeof DecompressionStream !== 'undefined') {
          const ds = new DecompressionStream('deflate-raw');
          const writer = ds.writable.getWriter();
          writer.write(compressedData);
          writer.close();
          const decompressedBuffer = await new Response(ds.readable).arrayBuffer();
          xmlString = decoder.decode(decompressedBuffer);
        }

        if (xmlString) {
          // Convert paragraph & table row tags to newlines before stripping XML
          const withBreaks = xmlString
            .replace(/<\/w:p>/g, '\n')
            .replace(/<\/w:tr>/g, '\n')
            .replace(/<\/w:tc>/g, ' | ')
            .replace(/<[^>]+>/g, '')
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"');

          return withBreaks
            .split('\n')
            .map(l => l.trim())
            .filter(Boolean)
            .join('\n');
        }
      }

      offset = dataStart + (compressedSize > 0 ? compressedSize : 1);
    }
  } catch (err) {
    console.warn('DOCX extraction fallback:', err);
  }
  return '';
}

/**
 * Extracts readable ASCII/UTF-8 text chunks from a PDF buffer when possible.
 */
function extractBasicPdfText(buffer: ArrayBuffer): string {
  try {
    const decoder = new TextDecoder('latin1');
    const raw = decoder.decode(buffer);
    const matches: string[] = [];

    // Match text inside parentheses (...) in PDF text blocks
    const regex = /\(([^()\\]{4,200})\)/g;
    let m: RegExpExecArray | null;
    while ((m = regex.exec(raw)) !== null && matches.length < 150) {
      const cleaned = m[1].replace(/[^\x20-\x7E\u00A0-\u00FF]/g, ' ').trim();
      // Filter out PDF metadata/font names
      if (
        cleaned.length > 4 &&
        !/^(Identity|Adobe|Times|Arial|Calibri|Helvetica|Font|Type|Page|Parent|Root)/i.test(cleaned)
      ) {
        matches.push(cleaned);
      }
    }

    if (matches.length > 3) {
      return matches.join(' ');
    }
  } catch {
    // ignore
  }
  return '';
}

/**
 * Parses an uploaded file (Excel, CSV, Word DOCX, TXT, JSON, HTML, PDF)
 * into structured text and rows that can be used as a reference/sandaran.
 */
export async function parseUploadedReferenceFile(file: File): Promise<ParsedFileResult> {
  const fileName = file.name;
  const fileType = file.type || fileName.split('.').pop()?.toLowerCase() || 'unknown';
  const fileSizeKb = Math.max(1, Math.round(file.size / 1024));
  const ext = fileName.split('.').pop()?.toLowerCase() || '';

  // Read DataURL for preview/download
  const dataUrl: string = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string) || '');
    reader.onerror = () => reject(new Error('Gagal membaca file'));
    reader.readAsDataURL(file);
  });

  // Read ArrayBuffer for parsing
  const arrayBuffer = await file.arrayBuffer();

  let extractedText = '';
  const extractedRows: Array<{
    no: number;
    col1: string;
    col2: string;
    col3: string;
    col4?: string;
  }> = [];

  // 1. Excel / CSV (.xlsx, .xls, .csv)
  if (ext === 'xlsx' || ext === 'xls' || ext === 'csv') {
    try {
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const textChunks: string[] = [];

      workbook.SheetNames.forEach(sheetName => {
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, defval: '' });

        textChunks.push(`=== Lembar: ${sheetName} ===`);
        rows.forEach((row) => {
          const nonEmptyCells = (row || [])
            .map(c => String(c ?? '').trim())
            .filter(Boolean);

          if (nonEmptyCells.length > 0) {
            textChunks.push(nonEmptyCells.join(' | '));
          }

          // Skip header rows and add data rows
          if (nonEmptyCells.length >= 2) {
            const firstCell = nonEmptyCells[0].toLowerCase();
            const isHeader =
              firstCell === 'no' ||
              firstCell === 'nomor' ||
              firstCell.includes('tujuan pembelajaran') ||
              firstCell.includes('capaian') ||
              firstCell.includes('materi pokok');

            if (!isHeader) {
              // Check if first cell is a number
              const hasNumIndex = !isNaN(Number(nonEmptyCells[0])) && nonEmptyCells.length >= 3;
              const col1 = hasNumIndex ? nonEmptyCells[1] : nonEmptyCells[0];
              const col2 = hasNumIndex ? nonEmptyCells[2] : nonEmptyCells[1] || '';
              const col3 = hasNumIndex ? nonEmptyCells[3] || '4 JP' : nonEmptyCells[2] || '4 JP';
              const col4 = hasNumIndex ? nonEmptyCells[4] || '' : nonEmptyCells[3] || '';

              if (col1 && col1.length > 2) {
                extractedRows.push({
                  no: extractedRows.length + 1,
                  col1,
                  col2: col2 || col1,
                  col3,
                  col4
                });
              }
            }
          }
        });
      });

      extractedText = textChunks.join('\n');
    } catch (err) {
      console.warn('Error parsing Excel file:', err);
    }
  }
  // 2. Word (.docx)
  else if (ext === 'docx') {
    extractedText = await extractDocxText(arrayBuffer);
    if (extractedText) {
      const lines = extractedText
        .split('\n')
        .map(l => l.trim())
        .filter(l => l.length > 8);

      lines.forEach(line => {
        if (line.includes('|')) {
          const parts = line
            .split('|')
            .map(p => p.trim())
            .filter(Boolean);
          if (parts.length >= 2) {
            const hasNo = !isNaN(Number(parts[0])) && parts.length >= 3;
            extractedRows.push({
              no: extractedRows.length + 1,
              col1: hasNo ? parts[1] : parts[0],
              col2: hasNo ? parts[2] : parts[1],
              col3: (hasNo ? parts[3] : parts[2]) || '4 JP',
              col4: (hasNo ? parts[4] : parts[3]) || ''
            });
          }
        } else if (/^(\d+[\.\)]|-|\•)\s+/.test(line)) {
          const cleanLine = line.replace(/^(\d+[\.\)]|-|\•)\s+/, '').trim();
          extractedRows.push({
            no: extractedRows.length + 1,
            col1: cleanLine,
            col2: cleanLine,
            col3: '4 JP'
          });
        }
      });
    }
  }
  // 3. Plain Text / Markdown / JSON / HTML (.txt, .md, .json, .html)
  else if (['txt', 'md', 'json', 'html', 'htm'].includes(ext)) {
    const decoder = new TextDecoder('utf-8');
    const rawText = decoder.decode(arrayBuffer);

    if (ext === 'html' || ext === 'htm') {
      extractedText = rawText
        .replace(/<style[\s\S]*?<\/style>/gi, '')
        .replace(/<script[\s\S]*?<\/script>/gi, '')
        .replace(/<\/(p|div|tr|li|h[1-6])>/gi, '\n')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+\n/g, '\n')
        .trim();
    } else if (ext === 'json') {
      try {
        const parsed = JSON.parse(rawText);
        extractedText = JSON.stringify(parsed, null, 2);
      } catch {
        extractedText = rawText;
      }
    } else {
      extractedText = rawText;
    }

    const lines = extractedText
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 6);

    lines.slice(0, 25).forEach(line => {
      const cleanLine = line.replace(/^(\d+[\.\)]|-|\•)\s+/, '').trim();
      if (cleanLine.length > 8) {
        extractedRows.push({
          no: extractedRows.length + 1,
          col1: cleanLine,
          col2: cleanLine,
          col3: '4 JP'
        });
      }
    });
  }
  // 4. PDF (.pdf) or DOC (.doc)
  else if (ext === 'pdf' || ext === 'doc') {
    const pdfExtracted = extractBasicPdfText(arrayBuffer);
    extractedText =
      pdfExtracted ||
      `Dokumen Acuan Resmi: ${fileName} (Ukuran: ${fileSizeKb} KB).\nGunakan pratinjau dokumen ini atau tuliskan/salin poin Capaian Pembelajaran (CP), Tujuan Pembelajaran (TP), dan Materi Pokok pada kolom ringkasan acuan di bawah untuk dijadikan sandaran otomatis.`;
  }

  // Fallback rows if extractedRows is empty but extractedText has multiple lines
  if (extractedRows.length === 0 && extractedText) {
    const paragraphs = extractedText
      .split(/\n+/)
      .map(p => p.trim())
      .filter(p => p.length > 15 && !p.startsWith('==='));

    paragraphs.slice(0, 12).forEach((p, idx) => {
      extractedRows.push({
        no: idx + 1,
        col1: p.length > 160 ? p.substring(0, 160) + '...' : p,
        col2: p,
        col3: '4 JP',
        col4: 'Beriman, Bertakwa & Kasih Sayang (KBC)'
      });
    });
  }

  return {
    fileName,
    fileType,
    fileSizeKb,
    dataUrl,
    extractedText,
    extractedRows
  };
}

/**
 * Converts an uploaded TeachingReferenceDoc directly into a complete TeachingDocument
 * ready to be saved into the Perangkat Ajar collection.
 */
export function convertRefDocToTeachingDocument(
  refDoc: TeachingReferenceDoc,
  targetDocType: TeachingDocType,
  appSettings: AppSettings,
  teacherProfile: TeacherProfile
): Omit<TeachingDocument, 'id' | 'createdAt' | 'updatedAt'> {
  const grade = refDoc.classGrade === 'all' ? '5' : refDoc.classGrade;
  const fase: 'Fase A' | 'Fase B' | 'Fase C' =
    grade === '1' || grade === '2' ? 'Fase A' : grade === '3' || grade === '4' ? 'Fase B' : 'Fase C';

  const schoolName =
    appSettings.schoolName || teacherProfile.schoolName || 'SDN Ciketing Udik 2 Bantargebang';
  const teacherName = teacherProfile.fullName || 'Guru PAI & Budi Pekerti';
  const teacherNip = teacherProfile.nip || '-';
  const principalName = appSettings.principalName || 'Kepala Sekolah';
  const principalNip = appSettings.principalNip || '-';
  const academicYear = appSettings.academicYear || '2026/2027';

  const rows =
    refDoc.extractedRows && refDoc.extractedRows.length > 0
      ? refDoc.extractedRows
      : [
          {
            no: 1,
            col1: `Memahami dan mengamalkan isi materi pada dokumen acuan "${refDoc.title}"`,
            col2: refDoc.title,
            col3: '12 JP',
            col4: 'Beriman, Bertakwa & Kasih Sayang (KBC)'
          }
        ];

  const parseJP = (val?: string): number => {
    if (!val) return 4;
    const m = String(val).match(/\d+/);
    return m ? Math.min(36, Math.max(1, Number(m[0]))) : 4;
  };

  const contentData: TeachingDocument['contentData'] = {
    sandaranAcuan: {
      referenceId: refDoc.id,
      referenceTitle: refDoc.title,
      fileName: refDoc.fileName,
      fileType: refDoc.fileType,
      dataUrl: refDoc.dataUrl,
      ringkasanAcuan: refDoc.extractedText.substring(0, 1200)
    },
    catatanTambahan: refDoc.notes
      ? `Disusun berdasarkan Dokumen Acuan: ${refDoc.title} (${refDoc.fileName}).\nCatatan: ${refDoc.notes}`
      : `Disusun berdasarkan Dokumen Acuan: ${refDoc.title} (${refDoc.fileName}).`
  };

  if (targetDocType === 'cp_atp') {
    contentData.capaianPembelajaran =
      refDoc.extractedText.trim() ||
      `Capaian Pembelajaran PAI & Budi Pekerti Kelas ${grade} (${fase}) berdasarkan dokumen acuan "${refDoc.title}".`;
    contentData.alurTujuanPembelajaran = rows.map((r, idx) => ({
      no: idx + 1,
      tujuan: r.col1,
      materi: r.col2 || refDoc.title,
      elemen: refDoc.elementDomain || "Al-Qur'an & Hadis",
      alokasiJP: parseJP(r.col3),
      profilPancasilaKBC: r.col4 || 'Beriman, Bertakwa & Kasih Sayang (KBC)',
      indikator: `Tercapainya kompetensi sesuai acuan: ${r.col1}`
    }));
  } else if (targetDocType === 'prota') {
    const protaItems = rows.map((r, idx) => ({
      no: idx + 1,
      semester: (idx % 2 === 0 ? 'Ganjil' : 'Genap') as 'Ganjil' | 'Genap',
      elemen: refDoc.elementDomain || "Al-Qur'an & Hadis",
      materiPokok: r.col2 || r.col1,
      tujuanPembelajaran: r.col1,
      alokasiJP: parseJP(r.col3),
      keterangan: r.col4 || 'Sesuai Dokumen Acuan'
    }));
    const jpGanjil = protaItems
      .filter(i => i.semester === 'Ganjil')
      .reduce((a, b) => a + b.alokasiJP, 0);
    const jpGenap = protaItems
      .filter(i => i.semester === 'Genap')
      .reduce((a, b) => a + b.alokasiJP, 0);
    contentData.protaItems = protaItems;
    contentData.totalJPGanjil = jpGanjil;
    contentData.totalJPGenap = jpGenap;
    contentData.totalJPTahunan = jpGanjil + jpGenap;
  } else if (targetDocType === 'promes') {
    contentData.promesItems = rows.map((r, idx) => ({
      no: idx + 1,
      materiPokok: r.col2 || r.col1,
      tujuanPembelajaran: r.col1,
      alokasiJP: parseJP(r.col3),
      distribusiBulan: [
        {
          bulan: r.col4 || (refDoc.semester === 'Genap' ? 'Januari - Maret' : 'Juli - September'),
          minggu: [parseJP(r.col3)]
        }
      ]
    }));
  } else if (targetDocType === 'kktp') {
    contentData.kktpItems = rows.map((r, idx) => ({
      no: idx + 1,
      tujuanPembelajaran: r.col1,
      indikatorKetuntasan: r.col2 || `Ketuntasan penguasaan materi ${r.col1}`,
      kriteria: {
        perluBimbingan: 'Belum mencapai indikator dasar, butuh bimbingan penuh kasih sayang (0-60).',
        cukup: 'Mencapai sebagian indikator dasar namun perlu penguatan (61-75).',
        baik: 'Mencapai indikator ketuntasan dengan baik dan mandiri (76-88).',
        sangatBaik: 'Sangat mahir, tuntas sempurna, dan mampu membimbing teman (89-100).'
      },
      tindakLanjutKBC: 'Pendampingan ramah anak & tutor sebaya berbasis Kurikulum Berbasis Cinta (KBC).'
    }));
  } else if (targetDocType === 'modul_ajar') {
    contentData.modulAjar = {
      identitas: {
        penyusun: teacherName,
        instansi: schoolName,
        faseKelas: `${fase} / Kelas ${grade}`,
        semester: refDoc.semester,
        materiPokok: refDoc.title,
        alokasiWaktu: '3 Pertemuan (9 JP)'
      },
      kompetensiAwal:
        refDoc.extractedText.substring(0, 300) ||
        `Peserta didik memahami konsep awal dari dokumen acuan ${refDoc.title}.`,
      profilPelajarPancasilaKBC: [
        'Beriman, Bertakwa kepada Tuhan YME, dan Berakhlak Mulia',
        'Gotong Royong & Kasih Sayang (KBC)',
        'Mandiri & Bernalar Kritis'
      ],
      saranaPrasarana: [
        `Dokumen Acuan: ${refDoc.fileName}`,
        'Buku Teks PAI & Budi Pekerti Kurikulum Merdeka',
        'LKPD & Media Pembelajaran'
      ],
      targetPesertaDidik: `Peserta Didik Kelas ${grade}`,
      modelPembelajaran: 'Problem Based Learning (PBL) & Kurikulum Berbasis Cinta (KBC)',
      komponenInti: {
        tujuanPembelajaran: rows.map(r => r.col1),
        pemahamanBermakna:
          'Mengamalkan ilmu agama dengan hati yang tulus, penuh kasih sayang, dan berakhlak mulia.',
        pertanyaanPemantik: [
          `Apa pesan kebaikan utama dari materi ${refDoc.title}?`,
          'Bagaimana cara kita mengamalkannya di sekolah dan di rumah?'
        ],
        kegiatanPembelajaran: {
          pendahuluan: [
            'Guru membuka kelas dengan salam hangat, sapaan kasih sayang, dan doa bersama.',
            'Tadarus surah pendek bersama dan apersepsi materi acuan.'
          ],
          kegiatanInti: rows.map(
            (r, idx) => `Kegiatan ${idx + 1}: Pembahasan dan praktik "${r.col1}" (${r.col2 || ''}).`
          ),
          penutup: [
            'Peserta didik bersama guru menyimpulkan inti pembelajaran.',
            'Refleksi kalbu (KBC) dan doa penutup majelis.'
          ]
        },
        asesmen: {
          diagnostik: 'Tanya jawab kesiapan belajar awal.',
          formatif: 'Observasi sikap kasih sayang (KBC) dan penugasan LKPD.',
          sumatif: 'Evaluasi akhir bab sesuai indikator dokumen acuan.'
        },
        pengayaanRemedial: 'Pendampingan remedial ramah anak & pengayaan.',
        refleksi: 'Refleksi ketercapaian pembelajaran guru dan siswa.'
      },
      lampiran: {
        bahanBacaan: refDoc.extractedText.substring(0, 600) || refDoc.title,
        glosarium: 'KBC: Kurikulum Berbasis Cinta.',
        daftarPustaka: `Dokumen Acuan: ${refDoc.fileName}`
      }
    };
  } else if (targetDocType === 'lkpd') {
    contentData.lkpd = {
      judulAktivitas: `Lembar Kerja Siswa: ${refDoc.title}`,
      temaNilaiKBC: 'Menebar Kasih Sayang & Cinta Ilmu',
      petunjukBelajar: [
        'Bacalah Basmalah sebelum mengerjakan LKPD.',
        'Pelajari ringkasan materi acuan dengan saksama.',
        'Jawablah pertanyaan dengan jujur dan santun.'
      ],
      stimulusCerita: refDoc.extractedText.substring(0, 450) || `Materi Acuan: ${refDoc.title}`,
      langkahAktivitas: [
        '1. Bacalah materi dan petunjuk dengan teliti.',
        '2. Kerjakan setiap butir aktivitas di bawah ini.'
      ],
      tugasSiswa: rows.slice(0, 6).map((r, idx) => ({
        nomor: idx + 1,
        instruksi: `Jelaskan pemahamanmu dan contoh penerapan dari: "${r.col1}"!`,
        tipe: 'isian' as const
      })),
      refleksiCinta: 'Kebaikan apa yang akan kamu praktikkan setelah mempelajari materi ini?',
      rubrikNilai: 'Pemahaman (50%), Sikap & Kejujuran (30%), Kerapian (20%). Skor = 100.'
    };
  } else {
    contentData.dokumenLainnya = {
      subKategori: `Dokumen Acuan & Perangkat Ajar (${refDoc.fileName})`,
      tujuanDokumen: `Sebagai dokumen perangkat ajar dan acuan resmi pembelajaran Kelas ${grade}.`,
      uraianIsi: refDoc.extractedText || refDoc.title,
      tabelBaris: rows.map((r, idx) => ({
        no: idx + 1,
        aspek: r.col1,
        uraian: r.col2 || r.col1,
        keterangan: r.col3 || 'Tuntas'
      })),
      lampiranFile: refDoc.dataUrl
        ? {
            fileName: refDoc.fileName,
            fileType: refDoc.fileType,
            dataUrl: refDoc.dataUrl
          }
        : undefined
    };
  }

  return {
    docType: targetDocType,
    classGrade: grade,
    semester: refDoc.semester,
    academicYear,
    title: refDoc.title.toUpperCase(),
    summary: `Disusun dari Dokumen Acuan "${refDoc.fileName}" (${rows.length} komponen/baris terdeteksi).`,
    schoolName,
    teacherName,
    teacherNip,
    principalName,
    principalNip,
    regulasi: REGULASI_RESMI_BKPDM,
    meta: {
      fase,
      elementDomain: refDoc.elementDomain || "Al-Qur'an & Hadis",
      alokasiWaktuJP: 12,
      targetBab: refDoc.title,
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)',
      regulasi: REGULASI_RESMI_BKPDM
    },
    contentData
  };
}
