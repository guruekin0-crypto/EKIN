import { TeachingDocument, AppSettings, TeacherProfile } from '../types';

export const REGULASI_RESMI_BKPDM = 'Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026 dengan pendekatan KBC (Kurikulum Berbasis Cinta)';

export const generateDocumentPrintHtml = (
  doc: TeachingDocument,
  appSettings: AppSettings,
  teacherProfile: TeacherProfile
): string => {
  const schoolName = doc.schoolName || appSettings.schoolName || teacherProfile.schoolName || 'SDN CIKETING UDIK 2 BANTARGEBANG';
  const schoolAddress = appSettings.schoolAddress || 'Jl. Raya Ciketing Udik No. 2, Kec. Bantargebang, Kota Bekasi, Jawa Barat';
  const logoUrl = appSettings.appLogoUrl || 'https://jhlryjdhotxtndavacpd.supabase.co/storage/v1/object/public/logo/logo.png';
  const principalName = doc.principalName || appSettings.principalName || 'Hj. Siti Aminah, M.Pd';
  const principalNip = doc.principalNip || appSettings.principalNip || '197608201999032001';
  const teacherName = doc.teacherName || teacherProfile.fullName || 'H. Ahmad Syarif, S.Pd.I';
  const teacherNip = doc.teacherNip || teacherProfile.nip || '198503152010011002';
  const academicYear = doc.academicYear || appSettings.academicYear || '2026/2027';

  // Render specific content depending on docType
  let bodyContentHtml = '';

  if (doc.docType === 'cp_atp') {
    const atpItems = doc.contentData.alurTujuanPembelajaran || [];
    bodyContentHtml = `
      <div class="section">
        <h4 class="section-title">I. DASAR HUKUM & PEDOMAN REGULASI TERBARU</h4>
        <div class="info-box">
          <b>Regulasi Resmi:</b> ${REGULASI_RESMI_BKPDM}.<br>
          <b>Prinsip Pembelajaran:</b> Mengedepankan kasih sayang (mahabbah), keteladanan akhlak mulia, dan suasana belajar yang menyejukkan tanpa kekerasan di lingkungan satuan pendidikan.
        </div>
      </div>

      <div class="section">
        <h4 class="section-title">II. CAPAIAN PEMBELAJARAN (CP) ELEMEN ${doc.meta.elementDomain.toUpperCase()}</h4>
        <p class="paragraph-box">${doc.contentData.capaianPembelajaran || '-'}</p>
      </div>

      <div class="section">
        <h4 class="section-title">III. ALUR TUJUAN PEMBELAJARAN (ATP) FASE ${doc.meta.fase.toUpperCase()} - KELAS ${doc.classGrade}</h4>
        <table class="data-table">
          <thead>
            <tr>
              <th style="width: 35px; text-align: center;">No</th>
              <th>Tujuan Pembelajaran (TP)</th>
              <th>Materi Pokok / Bab</th>
              <th>Dimensi Profil Pelajar & Nilai KBC</th>
              <th style="width: 50px; text-align: center;">JP</th>
            </tr>
          </thead>
          <tbody>
            ${atpItems.map((item, idx) => `
              <tr>
                <td style="text-align: center;">${item.no || idx + 1}</td>
                <td><b>${item.tujuan}</b><br><small style="color: #475569;">Indikator: ${item.indikator || '-'}</small></td>
                <td>${item.materi}</td>
                <td style="color: #047857; font-weight: 600;">${item.profilPancasilaKBC}</td>
                <td style="text-align: center; font-weight: bold;">${item.alokasiJP} JP</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } else if (doc.docType === 'prota') {
    const protaItems = doc.contentData.protaItems || [];
    bodyContentHtml = `
      <div class="section">
        <div class="info-box">
          <b>Pedoman Regulasi:</b> ${REGULASI_RESMI_BKPDM}.
        </div>
        <table class="data-table">
          <thead>
            <tr>
              <th style="width: 35px; text-align: center;">No</th>
              <th style="width: 70px;">Semester</th>
              <th>Materi Pokok / Bab</th>
              <th>Tujuan Pembelajaran</th>
              <th style="width: 50px; text-align: center;">JP</th>
              <th>Keterangan</th>
            </tr>
          </thead>
          <tbody>
            ${protaItems.map((item) => `
              <tr>
                <td style="text-align: center;">${item.no}</td>
                <td style="font-weight: bold;">${item.semester}</td>
                <td><b>${item.materiPokok}</b></td>
                <td>${item.tujuanPembelajaran}</td>
                <td style="text-align: center; font-weight: bold;">${item.alokasiJP} JP</td>
                <td style="font-size: 11px; color: #475569;">${item.keterangan || '-'}</td>
              </tr>
            `).join('')}
            <tr style="background: #f1f5f9; font-weight: bold;">
              <td colspan="4" style="text-align: right;">TOTAL ALOKASI WAKTU SATU TAHUN AJARAN:</td>
              <td style="text-align: center;">${doc.contentData.totalJPTahunan || 108} JP</td>
              <td>Tuntas</td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  } else if (doc.docType === 'promes') {
    const promesItems = doc.contentData.promesItems || [];
    bodyContentHtml = `
      <div class="section">
        <div class="info-box">
          <b>Pedoman Regulasi:</b> ${REGULASI_RESMI_BKPDM}.
        </div>
        <table class="data-table">
          <thead>
            <tr>
              <th style="width: 35px; text-align: center;">No</th>
              <th>Materi Pokok</th>
              <th>Tujuan Pembelajaran</th>
              <th style="width: 50px; text-align: center;">JP</th>
              <th>Distribusi Pekan Efektif</th>
            </tr>
          </thead>
          <tbody>
            ${promesItems.map((item) => `
              <tr>
                <td style="text-align: center;">${item.no}</td>
                <td><b>${item.materiPokok}</b></td>
                <td>${item.tujuanPembelajaran}</td>
                <td style="text-align: center; font-weight: bold;">${item.alokasiJP} JP</td>
                <td>${item.distribusiBulan.map(b => `${b.bulan} (${b.minggu.filter(m => m > 0).join(', ')} JP)`).join('; ')}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } else if (doc.docType === 'kktp') {
    const kktpItems = doc.contentData.kktpItems || [];
    bodyContentHtml = `
      <div class="section">
        <div class="info-box">
          <b>Pedoman Regulasi:</b> ${REGULASI_RESMI_BKPDM}.
        </div>
        ${kktpItems.map((item) => `
          <div class="kktp-card">
            <h5 style="margin: 0 0 4px 0; font-size: 13px;">${item.no}. ${item.tujuanPembelajaran}</h5>
            <p style="margin: 0 0 8px 0; font-size: 11px; color: #334155;"><b>Indikator Ketercapaian:</b> ${item.indikatorKetuntasan}</p>
            <table class="data-table" style="margin-bottom: 6px;">
              <thead>
                <tr>
                  <th style="width: 25%;">Perlu Bimbingan (0 - 60)</th>
                  <th style="width: 25%;">Cukup (61 - 75)</th>
                  <th style="width: 25%;">Baik (76 - 88)</th>
                  <th style="width: 25%;">Sangat Baik (89 - 100)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>${item.kriteria.perluBimbingan}</td>
                  <td>${item.kriteria.cukup}</td>
                  <td>${item.kriteria.baik}</td>
                  <td><b>${item.kriteria.sangatBaik}</b></td>
                </tr>
              </tbody>
            </table>
            <div style="font-size: 11px; background: #ecfdf5; border-left: 3px solid #059669; padding: 6px 10px; color: #065f46;">
              <b>Tindak Lanjut Kasih Sayang (KBC):</b> ${item.tindakLanjutKBC}
            </div>
          </div>
        `).join('')}
      </div>
    `;
  } else if (doc.docType === 'modul_ajar' && doc.contentData.modulAjar) {
    const ma = doc.contentData.modulAjar;
    bodyContentHtml = `
      <div class="section">
        <div class="info-box">
          <b>Pedoman Regulasi:</b> ${REGULASI_RESMI_BKPDM}.
        </div>
        <h4 class="section-title">I. INFORMASI UMUM MODUL</h4>
        <table class="data-table">
          <tbody>
            <tr><td style="width: 200px; font-weight: bold; background: #f8fafc;">Kompetensi Awal</td><td>${ma.kompetensiAwal}</td></tr>
            <tr><td style="font-weight: bold; background: #f8fafc;">Profil Pelajar Pancasila & KBC</td><td>${ma.profilPelajarPancasilaKBC.join(', ')}</td></tr>
            <tr><td style="font-weight: bold; background: #f8fafc;">Sarana & Prasarana</td><td>${ma.saranaPrasarana.join(', ')}</td></tr>
            <tr><td style="font-weight: bold; background: #f8fafc;">Model Pembelajaran</td><td>${ma.modelPembelajaran}</td></tr>
          </tbody>
        </table>

        <h4 class="section-title" style="margin-top: 16px;">II. KOMPONEN INTI</h4>
        <p><b>1. Tujuan Pembelajaran:</b></p>
        <ul style="margin: 4px 0 10px 20px;">
          ${ma.komponenInti.tujuanPembelajaran.map(tp => `<li>${tp}</li>`).join('')}
        </ul>

        <p><b>2. Pemahaman Bermakna (Kurikulum Berbasis Cinta):</b></p>
        <p class="paragraph-box" style="font-style: italic;">"${ma.komponenInti.pemahamanBermakna}"</p>

        <p><b>3. Pertanyaan Pemantik:</b></p>
        <ul style="margin: 4px 0 10px 20px;">
          ${ma.komponenInti.pertanyaanPemantik.map(q => `<li>${q}</li>`).join('')}
        </ul>

        <p><b>4. Langkah-Langkah Pembelajaran Berdiferensiasi:</b></p>
        <div style="border: 1px solid #cbd5e1; padding: 10px 14px; border-radius: 6px; margin-bottom: 10px;">
          <b>A. Kegiatan Pendahuluan:</b>
          <ul style="margin: 4px 0 8px 20px;">${ma.komponenInti.kegiatanPembelajaran.pendahuluan.map(act => `<li>${act}</li>`).join('')}</ul>
          <b>B. Kegiatan Inti (5M & Pendekatan Cinta):</b>
          <ul style="margin: 4px 0 8px 20px;">${ma.komponenInti.kegiatanPembelajaran.kegiatanInti.map(act => `<li>${act}</li>`).join('')}</ul>
          <b>C. Kegiatan Penutup & Refleksi:</b>
          <ul style="margin: 4px 0 0 20px;">${ma.komponenInti.kegiatanPembelajaran.penutup.map(act => `<li>${act}</li>`).join('')}</ul>
        </div>

        <p><b>5. Asesmen:</b></p>
        <p style="margin: 2px 0;">&bull; <b>Diagnostik:</b> ${ma.komponenInti.asesmen.diagnostik}</p>
        <p style="margin: 2px 0;">&bull; <b>Formatif:</b> ${ma.komponenInti.asesmen.formatif}</p>
        <p style="margin: 2px 0;">&bull; <b>Sumatif:</b> ${ma.komponenInti.asesmen.sumatif}</p>
      </div>
    `;
  } else if (doc.docType === 'lkpd' && doc.contentData.lkpd) {
    const lkpd = doc.contentData.lkpd;
    bodyContentHtml = `
      <div class="section">
        <div style="border: 1px solid #000; padding: 10px 14px; border-radius: 6px; margin-bottom: 14px; display: flex; justify-content: space-between; font-size: 11px;">
          <div>
            <p style="margin: 0;"><b>Nama Siswa :</b> ..............................................................</p>
            <p style="margin: 4px 0 0 0;"><b>Kelas / Rombel :</b> Kelas ${doc.classGrade} (${schoolName})</p>
          </div>
          <div>
            <p style="margin: 0;"><b>No. Absen :</b> ................</p>
            <p style="margin: 4px 0 0 0;"><b>Hari/Tgl :</b> ....................................</p>
          </div>
        </div>

        <div style="border-left: 4px solid #047857; padding-left: 10px; margin-bottom: 12px;">
          <h4 style="margin: 0; font-size: 14px; text-transform: uppercase;">${lkpd.judulAktivitas}</h4>
          <p style="margin: 2px 0 0 0; font-size: 11px; color: #475569;"><b>Tema Kasih Sayang:</b> ${lkpd.temaNilaiKBC}</p>
        </div>

        ${lkpd.stimulusCerita ? `
          <div style="background: #f8fafc; border: 1px solid #cbd5e1; padding: 10px 14px; border-radius: 6px; margin-bottom: 12px; font-style: italic; font-size: 12px;">
            <b>Kisah Inspiratif Sahabat Sekolah:</b>
            <p style="margin: 4px 0 0 0;">${lkpd.stimulusCerita}</p>
          </div>
        ` : ''}

        ${lkpd.arabicSnippet ? `
          <div style="text-align: center; margin: 12px 0; padding: 10px; background: #fafaf9; border: 1px solid #e7e5e4; border-radius: 6px;">
            <p style="font-family: 'Amiri', serif; font-size: 20px; line-height: 2.2; margin: 0;" dir="rtl">${lkpd.arabicSnippet.text}</p>
            <p style="font-size: 11px; font-style: italic; color: #44403c; margin: 4px 0 0 0;">"${lkpd.arabicSnippet.arti}"</p>
          </div>
        ` : ''}

        <h5 style="margin: 14px 0 8px 0; font-size: 12px; text-transform: uppercase;">Lembar Aktivitas Siswa:</h5>
        ${lkpd.tugasSiswa.map((t) => `
          <div style="border: 1px solid #000; padding: 8px 12px; border-radius: 6px; margin-bottom: 10px; font-size: 11px;">
            <p style="margin: 0; font-weight: bold;">${t.nomor}. ${t.instruksi}</p>
            ${t.opsi ? `
              <div style="margin: 6px 0 6px 14px;">
                ${t.opsi.map((op, oi) => `<div style="margin-bottom: 2px;">(${String.fromCharCode(65 + oi)}) ${op}</div>`).join('')}
              </div>
            ` : ''}
            <div style="margin-top: 8px;">
              <span style="font-size: 10px; color: #64748b;">Tuliskan jawabanmu di sini:</span>
              <div style="border-bottom: 1px dotted #000; height: 26px;"></div>
              <div style="border-bottom: 1px dotted #000; height: 26px;"></div>
            </div>
          </div>
        `).join('')}

        <div style="background: #ecfdf5; border: 1px solid #a7f3d0; padding: 10px 14px; border-radius: 6px; font-size: 11px; margin-top: 12px;">
          <b>Refleksi Kalbu (Kurikulum Berbasis Cinta):</b>
          <p style="margin: 4px 0 0 0; font-style: italic;">${lkpd.refleksiCinta}</p>
          <div style="border-bottom: 1px dotted #000; height: 26px; margin-top: 6px;"></div>
        </div>
      </div>
    `;
  } else if (doc.docType === 'lainnya' || doc.contentData.dokumenLainnya) {
    const dl = doc.contentData.dokumenLainnya || {
      subKategori: 'Dokumen Administrasi & Perangkat Ajar PAI',
      tujuanDokumen: doc.summary || '-',
      uraianIsi: doc.contentData.catatanTambahan || '-',
      tabelBaris: []
    };
    const rows = dl.tabelBaris || [];
    bodyContentHtml = `
      <div class="section">
        <div class="info-box">
          <b>Kategori Dokumen:</b> ${dl.subKategori || 'Perangkat Ajar Pendukung'}<br>
          <b>Pedoman Regulasi:</b> ${REGULASI_RESMI_BKPDM}.
        </div>

        ${dl.tujuanDokumen ? `
          <h4 class="section-title">I. TUJUAN & SASARAN DOKUMEN</h4>
          <p class="paragraph-box" style="margin-bottom: 12px;">${dl.tujuanDokumen}</p>
        ` : ''}

        ${dl.uraianIsi ? `
          <h4 class="section-title">II. URAIAN LENGKAP PERANGKAT AJAR</h4>
          <div class="paragraph-box" style="white-space: pre-line; margin-bottom: 12px;">${dl.uraianIsi}</div>
        ` : ''}

        ${rows.length > 0 ? `
          <h4 class="section-title">III. RINCIAN MATRIKS / KOMPONEN KEGIATAN</h4>
          <table class="data-table">
            <thead>
              <tr>
                <th style="width: 35px; text-align: center;">No</th>
                <th style="width: 30%;">Aspek / Komponen</th>
                <th>Uraian / Indikator / Kegiatan</th>
                <th style="width: 110px; text-align: center;">Keterangan / JP</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map((r, idx) => `
                <tr>
                  <td style="text-align: center;">${r.no || idx + 1}</td>
                  <td><b>${r.aspek}</b></td>
                  <td>${r.uraian}</td>
                  <td style="text-align: center; font-weight: bold;">${r.keterangan || '-'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : ''}

        ${dl.tautanBukti ? `
          <div style="margin-top: 12px; font-size: 11px; padding: 8px 12px; border: 1px dashed #64748b; border-radius: 6px;">
            <b>Tautan Dokumen / Bukti Fisik:</b> ${dl.tautanBukti}
          </div>
        ` : ''}

        ${dl.lampiranFile ? `
          <div style="margin-top: 8px; font-size: 11px; padding: 8px 12px; border: 1px solid #cbd5e1; background: #f8fafc; border-radius: 6px;">
            <b>Lampiran Berkas:</b> ${dl.lampiranFile.fileName}
          </div>
        ` : ''}
      </div>
    `;
  }

  if (doc.contentData.catatanTambahan && doc.docType !== 'lainnya') {
    bodyContentHtml += `
      <div class="section">
        <h4 class="section-title">CATATAN TAMBAHAN PENDIDIK</h4>
        <div class="paragraph-box" style="white-space: pre-line;">${doc.contentData.catatanTambahan}</div>
      </div>
    `;
  }

  const html = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>${doc.title} - ${schoolName}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      background: #f1f5f9;
      color: #0f172a;
      line-height: 1.5;
      font-size: 12px;
      padding-bottom: 40px;
    }
    .top-toolbar {
      position: sticky;
      top: 0;
      z-index: 100;
      background: #0f172a;
      color: #fff;
      padding: 12px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    }
    .top-toolbar .title-info {
      font-size: 12px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .top-toolbar button {
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      border: none;
      transition: all 0.2s;
    }
    .btn-print {
      background: #10b981;
      color: #fff;
    }
    .btn-print:hover {
      background: #059669;
    }
    .btn-close {
      background: rgba(255,255,255,0.15);
      color: #fff;
    }
    .btn-close:hover {
      background: rgba(255,255,255,0.25);
    }
    .paper-container {
      max-width: 850px;
      margin: 24px auto;
      background: #fff;
      padding: 40px 48px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.08);
      border-radius: 8px;
    }
    .kop-surat {
      display: flex;
      align-items: center;
      gap: 16px;
      border-bottom: 3px double #000;
      padding-bottom: 12px;
      margin-bottom: 20px;
    }
    .kop-logo {
      width: 72px;
      height: 72px;
      object-fit: contain;
    }
    .kop-text {
      flex: 1;
      text-align: center;
    }
    .kop-text h4 {
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .kop-text h2 {
      font-size: 17px;
      font-weight: 800;
      text-transform: uppercase;
      margin: 2px 0;
    }
    .kop-text p {
      font-size: 10px;
      color: #334155;
    }
    .doc-header {
      text-align: center;
      margin-bottom: 18px;
    }
    .doc-title {
      font-size: 15px;
      font-weight: 800;
      text-decoration: underline;
      text-transform: uppercase;
    }
    .doc-subtitle {
      font-size: 11px;
      color: #475569;
      margin-top: 4px;
      font-weight: 600;
    }
    .doc-regulation {
      display: inline-block;
      margin-top: 6px;
      background: #ecfdf5;
      color: #065f46;
      border: 1px solid #a7f3d0;
      padding: 3px 10px;
      border-radius: 9999px;
      font-size: 10px;
      font-weight: bold;
    }
    .meta-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 18px;
      font-size: 11px;
      border: 1px solid #94a3b8;
    }
    .meta-table td {
      padding: 6px 10px;
      border: 1px solid #cbd5e1;
    }
    .meta-label {
      font-weight: bold;
      width: 150px;
      background: #f8fafc;
    }
    .section {
      margin-bottom: 18px;
    }
    .section-title {
      font-size: 12px;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 6px;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 3px;
    }
    .info-box {
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 8px 12px;
      font-size: 11px;
      margin-bottom: 10px;
      color: #334155;
    }
    .paragraph-box {
      background: #fafafa;
      border: 1px solid #e5e5e5;
      padding: 10px 14px;
      border-radius: 6px;
      text-align: justify;
      font-size: 11px;
      line-height: 1.6;
    }
    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 11px;
      border: 1px solid #000;
      margin-top: 6px;
    }
    .data-table th, .data-table td {
      border: 1px solid #000;
      padding: 6px 8px;
      vertical-align: top;
    }
    .data-table th {
      background: #f1f5f9;
      font-weight: bold;
    }
    .kktp-card {
      border: 1px solid #000;
      border-radius: 6px;
      padding: 10px 12px;
      margin-bottom: 12px;
    }
    .signature-container {
      margin-top: 36px;
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      page-break-inside: avoid;
    }
    .signature-block {
      text-align: center;
      width: 250px;
    }
    .signature-space {
      height: 75px;
    }
    .signature-name {
      font-weight: bold;
      text-decoration: underline;
      text-transform: uppercase;
    }
    @media print {
      body {
        background: #fff;
        padding: 0;
      }
      .no-print, .top-toolbar {
        display: none !important;
      }
      .paper-container {
        box-shadow: none;
        margin: 0;
        padding: 0;
        max-width: 100%;
        border-radius: 0;
      }
    }
  </style>
</head>
<body>
  <div class="top-toolbar no-print">
    <div class="title-info">
      <span>📄 Pratinjau Resmi: ${doc.title}</span>
    </div>
    <div style="display: flex; gap: 8px;">
      <button class="btn-print" onclick="window.print()">🖨️ Cetak ke Printer / Simpan PDF</button>
      <button class="btn-close" onclick="window.close()">✕ Tutup Tab</button>
    </div>
  </div>

  <div class="paper-container">
    <!-- KOP RESMI -->
    <div class="kop-surat">
      <img src="${logoUrl}" alt="Logo" class="kop-logo" onerror="this.style.display='none'">
      <div class="kop-text">
        <h4>PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN</h4>
        <h2>${schoolName}</h2>
        <p>${schoolAddress}</p>
        <p style="font-family: monospace; font-size: 9px; margin-top: 2px;">
          Mata Pelajaran: Pendidikan Agama Islam &amp; Budi Pekerti &bull; Tahun Pelajaran: ${academicYear}
        </p>
      </div>
    </div>

    <!-- DOKUMEN JUDUL -->
    <div class="doc-header">
      <h3 class="doc-title">${doc.title}</h3>
      <p class="doc-subtitle">Tingkat Kelas: ${doc.classGrade} (${doc.meta.fase}) &bull; Semester: ${doc.semester} &bull; Elemen: ${doc.meta.elementDomain}</p>
      <div class="doc-regulation">
        ⚖️ Regulasi Acuan: ${REGULASI_RESMI_BKPDM}
      </div>
    </div>

    <!-- TABEL IDENTITAS -->
    <table class="meta-table">
      <tbody>
        <tr>
          <td class="meta-label">Satuan Pendidikan</td>
          <td>${schoolName}</td>
          <td class="meta-label">Fase / Kelas</td>
          <td>${doc.meta.fase} / Kelas ${doc.classGrade}</td>
        </tr>
        <tr>
          <td class="meta-label">Mata Pelajaran</td>
          <td>Pendidikan Agama Islam &amp; Budi Pekerti</td>
          <td class="meta-label">Tahun Pelajaran</td>
          <td>${academicYear}</td>
        </tr>
        <tr>
          <td class="meta-label">Dasar Kebijakan</td>
          <td colspan="3">${REGULASI_RESMI_BKPDM}</td>
        </tr>
      </tbody>
    </table>

    <!-- ISI DOKUMEN -->
    ${bodyContentHtml}

    <!-- DUAL SIGNATURE BLOCK -->
    <div class="signature-container">
      <div class="signature-block">
        <p>Mengetahui,</p>
        <p><b>Kepala Sekolah</b></p>
        <div class="signature-space"></div>
        <p class="signature-name">${principalName}</p>
        <p>NIP. ${principalNip}</p>
      </div>

      <div class="signature-block">
        <p>Bekasi, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
        <p><b>Guru PAI &amp; Budi Pekerti</b></p>
        <div class="signature-space"></div>
        <p class="signature-name">${teacherName}</p>
        <p>NIP. ${teacherNip}</p>
      </div>
    </div>
  </div>
</body>
</html>`;

  return html;
};

export const openDocumentInNewTab = (
  doc: TeachingDocument,
  appSettings: AppSettings,
  teacherProfile: TeacherProfile
): boolean => {
  try {
    const newWin = window.open('', '_blank');
    if (!newWin) {
      return false;
    }
    const html = generateDocumentPrintHtml(doc, appSettings, teacherProfile);
    newWin.document.open();
    newWin.document.write(html);
    newWin.document.close();
    return true;
  } catch (err) {
    console.warn('Failed to open document in new tab:', err);
    return false;
  }
};

export const openJournalPrintInNewTab = (
  journals: Array<{
    id: string;
    date: string;
    className: string;
    topic: string;
    learningObjective: string;
    reflection: string;
    absentStudents: string[];
    status: string;
  }>,
  appSettings: AppSettings,
  teacherProfile: TeacherProfile,
  formatDateFn: (d: string) => string
): boolean => {
  try {
    const newWin = window.open('', '_blank');
    if (!newWin) return false;

    const schoolName = appSettings.schoolName || teacherProfile.schoolName || 'SDN CIKETING UDIK 2 BANTARGEBANG';
    const schoolAddress = appSettings.schoolAddress || 'Jl. Raya Ciketing Udik No. 2, Kec. Bantargebang, Kota Bekasi';
    const logoUrl = appSettings.appLogoUrl || 'https://jhlryjdhotxtndavacpd.supabase.co/storage/v1/object/public/logo/logo.png';
    const principalName = appSettings.principalName || 'Hj. Siti Aminah, M.Pd';
    const principalNip = appSettings.principalNip || '197608201999032001';
    const teacherName = teacherProfile.fullName || 'H. Ahmad Syarif, S.Pd.I';
    const teacherNip = teacherProfile.nip || '198503152010011002';
    const academicYear = appSettings.academicYear || '2026/2027';

    const html = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Jurnal Mengajar PAI - ${schoolName}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Plus Jakarta Sans', Arial, sans-serif; background: #f1f5f9; color: #0f172a; font-size: 12px; padding-bottom: 40px; }
    .top-toolbar { position: sticky; top: 0; z-index: 100; background: #0f172a; color: #fff; padding: 12px 20px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 4px 16px rgba(0,0,0,0.2); }
    .top-toolbar button { padding: 8px 16px; border-radius: 8px; font-size: 12px; font-weight: bold; cursor: pointer; border: none; }
    .btn-print { background: #10b981; color: #fff; }
    .btn-close { background: rgba(255,255,255,0.15); color: #fff; }
    .paper { max-width: 960px; margin: 24px auto; background: #fff; padding: 36px 44px; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); }
    .kop { display: flex; align-items: center; gap: 16px; border-bottom: 3px double #000; padding-bottom: 12px; margin-bottom: 16px; }
    .kop img { width: 68px; height: 68px; object-fit: contain; }
    .kop-text { flex: 1; text-align: center; }
    .kop-text h4 { font-size: 12px; text-transform: uppercase; }
    .kop-text h2 { font-size: 17px; font-weight: 800; text-transform: uppercase; margin: 2px 0; }
    .kop-text p { font-size: 10px; color: #334155; }
    table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 11px; }
    th, td { border: 1px solid #000; padding: 6px 8px; vertical-align: top; }
    th { background: #f1f5f9; font-weight: bold; }
    .sig { margin-top: 32px; display: flex; justify-content: space-between; font-size: 11px; page-break-inside: avoid; }
    .sig-box { text-align: center; width: 240px; }
    @media print {
      body { background: #fff; padding: 0; }
      .top-toolbar { display: none !important; }
      .paper { box-shadow: none; margin: 0; padding: 0; max-width: 100%; }
    }
  </style>
</head>
<body>
  <div class="top-toolbar">
    <div><b>📄 Pratinjau Cetak Jurnal Mengajar PAI (${journals.length} Catatan)</b> &bull; Regulasi: Keputusan Kepala BKPDM No. 020 Tahun 2026 (KBC)</div>
    <div style="display:flex;gap:8px;">
      <button class="btn-print" onclick="window.print()">🖨️ Cetak ke Printer / Simpan PDF</button>
      <button class="btn-close" onclick="window.close()">✕ Tutup Tab</button>
    </div>
  </div>
  <div class="paper">
    <div class="kop">
      <img src="${logoUrl}" alt="Logo" onerror="this.style.display='none'">
      <div class="kop-text">
        <h4>PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN</h4>
        <h2>${schoolName}</h2>
        <p>${schoolAddress}</p>
        <p style="margin-top:3px;font-weight:bold;">JURNAL PELAKSANAAN PEMBELAJARAN PAI &amp; BUDI PEKERTI (KURIKULUM BERBASIS CINTA)</p>
      </div>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:10px;">
      <div>
        <p><b>Nama Pendidik:</b> ${teacherName}</p>
        <p><b>NIP:</b> ${teacherNip}</p>
      </div>
      <div style="text-align:right;">
        <p><b>Tahun Pelajaran:</b> ${academicYear}</p>
        <p><b>Pedoman CP/ATP:</b> Kep. Kepala BKPDM No. 020 Th 2026 (KBC)</p>
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th style="width:32px;text-align:center;">No</th>
          <th style="width:120px;">Hari/Tanggal</th>
          <th style="width:65px;text-align:center;">Kelas</th>
          <th style="width:160px;">Materi Pokok</th>
          <th>Tujuan Pembelajaran</th>
          <th>Refleksi Guru (KBC)</th>
          <th style="width:100px;">Ketidakhadiran</th>
          <th style="width:65px;text-align:center;">Status</th>
        </tr>
      </thead>
      <tbody>
        ${journals.map((j, idx) => `
          <tr>
            <td style="text-align:center;">${idx + 1}</td>
            <td>${formatDateFn(j.date)}</td>
            <td style="text-align:center;font-weight:bold;">Kelas ${j.className}</td>
            <td><b>${j.topic}</b></td>
            <td>${j.learningObjective}</td>
            <td>${j.reflection}</td>
            <td>${j.absentStudents.length ? j.absentStudents.join(', ') : 'Nihil'}</td>
            <td style="text-align:center;font-weight:bold;">${j.status}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
    <div class="sig">
      <div class="sig-box">
        <p>Mengetahui,</p>
        <p><b>Kepala Sekolah</b></p>
        <div style="height:68px;"></div>
        <p style="font-weight:bold;text-decoration:underline;text-transform:uppercase;">${principalName}</p>
        <p>NIP. ${principalNip}</p>
      </div>
      <div class="sig-box">
        <p>Bekasi, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
        <p><b>Guru PAI &amp; Budi Pekerti</b></p>
        <div style="height:68px;"></div>
        <p style="font-weight:bold;text-decoration:underline;text-transform:uppercase;">${teacherName}</p>
        <p>NIP. ${teacherNip}</p>
      </div>
    </div>
  </div>
</body>
</html>`;

    newWin.document.open();
    newWin.document.write(html);
    newWin.document.close();
    return true;
  } catch (err) {
    console.warn('Failed to open journal print in new tab:', err);
    return false;
  }
};

