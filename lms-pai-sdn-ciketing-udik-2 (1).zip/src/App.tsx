import React, { useState, useEffect } from 'react';
import { UserSession } from './types';
import { StorageService } from './services/storageService';
import { ToastContainer, ToastMessage } from './components/Toast';
import { LoginView } from './components/LoginView';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';

// Admin Components
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ClassesView } from './components/admin/ClassesView';
import { StudentsView } from './components/admin/StudentsView';
import { AttendanceView } from './components/admin/AttendanceView';
import { TeachingJournalsView } from './components/admin/TeachingJournalsView';
import { QuestionsBankView } from './components/admin/QuestionsBankView';
import { CreateQuestionsView } from './components/admin/CreateQuestionsView';
import { QuizzesAdminView } from './components/admin/QuizzesAdminView';
import { MaterialsAdminView } from './components/admin/MaterialsAdminView';
import { ReferencesAdminView } from './components/admin/ReferencesAdminView';
import { AnnouncementsView } from './components/admin/AnnouncementsView';
import { ReportsView } from './components/admin/ReportsView';
import { ProfileAndSettingsView } from './components/admin/ProfileAndSettingsView';
import { CurriculumPerClassView } from './components/admin/CurriculumPerClassView';
import { EKinerjaHarianView } from './components/admin/EKinerjaHarianView';

// Common & Student Components
import { DiscussionForumView } from './components/common/DiscussionForumView';
import { StudentDashboard } from './components/student/StudentDashboard';
import { StudentQuizzes } from './components/student/StudentQuizzes';
import { StudentMaterials } from './components/student/StudentMaterials';
import { StudentReferences } from './components/student/StudentReferences';
import { StudentAnnouncements } from './components/student/StudentAnnouncements';
import { StudentScores } from './components/student/StudentScores';

export default function App() {
  const [session, setSession] = useState<UserSession | null>(StorageService.getSession());
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [cloudSyncRevision, setCloudSyncRevision] = useState(0);

  // Toast handler
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const newToast: ToastMessage = {
      id: Math.random().toString(36).substring(2, 9),
      type,
      message
    };
    setToasts(prev => [...prev, newToast]);
  };

  // Automatic Offline-First IndexedDB cache & Supabase cloud sync engine
  useEffect(() => {
    const cleanup = StorageService.initOfflineSyncEngine(showToast);
    return cleanup;
  }, []);

  // Re-render mounted views when cloud data is pulled or synced across browsers/devices
  useEffect(() => {
    const handleCloudSynced = () => {
      setCloudSyncRevision(prev => prev + 1);
      setSession(prevSession => {
        if (!prevSession) return prevSession;
        if (prevSession.role === 'admin') {
          const prof = StorageService.getTeacherProfile();
          return { ...prevSession, fullName: prof.fullName };
        }
        return prevSession;
      });
    };
    window.addEventListener('lms-cloud-synced', handleCloudSynced);
    return () => window.removeEventListener('lms-cloud-synced', handleCloudSynced);
  }, []);

  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleLogout = () => {
    StorageService.clearSession();
    setSession(null);
    setCurrentView('dashboard');
    showToast('Anda telah keluar dari aplikasi', 'info');
  };

  const handleLoginSuccess = (userSession: UserSession) => {
    setSession(userSession);
    setCurrentView('dashboard');
  };

  // Dynamic header titles based on view and role
  const getHeaderInfo = () => {
    if (session?.role === 'admin') {
      switch (currentView) {
        case 'dashboard':
          return {
            title: 'Dashboard Utama & Analitik',
            subtitle: 'Analitik Performa Kelas (Supabase), Kalender Akademik, & Ringkasan PAI KBC'
          };
        case 'profile':
          return { title: 'Profil Guru PAI', subtitle: 'Identitas pendidik dan satuan pendidikan' };
        case 'e-kinerja':
          return {
            title: 'E-Kinerja Harian Pegawai / Guru PAI',
            subtitle: 'Identitas otomatis, periode bulan & tahun terpisah, RKH, Rencana Aksi, Tindak Lanjut, dan dokumentasi multi-foto'
          };
        case 'settings':
          return {
            title: 'Pengaturan, Cloud Supabase & Build .EXE',
            subtitle: 'Pengesahan Kepala Sekolah, Kredensial Supabase, dan Paket Desktop Windows'
          };
        case 'classes':
          return { title: 'Daftar Kelas (Rombel)', subtitle: 'Kelola rombongan belajar dan wali kelas' };
        case 'curriculum':
          return {
            title: 'Daftar Materi Pokok Per Kelas',
            subtitle: 'Manajemen silabus, alur capaian pembelajaran (ATP), dan program semester per kelas'
          };
        case 'discussion-forum':
          return {
            title: 'Forum Diskusi PAI Per Kelas',
            subtitle: 'Ruang tanya jawab materi PAI siswa dengan verifikasi dan moderasi Guru PAI'
          };
        case 'students':
          return { title: 'Data Siswa & Akun Login', subtitle: 'Manajemen siswa, import Excel, dan cetak kartu login' };
        case 'attendance':
          return { title: 'Presensi / Absensi Siswa', subtitle: 'Pencatatan kehadiran harian dan rekapitulasi bulanan' };
        case 'journals':
          return {
            title: 'Jurnal Mengajar Guru PAI (AI & Focus Reader)',
            subtitle: 'Catatan pelaksanaan belajar, refleksi AI, Focus Reader, dan cetak dokumen di tab baru'
          };
        case 'create-questions':
          return {
            title: 'Buat Soal & Generator AI',
            subtitle: 'Rumuskan butir soal model TKA ber-stimulus kontekstual, cetak kisi-kisi, dan opsi kirim ke siswa'
          };
        case 'questions':
          return {
            title: 'Bank Soal PAI & Budi Pekerti',
            subtitle: 'Repositori butir soal tersimpan, filter per kelas, dan cetak naskah resmi'
          };
        case 'quizzes':
          return { title: 'Manajemen Penilaian & Kuis', subtitle: 'Penerbitan kuis, timer pengerjaan, dan pemantauan nilai' };
        case 'materials':
          return {
            title: 'Bahan Pembelajaran PAI (Focus Reader)',
            subtitle: 'Ringkasan materi teks, ayat Al-Qur\'an, video modul, dan layar penuh Focus Reader'
          };
        case 'references':
          return { title: 'Referensi Baca & Juz Amma', subtitle: 'Perpustakaan digital surah pendek, doa, dan kisah Nabi' };
        case 'announcements':
          return { title: 'Papan Pengumuman Sekolah', subtitle: 'Siaran pengumuman ke seluruh siswa atau rombel terpilih' };
        case 'reports':
          return { title: 'Rekapitulasi Nilai Asesmen', subtitle: 'Matriks nilai siswa, export Excel, dan cetak raport PAI resmi' };
        default:
          return { title: 'LMS PAI SDN Ciketing Udik 2', subtitle: 'Sistem Pembelajaran Terpadu' };
      }
    } else {
      switch (currentView) {
        case 'dashboard':
          return {
            title: 'Beranda Siswa',
            subtitle: 'Ringkasan Tugas/Kuis, Forum Diskusi, dan Pengumuman Kelas'
          };
        case 'student-quizzes':
          return { title: 'Tugas & Kuis PAI', subtitle: 'Uji pemahaman materi pembelajaran PAI secara mandiri' };
        case 'student-materials':
          return {
            title: 'Baca Materi Pelajaran (Focus Reader)',
            subtitle: 'Pelajari rangkuman materi dalam mode layar penuh tanpa gangguan'
          };
        case 'student-references':
          return {
            title: 'Juz Amma & Doa Harian (Focus Reader)',
            subtitle: 'Tadarus ayat suci Al-Qur\'an dan doa sehari-hari anak shalih'
          };
        case 'student-forum':
          return {
            title: 'Forum Diskusi Kelas PAI',
            subtitle: 'Bertanya dan berdiskusi santun seputar materi PAI bersama teman dan Guru PAI'
          };
        case 'student-announcements':
          return { title: 'Pengumuman Guru PAI', subtitle: 'Pemberitahuan resmi seputar pembelajaran dan tugas' };
        case 'student-scores':
          return { title: 'Buku Nilai Siswa', subtitle: 'Catatan hasil pengerjaan kuis dan evaluasi belajar' };
        default:
          return { title: 'LMS PAI SDN Ciketing Udik 2', subtitle: 'Portal Siswa' };
      }
    }
  };

  const headerInfo = getHeaderInfo();

  if (!session) {
    return (
      <>
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
        <LoginView key={cloudSyncRevision} onLoginSuccess={handleLoginSuccess} showToast={showToast} />
      </>
    );
  }

  return (
    <div className="flex h-[100dvh] overflow-hidden w-full relative bg-slate-950 text-slate-100">
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Main Sidebar */}
      <Sidebar
        session={session}
        currentView={currentView}
        onNavigate={view => setCurrentView(view)}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onLogout={handleLogout}
      />

      {/* Main App Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-[100dvh] overflow-hidden">
        <Header
          session={session}
          title={headerInfo.title}
          subtitle={headerInfo.subtitle}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          showToast={showToast}
        />

        <main key={cloudSyncRevision} className="flex-1 overflow-y-auto p-4 sm:p-6 w-full scrollbar-thin">
          {session.role === 'admin' ? (
            <>
              {currentView === 'dashboard' && (
                <AdminDashboard
                  onNavigate={view => setCurrentView(view)}
                  showToast={showToast}
                />
              )}
              {currentView === 'profile' && (
                <ProfileAndSettingsView
                  mode="profile"
                  showToast={showToast}
                  onProfileUpdated={newName => {
                    setSession({ ...session, fullName: newName });
                  }}
                />
              )}
              {currentView === 'e-kinerja' && (
                <EKinerjaHarianView
                  showToast={showToast}
                  onProfileUpdated={newName => {
                    setSession({ ...session, fullName: newName });
                  }}
                />
              )}
              {currentView === 'settings' && (
                <ProfileAndSettingsView mode="settings" showToast={showToast} />
              )}
              {currentView === 'classes' && <ClassesView showToast={showToast} />}
              {currentView === 'curriculum' && <CurriculumPerClassView showToast={showToast} />}
              {currentView === 'discussion-forum' && (
                <DiscussionForumView session={session} showToast={showToast} />
              )}
              {currentView === 'students' && <StudentsView showToast={showToast} />}
              {currentView === 'attendance' && <AttendanceView showToast={showToast} />}
              {currentView === 'journals' && <TeachingJournalsView showToast={showToast} />}
              {currentView === 'create-questions' && (
                <CreateQuestionsView
                  showToast={showToast}
                  onNavigateToBank={() => setCurrentView('questions')}
                  onNavigateToQuizzes={() => setCurrentView('quizzes')}
                />
              )}
              {currentView === 'questions' && (
                <QuestionsBankView
                  showToast={showToast}
                  onNavigateToCreate={() => setCurrentView('create-questions')}
                />
              )}
              {currentView === 'quizzes' && <QuizzesAdminView showToast={showToast} />}
              {currentView === 'materials' && <MaterialsAdminView showToast={showToast} />}
              {currentView === 'references' && <ReferencesAdminView showToast={showToast} />}
              {currentView === 'announcements' && <AnnouncementsView showToast={showToast} />}
              {currentView === 'reports' && <ReportsView showToast={showToast} />}
            </>
          ) : (
            <>
              {currentView === 'dashboard' && (
                <StudentDashboard session={session} onNavigate={view => setCurrentView(view)} />
              )}
              {currentView === 'student-quizzes' && (
                <StudentQuizzes session={session} showToast={showToast} />
              )}
              {currentView === 'student-materials' && (
                <StudentMaterials session={session} showToast={showToast} />
              )}
              {currentView === 'student-references' && (
                <StudentReferences session={session} showToast={showToast} />
              )}
              {currentView === 'student-forum' && (
                <DiscussionForumView session={session} showToast={showToast} />
              )}
              {currentView === 'student-announcements' && (
                <StudentAnnouncements session={session} />
              )}
              {currentView === 'student-scores' && (
                <StudentScores session={session} />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
