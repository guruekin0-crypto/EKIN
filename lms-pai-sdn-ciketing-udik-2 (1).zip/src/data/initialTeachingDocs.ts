import { TeachingDocument } from '../types';

export const INITIAL_TEACHING_DOCS: TeachingDocument[] = [
  // 1. CP/ATP KELAS 5 (Fase C)
  {
    id: 'doc-cp-atp-5',
    docType: 'cp_atp',
    classGrade: '5',
    semester: 'Tahunan',
    academicYear: '2026/2027',
    title: 'CAPAIAN PEMBELAJARAN & ALUR TUJUAN PEMBELAJARAN (ATP) PAI KELAS 5',
    summary: 'Alur Tujuan Pembelajaran Fase C Kelas 5 PAI & Budi Pekerti berlandaskan Kurikulum Merdeka dan Pendekatan KBC.',
    schoolName: 'SDN Ciketing Udik 2 Bantargebang',
    teacherName: 'H. Ahmad Syarif, S.Pd.I',
    teacherNip: '198503152010011002',
    principalName: 'Hj. Siti Aminah, M.Pd',
    principalNip: '197608201999032001',
    regulasi: 'Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026 dengan pendekatan KBC',
    meta: {
      fase: 'Fase C',
      elementDomain: "Al-Qur'an Hadis & Akhlak Mulia",
      alokasiWaktuJP: 108,
      targetBab: "Surah Al-Ma'un, Asmaul Husna, Adab Bergaul, dan Shalat Berjamaah",
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)',
      regulasi: 'Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026'
    },
    contentData: {
      capaianPembelajaran: "Pada akhir Fase C (Kelas 5-6), peserta didik mampu membaca, menghafal, dan memahami hukum tajwid serta pesan pokok surah-surah pendek Al-Qur'an (Al-Ma'un, At-Tin, dsb), meyakini nama-nama indah Allah (Asmaul Husna) dan Hari Akhir dengan penuh cinta dan harap, meneladani akhlak mulia Rasulullah SAW dan para sahabat, membiasakan adab terpuji dalam pergaulan sehari-hari di lingkungan SDN Ciketing Udik 2, serta melaksanakan ibadah shalat dan thaharah dengan tertib dan khusyuk.",
      alurTujuanPembelajaran: [
        {
          no: 1,
          tujuan: "Membaca Surah Al-Ma'un dengan tartil sesuai kaidah tajwid serta menghafalnya dengan lancar.",
          materi: "Surah Al-Ma'un & Kepedulian Sosial",
          elemen: "Al-Qur'an & Hadis",
          alokasiJP: 12,
          profilPancasilaKBC: "Beriman, Bertakwa, & Kasih Sayang Kepada Sesama (Mahabbah)",
          indikator: "Mampu melafalkan ayat 1-7 dengan fasih, menyimak bacaan teman secara santun, dan mencontohkan perilaku peduli anak yatim."
        },
        {
          no: 2,
          tujuan: "Memahami makna Asmaul Husna: Al-Qawiyyu, Al-Qayyum, Al-Muhyi, Al-Mumit, dan Al-Ba'its.",
          materi: "Mengenal Asmaul Husna Kasih Sayang",
          elemen: "Akidah",
          alokasiJP: 12,
          profilPancasilaKBC: "Mandiri, Rendah Hati, & Percaya Diri",
          indikator: "Menjelaskan arti kelima Asmaul Husna dan merefleksikannya dalam menjaga kehidupan yang harmonis."
        },
        {
          no: 3,
          tujuan: "Menunjukkan sikap saling menghormati dan menghargai perbedaan antar kawan tanpa perundungan (bullying).",
          materi: "Indahnya Keragaman dan Persaudaraan Insani",
          elemen: "Akhlak",
          alokasiJP: 12,
          profilPancasilaKBC: "Berkebinekaan Global & Toleransi (Tasamuh)",
          indikator: "Mampu berkolaborasi aktif dalam kelompok majemuk dan bertutur kata sejuk menenangkan."
        },
        {
          no: 4,
          tujuan: "Mempraktikkan ketentuan shalat berjamaah, shalat tarawih, dan shalat witir dengan tertib.",
          materi: "Ibadah Shalat Mempererat Tali Cinta",
          elemen: "Fikih",
          alokasiJP: 12,
          profilPancasilaKBC: "Gotong Royong & Disiplin Diri",
          indikator: "Memperagakan posisi imam dan makmum, adab di musholla sekolah, serta ketepatan bacaan shalat."
        },
        {
          no: 5,
          tujuan: "Meneladani ketabahan Nabi Muhammad SAW dan para sahabat pada peristiwa hijrah ke Madinah.",
          materi: "Kisah Teladan Hijrah Rasulullah SAW",
          elemen: "Sejarah Peradaban Islam",
          alokasiJP: 10,
          profilPancasilaKBC: "Bernalar Kritis & Tangguh Menghadapi Cobaan",
          indikator: "Menceritakan kembali strategi hijrah dan sikap persaudaraan antara kaum Muhajirin dan Anshar."
        }
      ]
    },
    createdAt: '2026-07-15T08:00:00Z',
    updatedAt: '2026-07-15T08:00:00Z'
  },

  // 2. PROTA KELAS 5
  {
    id: 'doc-prota-5',
    docType: 'prota',
    classGrade: '5',
    semester: 'Tahunan',
    academicYear: '2026/2027',
    title: 'PROGRAM TAHUNAN (PROTA) KURIKULUM MERDEKA PAI KELAS 5 SD',
    summary: 'Distribusi alokasi waktu satu tahun ajaran (108 JP) untuk Semester Ganjil dan Genap di SDN Ciketing Udik 2 Bantargebang.',
    schoolName: 'SDN Ciketing Udik 2 Bantargebang',
    teacherName: 'H. Ahmad Syarif, S.Pd.I',
    teacherNip: '198503152010011002',
    principalName: 'Hj. Siti Aminah, M.Pd',
    principalNip: '197608201999032001',
    regulasi: 'Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026 dengan pendekatan KBC',
    meta: {
      fase: 'Fase C',
      elementDomain: 'Semua Elemen (Al-Qur\'an Hadis, Akidah, Akhlak, Fikih, SPI)',
      alokasiWaktuJP: 108,
      targetBab: 'Bab 1 s/d Bab 10 PAI Kelas 5',
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)',
      regulasi: 'Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026'
    },
    contentData: {
      protaItems: [
        {
          no: 1,
          semester: 'Ganjil',
          elemen: "Al-Qur'an & Hadis",
          materiPokok: "Bab 1: Menyayangi Anak Yatim (Surah Al-Ma'un)",
          tujuanPembelajaran: "Membaca, menghafal, dan mengamalkan pesan Surah Al-Ma'un untuk menyayangi anak yatim dan fakir miskin.",
          alokasiJP: 12,
          keterangan: 'Tuntas Sumatif 1'
        },
        {
          no: 2,
          semester: 'Ganjil',
          elemen: 'Akidah',
          materiPokok: 'Bab 2: Lebih Dekat dengan Nama-Nama Allah (Asmaul Husna)',
          tujuanPembelajaran: 'Meneladani sifat Al-Qawiyyu, Al-Qayyum, Al-Muhyi, Al-Mumit, dan Al-Ba\'its dalam perbuatan terpuji.',
          alokasiJP: 12,
          keterangan: 'Tuntas Sumatif 2'
        },
        {
          no: 3,
          semester: 'Ganjil',
          elemen: 'Akhlak',
          materiPokok: 'Bab 3: Aku Anak Shalih: Menghargai Keragaman sebagai Sunnatullah',
          tujuanPembelajaran: 'Menunjukkan sikap saling menghormati antarsesama pemeluk agama dan suku bangsa.',
          alokasiJP: 12,
          keterangan: 'Tuntas Sumatif 3'
        },
        {
          no: 4,
          semester: 'Ganjil',
          elemen: 'Fikih',
          materiPokok: 'Bab 4: Hidup Lapang dengan Berbagi (Zakat, Infak, Sedekah)',
          tujuanPembelajaran: 'Mempraktikkan adab memberi infak dengan tangan di atas penuh keikhlasan.',
          alokasiJP: 10,
          keterangan: 'Praktik Kotak Infaq KBC'
        },
        {
          no: 5,
          semester: 'Ganjil',
          elemen: 'Sejarah Peradaban Islam',
          materiPokok: 'Bab 5: Meneladani Perjuangan Rasulullah SAW Membangun Madinah',
          tujuanPembelajaran: 'Meneladani piagam Madinah sebagai teladan hidup berdampingan secara damai.',
          alokasiJP: 8,
          keterangan: 'Asesmen Akhir Semester Ganjil'
        },
        {
          no: 6,
          semester: 'Genap',
          elemen: "Al-Qur'an & Hadis",
          materiPokok: 'Bab 6: Hidup Damai dalam Kebersamaan (Surah Ali Imran: 64 & Hadis)',
          tujuanPembelajaran: 'Membaca dan meresapi pesan persaudaraan universal antar manusia.',
          alokasiJP: 12,
          keterangan: 'Tuntas Sumatif 4'
        },
        {
          no: 7,
          semester: 'Genap',
          elemen: 'Akidah',
          materiPokok: 'Bab 7: Ketika Kehidupan Telah Berhenti (Mengenal Hari Akhir)',
          tujuanPembelajaran: 'Meyakini adanya hari pembalasan dengan memperbanyak bekal amal kebajikan.',
          alokasiJP: 12,
          keterangan: 'Tuntas Sumatif 5'
        },
        {
          no: 8,
          semester: 'Genap',
          elemen: 'Akhlak',
          materiPokok: 'Bab 8: Senangnya Berteman Tanpa Membeda-bedakan',
          tujuanPembelajaran: 'Mencegah perundungan dan menyebarkan salam serta cinta di lingkungan sekolah.',
          alokasiJP: 10,
          keterangan: 'Projek Kebaikan KBC'
        },
        {
          no: 9,
          semester: 'Genap',
          elemen: 'Fikih',
          materiPokok: 'Bab 9: Ibadah Haji dan Kurban yang Menggetarkan Jiwa',
          tujuanPembelajaran: 'Mengenal manasik haji anak dan nilai pengorbanan Nabi Ibrahim AS.',
          alokasiJP: 12,
          keterangan: 'Praktik Mini Manasik'
        },
        {
          no: 10,
          semester: 'Genap',
          elemen: 'Sejarah Peradaban Islam',
          materiPokok: 'Bab 10: Keteladanan Sahabat Khulafaur Rasyidin',
          tujuanPembelajaran: 'Mencontoh ketegasan Umar, kedermawanan Utsman, dan kecerdasan Ali bin Abi Thalib.',
          alokasiJP: 8,
          keterangan: 'Asesmen Kenaikan Kelas'
        }
      ],
      totalJPGanjil: 54,
      totalJPGenap: 54,
      totalJPTahunan: 108
    },
    createdAt: '2026-07-15T08:00:00Z',
    updatedAt: '2026-07-15T08:00:00Z'
  },

  // 3. PROMES KELAS 5 - SEMESTER GANJIL
  {
    id: 'doc-promes-5-ganjil',
    docType: 'promes',
    classGrade: '5',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    title: 'PROGRAM SEMESTER (PROMES) KURIKULUM MERDEKA PAI KELAS 5 - SEMESTER GANJIL',
    summary: 'Distribusi pekan efektif belajar Semester Ganjil PAI & Budi Pekerti (Juli s/d Desember 2026).',
    schoolName: 'SDN Ciketing Udik 2 Bantargebang',
    teacherName: 'H. Ahmad Syarif, S.Pd.I',
    teacherNip: '198503152010011002',
    principalName: 'Hj. Siti Aminah, M.Pd',
    principalNip: '197608201999032001',
    meta: {
      fase: 'Fase C',
      elementDomain: 'Semua Elemen Semester Ganjil',
      alokasiWaktuJP: 54,
      targetBab: 'Bab 1 - 5',
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)'
    },
    contentData: {
      promesItems: [
        {
          no: 1,
          materiPokok: "Bab 1: Menyayangi Anak Yatim (Surah Al-Ma'un)",
          tujuanPembelajaran: "Membaca dan menghafal Surah Al-Ma'un dengan tartil serta membiasakan sikap empati.",
          alokasiJP: 12,
          distribusiBulan: [
            { bulan: 'Juli', minggu: [0, 0, 4, 4] },
            { bulan: 'Agustus', minggu: [4, 0, 0, 0] }
          ]
        },
        {
          no: 2,
          materiPokok: 'Bab 2: Mengenal Asmaul Husna yang Penuh Kasih',
          tujuanPembelajaran: 'Menghayati Asmaul Husna Al-Qawiyyu, Al-Qayyum, Al-Muhyi, Al-Mumit, dan Al-Ba\'its.',
          alokasiJP: 12,
          distribusiBulan: [
            { bulan: 'Agustus', minggu: [0, 4, 4, 4] }
          ]
        },
        {
          no: 3,
          materiPokok: 'Bab 3: Menghargai Keragaman sebagai Anugerah Allah',
          tujuanPembelajaran: 'Membiasakan pergaulan santun tanpa memandang ras, agama, atau kemampuan ekonomi.',
          alokasiJP: 12,
          distribusiBulan: [
            { bulan: 'September', minggu: [4, 4, 4, 0] }
          ]
        },
        {
          no: 4,
          materiPokok: 'Bab 4: Hidup Lapang dengan Berbagi (Zakat & Infak)',
          tujuanPembelajaran: 'Melatih rasa syukur dan kepedulian sosial melalui pembiasaan infak sukarela.',
          alokasiJP: 10,
          distribusiBulan: [
            { bulan: 'Oktober', minggu: [4, 4, 2, 0] }
          ]
        },
        {
          no: 5,
          materiPokok: 'Bab 5: Meneladani Kepemimpinan Rasulullah SAW di Madinah',
          tujuanPembelajaran: 'Mencontoh keteladanan Rasulullah SAW dalam mempersaudarakan umat dan menjaga amanah.',
          alokasiJP: 8,
          distribusiBulan: [
            { bulan: 'November', minggu: [4, 4, 0, 0] }
          ]
        }
      ]
    },
    createdAt: '2026-07-15T08:00:00Z',
    updatedAt: '2026-07-15T08:00:00Z'
  },

  // 4. KKTP KELAS 5
  {
    id: 'doc-kktp-5',
    docType: 'kktp',
    classGrade: '5',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    title: 'KRITERIA KETERCAPAIAN TUJUAN PEMBELAJARAN (KKTP) PAI KELAS 5',
    summary: 'Rubrik ketercapaian tujuan pembelajaran berbasis deskripsi kriteria dan penanganan humanis (KBC).',
    schoolName: 'SDN Ciketing Udik 2 Bantargebang',
    teacherName: 'H. Ahmad Syarif, S.Pd.I',
    teacherNip: '198503152010011002',
    principalName: 'Hj. Siti Aminah, M.Pd',
    principalNip: '197608201999032001',
    meta: {
      fase: 'Fase C',
      elementDomain: "Al-Qur'an & Hadis, Akidah, Akhlak",
      alokasiWaktuJP: 36,
      targetBab: "Surah Al-Ma'un, Asmaul Husna, Akhlak Kasih Sayang",
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)'
    },
    contentData: {
      kktpItems: [
        {
          no: 1,
          tujuanPembelajaran: "Membaca Surah Al-Ma'un ayat 1-7 dengan tartil dan tajwid yang benar.",
          indikatorKetuntasan: "Kesesuaian makhraj huruf, kaidah hukum mad thabi'i, ghunnah, dan adab memegang mushaf.",
          kriteria: {
            perluBimbingan: "Belum lancar membaca, sering tertukar antara huruf 'ain dan hamzah (0 - 60).",
            cukup: "Dapat membaca sampai selesai namun masih ada 2-3 kesalahan harakat atau tajwid (61 - 75).",
            baik: "Membaca lancar, makhraj tepat, dan tajwid konsisten dengan suara jelas (76 - 88).",
            sangatBaik: "Sangat tartil, fasih sempurna, berirama tenang, dan menunjukkan penghayatan adab mulia (89 - 100)."
          },
          tindakLanjutKBC: "Pendampingan guru secara privat dengan penuh senyuman (Talaqqi Kasih Sayang) tanpa celaan."
        },
        {
          no: 2,
          tujuanPembelajaran: "Menjelaskan pesan moral menyayangi anak yatim dan bahaya riya' (pamer ibadah).",
          indikatorKetuntasan: "Ketepatan menjelaskan 2 larangan utama dalam surah dan mengaitkannya dengan kehidupan sekolah.",
          kriteria: {
            perluBimbingan: "Belum dapat mengaitkan isi surah dengan contoh perilaku di sekolah (0 - 60).",
            cukup: "Mampu menjelaskan makna namun baru dapat memberikan 1 contoh umum (61 - 75).",
            baik: "Mampu menjelaskan pesan surah secara runut dan memberikan contoh konkret di SDN Ciketing Udik 2 (76 - 88).",
            sangatBaik: "Mampu menganalisis bahaya sifat kikir, mengajak kawan berinfak, dan menjadi pelopor kebaikan (89 - 100)."
          },
          tindakLanjutKBC: "Ajak anak berdialog santai dan beri kesempatan memimpin aksi berbagi bekal dengan kawan."
        },
        {
          no: 3,
          tujuanPembelajaran: "Menunjukkan perilaku suka menolong teman dan tidak sombong di kelas.",
          indikatorKetuntasan: "Observasi harian sikap peduli, berkata sopan kepada guru, dan menghormati pendapat kawan.",
          kriteria: {
            perluBimbingan: "Sering mengejek kawan saat bermain dan enggan berbagi alat tulis (0 - 60).",
            cukup: "Mau berteman namun masih mudah terpancing emosi ketika berbeda pendapat (61 - 75).",
            baik: "Sikap ramah dan santun konsisten, sigap membantu kawan piket kebersihan kelas (76 - 88).",
            sangatBaik: "Menjadi teladan cinta kasih kelas (Sahabat Teladan), selalu menghibur kawan yang bersedih (89 - 100)."
          },
          tindakLanjutKBC: "Penghargaan 'Bintang Cinta & Budi Pekerti' serta pelukan hangat dari guru pengampu."
        }
      ]
    },
    createdAt: '2026-07-15T08:00:00Z',
    updatedAt: '2026-07-15T08:00:00Z'
  },

  // 5. MODUL AJAR KELAS 5 (RPP MERDEKA)
  {
    id: 'doc-modul-ajar-5',
    docType: 'modul_ajar',
    classGrade: '5',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    title: "MODUL AJAR KURIKULUM MERDEKA PAI KELAS 5: MENYAYANGI ANAK YATIM (SURAH AL-MA'UN)",
    summary: 'Modul ajar berdiferensiasi terpadu pendekatan KBC, model Problem Based Learning, dan asesmen holistik.',
    schoolName: 'SDN Ciketing Udik 2 Bantargebang',
    teacherName: 'H. Ahmad Syarif, S.Pd.I',
    teacherNip: '198503152010011002',
    principalName: 'Hj. Siti Aminah, M.Pd',
    principalNip: '197608201999032001',
    meta: {
      fase: 'Fase C',
      elementDomain: "Al-Qur'an & Hadis",
      alokasiWaktuJP: 12,
      targetBab: "Surah Al-Ma'un & Kepedulian Sosial",
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)'
    },
    contentData: {
      modulAjar: {
        identitas: {
          penyusun: 'H. Ahmad Syarif, S.Pd.I',
          instansi: 'SDN Ciketing Udik 2 Bantargebang',
          faseKelas: 'Fase C / Kelas 5',
          semester: 'Ganjil',
          materiPokok: "Menyayangi Anak Yatim & Surah Al-Ma'un",
          alokasiWaktu: '3 Pertemuan (3 x 4 JP = 12 JP @ 35 Menit)'
        },
        kompetensiAwal: "Peserta didik telah mampu melafalkan huruf hijaiyah bersambung dan mengenal kalimat thayyibah serta memiliki fitrah senang menolong sesama teman.",
        profilPelajarPancasilaKBC: [
          'Beriman, Bertakwa kepada Tuhan YME dan Berakhlak Mulia (Hubbullah & Mahabbaturrasul)',
          'Gotong Royong & Peduli Sesama (Ta\'awun & Kasih Sayang)',
          'Bernalar Kritis (Menemukan hikmah dari kisah teladan)',
          'Mandiri & Beradab Luhur'
        ],
        saranaPrasarana: [
          'Buku Teks Utama PAI & Budi Pekerti Kelas 5 Kemendikbudristek/Kemenag',
          'Mushaf Al-Qur\'an Standar Indonesia & Kartu Potongan Ayat Khat Naskh Berharakat',
          'LCD Proyektor & Video Animasi Menyayangi Anak Yatim',
          'LKPD Ceria Sahabat Kebaikan',
          'Kotak Infak Kebaikan Siswa'
        ],
        targetPesertaDidik: 'Peserta Didik Reguler Kelas 5 SDN Ciketing Udik 2 Bantargebang (Jumlah: 28 Siswa).',
        modelPembelajaran: 'Tatap Muka - Problem Based Learning (PBL) Berdiferensiasi Berbasis Cinta (KBC)',
        komponenInti: {
          tujuanPembelajaran: [
            "Membaca Surah Al-Ma'un dengan tartil sesuai makhraj dan kaidah tajwid.",
            "Menghafalkan Surah Al-Ma'un ayat 1-7 dengan lancar dan penuh ketenangan.",
            "Menganalisis makna kandungan Surah Al-Ma'un mengenai larangan menghardik anak yatim dan mendustakan agama.",
            "Membiasakan perilaku tolong-menolong (ta'awun) dan menyayangi kawan di lingkungan sekolah."
          ],
          pemahamanBermakna: "Cinta sejati kepada Allah SWT dan Rasul-Nya harus mewujud dalam tindakan nyata menyayangi sesama, melindungi mereka yang lemah, dan menjauhi sifat pamer (riya').",
          pertanyaanPemantik: [
            "Siapakah yang disebut sebagai pendusta agama menurut Al-Qur'an?",
            "Pernahkah kamu melihat kawanmu di sekolah tidak memiliki uang saku atau pensilnya hilang? Apa yang akan kamu lakukan?",
            "Mengapa Rasulullah SAW menjanjikan bahwa orang yang menyayangi anak yatim akan sedekat dua jari dengan beliau di surga?"
          ],
          kegiatanPembelajaran: {
            pendahuluan: [
              "Guru menyapa seluruh murid dengan salam ceria, tersenyum hangat, dan menanyakan perasaan hati mereka pagi ini.",
              "Berdoa bersama dipimpin oleh salah satu siswa secara bergantian untuk melatih rasa percaya diri.",
              "Tadarus bersama membaca Surah Al-Fatihah dan shalawat Nabi bernada lembut.",
              "Apersepsi: Guru bercerita singkat tentang kehangatan Rasulullah SAW saat merangkul seorang anak yatim di hari raya.",
              "Menyampaikan tujuan dan rencana kegiatan yang akan dilakukan dengan suasana menggembirakan."
            ],
            kegiatanInti: [
              "Pertemuan 1 (Membaca Tartil): Murid menyimak lafaz Surah Al-Ma'un yang diperdengarkan guru dengan khat Naskh berharakat di layar. Murid membaca bergantian (metode talaqqi) dengan bimbingan santun.",
              "Pertemuan 2 (Memahami Pesan & Diskusi): Murid berkelompok menelaah ayat demi ayat menggunakan LKPD. Masing-masing kelompok menemukan pesan moral tentang larangan menghardik anak yatim dan enggan memberi bantuan.",
              "Pertemuan 3 (Penerapan KBC & Unjuk Kerja): Setiap kelompok mempresentasikan komitmen kebaikan kalbu mereka di kelas dan mempraktikkan gerakan infak kasih sayang ke kotak amal peduli teman."
            ],
            penutup: [
              "Refleksi Kalbu: Murid diajak merenungkan satu hal baik yang telah mereka syukuri hari ini.",
              "Guru memberikan umpan balik konstruktif dengan kata-kata apresiasi yang menyejukkan hati.",
              "Menyimpulkan bersama pelajaran hari ini dan menutup dengan doa kafaratul majlis."
            ]
          },
          asesmen: {
            diagnostik: "Tanya jawab lisan pada awal materi untuk mengetahui kelancaran baca Al-Qur'an masing-masing murid.",
            formatif: "Lembar observasi keaktifan diskusi, penilaian unjuk kerja hafalan tartil (rubrik skala 1-4), dan ceklis sikap kasih sayang.",
            sumatif: "Tes pilihan ganda kontekstual model TKA (HOTS berbasis stimulus kehidupan nyata di SDN Ciketing Udik 2)."
          },
          pengayaanRemedial: "Remedial: Bimbingan talaqqi lembut bagi siswa yang makhrajnya belum tepat. Pengayaan: Menjadi tutor sebaya mendampingi hafalan teman sekelas.",
          refleksi: "Refleksi Guru: Apakah seluruh murid merasa dihargai dan gembira selama pembelajaran? Apa langkah perbaikan untuk pertemuan berikutnya?"
        },
        lampiran: {
          bahanBacaan: "Bahan Bacaan Siswa: Kisah Teladan Rasulullah SAW dan Keutamaan Sedekah; Terjemahan Kemenag RI Surah Al-Ma'un.",
          glosarium: "Al-Ma'un (Barang berguna), Yatima (Anak yatim), Miskin (Orang miskin), Sahun (Lalai dalam shalat), Yura'un (Riya'/pamer amal).",
          daftarPustaka: "Buku Siswa PAI & Budi Pekerti Kelas V Kemendikbudristek 2024; Mushaf Al-Qur'an Standar Indonesia Kemenag RI."
        }
      }
    },
    createdAt: '2026-07-15T08:00:00Z',
    updatedAt: '2026-07-15T08:00:00Z'
  },

  // 6. LKPD KELAS 5
  {
    id: 'doc-lkpd-5',
    docType: 'lkpd',
    classGrade: '5',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    title: "LEMBAR KERJA PESERTA DIDIK (LKPD) PAI KELAS 5: SURAH AL-MA'UN & KASIH SAYANG",
    summary: 'Lembar kerja aktif dan reflektif anak SD berbasis cerita kontekstual di SDN Ciketing Udik 2 Bantargebang.',
    schoolName: 'SDN Ciketing Udik 2 Bantargebang',
    teacherName: 'H. Ahmad Syarif, S.Pd.I',
    teacherNip: '198503152010011002',
    principalName: 'Hj. Siti Aminah, M.Pd',
    principalNip: '197608201999032001',
    meta: {
      fase: 'Fase C',
      elementDomain: "Al-Qur'an & Hadis",
      alokasiWaktuJP: 4,
      targetBab: "Surah Al-Ma'un",
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)'
    },
    contentData: {
      lkpd: {
        judulAktivitas: "Menebar Kasih Sayang Bersama Sahabat Sholih",
        temaNilaiKBC: "Cinta Kepada Anak Yatim, Tolong-Menolong (Ta'awun), dan Ikhlas Beribadah",
        petunjukBelajar: [
          'Tuliskan nama lengkap, kelas, dan nomor absenmu di bagian atas lembar kerja.',
          'Ucapkan Basmalah dengan penuh rasa cinta kepada Allah sebelum mulai mengerjakan.',
          'Bacalah kutipan ayat Al-Qur\'an dan stimulus cerita berikut ini dengan cermat.',
          'Diskusikan jawaban terbaik dengan kawan sebangkumu secara rukun dan saling menghargai.'
        ],
        stimulusCerita: "Saat jam istirahat pertama di SDN Ciketing Udik 2 Bantargebang, Ahmad dan kawan-kawannya bermain di selasar kelas. Ahmad melihat Rizky duduk menyendiri di bangku bawah pohon mangga dengan wajah pucat. Ternyata Rizky tidak membawa bekal dan uang sakunya hilang. Ahmad teringat pesan guru PAI tentang keutamaan Surah Al-Ma'un bahwa seorang muslim sejati tidak boleh membiarkan saudaranya kelaparan. Tanpa ragu, Ahmad membagi rotinya menjadi dua dan memberikan setengahnya kepada Rizky sambil tersenyum tulus.",
        arabicSnippet: {
          text: "أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ ۝ فَذَٰلِكَ الَّذِي يَدُعُّ الْيَتِيمَ ۝ وَلَا يَحُضُّ عَلَىٰ طَعَامِ الْمِسْكِينِ",
          arti: "Tahukah kamu orang yang mendustakan agama? Maka itulah orang yang menghardik anak yatim, dan tidak mendorong memberi makan orang miskin. (QS. Al-Ma'un: 1-3)"
        },
        langkahAktivitas: [
          '1. Bacalah ayat suci di atas bersama temanmu dengan tartil.',
          '2. Temukan 2 perbuatan tercela yang dilarang dalam ayat tersebut.',
          '3. Hubungkan perilaku Ahmad pada cerita di SDN Ciketing Udik 2 dengan ajaran Surah Al-Ma\'un.',
          '4. Tuliskan komitmen kebaikan hatimu pada lembar refleksi cinta di bawah.'
        ],
        tugasSiswa: [
          {
            nomor: 1,
            instruksi: "Berdasarkan Surah Al-Ma'un ayat 1-3 di atas, sebutkan dua golongan orang yang dinilai mendustakan agama!",
            tipe: 'isian'
          },
          {
            nomor: 2,
            instruksi: "Sikap terpuji yang ditunjukkan Ahmad kepada Rizky di SDN Ciketing Udik 2 mencerminkan nilai:",
            tipe: 'pilihan',
            opsi: [
              "Ta'awun (Tolong-menolong) dan kasih sayang sesama muslim",
              "Riya' (Ingin dipuji teman dan guru)",
              "Sombong karena memiliki makanan lebih banyak",
              "Terpaksa karena merasa kasihan"
            ]
          },
          {
            nomor: 3,
            instruksi: "Tuliskan 1 contoh perbuatan nyata yang dapat kamu lakukan untuk membahagiakan anak yatim atau teman yang sedang kesulitan di sekolah!",
            tipe: 'isian'
          }
        ],
        refleksiCinta: "Bagaimana perasaan hatimu setelah membaca kisah kebaikan Ahmad? Tuliskan satu doa tulusmu untuk kedua orang tuamu, bapak/ibu gurumu, dan kawan-kawanmu di sekolah!",
        rubrikNilai: "Ketepatan Menjawab (40%), Ketertiban & Kerapian (30%), Refleksi Kalbu & Sikap KBC (30%). Nilai Maksimal: 100."
      }
    },
    createdAt: '2026-07-15T08:00:00Z',
    updatedAt: '2026-07-15T08:00:00Z'
  },

  // 7. Modul Ajar Kelas 1 (Fase A)
  {
    id: 'doc-modul-ajar-1',
    docType: 'modul_ajar',
    classGrade: '1',
    semester: 'Ganjil',
    academicYear: '2026/2027',
    title: "MODUL AJAR KURIKULUM MERDEKA PAI KELAS 1: AKU CINTA AL-QUR'AN & SURAH AL-FATIHAH",
    summary: 'Modul ajar Fase A ramah anak usia dini dengan pendekatan Kurikulum Berbasis Cinta (KBC).',
    schoolName: 'SDN Ciketing Udik 2 Bantargebang',
    teacherName: 'H. Ahmad Syarif, S.Pd.I',
    teacherNip: '198503152010011002',
    principalName: 'Hj. Siti Aminah, M.Pd',
    principalNip: '197608201999032001',
    meta: {
      fase: 'Fase A',
      elementDomain: "Al-Qur'an & Hadis",
      alokasiWaktuJP: 12,
      targetBab: "Surah Al-Fatihah & Huruf Hijaiyah",
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)'
    },
    contentData: {
      modulAjar: {
        identitas: {
          penyusun: 'H. Ahmad Syarif, S.Pd.I',
          instansi: 'SDN Ciketing Udik 2 Bantargebang',
          faseKelas: 'Fase A / Kelas 1',
          semester: 'Ganjil',
          materiPokok: "Aku Cinta Al-Qur'an & Mengenal Surah Al-Fatihah",
          alokasiWaktu: '3 Pertemuan (12 JP @ 35 Menit)'
        },
        kompetensiAwal: "Peserta didik mengenal bunyi huruf hijaiyah dan terbiasa mendengarkan lantunan ayat Al-Qur'an di rumah atau TPA.",
        profilPelajarPancasilaKBC: [
          'Beriman & Bertakwa kepada Allah SWT',
          'Akhlak Mulia kepada Guru dan Sahabat Kecil',
          'Mandiri & Ceria Belajar'
        ],
        saranaPrasarana: [
          'Kartu Huruf Hijaiyah Bergambar Ceria',
          'Audio Murottal Anak Merdu',
          'Buku Gambar dan Krayon Mewarnai Kaligrafi Al-Fatihah'
        ],
        targetPesertaDidik: 'Peserta Didik Fase A Kelas 1 SD Tipikal.',
        modelPembelajaran: 'Tatap Muka - Eksplorasi Ceria & Bernyanyi Edukatif Berbasis Kasih Sayang',
        komponenInti: {
          tujuanPembelajaran: [
            "Membiasakan melafalkan Basmalah dan Hamdalah sebelum dan sesudah beraktivitas.",
            "Melafalkan Surah Al-Fatihah ayat 1-7 dengan makhraj yang jelas dan riang.",
            "Menunjukkan kasih sayang kepada kawan sebangku saat bermain dan belajar."
          ],
          pemahamanBermakna: "Allah SWT Maha Pengasih dan Maha Penyayang. Bila kita menyayangi teman, Allah akan makin sayang kepada kita.",
          pertanyaanPemantik: [
            "Siapa yang suka tersenyum kepada teman di sekolah?",
            "Apa yang kita ucapkan saat kita hendak makan atau belajar?"
          ],
          kegiatanPembelajaran: {
            pendahuluan: [
              "Menyanyikan lagu 'Tepuk Anak Shalih' dan 'Tepuk Cinta PAI'.",
              "Guru menyapa anak satu per satu dengan pelukan hangat dan senyuman ramah."
            ],
            kegiatanInti: [
              "Menyimak bacaan Surah Al-Fatihah merdu dari guru.",
              "Menirukan pelafalan per ayat dengan gerakan tangan yang menyenangkan.",
              "Mewarnai tulisan lafaz 'Ar-Rahmaan' bersama teman kelompok."
            ],
            penutup: [
              "Tepuk apresiasi bersama dan berdoa penutup majlis penuh keceriaan."
            ]
          },
          asesmen: {
            diagnostik: "Menanyakan doa sebelum makan dan hafalan Al-Fatihah sederhana.",
            formatif: "Observasi senyum, keramahan, dan ketepatan melafalkan ayat.",
            sumatif: "Unjuk kerja melafalkan Surah Al-Fatihah berpasangan di depan kelas."
          },
          pengayaanRemedial: "Pendampingan kasih sayang dan kartu huruf warna-warni.",
          refleksi: "Apakah anak-anak merasa senang dan gembira belajar PAI hari ini?"
        },
        lampiran: {
          bahanBacaan: "Panduan Guru PAI Kelas 1 Kemendikbudristek RI.",
          glosarium: "Basmalah, Hamdalah, Al-Fatihah (Pembukaan).",
          daftarPustaka: "Buku PAI SD Kelas 1 Kurikulum Merdeka 2024."
        }
      }
    },
    createdAt: '2026-07-15T08:00:00Z',
    updatedAt: '2026-07-15T08:00:00Z'
  }
];
