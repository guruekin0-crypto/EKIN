import { TeachingDocument, TeachingDocType, TeachingReferenceDoc } from '../types';

export interface GenerateTeachingDocParams {
  docType: TeachingDocType;
  grade: string; // '1' - '6'
  semester: 'Ganjil' | 'Genap' | 'Tahunan';
  topic: string;
  domain: string;
  schoolName: string;
  teacherName: string;
  teacherNip: string;
  principalName: string;
  principalNip: string;
  academicYear?: string;
  referenceDoc?: TeachingReferenceDoc | null;
}

export const AiTeachingDocService = {
  generateDocument: async (params: GenerateTeachingDocParams): Promise<TeachingDocument> => {
    try {
      const response = await fetch('/api/generate-teaching-doc', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.document) {
          return data.document;
        }
      }
    } catch (err) {
      console.warn('Network call to AI endpoint failed, falling back to built-in KBC generator:', err);
    }

    // High fidelity built-in pedagogical generator
    return AiTeachingDocService.generateLocalPedagogicalDoc(params);
  },

  generateLocalPedagogicalDoc: (params: GenerateTeachingDocParams): TeachingDocument => {
    const {
      docType,
      grade,
      semester,
      topic,
      domain,
      schoolName,
      teacherName,
      teacherNip,
      principalName,
      principalNip,
      academicYear = '2026/2027'
    } = params;

    const fase = (grade === '1' || grade === '2') ? 'Fase A' : (grade === '3' || grade === '4') ? 'Fase B' : 'Fase C';
    const id = 'doc-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 6);
    const nowIso = new Date().toISOString();

    const baseMeta = {
      fase: fase as 'Fase A' | 'Fase B' | 'Fase C',
      elementDomain: domain || 'Al-Qur\'an & Hadis',
      alokasiWaktuJP: 12,
      targetBab: topic || 'Mengenal Nilai Kebaikan dan Kasih Sayang',
      pendekatan: 'Kurikulum Berbasis Cinta (KBC)',
      regulasi: 'Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026 dengan pendekatan KBC'
    };

    let title = '';
    let summary = '';
    const contentData: any = {};

    switch (docType) {
      case 'cp_atp': {
        title = `ALUR TUJUAN PEMBELAJARAN (ATP) PAI & BUDI PEKERTI - KELAS ${grade} (${fase})`;
        summary = `Dokumen Capaian Pembelajaran & Alur Tujuan Pembelajaran Kurikulum Merdeka Fase ${fase.split(' ')[1]} dengan penguatan Pendekatan KBC (Kurikulum Berbasis Cinta) di ${schoolName}.`;
        contentData.capaianPembelajaran = `Pada akhir Fase ${fase.split(' ')[1]} (Kelas ${grade}), peserta didik mampu memahami, melafalkan, dan mengamalkan pesan mulia dari ayat-ayat Al-Qur'an dan Hadis Nabi pilihan, meyakini rukun iman dengan hati penuh cinta, membiasakan akhlak terpuji terhadap sesama teman, orang tua, dan guru di ${schoolName}, serta melaksanakan ibadah pokok dengan kesadaran dan riang gembira berlandaskan cinta kasih kepada Allah SWT dan Rasul-Nya.`;
        contentData.alurTujuanPembelajaran = [
          {
            no: 1,
            tujuan: `Menjelaskan makna dan pesan pokok materi ${topic} dengan santun dan runtut.`,
            materi: topic,
            elemen: domain,
            alokasiJP: 4,
            profilPancasilaKBC: 'Beriman, Bertakwa & Kasih Sayang (Mahabbah)',
            indikator: `Peserta didik mampu menyebutkan 3 nilai kebajikan dan kasih sayang dari materi ${topic}.`
          },
          {
            no: 2,
            tujuan: `Membaca dan melafalkan dalil/teks pokok ${topic} dengan tartil serta makharijul huruf yang tepat.`,
            materi: topic,
            elemen: domain,
            alokasiJP: 4,
            profilPancasilaKBC: 'Mandiri & Beradab Luhur',
            indikator: `Peserta didik mampu melafalkan bacaan dengan tartil tanpa ragu dan saling menyimak dengan penuh apresiasi.`
          },
          {
            no: 3,
            tujuan: `Menunjukkan perilaku empati, tolong-menolong (ta'awun), dan kepedulian sosial di lingkungan sekolah ${schoolName}.`,
            materi: topic,
            elemen: domain,
            alokasiJP: 4,
            profilPancasilaKBC: 'Gotong Royong & Peduli Sesama',
            indikator: `Peserta didik terbiasa mengulurkan tangan membantu kawan yang membutuhkan di kelas maupun halaman sekolah.`
          }
        ];
        break;
      }

      case 'prota': {
        title = `PROGRAM TAHUNAN (PROTA) KURIKULUM MERDEKA PAI & BUDI PEKERTI KELAS ${grade}`;
        summary = `Rancangan alokasi jam pelajaran selama satu tahun ajaran (${academicYear}) terbagi atas Semester Ganjil dan Semester Genap berorientasi akhlak karimah dan KBC.`;
        contentData.protaItems = [
          {
            no: 1,
            semester: 'Ganjil',
            elemen: 'Al-Qur\'an & Hadis',
            materiPokok: topic,
            tujuanPembelajaran: 'Memahami makna kandungan surah/ayat pilihan dan membiasakan membacanya dengan tartil.',
            alokasiJP: 12,
            keterangan: 'Tuntas pada Asesmen Sumatif 1'
          },
          {
            no: 2,
            semester: 'Ganjil',
            elemen: 'Akidah',
            materiPokok: 'Mengenal Sifat-Sifat Allah & Asmaul Husna yang Penuh Kasih Sayang',
            tujuanPembelajaran: 'Meyakini sifat kasih sayang Allah SWT (Ar-Rahman dan Ar-Rahim) dalam kehidupan harian.',
            alokasiJP: 12,
            keterangan: 'Tuntas pada Asesmen Sumatif 2'
          },
          {
            no: 3,
            semester: 'Ganjil',
            elemen: 'Akhlak',
            materiPokok: 'Adab Mulia: Berbakti Kepada Orang Tua & Menghormati Guru',
            tujuanPembelajaran: 'Membiasakan tutur kata santun, mencium tangan orang tua, dan mendengarkan nasihat guru di sekolah.',
            alokasiJP: 12,
            keterangan: 'Tuntas pada Asesmen Sumatif 3'
          },
          {
            no: 4,
            semester: 'Ganjil',
            elemen: 'Fikih',
            materiPokok: 'Tata Cara Shalat Khusyuk & Thaharah (Bersuci)',
            tujuanPembelajaran: 'Mempraktikkan wudhu dan shalat fardhu secara tertib dengan hati yang senang dan tenang.',
            alokasiJP: 14,
            keterangan: 'Praktik Ibadah di Musholla Sekolah'
          },
          {
            no: 5,
            semester: 'Ganjil',
            elemen: 'Sejarah Peradaban Islam',
            materiPokok: 'Kisah Teladan Rasulullah SAW yang Lemah Lembut & Penuh Kasih',
            tujuanPembelajaran: 'Meneladani kelembutan dan kejujuran (shiddiq) Nabi Muhammad SAW saat berinteraksi.',
            alokasiJP: 8,
            keterangan: 'Cadangan & Asesmen Sumatif Akhir Semester'
          },
          {
            no: 6,
            semester: 'Genap',
            elemen: 'Al-Qur\'an & Hadis',
            materiPokok: 'Hadis Menyayangi Teman & Tolong-Menolong (Ta\'awun)',
            tujuanPembelajaran: 'Menghafal hadis persaudaraan dan membuktikan persahabatan sejati di kelas.',
            alokasiJP: 12,
            keterangan: 'Tuntas pada Asesmen Sumatif 4'
          },
          {
            no: 7,
            semester: 'Genap',
            elemen: 'Akidah',
            materiPokok: 'Beriman Kepada Hari Akhir & Amal Kebaikan',
            tujuanPembelajaran: 'Memahami bahwa setiap kebaikan sekecil apapun dicatat dan dibalas kebaikan oleh Allah SWT.',
            alokasiJP: 12,
            keterangan: 'Tuntas pada Asesmen Sumatif 5'
          },
          {
            no: 8,
            semester: 'Genap',
            elemen: 'Akhlak',
            materiPokok: 'Menjaga Kebersihan Diri, Kelas, dan Lingkungan Sekolah',
            tujuanPembelajaran: 'Mempraktikkan gotong royong memilah sampah dan mencintai alam ciptaan Allah.',
            alokasiJP: 12,
            keterangan: 'Projek Penguatan Akhlak KBC'
          },
          {
            no: 9,
            semester: 'Genap',
            elemen: 'Fikih',
            materiPokok: 'Puasa Ramadhan yang Menggembirakan & Zakat Fitrah',
            tujuanPembelajaran: 'Mengenal hikmah puasa melatih empati dan indahnya berbagi dengan sesama anak shalih.',
            alokasiJP: 12,
            keterangan: 'Praktik Pembiasaan Ramadhan Ceria'
          },
          {
            no: 10,
            semester: 'Genap',
            elemen: 'Sejarah Peradaban Islam',
            materiPokok: 'Kisah Sahabat Nabi: Kedermawanan Sayyidina Abu Bakar & Utsman',
            tujuanPembelajaran: 'Mencontoh ketulusan hati para sahabat dalam membela kebenaran dan menolong kaum dhuafa.',
            alokasiJP: 8,
            keterangan: 'Sumatif Akhir Jenjang / Kenaikan Kelas'
          }
        ];
        contentData.totalJPGanjil = 58;
        contentData.totalJPGenap = 56;
        contentData.totalJPTahunan = 114;
        break;
      }

      case 'promes': {
        title = `PROGRAM SEMESTER (PROMES) PAI & BUDI PEKERTI - KELAS ${grade} SEMESTER ${semester.toUpperCase()}`;
        summary = `Rincian alokasi jam tatap muka per pekan efektif pada Semester ${semester} Tahun Pelajaran ${academicYear} di ${schoolName}.`;
        const bulanList = semester === 'Ganjil' 
          ? ['Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
          : ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni'];

        contentData.promesItems = [
          {
            no: 1,
            materiPokok: `${topic} (Elemen: ${domain})`,
            tujuanPembelajaran: 'Membaca, memahami pesan pokok, dan menerapkannya dalam interaksi ramah anak di sekolah.',
            alokasiJP: 12,
            distribusiBulan: [
              { bulan: bulanList[0], minggu: [0, 4, 4] },
              { bulan: bulanList[1], minggu: [4, 0, 0] }
            ]
          },
          {
            no: 2,
            materiPokok: 'Asmaul Husna & Akidah Kasih Sayang Allah SWT',
            tujuanPembelajaran: 'Meneladani sifat-sifat mulia Allah SWT dalam bersikap jujur dan mengayomi teman sebaya.',
            alokasiJP: 12,
            distribusiBulan: [
              { bulan: bulanList[1], minggu: [0, 4, 4] },
              { bulan: bulanList[2], minggu: [4, 0, 0] }
            ]
          },
          {
            no: 3,
            materiPokok: 'Indahnya Berakhlak Terpuji & Berbakti Kepada Sesama',
            tujuanPembelajaran: 'Membiasakan 5S (Senyum, Salam, Sapa, Sopan, Santun) dan menghindari perundungan (bullying).',
            alokasiJP: 12,
            distribusiBulan: [
              { bulan: bulanList[2], minggu: [0, 4, 4] },
              { bulan: bulanList[3], minggu: [4, 0, 0] }
            ]
          },
          {
            no: 4,
            materiPokok: 'Praktik Ibadah Shalat & Thaharah Penuh Khusyuk',
            tujuanPembelajaran: 'Melaksanakan shalat berjamaah di musholla sekolah dengan tertib dan berwudhu secara sempurna.',
            alokasiJP: 12,
            distribusiBulan: [
              { bulan: bulanList[3], minggu: [0, 4, 4] },
              { bulan: bulanList[4], minggu: [4, 0, 0] }
            ]
          },
          {
            no: 5,
            materiPokok: 'Kisah Sahabat & Keteladanan Akhlak Mulia',
            tujuanPembelajaran: 'Menyimak kisah perjuangan dakwah penuh kedamaian dan menyimpulkan hikmah ketabahan.',
            alokasiJP: 8,
            distribusiBulan: [
              { bulan: bulanList[4], minggu: [0, 4, 4] },
              { bulan: bulanList[5], minggu: [0, 0, 0] }
            ]
          }
        ];
        break;
      }

      case 'kktp': {
        title = `KRITERIA KETERCAPAIAN TUJUAN PEMBELAJARAN (KKTP) KELAS ${grade} SD`;
        summary = `Pedoman rubrik asesmen ketercapaian kompetensi berbasis pendekatan deskripsi kriteria dan interval cinta (KBC) untuk memotivasi anak tanpa pelabelan negatif.`;
        contentData.kktpItems = [
          {
            no: 1,
            tujuanPembelajaran: `Mampu membaca dan melafalkan ayat/dalil pokok terkait "${topic}" dengan tartil.`,
            indikatorKetuntasan: 'Kesesuaian makhraj, kelancaran tajwid, dan adab ketika melantunkan ayat Al-Qur\'an.',
            kriteria: {
              perluBimbingan: 'Belum lancar membaca, masih sering terbata-bata dan keliru harakat (0 - 60).',
              cukup: 'Dapat membaca ayat namun masih butuh arahan pada hukum bacaan mad dan tajwid (61 - 75).',
              baik: 'Membaca dengan lancar, makhraj fasih, dan tajwid cukup konsisten (76 - 88).',
              sangatBaik: 'Sangat fasih, tartil sempurna, suara merdu, dan penuh penghayatan adab mulia (89 - 100).'
            },
            tindakLanjutKBC: 'Pendampingan penuh kelembutan (Talaqqi One-on-One) dengan pujian motivasi tanpa rasa malu.'
          },
          {
            no: 2,
            tujuanPembelajaran: `Mampu memahami makna isi kandungan ${topic} dan menghubungkannya dengan kehidupan harian.`,
            indikatorKetuntasan: 'Ketepatan menjelaskan makna kebaikan dan memberi contoh aksi nyata di sekolah.',
            kriteria: {
              perluBimbingan: 'Belum mampu menjelaskan pesan pokok materi walau telah diberi stimulus (0 - 60).',
              cukup: 'Mampu menyebutkan inti pesan tetapi belum bisa memberi contoh kontekstual di kelas (61 - 75).',
              baik: 'Mampu menjelaskan pesan dan memberi 2 contoh perbuatan baik yang nyata di sekolah (76 - 88).',
              sangatBaik: 'Mampu menganalisis pesan moral, mengaitkan dengan kasih sayang Allah, dan mengajak teman berbuat baik (89 - 100).'
            },
            tindakLanjutKBC: 'Diskusi kelompok ceria (peer tutoring) bersama kawan sebaya untuk menumbuhkan saling menghargai.'
          },
          {
            no: 3,
            tujuanPembelajaran: `Membiasakan karakter mulia KBC: kasih sayang sesama teman, empati, dan tidak membeda-bedakan.`,
            indikatorKetuntasan: 'Observasi sikap ramah, gemar menolong saat piket, serta bertutur kata sopan di lingkungan sekolah.',
            kriteria: {
              perluBimbingan: 'Masih enggan berbagi dan kadang berbicara ketus kepada teman (0 - 60).',
              cukup: 'Mau bergaul namun masih pasif saat teman membutuhkan bantuan (61 - 75).',
              baik: 'Sikap ramah konsisten, gemar menolong kawan, dan suka menyapa guru (76 - 88).',
              sangatBaik: 'Menjadi teladan cinta kasih (Duta Kebaikan Kelas), selalu mendamaikan teman dan berinisiatif menolong (89 - 100).'
            },
            tindakLanjutKBC: 'Pemberian apresiasi "Bintang Kebaikan Kalbu" dan pelukan kasih sayang guru.'
          }
        ];
        break;
      }

      case 'modul_ajar': {
        title = `MODUL AJAR KURIKULUM MERDEKA PAI & BUDI PEKERTI: ${topic.toUpperCase()} (KELAS ${grade})`;
        summary = `Rencana Pelaksanaan Pembelajaran (RPP) Merdeka komprehensif berorientasi student-centered learning, diferensiasi konten & proses, serta integrasi Kurikulum Berbasis Cinta (KBC).`;
        contentData.modulAjar = {
          identitas: {
            penyusun: teacherName,
            instansi: schoolName,
            faseKelas: `${fase} / Kelas ${grade}`,
            semester: semester,
            materiPokok: topic,
            alokasiWaktu: '3 Pekan (3 Pertemuan x 3 JP @ 35 Menit)'
          },
          kompetensiAwal: `Peserta didik telah terbiasa melafalkan kalimat thayyibah (Basmalah & Hamdalah) dan memiliki fitrah cinta kebaikan dalam bermain bersama kawan-kawan di sekolah.`,
          profilPelajarPancasilaKBC: [
            'Beriman, Bertakwa kepada Tuhan YME dan Berakhlak Mulia (Hubbullah & Mahabbaturrasul)',
            'Gotong Royong & Peduli Sesama (Ta\'awun & Kasih Sayang KBC)',
            'Bernalar Kritis (Menemukan hikmah kebaikan di balik kisah)',
            'Mandiri & Beradab Luhur'
          ],
          saranaPrasarana: [
            'Buku Teks Utama PAI & Budi Pekerti SD Kurikulum Merdeka Kemendikbudristek/Kemenag',
            'Mushaf Al-Qur\'an Digital / Kartu Potongan Ayat Khat Naskh Berharakat Lengkap',
            'LCD Proyektor & Video Edukasi Karakter Ceria',
            'Lembar Kerja Peserta Didik (LKPD) Ceria',
            'Kotak Kebaikan "Cinta untuk Sahabat"'
          ],
          targetPesertaDidik: `Peserta didik reguler/tipikal Kelas ${grade} SD (${schoolName}) dengan gaya belajar kinestetik, visual, dan auditori.`,
          modelPembelajaran: 'Tatap Muka - Problem Based Learning (PBL) & Cooperative Learning dengan Pendekatan Cinta (KBC)',
          komponenInti: {
            tujuanPembelajaran: [
              `Peserta didik mampu melafalkan dalil/bacaan pokok terkait "${topic}" secara fasih dan tartil.`,
              `Peserta didik mampu menguraikan hikmah dan pesan kasih sayang dari materi "${topic}".`,
              `Peserta didik mampu mempraktikkan aksi nyata peduli sesama dan gemar tolong-menolong di lingkungan ${schoolName}.`
            ],
            pemahamanBermakna: `Cinta kepada Allah SWT dan Rasul-Nya dibuktikan dengan cara menyayangi sesama makhluk, menghormati guru dan orang tua, serta bersikap lemah lembut kepada setiap kawan tanpa membedakan.`,
            pertanyaanPemantik: [
              `Pernahkah kamu melihat kawanmu bersedih atau terjatuh di halaman sekolah? Apa yang hatimu rasakan?`,
              `Mengapa Allah SWT sangat mencintai orang-orang yang gemar berbuat baik dan saling menolong?`,
              `Bagaimana cara kita membahagiakan orang tua dan guru kita hari ini?`
            ],
            kegiatanPembelajaran: {
              pendahuluan: [
                'Guru membuka kelas dengan salam hangat penuh senyuman, menyapa kabar peserta didik dengan panggilan ramah dan penuh kasih sayang.',
                'Berdoa bersama dipimpin oleh ketua kelas, dilanjutkan membaca salah satu surah pendek juz 30.',
                'Apersepsi: Guru mengaitkan materi hari ini dengan pengalaman nyata peserta didik saat bermain di ${schoolName}.',
                'Menyampaikan tujuan pembelajaran dan memotivasi peserta didik bahwa hari ini kita akan berpetualang menimba ilmu yang membuat hati bahagia.'
              ],
              kegiatanInti: [
                'Tahap 1 (Orientasi Masalah Berbasis Cinta): Peserta didik menyimak video/gambar stimulus tentang kisah tolong-menolong antar kawan.',
                'Tahap 2 (Organisasi Belajar): Peserta didik dibagi ke dalam kelompok kecil heterogen. Guru membagikan LKPD Ceria.',
                'Tahap 3 (Penyelidikan Mandiri & Kolaborasi): Peserta didik berdiskusi santun mengidentifikasi nilai-nilai kasih sayang yang terkandung dalam teks.',
                'Tahap 4 (Pengembangan & Presentasi Hasil): Setiap perwakilan kelompok memperagakan contoh adab mulia dan membacakan hasil temuannya ke depan kelas.',
                'Tahap 5 (Evaluasi & Penguatan): Guru memberikan penguatan konsep, meluruskan pemahaman dengan lembut, dan mengapresiasi keberanian seluruh peserta didik.'
              ],
              penutup: [
                'Peserta didik bersama guru menyimpulkan inti pembelajaran hari ini.',
                'Refleksi Kalbu: Anak-anak diminta menuliskan atau mengungkapkan satu hal kebaikan yang ingin mereka lakukan kepada sahabatnya hari ini.',
                'Guru memberikan apresiasi tepuk tangan meriah dan doa bersama penutup majlis.'
              ]
            },
            asesmen: {
              diagnostik: 'Tanya jawab lisan awal pertemuan untuk memetakan kesiapan dan minat belajar peserta didik.',
              formatif: 'Observasi keaktifan diskusi kelompok, unjuk kerja membaca tartil ayat, dan lembar ceklis sikap kasih sayang (KBC).',
              sumatif: 'Tes tertulis pilihan ganda kontekstual (model TKA HOTS) dan penilaian produk aksi kebaikan siswa.'
            },
            pengayaanRemedial: 'Remedial: Bimbingan intensif dan tutor sebaya penuh kesabaran bagi siswa yang belum mencapai KKTP. Pengayaan: Diberikan kesempatan menjadi "Duta PAI Ceria" untuk memimpin tadarus pagi.',
            refleksi: 'Refleksi Pendidik: Apakah suasana belajar hari ini menyenangkan dan menumbuhkan rasa cinta belajar? Peserta Didik: Bagian mana yang paling kamu sukai dari kegiatan hari ini?'
          },
          lampiran: {
            bahanBacaan: `Ringkasan Rangkuman Guru & Siswa mengenai ${topic}, keutamaan berbuat ihsan, dan fadhilah mengamalkannya sejak usia dini.`,
            glosarium: 'KBC (Kurikulum Berbasis Cinta), Mahabbah (Cinta), Ta\'awun (Tolong-menolong), Tartil (Membaca perlahan dan benar), Akhlakul Karimah (Budi pekerti luhur).',
            daftarPustaka: `Buku Panduan Guru & Siswa PAI Kelas ${grade} SD Kemendikbudristek RI 2024; Al-Qur'an Standar Indonesia Kementerian Agama RI.`
          }
        };
        break;
      }

      case 'lkpd': {
        title = `LEMBAR KERJA PESERTA DIDIK (LKPD) CERIA KELAS ${grade}: ${topic.toUpperCase()}`;
        summary = `Lembar aktivitas belajar siswa bernuansa kasih sayang, dilengkapi stimulus cerita kontekstual, khat Arab rapi, dan tantangan aksi kebaikan di ${schoolName}.`;
        contentData.lkpd = {
          judulAktivitas: `Petualangan Sahabat Kebaikan: ${topic}`,
          temaNilaiKBC: 'Menebar Cinta Kasih, Meneladani Rasulullah SAW, dan Gemar Berbuat Baik',
          petunjukBelajar: [
            'Tulis nama lengkap, kelas, dan nomor absenmu pada kolom yang disediakan.',
            'Awali setiap langkah belajarmu dengan melafalkan Basmalah: "Bismillaahir Rahmaanir Rahiim".',
            'Bacalah cerita dengan teliti, lalu diskusikan jawaban terbaik bersama teman sebangkumu dengan senyuman hangat.',
            'Kerjakan tugas dengan jujur, percaya diri, dan penuh semangat.'
          ],
          stimulusCerita: `Pagi itu di ${schoolName}, bel istirahat berbunyi ceria. Hasan melihat seorang kawannya bernama Farhan duduk termenung di dekat taman kelas. Bekal Farhan tidak sengaja terjatuh saat bergegas keluar. Melihat hal itu, Hasan tersenyum lembut dan segera menghampirinya. "Farhan, jangan bersedih ya. Mari kita makan bekalku bersama-sama, ibuku membawakan roti yang lezat," ajak Hasan penuh kehangatan. Farhan tersenyum lega dan mengucapkan terima kasih. Keduanya menikmati bekal dengan riang sambil bersyukur kepada Allah SWT.`,
          arabicSnippet: {
            text: 'وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ ۖ وَلَا تَعَاوَنُوا عَلَى الْإِثْمِ وَالْعُدْوَانِ',
            arti: 'Dan tolong-menolonglah kamu dalam (mengerjakan) kebajikan dan takwa, dan jangan tolong-menolong dalam berbuat dosa dan permusuhan. (QS. Al-Ma\'idah: 2)'
          },
          langkahAktivitas: [
            '1. Amati bacaan ayat dan renungkan artinya bersama guru dan temanmu.',
            '2. Temukan teladan kasih sayang yang dicontohkan Hasan kepada Farhan pada cerita di atas.',
            '3. Kerjakan pertanyaan refleksi di bawah ini dengan tulisan yang rapi dan jujur.'
          ],
          tugasSiswa: [
            {
              nomor: 1,
              instruksi: `Berdasarkan cerita di ${schoolName}, apa yang membuat hati Hasan tergerak menolong Farhan? Jelaskan dengan kalimatmu sendiri!`,
              tipe: 'isian'
            },
            {
              nomor: 2,
              instruksi: `Di bawah ini yang merupakan contoh penerapan nilai tolong-menolong (ta'awun) di sekolah adalah:`,
              tipe: 'pilihan',
              opsi: [
                'Menertawakan teman yang terlambat datang ke sekolah',
                'Membantu merapikan meja dan meminjamkan alat tulis kepada teman yang lupa membawa',
                'Membiarkan sampah berserakan di depan ruang kelas',
                'Bermain sendiri dan menolak berbagi mainan dengan kawan'
              ]
            },
            {
              nomor: 3,
              instruksi: `Tuliskan 2 kebaikan kecil yang telah kamu lakukan untuk sahabatmu atau gurumu hari ini!`,
              tipe: 'isian'
            }
          ],
          refleksiCinta: 'Bagaimana perasaan hatimu setelah berbuat baik kepada sesama kawan hari ini? Berikan tanda bintang pada kotak perasaanmu (Sangat Bahagia / Gembira / Sejuk di Hati)!',
          rubrikNilai: 'Kriteria Penilaian: Pemahaman Materi (40%), Sikap & Kejujuran (40%), Kerapian Berkas (20%). Skor maksimal = 100.'
        };
        break;
      }

      case 'lainnya':
      default: {
        title = `DOKUMEN PERANGKAT AJAR PAI & BUDI PEKERTI: ${topic.toUpperCase()} (KELAS ${grade})`;
        summary = `Dokumen administrasi & perangkat pendukung pembelajaran PAI Kurikulum Merdeka berorientasi Kurikulum Berbasis Cinta (KBC) di ${schoolName}.`;
        contentData.dokumenLainnya = {
          subKategori: 'Silabus & Program Pendukung PAI',
          tujuanDokumen: `Menjadi pedoman pelaksanaan, evaluasi, dan tindak lanjut pembelajaran materi "${topic}" pada Kelas ${grade} (${fase}).`,
          uraianIsi: `Dokumen ini disusun sebagai kelengkapan administrasi pembelajaran Pendidikan Agama Islam dan Budi Pekerti di ${schoolName} dengan mengintegrasikan nilai-nilai kasih sayang (mahabbah), keteladanan akhlak mulia, dan pembelajaran ramah anak.`,
          tabelBaris: [
            {
              no: 1,
              aspek: `Pemahaman & Materi Pokok (${domain})`,
              uraian: `Memahami dan mengamalkan nilai utama dari materi ${topic} secara menyenangkan dan kontekstual.`,
              keterangan: '4 JP'
            },
            {
              no: 2,
              aspek: 'Praktik & Pembiasaan Akhlak KBC',
              uraian: 'Menerapkan adab sopan santun, gemar menolong teman, dan menjaga kebersihan lingkungan kelas.',
              keterangan: '4 JP'
            },
            {
              no: 3,
              aspek: 'Evaluasi, Refleksi & Tindak Lanjut',
              uraian: 'Pelaksanaan asesmen formatif/sumatif serta pendampingan remedial/pengayaan penuh kasih sayang.',
              keterangan: '4 JP'
            }
          ]
        };
        break;
      }
    }

    if (params.referenceDoc) {
      const ref = params.referenceDoc;
      contentData.sandaranAcuan = {
        referenceId: ref.id,
        referenceTitle: ref.title,
        fileName: ref.fileName,
        fileType: ref.fileType,
        dataUrl: ref.dataUrl,
        ringkasanAcuan: ref.extractedText.substring(0, 1200)
      };
      summary = `${summary} (Disusun berlandaskan Dokumen Acuan: "${ref.title}" - ${ref.fileName}).`;

      const refRows = (ref.extractedRows || []).filter(r => r.col1 && r.col1.trim());
      if (docType === 'cp_atp') {
        if (ref.extractedText && ref.extractedText.length > 20) {
          contentData.capaianPembelajaran = ref.extractedText;
        }
        if (refRows.length > 0) {
          contentData.alurTujuanPembelajaran = refRows.map((r, idx) => ({
            no: idx + 1,
            tujuan: r.col1,
            materi: r.col2 || topic,
            elemen: domain,
            alokasiJP: parseInt(String(r.col3), 10) || 4,
            profilPancasilaKBC: r.col4 || 'Beriman, Bertakwa & Kasih Sayang (KBC)',
            indikator: `Tercapainya kompetensi sesuai dokumen acuan: ${r.col1}`
          }));
        }
      } else if (docType === 'prota' && refRows.length > 0) {
        contentData.protaItems = refRows.map((r, idx) => ({
          no: idx + 1,
          semester: idx % 2 === 0 ? 'Ganjil' : 'Genap',
          elemen: domain,
          materiPokok: r.col2 || r.col1,
          tujuanPembelajaran: r.col1,
          alokasiJP: parseInt(String(r.col3), 10) || 12,
          keterangan: `Acuan: ${ref.fileName}`
        }));
      } else if (docType === 'promes' && refRows.length > 0) {
        contentData.promesItems = refRows.map((r, idx) => ({
          no: idx + 1,
          materiPokok: r.col2 || r.col1,
          tujuanPembelajaran: r.col1,
          alokasiJP: parseInt(String(r.col3), 10) || 12,
          distribusiBulan: [
            {
              bulan: semester === 'Genap' ? 'Januari - Maret' : 'Juli - September',
              minggu: [4, 4, 4]
            }
          ]
        }));
      } else if (docType === 'kktp' && refRows.length > 0) {
        contentData.kktpItems = refRows.slice(0, 6).map((r, idx) => ({
          no: idx + 1,
          tujuanPembelajaran: r.col1,
          indikatorKetuntasan: r.col2 || `Ketuntasan penguasaan materi ${r.col1}`,
          kriteria: {
            perluBimbingan: 'Belum mencapai ketuntasan dasar sesuai dokumen acuan (0 - 60).',
            cukup: 'Mencapai sebagian indikator dasar namun butuh bimbingan (61 - 75).',
            baik: 'Mencapai indikator ketuntasan dengan baik dan konsisten (76 - 88).',
            sangatBaik: 'Sangat fasih, tuntas sempurna, dan menjadi teladan KBC (89 - 100).'
          },
          tindakLanjutKBC: 'Pendampingan penuh kelembutan & tutor sebaya berbasis KBC.'
        }));
      } else if (docType === 'modul_ajar' && contentData.modulAjar && refRows.length > 0) {
        contentData.modulAjar.komponenInti.tujuanPembelajaran = refRows.map(r => r.col1);
        contentData.modulAjar.lampiran.bahanBacaan =
          ref.extractedText.substring(0, 800) || contentData.modulAjar.lampiran.bahanBacaan;
      }
    }

    return {
      id,
      docType,
      classGrade: String(grade),
      semester,
      academicYear,
      title,
      summary,
      schoolName,
      teacherName,
      teacherNip,
      principalName,
      principalNip,
      regulasi: 'Keputusan Kepala Badan Kebijakan Pendidikan Dasar dan Menengah (BKPDM) Nomor 020 Tahun 2026 dengan pendekatan KBC',
      meta: baseMeta,
      contentData,
      createdAt: nowIso,
      updatedAt: nowIso
    };
  }
};
