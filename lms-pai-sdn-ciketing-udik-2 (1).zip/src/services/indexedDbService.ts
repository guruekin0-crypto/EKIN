// ============================================================================
// INDEXEDDB OFFLINE-FIRST CACHE & OUTBOX QUEUE LAYER
// Menyimpan seluruh koleksi data LMS di IndexedDB sebagai lapisan cache lokal
// tahan banting (durable) dan antrean sinkronisasi otomatis (Outbox) ke Supabase
// saat koneksi internet terdeteksi kembali.
// ============================================================================

export interface CachedKVItem {
  key: string;
  value: any;
  updatedAt: string;
  synced: boolean;
}

export interface OutboxQueueItem {
  key: string;
  payload: any;
  queuedAt: string;
  retryCount: number;
  lastError?: string;
}

export type SyncStateType = 'synced' | 'syncing' | 'offline_cached' | 'pending_outbox' | 'error';

export interface OfflineSyncStatus {
  isOnline: boolean;
  syncState: SyncStateType;
  pendingCount: number;
  cachedKeysCount: number;
  lastSyncedAt: string | null;
  lastMessage: string;
}

const DB_NAME = 'lms_pai_offline_db';
const DB_VERSION = 1;
const STORE_KV_CACHE = 'kv_cache';
const STORE_SYNC_OUTBOX = 'sync_outbox';
const LAST_SYNC_META_KEY = 'lms_pai_last_synced_at';

type SyncListener = (status: OfflineSyncStatus) => void;
const listeners = new Set<SyncListener>();

let currentStatus: OfflineSyncStatus = {
  isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
  syncState: typeof navigator !== 'undefined' && !navigator.onLine ? 'offline_cached' : 'synced',
  pendingCount: 0,
  cachedKeysCount: 0,
  lastSyncedAt: typeof localStorage !== 'undefined' ? localStorage.getItem(LAST_SYNC_META_KEY) : null,
  lastMessage:
    typeof navigator !== 'undefined' && !navigator.onLine
      ? 'Mode Offline Aktif — Data diamankan di IndexedDB'
      : 'IndexedDB & Supabase Cloud Tersinkronisasi'
};

function notifyListeners() {
  const snapshot = { ...currentStatus };
  listeners.forEach(listener => {
    try {
      listener(snapshot);
    } catch (err) {
      console.error('Error in sync listener:', err);
    }
  });
}

let dbPromise: Promise<IDBDatabase> | null = null;

function openDatabase(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') {
    return Promise.reject(new Error('IndexedDB tidak didukung di lingkungan ini'));
  }
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_KV_CACHE)) {
        db.createObjectStore(STORE_KV_CACHE, { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains(STORE_SYNC_OUTBOX)) {
        db.createObjectStore(STORE_SYNC_OUTBOX, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      dbPromise = null;
      reject(request.error);
    };
  });

  return dbPromise;
}

export const IndexedDbService = {
  /**
   * Subscribe to real-time changes in offline/online & IndexedDB sync state
   */
  subscribeSyncStatus: (listener: SyncListener): (() => void) => {
    listeners.add(listener);
    listener({ ...currentStatus });
    return () => {
      listeners.delete(listener);
    };
  },

  getSyncStatus: (): OfflineSyncStatus => ({ ...currentStatus }),

  updateSyncStatus: (partial: Partial<OfflineSyncStatus>) => {
    if (partial.lastSyncedAt) {
      try {
        localStorage.setItem(LAST_SYNC_META_KEY, partial.lastSyncedAt);
      } catch {
        // ignore
      }
    }
    currentStatus = {
      ...currentStatus,
      ...partial
    };
    notifyListeners();
  },

  /**
   * Put or update a key-value entry in the IndexedDB kv_cache store
   */
  putCache: async (key: string, value: any, synced = true): Promise<void> => {
    try {
      const db = await openDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(STORE_KV_CACHE, 'readwrite');
        const store = tx.objectStore(STORE_KV_CACHE);
        const item: CachedKVItem = {
          key,
          value,
          updatedAt: new Date().toISOString(),
          synced
        };
        store.put(item);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      await IndexedDbService.refreshCounts();
    } catch (err) {
      console.warn('IndexedDB putCache fallback warning:', err);
    }
  },

  /**
   * Retrieve a single cached item from IndexedDB
   */
  getCache: async <T = any>(key: string): Promise<CachedKVItem | undefined> => {
    try {
      const db = await openDatabase();
      return await new Promise<CachedKVItem | undefined>((resolve, reject) => {
        const tx = db.transaction(STORE_KV_CACHE, 'readonly');
        const store = tx.objectStore(STORE_KV_CACHE);
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result as CachedKVItem | undefined);
        req.onerror = () => reject(req.error);
      });
    } catch {
      return undefined;
    }
  },

  /**
   * Retrieve all cached items in IndexedDB kv_cache
   */
  getAllCache: async (): Promise<CachedKVItem[]> => {
    try {
      const db = await openDatabase();
      return await new Promise<CachedKVItem[]>((resolve, reject) => {
        const tx = db.transaction(STORE_KV_CACHE, 'readonly');
        const store = tx.objectStore(STORE_KV_CACHE);
        const req = store.getAll();
        req.onsuccess = () => resolve((req.result as CachedKVItem[]) || []);
        req.onerror = () => reject(req.error);
      });
    } catch {
      return [];
    }
  },

  /**
   * Queue a mutation in the IndexedDB sync_outbox store when offline or when Supabase request fails
   */
  enqueueOutbox: async (key: string, payload: any, lastError?: string): Promise<void> => {
    try {
      const db = await openDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction([STORE_SYNC_OUTBOX, STORE_KV_CACHE], 'readwrite');
        const outboxStore = tx.objectStore(STORE_SYNC_OUTBOX);
        const cacheStore = tx.objectStore(STORE_KV_CACHE);

        const getReq = outboxStore.get(key);
        getReq.onsuccess = () => {
          const existing = getReq.result as OutboxQueueItem | undefined;
          const item: OutboxQueueItem = {
            key,
            payload,
            queuedAt: new Date().toISOString(),
            retryCount: existing ? existing.retryCount + 1 : 0,
            lastError
          };
          outboxStore.put(item);
        };

        cacheStore.put({
          key,
          value: payload,
          updatedAt: new Date().toISOString(),
          synced: false
        } as CachedKVItem);

        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      await IndexedDbService.refreshCounts();
    } catch (err) {
      console.warn('IndexedDB enqueueOutbox warning:', err);
    }
  },

  /**
   * Get all pending mutations from the IndexedDB sync_outbox store
   */
  getOutboxItems: async (): Promise<OutboxQueueItem[]> => {
    try {
      const db = await openDatabase();
      return await new Promise<OutboxQueueItem[]>((resolve, reject) => {
        const tx = db.transaction(STORE_SYNC_OUTBOX, 'readonly');
        const store = tx.objectStore(STORE_SYNC_OUTBOX);
        const req = store.getAll();
        req.onsuccess = () => resolve((req.result as OutboxQueueItem[]) || []);
        req.onerror = () => reject(req.error);
      });
    } catch {
      return [];
    }
  },

  /**
   * Remove a successfully synced key from the IndexedDB sync_outbox store and mark it synced in kv_cache
   */
  removeOutboxItem: async (key: string): Promise<void> => {
    try {
      const db = await openDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction([STORE_SYNC_OUTBOX, STORE_KV_CACHE], 'readwrite');
        const outboxStore = tx.objectStore(STORE_SYNC_OUTBOX);
        const cacheStore = tx.objectStore(STORE_KV_CACHE);

        outboxStore.delete(key);

        const cacheReq = cacheStore.get(key);
        cacheReq.onsuccess = () => {
          const cached = cacheReq.result as CachedKVItem | undefined;
          if (cached) {
            cached.synced = true;
            cacheStore.put(cached);
          }
        };

        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      await IndexedDbService.refreshCounts();
    } catch (err) {
      console.warn('IndexedDB removeOutboxItem warning:', err);
    }
  },

  /**
   * Clear all IndexedDB stores (used when resetting database to factory defaults)
   */
  clearAll: async (): Promise<void> => {
    try {
      const db = await openDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction([STORE_KV_CACHE, STORE_SYNC_OUTBOX], 'readwrite');
        tx.objectStore(STORE_KV_CACHE).clear();
        tx.objectStore(STORE_SYNC_OUTBOX).clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
      await IndexedDbService.refreshCounts();
    } catch (err) {
      console.warn('IndexedDB clearAll warning:', err);
    }
  },

  /**
   * Refresh cachedKeysCount and pendingCount from IndexedDB and update status
   */
  refreshCounts: async (): Promise<{ cachedKeysCount: number; pendingCount: number }> => {
    try {
      const [cacheItems, outboxItems] = await Promise.all([
        IndexedDbService.getAllCache(),
        IndexedDbService.getOutboxItems()
      ]);
      const cachedKeysCount = cacheItems.length;
      const pendingCount = outboxItems.length;
      const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;

      let nextState: SyncStateType = currentStatus.syncState;
      let nextMessage = currentStatus.lastMessage;

      if (!isOnline) {
        nextState = 'offline_cached';
        nextMessage =
          pendingCount > 0
            ? `Offline — ${pendingCount} perubahan dalam antrean IndexedDB`
            : 'Offline — Data diamankan di cache IndexedDB';
      } else if (currentStatus.syncState !== 'syncing') {
        if (pendingCount > 0) {
          nextState = 'pending_outbox';
          nextMessage = `${pendingCount} antrean IndexedDB siap disinkronkan ke Supabase`;
        } else {
          nextState = 'synced';
          nextMessage = 'IndexedDB & Supabase Cloud Tersinkronisasi';
        }
      }

      IndexedDbService.updateSyncStatus({
        isOnline,
        cachedKeysCount,
        pendingCount,
        syncState: nextState,
        lastMessage: nextMessage
      });

      return { cachedKeysCount, pendingCount };
    } catch {
      return { cachedKeysCount: 0, pendingCount: 0 };
    }
  },

  /**
   * Bi-directional hydration between IndexedDB and localStorage:
   * - If localStorage is missing a key that exists in IndexedDB (e.g. after browser storage eviction),
   *   restores it from IndexedDB into localStorage so synchronous reads immediately work.
   * - If localStorage has keys not yet stored in IndexedDB, seeds IndexedDB kv_cache.
   */
  hydrateAndMirrorLocalStorage: async (storageKeys: string[]): Promise<{
    restoredFromIdb: number;
    mirroredToIdb: number;
  }> => {
    let restoredFromIdb = 0;
    let mirroredToIdb = 0;

    try {
      const allCached = await IndexedDbService.getAllCache();
      const cacheMap = new Map<string, CachedKVItem>();
      allCached.forEach(item => cacheMap.set(item.key, item));

      for (const key of storageKeys) {
        const localRaw = localStorage.getItem(key);
        const idbItem = cacheMap.get(key);

        if (!localRaw && idbItem && idbItem.value !== undefined) {
          // Restore evicted localStorage from IndexedDB durable cache
          localStorage.setItem(key, JSON.stringify(idbItem.value));
          restoredFromIdb++;
        } else if (localRaw && !idbItem) {
          // Mirror existing localStorage into IndexedDB cache
          try {
            const parsed = JSON.parse(localRaw);
            await IndexedDbService.putCache(key, parsed, true);
            mirroredToIdb++;
          } catch {
            // ignore malformed JSON
          }
        }
      }

      await IndexedDbService.refreshCounts();
    } catch (err) {
      console.warn('Error hydrating between IndexedDB and localStorage:', err);
    }

    return { restoredFromIdb, mirroredToIdb };
  }
};
