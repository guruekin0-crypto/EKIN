import { Question, QuestionType } from '../types';

export interface GenerateQuestionsParams {
  topic: string;
  grade: string; // '1' - '6'
  semester: 'Ganjil' | 'Genap';
  count: number;
  schoolName: string;
  questionType?: string; // 'all' | 'per_type' | 'pg_standar' | 'pg_kompleks' | 'benar_salah' | 'menjodohkan' | 'isian_singkat' | 'essay'
  typeCounts?: Partial<Record<QuestionType, number>>;
}

/**
 * High-fidelity generator for PAI Kurikulum Merdeka with:
 * 1. Pendekatan KBC (Kurikulum Berbasis Cinta / Kasih Sayang & Karakter)
 * 2. Model Soal TKA (Tes Kemampuan Akademik) dengan Stimulus Cerita Kontekstual Anak SD
 * 3. Teks Huruf Arab Berharakat Lengkap (Khat Naskh Mushaf Standar Indonesia)
 * 4. Mendukung 6 Jenis Soal: PG Standar, PG Kompleks, Benar/Salah, Menjodohkan, Isian Singkat, Uraian/Essay
 * 5. Mendukung penentuan jumlah soal manual per jenis soal
 */
export function generateLocalKbcQuestions(params: GenerateQuestionsParams): Question[] {
  const {
    topic,
    grade,
    semester,
    count,
    schoolName,
    questionType = 'all',
    typeCounts
  } = params;
  const numGrade = parseInt(grade, 10) || 5;
  const sName = schoolName || 'SDN Ciketing Udik 2 Bantargebang';
  const cleanTopic = topic.trim() || "Surah Al-Ma'un & Kepedulian Sosial";

  // Build ordered list of target question types to generate based on typeCounts or questionType
  const requestedTypes: QuestionType[] = [];
  if (typeCounts && Object.values(typeCounts).some(v => (v || 0) > 0)) {
    const order: QuestionType[] = [
      'pg_standar',
      'pg_kompleks',
      'benar_salah',
      'menjodohkan',
      'isian_singkat',
      'essay'
    ];
    order.forEach(qt => {
      const c = Math.max(0, Math.min(50, Number(typeCounts[qt] || 0)));
      for (let i = 0; i < c; i++) {
        requestedTypes.push(qt);
      }
    });
  }

  const totalToMake =
    requestedTypes.length > 0
      ? Math.min(requestedTypes.length, 50)
      : Math.max(1, Math.min(Number(count) || 5, 50));

  if (requestedTypes.length === 0) {
    const cycleTypes: QuestionType[] = [
      'pg_standar',
      'pg_kompleks',
      'benar_salah',
      'menjodohkan',
      'isian_singkat',
      'essay'
    ];
    for (let i = 0; i < totalToMake; i++) {
      if (questionType && questionType !== 'all' && questionType !== 'per_type') {
        requestedTypes.push(questionType as QuestionType);
      } else {
        requestedTypes.push(cycleTypes[i % cycleTypes.length]);
      }
    }
  }

  // Contextual scenarios at school for rich variety
  const studentNames = [
    ['Ahmad', 'Salman'],
    ['Siti', 'Fatimah'],
    ['Rizky', 'Farhan'],
    ['Aisyah', 'Nabila'],
    ['Zaid', 'Bilal'],
    ['Hasan', 'Husain']
  ];

  const lowerTopic = cleanTopic.toLowerCase();
  let domain = "Al-Qur'an & Hadis";
  let arabicSnippet = 'فَذَٰلِكَ الَّذِي يَدُعُّ الْيَتِيمَ ۝ وَلَا يَحُضُّ عَلَىٰ طَعَامِ الْمِسْكِينِ';

  if (lowerTopic.includes('asmaul') || lowerTopic.includes('iman') || lowerTopic.includes('kitab') || lowerTopic.includes('malaikat') || lowerTopic.includes('qadha') || lowerTopic.includes('takdir')) {
    domain = 'Akidah';
    arabicSnippet = 'إِنَّ اللَّهَ هُوَ الرَّزَّاقُ ذُو الْقُوَّةِ الْمَتِينُ';
  } else if (lowerTopic.includes('wudhu') || lowerTopic.includes('shalat') || lowerTopic.includes('puasa') || lowerTopic.includes('zakat') || lowerTopic.includes('infaq') || lowerTopic.includes('halal')) {
    domain = 'Fikih';
    arabicSnippet = 'وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ وَارْكَعُوا مَعَ الرَّاكِعِينَ';
  } else if (lowerTopic.includes('nabi') || lowerTopic.includes('rasul') || lowerTopic.includes('khalifah') || lowerTopic.includes('hijrah') || lowerTopic.includes('madinah') || lowerTopic.includes('makkah')) {
    domain = 'Sejarah Peradaban Islam';
    arabicSnippet = 'لَّقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ';
  } else if (lowerTopic.includes('akhlak') || lowerTopic.includes('hormat') || lowerTopic.includes('santun') || lowerTopic.includes('keragaman') || lowerTopic.includes('tetangga') || lowerTopic.includes('lingkungan')) {
    domain = 'Akhlak';
    arabicSnippet = 'وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ ۖ وَلَا تَعَاوَنُوا عَلَى الْإِثْمِ وَالْعُدْوَانِ';
  } else if (lowerTopic.includes('fatihah')) {
    domain = "Al-Qur'an & Hadis";
    arabicSnippet = 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ';
  } else if (lowerTopic.includes('tin')) {
    domain = "Al-Qur'an & Hadis";
    arabicSnippet = 'لَقَدْ خَلَقْنَا الْإِنسَانَ فِي أَحْسَنِ تَقْوِيمٍ';
  } else if (lowerTopic.includes('hujurat')) {
    domain = "Al-Qur'an & Hadis";
    arabicSnippet = 'يَا أَيُّهَا النَّاسُ إِنَّا خَلَقْنَاكُم مِّن ذَكَرٍ وَأُنثَىٰ وَجَعَلْنَاكُمْ شُعُوبًا وَقَبَائِلَ لِتَعَارَفُوا';
  } else if (lowerTopic.includes('dhuha')) {
    domain = "Al-Qur'an & Hadis";
    arabicSnippet = 'وَالضُّحَىٰ ۝ وَاللَّيْلِ إِذَا سَجَىٰ ۝ مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ';
  }

  const generated: Question[] = [];

  for (let i = 0; i < totalToMake; i++) {
    const targetType = requestedTypes[i] || 'pg_standar';
    const pair = studentNames[i % studentNames.length];
    const [childA, childB] = pair;
    const scenarioIndex = i % 4;

    const stimulusBase =
      scenarioIndex === 0
        ? `Saat kegiatan pembelajaran PAI kelas ${numGrade} di ${sName}, ${childA} dan ${childB} sedang mempelajari materi "${cleanTopic}" bersama Bapak/Ibu Guru PAI dengan suasana penuh kasih sayang dan antusias.`
        : scenarioIndex === 1
        ? `Pada jam istirahat di halaman ${sName}, ${childA} melihat ${childB} membutuhkan bantuan. ${childA} teringat nasihat guru tentang pengamalan materi "${cleanTopic}" dalam kehidupan sehari-hari anak shalih.`
        : scenarioIndex === 2
        ? `Di musholla ${sName}, siswa-siswi kelas ${numGrade} berkumpul untuk melaksanakan pembiasaan ibadah dan tadarus pagi, kemudian mendiskusikan hikmah dari materi "${cleanTopic}".`
        : `Ketika mengerjakan tugas kelompok di kelas ${numGrade} ${sName}, ${childA} mengajak ${childB} serta teman-temannya mengamalkan nilai Kurikulum Berbasis Cinta (KBC) sesuai topik "${cleanTopic}".`;

    if (targetType === 'pg_standar') {
      const opts = [
        `Mengamalkan nilai kasih sayang, kejujuran, dan kepedulian kepada sesama teman sesuai hikmah "${cleanTopic}" dengan ikhlas karena Allah SWT`,
        `Bersikap acuh tak acuh terhadap teman yang mengalami kesulitan di sekolah`,
        `Melakukan kebaikan hanya ketika dilihat dan dipuji oleh guru di kelas`,
        `Menunda-nunda kewajiban belajar dan ibadah untuk bermain bersama teman`
      ];
      generated.push({
        id: `q-kbc-${Date.now().toString(36)}-${i}`,
        questionType: 'pg_standar',
        stimulus: stimulusBase,
        arabicText: arabicSnippet,
        question: `Berdasarkan cerita kontekstual di ${sName} di atas, perilaku terpuji yang paling tepat mencerminkan pemahaman materi "${cleanTopic}" dengan pendekatan Kurikulum Berbasis Cinta (KBC) adalah...`,
        options: opts,
        correctAnswer: opts[0],
        scoreWeight: 10,
        classId: grade,
        className: `Tingkat Kelas ${grade}`,
        semester,
        domain,
        approach: 'Kurikulum Berbasis Cinta (KBC)',
        explanation: `Pengamalan materi "${cleanTopic}" menurut Keputusan Kepala BKPDM Nomor 020 Tahun 2026 menekankan ketulusan hati, kasih sayang kepada sesama, dan akhlak mulia.`
      });
    } else if (targetType === 'pg_kompleks') {
      const opts = [
        `Menolong dan berbagi kepada kawan di ${sName} dengan hati yang tulus dan santun`,
        `Menjaga adab, kebersihan hati, serta ketertiban saat belajar materi "${cleanTopic}"`,
        `Membanggakan diri sendiri dan meremehkan pendapat teman sekelas`,
        `Mengharapkan imbalan atau pujian semata ketika berbuat baik di sekolah`
      ];
      generated.push({
        id: `q-kbc-${Date.now().toString(36)}-${i}`,
        questionType: 'pg_kompleks',
        stimulus: stimulusBase,
        arabicText: arabicSnippet,
        question: `Perhatikan kisah di ${sName} tersebut! Pilihlah DUA pernyataan yang menunjukkan pengamalan nyata dari materi "${cleanTopic}"!`,
        options: opts,
        correctAnswer: [opts[0], opts[1]],
        scoreWeight: 15,
        classId: grade,
        className: `Tingkat Kelas ${grade}`,
        semester,
        domain,
        approach: 'Kurikulum Berbasis Cinta (KBC)',
        explanation: `Dua sikap utama yang wajib diamalkan siswa adalah menolong sesama dengan tulus (ta'awun) serta menjaga adab dalam menuntut ilmu.`
      });
    } else if (targetType === 'benar_salah') {
      const isTrueStatement = i % 2 === 0;
      const statementText = isTrueStatement
        ? `Mengamalkan hikmah materi "${cleanTopic}" dengan penuh kasih sayang, empati, dan saling menghormati antar teman di ${sName} merupakan wujud akhlak mulia anak shalih.`
        : `Dalam mempelajari "${cleanTopic}", seorang siswa diperbolehkan bersikap sombong dan mengabaikan teman yang membutuhkan pertolongan di sekolah.`;
      generated.push({
        id: `q-kbc-${Date.now().toString(36)}-${i}`,
        questionType: 'benar_salah',
        stimulus: stimulusBase,
        arabicText: arabicSnippet,
        question: `Tentukan apakah pernyataan berikut BENAR atau SALAH berdasarkan materi "${cleanTopic}": "${statementText}"`,
        options: ['Benar', 'Salah'],
        correctAnswer: isTrueStatement ? 'Benar' : 'Salah',
        scoreWeight: 10,
        classId: grade,
        className: `Tingkat Kelas ${grade}`,
        semester,
        domain,
        approach: 'Kurikulum Berbasis Cinta (KBC)',
        explanation: isTrueStatement
          ? `Pernyataan tersebut BENAR karena ajaran Islam dan pendekatan KBC menuntun siswa untuk selalu menyayangi dan menghormati sesama.`
          : `Pernyataan tersebut SALAH karena Islam melarang sikap sombong dan memerintahkan kita saling menolong dalam kebaikan.`
      });
    } else if (targetType === 'menjodohkan') {
      const pairs = [
        {
          left: `Sikap ${childA} membantu teman yang kesulitan saat mempelajari ${cleanTopic}`,
          right: `Ta'awun (Tolong-menolong dalam kebaikan)`
        },
        {
          left: `Melaksanakan ibadah dan belajar di ${sName} semata-mata mengharap ridha Allah SWT`,
          right: `Ikhlas (Kemurnian hati karena Allah)`
        },
        {
          left: `Berbicara sopan dan mendengarkan penjelasan Guru PAI dengan penuh takzim`,
          right: `Tawadhu & Adab Menuntut Ilmu`
        }
      ];
      generated.push({
        id: `q-kbc-${Date.now().toString(36)}-${i}`,
        questionType: 'menjodohkan',
        stimulus: stimulusBase,
        arabicText: arabicSnippet,
        question: `Jodohkanlah pernyataan perilaku keseharian siswa di ${sName} pada lajur kiri dengan istilah nilai budi pekerti PAI ("${cleanTopic}") yang tepat pada lajur kanan!`,
        matchingPairs: pairs,
        options: pairs.map(p => `${p.left} ➔ ${p.right}`),
        correctAnswer: pairs.map(p => `${p.left} = ${p.right}`),
        scoreWeight: 15,
        classId: grade,
        className: `Tingkat Kelas ${grade}`,
        semester,
        domain,
        approach: 'Kurikulum Berbasis Cinta (KBC)',
        explanation: `Setiap perilaku terpuji pada lajur kiri berpasangan langsung dengan konsep akhlak mulia dalam materi "${cleanTopic}" (Ta'awun, Ikhlas, dan Adab Menuntut Ilmu).`
      });
    } else if (targetType === 'isian_singkat') {
      let shortQuestion = `Sikap saling menolong dalam kebaikan dan ketakwaan antar sesama teman di ${sName} sebagaimana diajarkan dalam materi "${cleanTopic}" disebut dengan istilah...`;
      let shortKey = "Ta'awun / Tolong-menolong / Ikhlas";

      if (lowerTopic.includes('ma\'un') || lowerTopic.includes('yatim')) {
        shortQuestion = `Berdasarkan Surah Al-Ma'un yang dipelajari di ${sName}, orang yang menghardik anak yatim dan enggan memberi makan orang miskin disebut sebagai pendusta...`;
        shortKey = 'Agama / Ad-Din';
      } else if (lowerTopic.includes('asmaul')) {
        shortQuestion = `Nama-nama Allah SWT yang indah dan agung yang wajib diteladani oleh siswa ${sName} dalam materi "${cleanTopic}" disebut...`;
        shortKey = 'Asmaul Husna';
      } else if (lowerTopic.includes('wudhu') || lowerTopic.includes('shalat')) {
        shortQuestion = `Bersuci menggunakan air yang suci lagi menyucikan sebelum melaksanakan ibadah shalat di musholla ${sName} disebut...`;
        shortKey = 'Wudhu / Berwudhu / Thaharah';
      } else if (lowerTopic.includes('nabi') || lowerTopic.includes('muhammad')) {
        shortQuestion = `Gelar mulia yang diberikan masyarakat Makkah kepada Nabi Muhammad SAW karena kejujuran dan sifat dapat dipercaya beliau adalah...`;
        shortKey = 'Al-Amin';
      }

      generated.push({
        id: `q-kbc-${Date.now().toString(36)}-${i}`,
        questionType: 'isian_singkat',
        stimulus: stimulusBase,
        arabicText: arabicSnippet,
        question: shortQuestion,
        options: [],
        correctAnswer: shortKey,
        scoreWeight: 10,
        classId: grade,
        className: `Tingkat Kelas ${grade}`,
        semester,
        domain,
        approach: 'Kurikulum Berbasis Cinta (KBC)',
        explanation: `Jawaban singkat yang tepat untuk pertanyaan konsep inti materi "${cleanTopic}" adalah: ${shortKey}.`
      });
    } else {
      // essay
      generated.push({
        id: `q-kbc-${Date.now().toString(36)}-${i}`,
        questionType: 'essay',
        stimulus: stimulusBase,
        arabicText: arabicSnippet,
        question: `Tuliskan 3 contoh nyata perilaku kasih sayang dan budi pekerti yang dapat kamu amalkan di ${sName} maupun di rumah setelah mempelajari materi "${cleanTopic}"!`,
        options: [],
        correctAnswer: `1. Menyayangi dan membantu teman tanpa membeda-bedakan; 2. Berbicara santun kepada guru dan orang tua; 3. Melaksanakan ibadah dan mengamalkan materi "${cleanTopic}" dengan ikhlas.`,
        scoreWeight: 20,
        classId: grade,
        className: `Tingkat Kelas ${grade}`,
        semester,
        domain,
        approach: 'Kurikulum Berbasis Cinta (KBC)',
        explanation: `Siswa mampu menguraikan minimal 3 contoh penerapan nyata materi "${cleanTopic}" dalam keseharian di sekolah dan di rumah.`
      });
    }
  }

  return generated;
}

/**
 * Service call to generate AI questions.
 * Tries server endpoint first (Gemini), falls back seamlessly to the rich local KBC engine.
 */
export async function generateAiQuestions(params: GenerateQuestionsParams): Promise<{
  source: 'gemini' | 'engine-kbc';
  questions: Question[];
}> {
  try {
    const res = await fetch('/api/generate-questions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.questions) && data.questions.length > 0) {
        return {
          source: data.source || 'gemini',
          questions: data.questions
        };
      }
    }
  } catch (err) {
    console.info('Server AI endpoint unavailable or using offline fallback:', err);
  }

  // Graceful, rich fallback generator
  const localQuestions = generateLocalKbcQuestions(params);
  return {
    source: 'engine-kbc',
    questions: localQuestions
  };
}
