import { RemedialRecommendation, RemedialWeakQuiz } from '../types';
import { StorageService } from './storageService';

interface DomainKbcTemplate {
  domain: string;
  keywords: string[];
  gradeMaterials: Record<
    string,
    {
      title: string;
      summary: string;
      keyPoints: string[];
      arabicVerse: string;
      arabicTranslation: string;
      kbcReflection: string;
      assignmentTitle: string;
      assignmentType:
        | 'Praktik Ibadah & Pembiasaan'
        | 'Lembar Kerja Terarah (LKPD Remedial)'
        | 'Proyek Kasih Sayang (KBC) & Akhlak'
        | 'Tadarus & Hafalan Terbimbing';
      instructions: string[];
      targetCompetency: string;
      parentGuidance: string;
    }
  >;
}

const DOMAIN_TEMPLATES: DomainKbcTemplate[] = [
  {
    domain: 'Al-Qur\'an & Hadis',
    keywords: ['qur\'an', 'surah', 'ayat', 'ma\'un', 'falaq', 'nas', 'ikhlas', 'fatihah', 'kafirun', 'hujurat', 'hadis', 'tajwid', 'hijaiyah', 'tadarus'],
    gradeMaterials: {
      default: {
        title: 'Menguatkan Cinta Al-Qur\'an & Kepedulian Sosial (Surah Al-Ma\'un & Juz Amma)',
        summary:
          'Materi remedial ini dirancang dengan pendekatan Kurikulum Berbasis Cinta (KBC) untuk membantu ananda memahami pesan kasih sayang di dalam surah-surah pilihan Al-Qur\'an. Membaca Al-Qur\'an dengan tartil harus diiringi dengan empati tulus kepada anak yatim, fakir miskin, dan teman sebaya yang membutuhkan pertolongan.',
        keyPoints: [
          'Membaca ayat demi ayat secara perlahan (tartil) dengan memperhatikan panjang-pendek (mad) dan dengung (ghunnah).',
          'Memahami makna larangan menghardik anak yatim dan kewajiban berbagi barang berguna (Al-Ma\'un) kepada teman.',
          'Menjaga ketepatan waktu dan kekhusyukan shalat agar terhindar dari sifat lalai (sahūn) maupun riya.'
        ],
        arabicVerse: 'أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ ۝ فَذَٰلِكَ الَّذِي يَدُعُّ الْيَتِيمَ ۝ وَلَا يَحُضُّ عَلَىٰ طَعَامِ الْمِسْكِينِ',
        arabicTranslation:
          'Tahukah kamu (orang) yang mendustakan agama? Maka itulah orang yang menghardik anak yatim, dan tidak mendorong memberi makan orang miskin. (QS. Al-Ma\'un: 1-3)',
        kbcReflection:
          'Setiap huruf Al-Qur\'an yang kamu baca dengan penuh cinta akan menerangi hatimu dan melipatgandakan kebaikanmu, meskipun kamu masih terus berlatih!',
        assignmentTitle: 'Tadarus Berpasangan & Jurnal Aksi Berbagi Kasih (KBC)',
        assignmentType: 'Tadarus & Hafalan Terbimbing',
        instructions: [
          'Bacalah kembali surah pendek pilihan bersama orang tua atau teman sebangku sebanyak 3 kali dengan tartil.',
          'Tuliskan 3 contoh perbuatan nyata menolong teman di sekolah yang sesuai dengan pesan surah tersebut.',
          'Lakukan 1 aksi berbagi (meminjamkan alat tulis, berbagi bekal, atau bersedekah) dan ceritakan perasaan bahagiamu di buku catatan PAI.'
        ],
        targetCompetency:
          'Mampu membaca, mengartikan, dan mengamalkan pesan pokok surah pendek Al-Qur\'an dengan tartil dan sikap peduli sesama sesuai CP/ATP Kep. Kepala BKPDM No. 020 Tahun 2026.',
        parentGuidance:
          'Mohon Ayah/Bunda menyimak bacaan surah pendek ananda selama 10 menit selepas shalat Maghrib dengan suasana hangat, memberi pujian atas keberaniannya, dan membimbing pelafalan huruf yang belum tepat.'
      },
      faseA: {
        title: 'Mengenal Huruf Hijaiyah Bersambung & Cinta Surah Al-Fatihah / Al-Ikhlas',
        summary:
          'Melalui pendekatan Kurikulum Berbasis Cinta (KBC), ananda diajak mengenal keindahan huruf-huruf Al-Qur\'an dan melafalkan Surah Al-Fatihah serta Surah Al-Ikhlas dengan gembira. Mengenal tanda baca harakat (fathah, kasrah, dhammah) membuat kita semakin dekat dengan kalam kasih sayang Allah SWT.',
        keyPoints: [
          'Membedakan bentuk huruf hijaiyah di awal, tengah, dan akhir kata beserta tanda baca harakatnya.',
          'Melafalkan Surah Al-Fatihah dan Surah Al-Ikhlas ayat demi ayat dengan makhraj yang jelas.',
          'Meyakini bahwa Allah Maha Pengasih (Ar-Rahman) dan Maha Penyayang (Ar-Rahim) kepada anak yang rajin mengaji.'
        ],
        arabicVerse: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
        arabicTranslation:
          'Dengan nama Allah Yang Maha Pengasih, Maha Penyayang. Segala puji bagi Allah, Tuhan seluruh alam. (QS. Al-Fatihah: 1-2)',
        kbcReflection:
          'Allah sangat mencintai anak shalih yang mau belajar mengeja huruf Al-Qur\'an sedikit demi sedikit dengan senyum dan kesabaran.',
        assignmentTitle: 'Kartu Ceria Huruf Hijaiyah & Setoran Hafalan Kasih Sayang',
        assignmentType: 'Tadarus & Hafalan Terbimbing',
        instructions: [
          'Tirukan bacaan Surah Al-Fatihah dan Al-Ikhlas bersama Ayah/Bunda di rumah sebanyak 3 kali.',
          'Warnai dan pasangkan 5 kata huruf hijaiyah berharakat fathah, kasrah, dan dhammah pada buku latihan PAI.',
          'Setorkan bacaanmu di depan Guru PAI dengan penuh percaya diri.'
        ],
        targetCompetency:
          'Mampu melafalkan huruf hijaiyah berharakat dan membaca surah pendek Fase A dengan benar sesuai CP/ATP Kep. Kepala BKPDM No. 020 Tahun 2026.',
        parentGuidance:
          'Dampingi ananda membaca huruf hijaiyah menggunakan jari telunjuk secara perlahan dan berikan pelukan apresiasi setiap selesai membaca satu ayat.'
      }
    }
  },
  {
    domain: 'Akidah',
    keywords: ['iman', 'asmaul', 'husna', 'malaikat', 'rasul', 'kitab', 'hari akhir', 'qada', 'qadar', 'allah', 'pencipta', 'qawiyyu', 'qayyum'],
    gradeMaterials: {
      default: {
        title: 'Meneladani Keindahan Asmaul Husna & Menguatkan Rukun Iman',
        summary:
          'Materi penguatan Akidah berbasis Kurikulum Berbasis Cinta (KBC) ini membimbing ananda merasakan kehadiran dan kasih sayang Allah SWT melalui sifat-sifat mulia-Nya (Asmaul Husna). Ketika kita mengenal Allah Yang Maha Kuat (Al-Qawiyyu), Maha Mandiri (Al-Qayyum), dan Maha Pengasih, hati kita menjadi tenang, mandiri, dan gemar berbuat kebaikan.',
        keyPoints: [
          'Memahami arti dan bukti keagungan Asmaul Husna dalam keteraturan alam semesta dan kehidupan sehari-hari.',
          'Meneladani sifat mandiri (Al-Qayyum) dengan menyiapkan perlengkapan sekolah sendiri tanpa mengeluh.',
          'Menggunakan kekuatan diri (keteladanan Al-Qawiyyu) untuk melindungi dan membantu teman yang lemah.'
        ],
        arabicVerse: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ',
        arabicTranslation:
          'Allah, tidak ada Tuhan selain Dia, Yang Maha Hidup, Yang terus-menerus mengurus (makhluk-Nya). (QS. Al-Baqarah: 255)',
        kbcReflection:
          'Mengenal Allah membuat hati kita penuh harapan. Kamu adalah anak hebat yang diberi kekuatan oleh Allah untuk terus tumbuh menjadi pribadi mandiri dan penyayang.',
        assignmentTitle: 'Jurnal Keteladanan Asmaul Husna & Peta Konsep Rukun Iman',
        assignmentType: 'Lembar Kerja Terarah (LKPD Remedial)',
        instructions: [
          'Buatlah tabel sederhana berisi 3 Asmaul Husna yang dipelajari beserta artinya dengan tulisan yang rapi.',
          'Tuliskan masing-masing 1 contoh sikap mandiri di rumah dan 1 contoh sikap menolong teman di sekolah sebagai wujud meneladani Asmaul Husna.',
          'Ceritakan kepada guru bagaimana perasaanmu setelah berusaha mandiri menyiapkan buku pelajaran sendiri.'
        ],
        targetCompetency:
          'Memahami makna Asmaul Husna dan pokok keimanan serta menampilkannya dalam perilaku mandiri dan kasih sayang sesuai CP/ATP Kep. Kepala BKPDM No. 020 Tahun 2026.',
        parentGuidance:
          'Berikan kesempatan kepada ananda untuk merapikan tempat tidur atau tas sekolahnya sendiri, lalu berikan apresiasi bahwa sikap tersebut dicintai Allah SWT.'
      }
    }
  },
  {
    domain: 'Fikih',
    keywords: ['wudhu', 'shalat', 'ibadah', 'thaharah', 'tayammum', 'puasa', 'zakat', 'infaq', 'sedekah', 'adzan', 'iqamah', 'bersuci', 'dzikir'],
    gradeMaterials: {
      default: {
        title: 'Panduan Praktis Bersuci (Thaharah) & Tertib Shalat Penuh Cinta',
        summary:
          'Dalam pendekatan Kurikulum Berbasis Cinta (KBC), ibadah wudhu dan shalat bukan sekadar kewajiban, melainkan saat terindah seorang hamba berdialog dengan Allah SWT. Materi remedial ini memandu langkah demi langkah urutan rukun wudhu dan bacaan/gerakan shalat secara visual, tertib, dan khusyuk.',
        keyPoints: [
          'Menghafal urutan 6 rukun wudhu secara tertib: Niat, membasuh wajah, membasuh kedua tangan hingga siku, mengusap sebagian kepala, membasuh kaki hingga mata kaki, dan tertib.',
          'Menjaga adab hemat air saat berwudhu sebagai wujud cinta lingkungan.',
          'Melaksanakan gerakan dan bacaan shalat secara tuma\'ninah (tenang, tidak tergesa-gesa) dan berjamaah.'
        ],
        arabicVerse: 'وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ وَارْكَعُوا مَعَ الرَّاكِعِينَ',
        arabicTranslation:
          'Dan laksanakanlah shalat, tunaikanlah zakat, dan rukuklah beserta orang-orang yang rukuk. (QS. Al-Baqarah: 43)',
        kbcReflection:
          'Air wudhu membersihkan wajah dan anggota tubuhmu, sedangkan shalat yang tenang menyejukkan hatimu. Mari berlatih bersama dengan gembira!',
        assignmentTitle: 'Praktik Terbimbing Urutan Wudhu & Kartu Ceklis Shalat Harian',
        assignmentType: 'Praktik Ibadah & Pembiasaan',
        instructions: [
          'Urutkan kembali langkah-langkah rukun wudhu dari niat hingga tertib pada lembar kerja remedial.',
          'Praktikkan gerakan wudhu dan bacaan shalat di depan orang tua atau Guru PAI dengan tenang (tuma\'ninah).',
          'Isi tabel ceklis pelaksanaan shalat 5 waktu selama 3 hari berturut-turut dengan ditandatangani orang tua.'
        ],
        targetCompetency:
          'Memahami ketentuan dan mempraktikkan tata cara bersuci (wudhu) serta ibadah shalat secara tertib dan khusyuk sesuai CP/ATP Kep. Kepala BKPDM No. 020 Tahun 2026.',
        parentGuidance:
          'Ajaklah ananda berwudhu dan shalat berjamaah bersama di rumah, sambil mengingatkan urutan basuhan wudhu dengan nada lembut dan penuh kasih sayang.'
      }
    }
  },
  {
    domain: 'Akhlak',
    keywords: ['akhlak', 'adab', 'jujur', 'sopan', 'santun', 'orang tua', 'guru', 'teman', 'ta\'awun', 'toleransi', 'hormat', 'budi pekerti', 'salam', 'maaf'],
    gradeMaterials: {
      default: {
        title: 'Indahnya Akhlak Mulia: Ta\'awun, Santun kepada Guru & Menyayangi Teman',
        summary:
          'Inti dari Kurikulum Berbasis Cinta (KBC) adalah memuliakan sesama manusia dengan akhlakul karimah. Materi remedial ini mengajak ananda memahami pentingnya berkata santun (qaulan karima) kepada orang tua dan guru, gemar tolong-menolong (ta\'awun), serta berjiwa besar untuk meminta maaf dan memaafkan teman.',
        keyPoints: [
          'Mengucapkan salam, tersenyum, dan mencium tangan orang tua serta guru sebagai wujud takzim dan cinta.',
          'Mengamalkan sikap ta\'awun (tolong-menolong dalam kebaikan) saat ada teman yang kesulitan di kelas.',
          'Membiasakan tiga kata ajaib penuh berkah: "Tolong", "Maaf", dan "Terima Kasih".'
        ],
        arabicVerse: 'وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ ۖ وَلَا تَعَاوَنُوا عَلَى الْإِثْمِ وَالْعُدْوَانِ',
        arabicTranslation:
          'Dan tolong-menolonglah kamu dalam (mengerjakan) kebajikan dan takwa, dan jangan tolong-menolong dalam berbuat dosa dan permusuhan. (QS. Al-Maidah: 2)',
        kbcReflection:
          'Kebaikan sekecil apa pun yang kamu lakukan dengan tulus kepada orang tua, guru, dan teman akan dicatat oleh malaikat sebagai amal cinta yang mulia.',
        assignmentTitle: 'Proyek Harian Duta Kasih Sayang & Refleksi Budi Pekerti (KBC)',
        assignmentType: 'Proyek Kasih Sayang (KBC) & Akhlak',
        instructions: [
          'Tuliskan 3 adab mulia kepada orang tua di rumah dan 3 adab mulia kepada guru di sekolah.',
          'Lakukan 2 aksi kebaikan membantu orang tua di rumah dan membantu teman di kelas hari ini.',
          'Tuliskan cerita pendek (4-5 kalimat) tentang pengalamanmu menolong atau memaafkan teman di sekolah.'
        ],
        targetCompetency:
          'Menunjukkan perilaku hormat dan patuh kepada orang tua serta guru, dan sikap saling menghargai serta tolong-menolong sesama teman sesuai CP/ATP Kep. Kepala BKPDM No. 020 Tahun 2026.',
        parentGuidance:
          'Berikan teladan tutur kata lembut di rumah dan berikan apresiasi tertulis singkat pada lembar tugas ananda saat ia membantu pekerjaan ringan di rumah.'
      }
    }
  },
  {
    domain: 'Sejarah Peradaban Islam',
    keywords: ['nabi', 'rasul', 'muhammad', 'kisah', 'sejarah', 'sahabat', 'hijrah', 'khulafaur', 'rasyidin', 'wali', 'songo', 'keteladanan', 'al-amin'],
    gradeMaterials: {
      default: {
        title: 'Meneladani Kejujuran & Kasih Sayang Rasulullah SAW (Uswatun Hasanah)',
        summary:
          'Kisah perjuangan Nabi Muhammad SAW dan para nabi pilihan sarat dengan pesan kesabaran, kejujuran (Al-Amin), dan kasih sayang kepada seluruh umat. Melalui materi remedial berbasis KBC ini, ananda diajak mengambil hikmah dari kisah teladan Nabi untuk diterapkan dalam kejujuran belajar dan pergaulan di sekolah.',
        keyPoints: [
          'Memahami alasan Nabi Muhammad SAW diberi gelar Al-Amin (orang yang dapat dipercaya) karena kejujurannya.',
          'Meneladani kesabaran dan sifat pemaaf Rasulullah SAW ketika menghadapi cobaan dalam berdakwah.',
          'Menerapkan nilai amanah dan tanggung jawab saat mengerjakan tugas maupun menjaga barang milik bersama.'
        ],
        arabicVerse: 'لَّقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ',
        arabicTranslation:
          'Sungguh, telah ada pada (diri) Rasulullah itu suri teladan yang baik bagimu. (QS. Al-Ahzab: 21)',
        kbcReflection:
          'Rasulullah SAW sangat menyayangi anak-anak yang jujur dan pemaaf. Setiap kali kamu berkata jujur, kamu sedang mengikuti jejak mulia beliau!',
        assignmentTitle: 'Jejak Keteladanan Nabi & Cerita Hikmah Anak Jujur',
        assignmentType: 'Lembar Kerja Terarah (LKPD Remedial)',
        instructions: [
          'Bacalah kembali ringkasan kisah keteladanan Nabi pada modul remedial ini dengan saksama.',
          'Sebutkan 3 sifat mulia Rasulullah SAW atau Nabi yang sedang dipelajari beserta contoh penerapannya di sekolah.',
          'Buatlah kartu komitmen singkat: "Aku Berjanji Menjadi Anak Jujur & Penyayang seperti Rasulullah SAW".'
        ],
        targetCompetency:
          'Memahami kisah keteladanan Nabi dan Rasul serta mengimplementasikan hikmah kejujuran, kesabaran, dan kasih sayang dalam keseharian sesuai CP/ATP Kep. Kepala BKPDM No. 020 Tahun 2026.',
        parentGuidance:
          'Bacakan atau diskusikan kisah teladan Nabi menjelang waktu istirahat malam selama 10 menit dan tanyakan hikmah kebaikan apa yang paling disukai ananda.'
      }
    }
  }
];

export function inferPaiDomain(quizTitle: string, gradeLevel: string = '5'): string {
  const lower = (quizTitle || '').toLowerCase();
  for (const tpl of DOMAIN_TEMPLATES) {
    if (tpl.keywords.some(k => lower.includes(k))) {
      return tpl.domain;
    }
  }
  const topics = StorageService.getClassTopics(gradeLevel);
  if (topics.length > 0) {
    return topics[0].domain;
  }
  return 'Al-Qur\'an & Hadis';
}

export function buildLocalKbcRemedialPlan(params: {
  studentId: string;
  studentName: string;
  nis: string;
  classId: string;
  className: string;
  gradeLevel: string;
  currentAvg: number;
  kktpThreshold: number;
  quizCount: number;
  weakQuizzes: RemedialWeakQuiz[];
  schoolName?: string;
}): RemedialRecommendation {
  const {
    studentId,
    studentName,
    nis,
    classId,
    className,
    gradeLevel,
    currentAvg,
    kktpThreshold,
    quizCount,
    weakQuizzes
  } = params;

  const primaryDomain =
    weakQuizzes.length > 0 ? weakQuizzes[0].domain : inferPaiDomain('', gradeLevel);

  const matchedDomainTpl =
    DOMAIN_TEMPLATES.find(d => d.domain === primaryDomain) || DOMAIN_TEMPLATES[0];

  const isFaseA = gradeLevel === '1' || gradeLevel === '2';
  const matTemplate =
    isFaseA && matchedDomainTpl.gradeMaterials.faseA
      ? matchedDomainTpl.gradeMaterials.faseA
      : matchedDomainTpl.gradeMaterials.default;

  const kktpCategory: RemedialRecommendation['kktpCategory'] =
    quizCount === 0
      ? 'Belum Mengikuti Evaluasi'
      : currentAvg <= 60
      ? 'Perlu Bimbingan (0-60)'
      : 'Cukup / Mendekati KKTP (61-74)';

  const gapPoints = Math.max(0, kktpThreshold - currentAvg);
  const weakQuizNames = weakQuizzes.map(w => w.quizTitle).join(', ');

  let diagnosticSummary = '';
  if (quizCount === 0) {
    diagnosticSummary = `Berdasarkan analisis otomatis nilai kelas ${className}, ananda ${studentName} belum memiliki rekaman nilai evaluasi kuis pada elemen ${primaryDomain}. Melalui pendekatan Kurikulum Berbasis Cinta (KBC), guru disarankan memberikan pendampingan pengenalan materi esensial secara personal dan penugasan bertahap tanpa tekanan agar ananda percaya diri mengikuti evaluasi susulan.`;
  } else if (currentAvg <= 60) {
    diagnosticSummary = `Capaian rata-rata ananda ${studentName} (${currentAvg}) berada pada kategori "Perlu Bimbingan (0-60)" dengan selisih ${gapPoints} poin dari standar KKTP (${kktpThreshold}), khususnya pada evaluasi ${weakQuizNames || primaryDomain}. Diperlukan bimbingan remedial terstruktur dengan scaffolding cerita kontekstual KBC serta penugasan praktik terbimbing bersama orang tua.`;
  } else {
    diagnosticSummary = `Capaian rata-rata ananda ${studentName} (${currentAvg}) berada pada kategori "Cukup / Mendekati KKTP" (hanya terpaut ${gapPoints} poin dari batas ketuntasan ${kktpThreshold}) pada elemen ${primaryDomain} (${weakQuizNames || 'Evaluasi Formatif'}). Penguatan ringkasan poin kunci dan satu penugasan pengayaan terarah akan sangat efektif mengantarkan ananda mencapai ketuntasan penuh.`;
  }

  return {
    id: `rem-${studentId}`,
    studentId,
    studentName,
    nis,
    classId,
    className,
    gradeLevel,
    currentAvg,
    kktpThreshold,
    gapPoints,
    kktpCategory,
    weakQuizzes,
    primaryDomain,
    diagnosticSummary,
    remedialMaterial: {
      title: matTemplate.title,
      domain: primaryDomain,
      summary: matTemplate.summary,
      keyPoints: matTemplate.keyPoints,
      arabicVerse: matTemplate.arabicVerse,
      arabicTranslation: matTemplate.arabicTranslation,
      kbcReflection: matTemplate.kbcReflection
    },
    specialAssignment: {
      title: matTemplate.assignmentTitle,
      type: matTemplate.assignmentType,
      instructions: matTemplate.instructions,
      targetCompetency: matTemplate.targetCompetency,
      deadlineDays: quizCount === 0 || currentAvg <= 60 ? 5 : 3,
      parentGuidance: matTemplate.parentGuidance,
      evaluationRubric: `Ketuntasan Remedial KKTP (${kktpThreshold}): Pemahaman Konsep Inti (40%), Praktik/Kejujuran Pengerjaan (40%), dan Refleksi Sikap Kasih Sayang KBC (20%).`
    },
    status: 'recommended',
    source: 'engine-kbc',
    createdAt: new Date().toISOString()
  };
}

/**
 * Secara otomatis memindai seluruh nilai siswa di semua kelas terhadap ambang KKTP,
 * menggabungkannya dengan rencana remedial yang sudah tersimpan di StorageService (IndexedDB/Supabase),
 * serta menyusun rekomendasi materi remedial & penugasan khusus bagi siswa yang belum tuntas.
 */
export function analyzeAllStudentsKktp(kktpThreshold: number = 75): {
  recommendations: RemedialRecommendation[];
  totalStudents: number;
  passedCount: number;
  belowKktpCount: number;
  noQuizCount: number;
  assignedCount: number;
  avgGap: number;
  domainBreakdown: Record<string, number>;
} {
  const classes = StorageService.getClasses();
  const savedPlans = StorageService.getRemedialPlans();
  const savedMap = new Map<string, RemedialRecommendation>();
  savedPlans.forEach(p => savedMap.set(p.studentId, p));

  let totalStudents = 0;
  let passedCount = 0;
  let belowKktpCount = 0;
  let noQuizCount = 0;
  const domainBreakdown: Record<string, number> = {};
  const recommendations: RemedialRecommendation[] = [];

  classes.forEach(cls => {
    const gradeLevel = cls.className.replace(/[^0-9]/g, '') || '5';
    const recap = StorageService.getClassRecap(cls.id);

    recap.students.forEach(st => {
      totalStudents++;

      // Identify individual weak quizzes (< kktpThreshold or null)
      const weakQuizzes: RemedialWeakQuiz[] = [];
      recap.quizzes.forEach(q => {
        const sc = st.quizScores[q.id];
        if (sc === null || sc === undefined || sc < kktpThreshold) {
          weakQuizzes.push({
            quizId: q.id,
            quizTitle: q.title,
            score: sc !== undefined ? sc : null,
            domain: inferPaiDomain(q.title, gradeLevel)
          });
        }
      });

      if (st.quizCount === 0) {
        noQuizCount++;
        return;
      }

      if (st.avg >= kktpThreshold) {
        passedCount++;
        return;
      }

      belowKktpCount++;

      // Check if we already have a stored plan (e.g., Gemini-generated or already assigned)
      const existing = savedMap.get(st.id);
      let plan: RemedialRecommendation;

      if (existing) {
        const gapPoints = Math.max(0, kktpThreshold - st.avg);
        const kktpCategory: RemedialRecommendation['kktpCategory'] =
          st.quizCount === 0
            ? 'Belum Mengikuti Evaluasi'
            : st.avg <= 60
            ? 'Perlu Bimbingan (0-60)'
            : 'Cukup / Mendekati KKTP (61-74)';

        plan = {
          ...existing,
          currentAvg: st.avg,
          kktpThreshold,
          gapPoints,
          kktpCategory,
          weakQuizzes: weakQuizzes.length > 0 ? weakQuizzes : existing.weakQuizzes
        };
      } else {
        plan = buildLocalKbcRemedialPlan({
          studentId: st.id,
          studentName: st.name,
          nis: st.nis,
          classId: cls.id,
          className: cls.className,
          gradeLevel,
          currentAvg: st.avg,
          kktpThreshold,
          quizCount: st.quizCount,
          weakQuizzes
        });
      }

      domainBreakdown[plan.primaryDomain] = (domainBreakdown[plan.primaryDomain] || 0) + 1;
      recommendations.push(plan);
    });
  });

  // Sort: lowest avg first so students needing the most attention appear at top
  recommendations.sort((a, b) => a.currentAvg - b.currentAvg);

  const assignedCount = recommendations.filter(r => r.status === 'assigned' || r.status === 'completed').length;
  const totalGap = recommendations.reduce((sum, r) => sum + r.gapPoints, 0);
  const avgGap = recommendations.length > 0 ? Math.round(totalGap / recommendations.length) : 0;

  return {
    recommendations,
    totalStudents,
    passedCount,
    belowKktpCount,
    noQuizCount,
    assignedCount,
    avgGap,
    domainBreakdown
  };
}

/**
 * Meminta analisis mendalam AI (Gemini 3.8 Flash melalui endpoint server `/api/analyze-kktp-remedial`)
 * untuk menyusun materi remedial & penugasan khusus yang terpersonalisasi bagi siswa,
 * dengan fallback otomatis ke mesin diagnostik KBC lokal jika offline.
 */
export async function requestAiDeepRemedialAnalysis(
  rec: RemedialRecommendation,
  schoolName: string = 'SDN Ciketing Udik 2 Bantargebang'
): Promise<RemedialRecommendation> {
  try {
    const res = await fetch('/api/analyze-kktp-remedial', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        studentName: rec.studentName,
        className: rec.className,
        gradeLevel: rec.gradeLevel,
        currentAvg: rec.currentAvg,
        kktpThreshold: rec.kktpThreshold,
        weakQuizzes: rec.weakQuizzes,
        primaryDomain: rec.primaryDomain,
        schoolName
      })
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success && data.analysis) {
        const aiPlan: RemedialRecommendation = {
          ...rec,
          diagnosticSummary: data.analysis.diagnosticSummary || rec.diagnosticSummary,
          remedialMaterial: {
            title: data.analysis.remedialMaterial?.title || rec.remedialMaterial.title,
            domain: data.analysis.remedialMaterial?.domain || rec.primaryDomain,
            summary: data.analysis.remedialMaterial?.summary || rec.remedialMaterial.summary,
            keyPoints: Array.isArray(data.analysis.remedialMaterial?.keyPoints)
              ? data.analysis.remedialMaterial.keyPoints
              : rec.remedialMaterial.keyPoints,
            arabicVerse: data.analysis.remedialMaterial?.arabicVerse || rec.remedialMaterial.arabicVerse,
            arabicTranslation:
              data.analysis.remedialMaterial?.arabicTranslation || rec.remedialMaterial.arabicTranslation,
            kbcReflection: data.analysis.remedialMaterial?.kbcReflection || rec.remedialMaterial.kbcReflection
          },
          specialAssignment: {
            title: data.analysis.specialAssignment?.title || rec.specialAssignment.title,
            type: data.analysis.specialAssignment?.type || rec.specialAssignment.type,
            instructions: Array.isArray(data.analysis.specialAssignment?.instructions)
              ? data.analysis.specialAssignment.instructions
              : rec.specialAssignment.instructions,
            targetCompetency:
              data.analysis.specialAssignment?.targetCompetency || rec.specialAssignment.targetCompetency,
            deadlineDays: Number(data.analysis.specialAssignment?.deadlineDays) || rec.specialAssignment.deadlineDays,
            parentGuidance: data.analysis.specialAssignment?.parentGuidance || rec.specialAssignment.parentGuidance,
            evaluationRubric:
              data.analysis.specialAssignment?.evaluationRubric || rec.specialAssignment.evaluationRubric
          },
          source: 'gemini',
          createdAt: new Date().toISOString()
        };
        StorageService.saveRemedialPlan(aiPlan);
        return aiPlan;
      }
    }
  } catch (err) {
    console.info('Menggunakan mesin diagnostik KBC lokal untuk analisis remedial:', err);
  }

  // Enrich local recommendation & persist to StorageService (IndexedDB + Supabase)
  const refreshed = buildLocalKbcRemedialPlan({
    studentId: rec.studentId,
    studentName: rec.studentName,
    nis: rec.nis,
    classId: rec.classId,
    className: rec.className,
    gradeLevel: rec.gradeLevel,
    currentAvg: rec.currentAvg,
    kktpThreshold: rec.kktpThreshold,
    quizCount: rec.weakQuizzes.some(q => q.score !== null) ? 1 : 0,
    weakQuizzes: rec.weakQuizzes,
    schoolName
  });

  const finalPlan: RemedialRecommendation = {
    ...refreshed,
    status: rec.status,
    assignedAt: rec.assignedAt,
    assignedMaterialId: rec.assignedMaterialId
  };

  StorageService.saveRemedialPlan(finalPlan);
  return finalPlan;
}
