import React from 'react';
import { Megaphone, Calendar } from 'lucide-react';
import { UserSession } from '../../types';
import { StorageService } from '../../services/storageService';

interface StudentAnnouncementsProps {
  session: UserSession;
}

export const StudentAnnouncements: React.FC<StudentAnnouncementsProps> = ({ session }) => {
  const announcements = StorageService.getAnnouncements(session.classId);

  return (
    <div className="space-y-5">
      <div className="glass rounded-2xl p-5 border border-white/10">
        <h3 className="font-bold text-base text-white flex items-center gap-2 font-display">
          <Megaphone className="w-5 h-5 text-amber-400" /> Papan Pengumuman Kelas {session.className}
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Informasi dan instruksi resmi dari Bapak/Ibu Guru PAI
        </p>
      </div>

      <div className="space-y-3.5">
        {announcements.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center text-slate-400 italic">
            Belum ada pengumuman terbaru.
          </div>
        ) : (
          announcements.map(ann => (
            <div
              key={ann.id}
              className="glass rounded-3xl p-5 sm:p-6 border border-white/10 shadow-md space-y-3"
            >
              <div className="flex items-center justify-between border-b border-white/5 pb-2">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-xs">
                  {ann.targetLabel || 'Semua Siswa'}
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  {new Date(ann.createdAt).toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </span>
              </div>

              <h4 className="font-bold text-base text-white">{ann.title}</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                {ann.body}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
