import React from 'react';
import {
  FileQuestion,
  Megaphone,
  Sparkles,
  ArrowRight,
  Clock,
  CheckCircle2,
  MessageSquare,
  UserCheck
} from 'lucide-react';
import { UserSession } from '../../types';
import { StorageService } from '../../services/storageService';

interface StudentDashboardProps {
  session: UserSession;
  onNavigate: (viewId: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ session, onNavigate }) => {
  const quizzes = StorageService.getQuizzes(session.userId, session.classId);
  const announcements = StorageService.getAnnouncements(session.classId);
  const forumThreads = StorageService.getForumThreads(session.classId);

  const pendingQuizzes = quizzes.filter(q => !q.completed && q.status === 'published');
  const completedQuizzesCount = quizzes.filter(q => q.completed).length;

  return (
    <div className="space-y-6">
      {/* 1. ASSALAMU'ALAIKUM WELCOME BANNER */}
      <div className="relative overflow-hidden rounded-3xl glass-strong border border-emerald-500/25 p-5 sm:p-7 shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" /> Portal Belajar Siswa PAI &amp; Budi Pekerti
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold">
                Kelas {session.className}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
              Assalamu'alaikum, {session.fullName}!
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
              Selamat datang di ruang belajar Pendidikan Agama Islam &amp; Budi Pekerti Kelas{' '}
              <b>{session.className}</b>. Silakan pantau tugas/kuis, ikuti diskusi kelas, dan simak pengumuman terbaru dari Guru PAI di bawah ini.
            </p>
            <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-emerald-400 font-mono">
              <span>
                Username: <b>{session.username}</b>
              </span>
              <span>&bull;</span>
              <span>
                NIS: <b>{session.nis || '-'}</b>
              </span>
              <span>&bull;</span>
              <span>
                Tugas Selesai: <b>{completedQuizzesCount}</b>
              </span>
            </div>
          </div>

          <div className="shrink-0 flex flex-wrap gap-2.5">
            <button
              onClick={() => onNavigate('student-quizzes')}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 flex items-center gap-2 cursor-pointer transition-all active:scale-95"
            >
              <FileQuestion className="w-4 h-4" /> Tugas &amp; Kuis ({pendingQuizzes.length})
            </button>
            <button
              onClick={() => onNavigate('student-forum')}
              className="px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs sm:text-sm border border-white/10 flex items-center gap-2 cursor-pointer transition-all"
            >
              <MessageSquare className="w-4 h-4 text-pink-400" /> Diskusi Kelas ({forumThreads.length})
            </button>
            <button
              onClick={() => onNavigate('student-announcements')}
              className="px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs sm:text-sm border border-white/10 flex items-center gap-2 cursor-pointer transition-all"
            >
              <Megaphone className="w-4 h-4 text-amber-400" /> Pengumuman ({announcements.length})
            </button>
          </div>
        </div>
      </div>

      {/* MAIN CONTENT: TUGAS/KUIS, DISKUSI, DAN PENGUMUMAN */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left & Center Column (2 cols): Tugas/Kuis & Diskusi */}
        <div className="lg:col-span-2 space-y-6">
          {/* 2. TUGAS / KUIS */}
          <div className="glass rounded-3xl p-5 sm:p-6 border border-emerald-500/25 space-y-4 shadow-lg">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <FileQuestion className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white font-display">
                    Tugas &amp; Kuis
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Daftar tugas dan kuis evaluasi PAI Kelas {session.className}
                  </p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('student-quizzes')}
                className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                Lihat Semua <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {pendingQuizzes.length === 0 ? (
              <div className="rounded-2xl bg-white/5 p-7 text-center text-slate-400 border border-white/10">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
                <p className="text-sm font-bold text-white">Alhamdulillah! Semua Tugas &amp; Kuis Selesai</p>
                <p className="text-xs text-slate-400 mt-1">
                  Saat ini tidak ada tugas atau kuis aktif yang belum dikerjakan.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingQuizzes.map(q => (
                  <div
                    key={q.id}
                    className="rounded-2xl bg-slate-900/60 p-4 sm:p-5 border border-white/10 hover:border-emerald-500/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                          Kelas {q.className} &bull; Semester {q.semester}
                        </span>
                      </div>
                      <h4 className="text-sm sm:text-base font-bold text-white">{q.title}</h4>
                      <p className="text-xs text-slate-300 line-clamp-1">{q.description}</p>
                      <div className="flex items-center gap-3 text-xs text-slate-400 pt-1">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-amber-400" /> {q.durationMinutes} Menit
                        </span>
                        <span>&bull;</span>
                        <span className="flex items-center gap-1">
                          <FileQuestion className="w-3.5 h-3.5 text-cyan-400" /> {q.questionIds.length} Soal
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onNavigate('student-quizzes')}
                      className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer shrink-0 transition-all active:scale-95"
                    >
                      Kerjakan Sekarang <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 3. DISKUSI KELAS */}
          <div className="glass rounded-3xl p-5 sm:p-6 border border-pink-500/25 space-y-4 shadow-lg">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-pink-500/20 border border-pink-500/30 flex items-center justify-center text-pink-400">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white font-display">
                    Diskusi Kelas PAI
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Ruang tanya jawab dan diskusi materi PAI Kelas {session.className}
                  </p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('student-forum')}
                className="text-xs font-bold text-pink-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                Buka Forum Diskusi <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {forumThreads.length === 0 ? (
              <div className="rounded-2xl bg-white/5 p-7 text-center text-slate-400 border border-white/10 space-y-2">
                <MessageSquare className="w-9 h-9 text-pink-400 mx-auto opacity-80" />
                <p className="text-sm font-bold text-white">Belum Ada Topik Diskusi di Kelas Ini</p>
                <p className="text-xs text-slate-400">
                  Jadilah yang pertama mengajukan pertanyaan atau memulai diskusi santun bersama Guru PAI dan teman sekelas.
                </p>
                <button
                  onClick={() => onNavigate('student-forum')}
                  className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/30 text-pink-300 text-xs font-bold cursor-pointer transition-all"
                >
                  <MessageSquare className="w-3.5 h-3.5" /> Mulai Diskusi Baru
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {forumThreads.slice(0, 4).map(thread => (
                  <div
                    key={thread.id}
                    onClick={() => onNavigate('student-forum')}
                    className="rounded-2xl bg-slate-900/60 p-4 border border-white/10 hover:border-pink-500/40 transition-all cursor-pointer space-y-1.5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md bg-pink-500/15 border border-pink-500/30 text-pink-300 text-[10px] font-bold">
                          {thread.topicCategory || 'Diskusi PAI'}
                        </span>
                        {thread.isResolved && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                            <UserCheck className="w-3 h-3" /> Dijawab Guru
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400">
                        {thread.replies.length} Balasan
                      </span>
                    </div>
                    <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                      {thread.title}
                    </h4>
                    <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                      {thread.content}
                    </p>
                    <div className="pt-1 flex items-center justify-between text-[11px] text-slate-400">
                      <span>Oleh: <b className="text-slate-300">{thread.authorName}</b></span>
                      <span className="text-pink-300 font-semibold">Ikut Berdiskusi &rarr;</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column (1 col): 4. PENGUMUMAN */}
        <div className="space-y-6">
          <div className="glass rounded-3xl p-5 sm:p-6 border border-amber-500/25 space-y-4 shadow-lg">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <Megaphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white font-display">
                    Pengumuman
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Informasi resmi dari Guru PAI
                  </p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('student-announcements')}
                className="text-xs font-bold text-amber-400 hover:underline cursor-pointer"
              >
                Semua
              </button>
            </div>

            {announcements.length === 0 ? (
              <div className="rounded-2xl bg-white/5 p-6 text-center text-slate-400 border border-white/10">
                <Megaphone className="w-8 h-8 text-amber-400 mx-auto mb-2 opacity-75" />
                <p className="text-xs font-bold text-white">Belum Ada Pengumuman</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Pengumuman terbaru dari Guru PAI akan tampil di sini.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {announcements.slice(0, 5).map(ann => (
                  <div
                    key={ann.id}
                    onClick={() => onNavigate('student-announcements')}
                    className="p-3.5 rounded-2xl bg-slate-900/60 border border-white/10 hover:border-amber-500/40 transition-all cursor-pointer space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-bold">
                        {ann.targetClass === 'Semua Kelas' ? 'Semua Kelas' : `Kelas ${ann.targetClass}`}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {ann.date}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                      {ann.title}
                    </p>
                    <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed">
                      {ann.body}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
