import React from 'react';
import {
  BarChart3,
  Award,
  CheckCircle2,
  Calendar,
  TrendingUp,
  FileQuestion
} from 'lucide-react';
import { UserSession } from '../../types';
import { StorageService } from '../../services/storageService';

interface StudentScoresProps {
  session: UserSession;
}

export const StudentScores: React.FC<StudentScoresProps> = ({ session }) => {
  const scores = StorageService.getStudentScores(session.userId);

  const avg = scores.length
    ? Math.round(scores.reduce((a, b) => a + b.percentage, 0) / scores.length)
    : 0;

  const highest = scores.length ? Math.max(...scores.map(s => s.percentage)) : 0;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="glass rounded-2xl p-5 border border-white/10">
        <h3 className="font-bold text-base text-white flex items-center gap-2 font-display">
          <BarChart3 className="w-5 h-5 text-emerald-400" /> Lembar Nilai & Rekapitulasi Siswa
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Nama: <b className="text-white">{session.fullName}</b> &bull; Kelas: {session.className} &bull; NIS: {session.nis || '-'}
        </p>
      </div>

      {/* KPI Stats Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-4 sm:p-5 border border-white/10 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-lg">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Rata-rata Nilai
            </span>
            <p className="text-2xl sm:text-3xl font-extrabold font-display text-emerald-400 tabular-nums">
              {avg}
            </p>
          </div>
        </div>

        <div className="glass rounded-2xl p-4 sm:p-5 border border-white/10 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-lg">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Nilai Tertinggi
            </span>
            <p className="text-2xl sm:text-3xl font-extrabold font-display text-cyan-300 tabular-nums">
              {highest}
            </p>
          </div>
        </div>

        <div className="glass rounded-2xl p-4 sm:p-5 border border-white/10 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-lg">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Kuis Selesai
            </span>
            <p className="text-2xl sm:text-3xl font-extrabold font-display text-indigo-300 tabular-nums">
              {scores.length}
            </p>
          </div>
        </div>
      </div>

      {/* Scores Table */}
      <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs sm:text-sm min-w-[600px]">
            <thead className="bg-white/5 text-[10px] uppercase font-bold text-slate-400 border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4 w-12 text-center">No</th>
                <th className="py-3.5 px-4">Nama Penilaian / Kuis</th>
                <th className="py-3.5 px-4 w-32 text-center">Skor Perolehan</th>
                <th className="py-3.5 px-4 w-28 text-center">Nilai Akhir</th>
                <th className="py-3.5 px-4 w-32 text-center">Kategori</th>
                <th className="py-3.5 px-4 w-36 text-right">Tanggal Selesai</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {scores.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-400 italic">
                    Belum ada nilai kuis yang tercatat. Silakan kerjakan kuis yang tersedia.
                  </td>
                </tr>
              ) : (
                scores.map((sc, idx) => {
                  const kktp =
                    sc.percentage >= 85
                      ? 'Sangat Baik'
                      : sc.percentage >= 70
                      ? 'Baik'
                      : sc.percentage >= 60
                      ? 'Cukup'
                      : 'Perlu Bimbingan';

                  const badgeColor =
                    sc.percentage >= 85
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      : sc.percentage >= 70
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                      : sc.percentage >= 60
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      : 'bg-rose-500/20 text-rose-300 border-rose-500/30';

                  return (
                    <tr key={sc.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4 text-center font-mono text-slate-400">{idx + 1}</td>
                      <td className="py-3 px-4 font-bold text-white">{sc.quizTitle}</td>
                      <td className="py-3 px-4 text-center font-mono text-slate-300">
                        {sc.rawScore} / {sc.maxScore}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="text-base font-black font-display text-emerald-400 font-mono">
                          {sc.percentage}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${badgeColor}`}>
                          {kktp}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-slate-400">
                        {new Date(sc.createdAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
