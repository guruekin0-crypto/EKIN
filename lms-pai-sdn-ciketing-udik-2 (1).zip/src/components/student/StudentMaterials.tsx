import React, { useState } from 'react';
import {
  BookText,
  Search,
  Eye,
  X,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Award,
  CheckCircle2
} from 'lucide-react';
import { Material, UserSession } from '../../types';
import { StorageService } from '../../services/storageService';
import { FocusReaderModal } from '../common/FocusReaderModal';

interface StudentMaterialsProps {
  session: UserSession;
  showToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const StudentMaterials: React.FC<StudentMaterialsProps> = ({ session, showToast }) => {
  const gradeNum = session.className?.replace(/\D/g, '') || '5';
  const materials = StorageService.getMaterials(gradeNum);
  const [search, setSearch] = useState('');
  const [selectedMat, setSelectedMat] = useState<Material | null>(null);
  const [focusMat, setFocusMat] = useState<Material | null>(null);
  const [fontSize, setFontSize] = useState<number>(15);
  const [gamification, setGamification] = useState(() =>
    StorageService.getStudentGamification(session.userId)
  );

  const handleCompleteReading = (mat: Material) => {
    const res = StorageService.awardStudentActivity(session.userId, 'material', mat.id);
    setGamification(res.profile);
    if (showToast) {
      const badgeMsg =
        res.newlyEarnedBadges.length > 0
          ? ` & Membuka Lencana "${res.newlyEarnedBadges[0].name}"!`
          : '!';
      showToast(
        `Alhamdulillah! Kamu mendapat +${res.xpGained} XP dari membaca "${mat.title}"${badgeMsg}`,
        'success'
      );
    }
  };

  const filtered = materials.filter(m => {
    return (
      m.title.toLowerCase().includes(search.toLowerCase()) ||
      m.contentText.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-3 border border-white/10">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2 font-display">
            <BookText className="w-5 h-5 text-emerald-400" /> Bahan Pembelajaran PAI Kelas{' '}
            {session.className}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Gunakan fitur <b>Focus Reader (Layar Penuh)</b> untuk kenyamanan membaca &amp; raih{' '}
            <b className="text-amber-300">+25 Poin XP</b> setiap materi selesai!
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Cari materi..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Materials List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-2 glass rounded-2xl p-10 text-center text-slate-400 italic">
            Belum ada bahan materi untuk kelas Anda.
          </div>
        ) : (
          filtered.map(mat => {
            const isRead = gamification.readMaterialIds.includes(mat.id);
            return (
              <div
                key={mat.id}
                className="glass rounded-2xl p-5 border border-white/10 hover:border-emerald-500/40 transition-all shadow-md flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[10px]">
                      Kelas {mat.classId || 'Umum'} &bull; {mat.subject || 'PAI'}
                    </span>
                    {isRead ? (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Sudah Dibaca
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold flex items-center gap-1">
                        <Award className="w-3 h-3" /> +25 XP
                      </span>
                    )}
                  </div>
                  <h4 className="font-bold text-base text-white mt-2 leading-snug">
                    {mat.title}
                  </h4>
                  <div
                    className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed opacity-90"
                    dangerouslySetInnerHTML={{
                      __html: mat.contentText ? mat.contentText.replace(/<[^>]*>/g, ' ') : ''
                    }}
                  />
                </div>

                <div className="pt-3 border-t border-white/5 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-400 font-medium">
                    Semester {mat.semester}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedMat(mat)}
                      className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
                    >
                      <Eye className="w-3.5 h-3.5 text-cyan-400" /> Ringkas
                    </button>
                    <button
                      type="button"
                      onClick={() => setFocusMat(mat)}
                      className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer transition-all"
                    >
                      <Maximize2 className="w-3.5 h-3.5" /> Focus Reader
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Standard Reading Mode Modal */}
      {selectedMat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-slate-900/90">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                  Materi Pelajaran &bull; Tingkat Kelas {selectedMat.classId || 'Umum'}
                </span>
                <h3 className="font-bold text-base sm:text-lg text-white">{selectedMat.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const mat = selectedMat;
                    setSelectedMat(null);
                    setFocusMat(mat);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  title="Buka di Focus Reader Layar Penuh"
                >
                  <Maximize2 className="w-3.5 h-3.5" /> Focus Reader
                </button>
                <button
                  onClick={() => setFontSize(prev => Math.max(13, prev - 1))}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                  title="Perkecil Ukuran Teks"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setFontSize(prev => Math.min(22, prev + 1))}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                  title="Perbesar Ukuran Teks"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedMat(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 ml-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div
              className="p-6 sm:p-8 overflow-y-auto flex-1 bg-slate-950/60 text-slate-100 leading-relaxed space-y-4"
              style={{ fontSize: `${fontSize}px` }}
            >
              <div
                className="prose prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: selectedMat.contentText }}
              />
            </div>

            <div className="p-4 border-t border-white/10 bg-slate-900/90 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Selesaikan membaca untuk klaim Poin XP Motivasi Belajar
              </span>
              <button
                type="button"
                onClick={() => {
                  handleCompleteReading(selectedMat);
                  setSelectedMat(null);
                }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Award className="w-4 h-4" /> Selesai Membaca (+25 XP)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Focus Reader Modal */}
      <FocusReaderModal
        isOpen={!!focusMat}
        onClose={() => setFocusMat(null)}
        title={focusMat?.title || ''}
        subtitle={`Bahan Materi PAI & Budi Pekerti • Kelas ${focusMat?.classId || 'Umum'} • Semester ${focusMat?.semester || 'Ganjil'}`}
        badgeText={focusMat?.subject || 'PAI & Budi Pekerti'}
        htmlContent={focusMat?.contentText}
        onCompleteReading={focusMat ? () => handleCompleteReading(focusMat) : undefined}
        completedRewardLabel="Klik 'Selesai Baca & Klaim Poin XP' untuk mendapatkan +25 XP dan Lencana Pecinta Ilmu!"
      />
    </div>
  );
};
