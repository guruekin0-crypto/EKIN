import React, { useState } from 'react';
import {
  Library,
  Search,
  Volume2,
  BookOpen,
  Maximize2,
  Award,
  CheckCircle2
} from 'lucide-react';
import { ReadingReference, UserSession } from '../../types';
import { StorageService } from '../../services/storageService';
import { FocusReaderModal } from '../common/FocusReaderModal';

interface StudentReferencesProps {
  session: UserSession;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const StudentReferences: React.FC<StudentReferencesProps> = ({ session, showToast }) => {
  const references = StorageService.getReferences();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [focusRef, setFocusRef] = useState<ReadingReference | null>(null);
  const [gamification, setGamification] = useState(() =>
    StorageService.getStudentGamification(session.userId)
  );

  const toggleAudio = (id: string) => {
    if (playingId === id) {
      setPlayingId(null);
      showToast('Audio dihentikan', 'info');
    } else {
      setPlayingId(id);
      showToast('Memutar audio tilawah Murottal Juz Amma...', 'info');
    }
  };

  const handleRewardReference = (ref: ReadingReference) => {
    const res = StorageService.awardStudentActivity(session.userId, 'reference', ref.id);
    setGamification(res.profile);
    const badgeMsg =
      res.newlyEarnedBadges.length > 0
        ? ` & Meraih Lencana "${res.newlyEarnedBadges[0].name}"!`
        : '!';
    showToast(
      `MasyaAllah! Kamu mendapat +${res.xpGained} XP dari tadarus/bacaan "${ref.title}"${badgeMsg}`,
      'success'
    );
  };

  const filtered = references.filter(r => {
    const matchCat =
      activeCategory === 'all' ||
      r.category.toLowerCase().includes(activeCategory.toLowerCase());
    const matchSearch =
      r.title.toLowerCase().includes(search.toLowerCase()) ||
      r.content.toLowerCase().includes(search.toLowerCase()) ||
      (r.translation || '').toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="space-y-5">
      {/* Search and Category Filter */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-3 border border-white/10">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2 font-display">
            <Library className="w-5 h-5 text-cyan-400" /> Perpustakaan Digital PAI &amp; Juz Amma
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Pelajari surah pendek Al-Qur'an, doa sehari-hari, dan kisah teladan Nabi dengan{' '}
            <b>Focus Reader</b> (+20 XP per bacaan)
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Cari surah / doa..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-2">
        {['all', 'Juz Amma', 'Doa Harian', 'Kisah 25 Nabi'].map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategory === cat
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/20'
                : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
            }`}
          >
            {cat === 'all' ? 'Semua Bacaan' : cat}
          </button>
        ))}
      </div>

      {/* Reference Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(r => {
          const isRead = gamification.readReferenceIds.includes(r.id);
          return (
            <div
              key={r.id}
              className="glass rounded-3xl p-5 sm:p-6 border border-white/10 hover:border-emerald-500/30 transition-all shadow-md flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-bold text-[11px]">
                      {r.category}
                    </span>
                    {isRead ? (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Sudah Dibaca
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                        +20 XP
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => toggleAudio(r.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      playingId === r.id
                        ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/30 animate-pulse'
                        : 'bg-white/5 hover:bg-white/10 text-cyan-300 border border-white/10'
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{playingId === r.id ? 'Berhenti' : 'Putar Murottal'}</span>
                  </button>
                </div>

                <h4 className="font-bold text-base text-white">{r.title}</h4>

                {r.arabicSnippet && (
                  <div className="mt-3.5 p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/25 text-right shadow-inner">
                    <p className="khat-naskh text-emerald-300 text-base sm:text-lg leading-loose font-arabic">
                      {r.arabicSnippet}
                    </p>
                  </div>
                )}

                <p className="text-xs text-slate-300 mt-3 leading-relaxed font-serif italic">
                  {r.content}
                </p>

                {r.translation && (
                  <div className="mt-2.5 pt-2 border-t border-white/5 text-[11px] text-slate-400 leading-relaxed">
                    <span className="font-bold text-slate-300">Terjemahan:</span> {r.translation}
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-white/5 flex flex-wrap items-center justify-between gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => handleRewardReference(r)}
                  className="px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Award className="w-3.5 h-3.5" /> Tandai Sudah Tadarus (+20 XP)
                </button>
                <button
                  type="button"
                  onClick={() => setFocusRef(r)}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Maximize2 className="w-3.5 h-3.5" /> Focus Reader
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Fullscreen Focus Reader Modal */}
      <FocusReaderModal
        isOpen={!!focusRef}
        onClose={() => setFocusRef(null)}
        title={focusRef?.title || ''}
        subtitle={`Perpustakaan PAI & Juz Amma • ${focusRef?.category || ''}`}
        badgeText={focusRef?.category}
        arabicText={focusRef?.arabicSnippet}
        plainContent={focusRef?.content}
        extraSections={
          focusRef?.translation
            ? [{ label: 'Terjemahan & Makna Kandungan', content: focusRef.translation }]
            : undefined
        }
        onCompleteReading={focusRef ? () => handleRewardReference(focusRef) : undefined}
        completedRewardLabel="Klaim +20 XP dan Lencana Sahabat Juz Amma & Doa setelah tadarus!"
      />
    </div>
  );
};
