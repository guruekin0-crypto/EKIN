import React, { useState, useEffect } from 'react';
import {
  FileQuestion,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Play,
  ArrowRight,
  ArrowLeft,
  Send,
  HelpCircle,
  Award,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Quiz, Question, UserSession } from '../../types';
import { StorageService } from '../../services/storageService';

interface StudentQuizzesProps {
  session: UserSession;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const StudentQuizzes: React.FC<StudentQuizzesProps> = ({ session, showToast }) => {
  const [quizzes, setQuizzes] = useState<Quiz[]>(
    StorageService.getQuizzes(session.userId, session.classId)
  );

  // Active quiz playing state
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);

  // Result state
  const [quizResult, setQuizResult] = useState<{
    score: number;
    maxScore: number;
    percentage: number;
  } | null>(null);

  const [confirmSubmitModal, setConfirmSubmitModal] = useState(false);

  const refreshQuizzes = () => {
    setQuizzes(StorageService.getQuizzes(session.userId, session.classId));
  };

  // Start Quiz
  const handleStartQuiz = (quiz: Quiz) => {
    try {
      const data = StorageService.getQuizForStudent(quiz.id);
      setActiveQuiz(data.quiz);
      setQuestions(data.questions);
      setCurrentQuestionIndex(0);
      setAnswers({});
      setTimeLeftSeconds(data.quiz.durationMinutes * 60);
      setQuizResult(null);
      showToast(`Kuis dimulai! Waktu Anda ${data.quiz.durationMinutes} menit.`, 'info');
    } catch (err: any) {
      showToast(err.message || 'Gagal memuat soal kuis', 'error');
    }
  };

  // Timer Countdown Effect
  useEffect(() => {
    if (!activeQuiz || quizResult || timeLeftSeconds <= 0) return;

    const interval = setInterval(() => {
      setTimeLeftSeconds(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          handleFinishQuiz('timeout');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [activeQuiz, quizResult, timeLeftSeconds]);

  // Handle Answer Selection
  const handleAnswerSelect = (qid: string, val: any, type: string) => {
    if (type === 'pg_kompleks') {
      const currentList: string[] = answers[qid] || [];
      if (currentList.includes(val)) {
        setAnswers({
          ...answers,
          [qid]: currentList.filter(item => item !== val)
        });
      } else {
        setAnswers({
          ...answers,
          [qid]: [...currentList, val]
        });
      }
    } else {
      setAnswers({
        ...answers,
        [qid]: val
      });
    }
  };

  // Submit and Grade Quiz
  const handleFinishQuiz = (status: 'submitted' | 'timeout' = 'submitted') => {
    if (!activeQuiz) return;

    setConfirmSubmitModal(false);
    const result = StorageService.submitQuiz(
      activeQuiz.id,
      session.userId,
      session.fullName,
      session.className,
      answers,
      status
    );

    const bonusXp = result.percentage >= 85 ? 25 : 0;
    const gamificationRes = StorageService.awardStudentActivity(
      session.userId,
      'quiz',
      activeQuiz.id,
      bonusXp
    );

    setQuizResult(result);
    refreshQuizzes();

    // Trigger celebratory confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (e) {}

    const badgeToast =
      gamificationRes.newlyEarnedBadges.length > 0
        ? ` & Lencana "${gamificationRes.newlyEarnedBadges[0].name}" Terbuka!`
        : '!';

    showToast(
      status === 'timeout'
        ? `Waktu habis! Jawaban tersimpan (+${gamificationRes.xpGained} XP)${badgeToast}`
        : `Alhamdulillah, jawaban dikumpulkan! Kamu meraih +${gamificationRes.xpGained} XP${badgeToast}`,
      'success'
    );
  };

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // If in quiz player mode
  if (activeQuiz) {
    if (quizResult) {
      // Quiz Finished Screen
      return (
        <div className="max-w-xl mx-auto py-6 space-y-6">
          <div className="glass-strong rounded-3xl p-6 sm:p-8 border border-emerald-500/30 text-center space-y-5 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
              <Award className="w-9 h-9" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-xs uppercase tracking-wider">
                Hasil Penilaian
              </span>
              <h3 className="text-xl sm:text-2xl font-bold font-display text-white mt-2">
                {activeQuiz.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Terima kasih, {session.fullName}. Jawaban Anda telah tersimpan rapi.
              </p>
            </div>

            {activeQuiz.showScoreImmediately && (
              <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <span className="text-xs font-bold uppercase text-slate-400">
                  Nilai Akhir Anda
                </span>
                <p className="text-5xl font-black font-display text-emerald-400 tabular-nums">
                  {quizResult.percentage}
                </p>
                <p className="text-xs text-slate-300 font-mono">
                  Skor Perolehan: {quizResult.score} dari {quizResult.maxScore} poin
                </p>
              </div>
            )}

            <div className="pt-3 border-t border-white/10 flex justify-center">
              <button
                onClick={() => {
                  setActiveQuiz(null);
                  setQuizResult(null);
                }}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 flex items-center gap-2 cursor-pointer transition-all"
              >
                <ArrowLeft className="w-4 h-4" /> Kembali ke Daftar Kuis
              </button>
            </div>
          </div>
        </div>
      );
    }

    const currentQ = questions[currentQuestionIndex];
    const totalQ = questions.length;
    const isAnswered = (qid: string) => {
      const val = answers[qid];
      if (Array.isArray(val)) return val.length > 0;
      if (val && typeof val === 'object') {
        return Object.values(val).some(v => v !== undefined && v !== null && String(v).trim() !== '');
      }
      return val !== undefined && val !== null && String(val).trim() !== '';
    };

    return (
      <div className="space-y-4 max-w-4xl mx-auto">
        {/* Quiz Sticky Header */}
        <div className="glass-strong rounded-2xl p-4 border border-white/15 flex items-center justify-between shadow-xl">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-white truncate max-w-md">
              {activeQuiz.title}
            </h3>
            <p className="text-[11px] text-slate-400">
              Soal {currentQuestionIndex + 1} dari {totalQ}
            </p>
          </div>

          <div
            className={`px-3.5 py-1.5 rounded-xl font-mono font-bold text-xs sm:text-sm flex items-center gap-2 border shadow-sm ${
              timeLeftSeconds < 300
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{formatTimer(timeLeftSeconds)}</span>
          </div>
        </div>

        {/* Question Jumper Grid */}
        <div className="glass rounded-2xl p-3 border border-white/10">
          <div className="flex flex-wrap gap-1.5 justify-center">
            {questions.map((q, idx) => {
              const answered = isAnswered(q.id);
              const isActive = idx === currentQuestionIndex;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentQuestionIndex(idx)}
                  className={`w-8 h-8 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/30 ring-2 ring-cyan-300'
                      : answered
                      ? 'bg-emerald-500 text-white shadow-sm'
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Question Box */}
        {currentQ && (
          <div className="glass rounded-3xl p-5 sm:p-7 border border-white/15 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-xs">
                Nomor {currentQuestionIndex + 1}
              </span>
              <span className="text-xs text-amber-300 font-mono font-semibold">
                Bobot: {currentQ.scoreWeight} Poin
              </span>
            </div>

            {/* TKA Stimulus Reading if any */}
            {currentQ.stimulus && (
              <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 space-y-1.5 shadow-inner">
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-300 uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Stimulus Cerita / Kasus (Model Soal TKA):</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-100 leading-relaxed font-medium">
                  {currentQ.stimulus}
                </p>
              </div>
            )}

            {/* Arabic Verse if any with Khat Naskh */}
            {currentQ.arabicText && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 text-right shadow-md">
                <p className="khat-naskh text-emerald-300 text-xl sm:text-2xl leading-loose font-arabic">
                  {currentQ.arabicText}
                </p>
              </div>
            )}

            {/* Question Text */}
            <div className="space-y-1">
              <span className="text-[11px] text-emerald-400 font-bold uppercase tracking-wider block">
                Pertanyaan Soal:
              </span>
              <p className="text-sm sm:text-base font-bold text-white leading-relaxed">
                {currentQ.question}
              </p>
            </div>

            {/* Answer Options */}
            <div className="space-y-2.5 pt-2">
              {currentQ.questionType === 'pg_standar' &&
                currentQ.options.map((opt, optIdx) => {
                  const letter = String.fromCharCode(65 + optIdx);
                  const isChecked = answers[currentQ.id] === opt;
                  return (
                    <div
                      key={optIdx}
                      onClick={() => handleAnswerSelect(currentQ.id, opt, 'pg_standar')}
                      className={`p-3.5 rounded-2xl border text-xs sm:text-sm flex items-center gap-3 cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-emerald-500/20 border-emerald-500/50 text-white font-bold shadow-md'
                          : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <span
                        className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                          isChecked ? 'bg-emerald-500 text-white' : 'bg-white/10 text-slate-400'
                        }`}
                      >
                        {letter}
                      </span>
                      <span className="flex-1 leading-relaxed">{opt}</span>
                    </div>
                  );
                })}

              {currentQ.questionType === 'pg_kompleks' &&
                currentQ.options.map((opt, optIdx) => {
                  const letter = String.fromCharCode(65 + optIdx);
                  const selectedList = answers[currentQ.id] || [];
                  const isChecked = selectedList.includes(opt);
                  return (
                    <div
                      key={optIdx}
                      onClick={() => handleAnswerSelect(currentQ.id, opt, 'pg_kompleks')}
                      className={`p-3.5 rounded-2xl border text-xs sm:text-sm flex items-center gap-3 cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-emerald-500/20 border-emerald-500/50 text-white font-bold shadow-md'
                          : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}}
                        className="accent-emerald-500 w-4 h-4"
                      />
                      <span className="w-5 text-center font-bold text-xs text-slate-400">
                        {letter}.
                      </span>
                      <span className="flex-1 leading-relaxed">{opt}</span>
                    </div>
                  );
                })}

              {currentQ.questionType === 'benar_salah' && (
                <div className="grid grid-cols-2 gap-3">
                  {['Benar', 'Salah'].map(val => {
                    const isChecked = answers[currentQ.id] === val;
                    return (
                      <button
                        type="button"
                        key={val}
                        onClick={() => handleAnswerSelect(currentQ.id, val, 'benar_salah')}
                        className={`py-3.5 rounded-2xl text-xs sm:text-sm font-bold border transition-all cursor-pointer ${
                          isChecked
                            ? 'bg-emerald-500/25 border-emerald-500/60 text-emerald-300 shadow-md ring-2 ring-emerald-500/30'
                            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        {val}
                      </button>
                    );
                  })}
                </div>
              )}

              {currentQ.questionType === 'menjodohkan' && (
                <div className="space-y-3">
                  <p className="text-xs text-cyan-300 font-semibold">
                    Pasangkan setiap pernyataan di sebelah kiri dengan pasangan jawaban yang tepat di sebelah kanan:
                  </p>
                  {(currentQ.matchingPairs && currentQ.matchingPairs.length > 0
                    ? currentQ.matchingPairs
                    : (currentQ.options || []).map(opt => {
                        const parts = opt.split(/➔|=>|=/);
                        return {
                          left: (parts[0] || opt).trim(),
                          right: (parts[1] || opt).trim()
                        };
                      })
                  ).map((pair, pIdx, allPairs) => {
                    const currentMap: Record<string, string> =
                      answers[currentQ.id] && typeof answers[currentQ.id] === 'object'
                        ? answers[currentQ.id]
                        : {};
                    const rightChoices = allPairs.map(p => p.right);
                    return (
                      <div
                        key={pIdx}
                        className="p-3.5 rounded-2xl bg-white/5 border border-white/10 grid grid-cols-1 sm:grid-cols-12 gap-3 items-center"
                      >
                        <div className="sm:col-span-6 text-xs sm:text-sm text-white font-medium">
                          <span className="font-mono font-bold text-emerald-400 mr-1.5">
                            {pIdx + 1}.
                          </span>
                          {pair.left}
                        </div>
                        <div className="sm:col-span-6">
                          <select
                            value={currentMap[pair.left] || ''}
                            onChange={e => {
                              const updatedMap = {
                                ...currentMap,
                                [pair.left]: e.target.value
                              };
                              handleAnswerSelect(currentQ.id, updatedMap, 'menjodohkan');
                            }}
                            className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-emerald-500/40 text-xs sm:text-sm text-white font-semibold focus:outline-none focus:border-emerald-400 cursor-pointer"
                          >
                            <option value="">-- Pilih Pasangan Jawaban --</option>
                            {rightChoices.map((rc, rIdx) => (
                              <option key={rIdx} value={rc}>
                                {rc}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {currentQ.questionType === 'isian_singkat' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-amber-300 uppercase block">
                    Jawaban Singkat Anda:
                  </label>
                  <input
                    type="text"
                    value={answers[currentQ.id] || ''}
                    onChange={e => handleAnswerSelect(currentQ.id, e.target.value, 'isian_singkat')}
                    placeholder="Ketik jawaban singkat dengan tepat di sini..."
                    className="w-full px-4 py-3 rounded-2xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm font-bold focus:outline-none focus:border-emerald-500"
                  />
                </div>
              )}

              {currentQ.questionType === 'essay' && (
                <textarea
                  rows={4}
                  value={answers[currentQ.id] || ''}
                  onChange={e => handleAnswerSelect(currentQ.id, e.target.value, 'essay')}
                  placeholder="Ketikkan jawaban Anda secara jelas dan santun..."
                  className="w-full p-4 rounded-2xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500 leading-relaxed"
                />
              )}
            </div>

            {/* Navigation buttons */}
            <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3">
              <button
                type="button"
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed text-slate-300 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Sebelumnya
              </button>

              {currentQuestionIndex < totalQ - 1 ? (
                <button
                  type="button"
                  onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                >
                  Berikutnya <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmSubmitModal(true)}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-extrabold flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition-all cursor-pointer"
                >
                  <Send className="w-4 h-4" /> Kumpulkan Jawaban
                </button>
              )}
            </div>
          </div>
        )}

        {/* Confirmation Modal */}
        {confirmSubmitModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <div className="glass-strong rounded-3xl w-full max-w-sm p-6 text-center border border-white/20 shadow-2xl space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                <HelpCircle className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-white text-base">Konfirmasi Pengumpulan</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Apakah Anda sudah yakin dengan semua jawaban Anda? Setelah dikumpulkan, jawaban tidak dapat diubah kembali.
              </p>
              <div className="flex gap-2.5 pt-2">
                <button
                  onClick={() => setConfirmSubmitModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold"
                >
                  Periksa Lagi
                </button>
                <button
                  onClick={() => handleFinishQuiz('submitted')}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/25"
                >
                  Ya, Kumpulkan
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Quizzes List View for Student
  return (
    <div className="space-y-5">
      <div className="glass rounded-2xl p-5 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div>
          <h3 className="font-bold text-base text-white flex items-center gap-2 font-display">
            <FileQuestion className="w-5 h-5 text-emerald-400" /> Tugas & Kuis PAI Kelas {session.className}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Daftar tugas mandiri, penilaian harian, dan evaluasi agama Islam
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {quizzes.length === 0 ? (
          <div className="col-span-2 glass rounded-2xl p-10 text-center text-slate-400 italic">
            Belum ada tugas atau kuis yang ditugaskan untuk rombel kelas Anda.
          </div>
        ) : (
          quizzes.map(quiz => {
            const isCompleted = quiz.completed;
            const isClosed = quiz.status === 'closed';

            return (
              <div
                key={quiz.id}
                className="glass rounded-2xl p-5 border border-white/10 hover:border-emerald-500/40 transition-all shadow-md flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[11px]">
                      Kelas {quiz.className} &bull; Semester {quiz.semester}
                    </span>

                    {isCompleted ? (
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold text-[10px] flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Selesai
                      </span>
                    ) : isClosed ? (
                      <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold text-[10px]">
                        Ditutup
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-[10px]">
                        Aktif
                      </span>
                    )}
                  </div>

                  <h4 className="font-bold text-base text-white">{quiz.title}</h4>
                  <p className="text-xs text-slate-300 mt-1 line-clamp-2 leading-relaxed">
                    {quiz.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-white/5 space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-amber-400" /> {quiz.durationMinutes} Menit
                    </span>
                    <span className="flex items-center gap-1">
                      <FileQuestion className="w-3.5 h-3.5 text-cyan-400" /> {quiz.questionIds.length} Butir Soal
                    </span>
                  </div>

                  {isCompleted ? (
                    <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center text-xs font-bold text-emerald-300">
                      Anda sudah menyelesaikan evaluasi ini
                    </div>
                  ) : isClosed ? (
                    <div className="p-2.5 rounded-xl bg-white/5 text-center text-xs text-slate-400">
                      Kuis sudah ditutup oleh Guru PAI
                    </div>
                  ) : (
                    <button
                      onClick={() => handleStartQuiz(quiz)}
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer transition-all active:scale-95"
                    >
                      <Play className="w-3.5 h-3.5" /> Mulai Kerjakan Kuis
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
