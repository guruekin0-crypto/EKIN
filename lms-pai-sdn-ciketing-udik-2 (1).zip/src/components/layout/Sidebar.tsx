import React from 'react';
import {
  LayoutDashboard,
  User,
  Settings,
  School,
  Users,
  CalendarCheck,
  NotebookPen,
  Sparkles,
  FileQuestion,
  BookText,
  Library,
  Megaphone,
  BarChart3,
  LogOut,
  X,
  GraduationCap,
  Layers,
  FileSpreadsheet,
  Database,
  UserCheck,
  MessageSquare,
  ClipboardCheck
} from 'lucide-react';
import { UserSession } from '../../types';
import { StorageService } from '../../services/storageService';

interface SidebarProps {
  session: UserSession;
  currentView: string;
  onNavigate: (viewId: string) => void;
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  session,
  currentView,
  onNavigate,
  isOpen,
  onClose,
  onLogout
}) => {
  const appSettings = StorageService.getAppSettings();

  const adminNav = [
    { id: 'dashboard', label: 'Dashboard Utama', icon: LayoutDashboard },
    { id: 'profile', label: 'Profil Guru PAI', icon: User },
    { id: 'e-kinerja', label: 'E-Kinerja Harian', icon: ClipboardCheck },
    { id: 'settings', label: 'Pengaturan & Cloud', icon: Settings },
    { id: 'classes', label: 'Daftar Kelas', icon: School },
    { id: 'curriculum', label: 'Materi Pokok Per Kelas', icon: Layers },
    { id: 'discussion-forum', label: 'Forum Diskusi Kelas', icon: MessageSquare },
    { id: 'create-questions', label: 'Buat Soal (AI)', icon: Sparkles },
    { id: 'questions', label: 'Bank Soal PAI', icon: Database },
    { id: 'quizzes', label: 'Manajemen Kuis', icon: FileQuestion },
    { id: 'students', label: 'Data Siswa & Kartu', icon: Users },
    { id: 'attendance', label: 'Absensi Siswa', icon: CalendarCheck },
    { id: 'journals', label: 'Jurnal Mengajar AI', icon: NotebookPen },
    { id: 'materials', label: 'Bahan Materi (Focus)', icon: BookText },
    { id: 'references', label: 'Referensi Baca PAI', icon: Library },
    { id: 'announcements', label: 'Pengumuman', icon: Megaphone },
    { id: 'reports', label: 'Rekap Nilai Siswa', icon: BarChart3 }
  ];

  const studentNav = [
    { id: 'dashboard', label: 'Beranda Siswa', icon: LayoutDashboard },
    { id: 'student-quizzes', label: 'Tugas & Kuis', icon: FileQuestion },
    { id: 'student-materials', label: 'Baca Materi (Focus)', icon: BookText },
    { id: 'student-references', label: 'Juz Amma & Doa', icon: Library },
    { id: 'student-forum', label: 'Forum Diskusi PAI', icon: MessageSquare },
    { id: 'student-announcements', label: 'Pengumuman', icon: Megaphone },
    { id: 'student-scores', label: 'Nilai Saya', icon: BarChart3 }
  ];

  const navItems = session.role === 'admin' ? adminNav : studentNav;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:relative inset-y-0 left-0 z-50 w-72 flex flex-col flex-shrink-0 glass-strong border-r border-white/10 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={appSettings.appLogoUrl || 'https://jhlryjdhotxtndavacpd.supabase.co/storage/v1/object/public/logo/logo.png'}
              alt="Logo"
              className="w-9 h-9 object-contain"
              onError={e => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            <div>
              <h2 className="font-display font-extrabold text-sm sm:text-base gradient-text tracking-wide">
                LMS PAI
              </h2>
              <p className="text-[10px] text-slate-400 font-medium truncate max-w-[140px]">
                SDN Ciketing Udik 2
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Card */}
        <div className="p-3.5 border-b border-white/10">
          <div className="glass rounded-xl p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-white text-sm shadow-md shrink-0">
              {session.fullName.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-white truncate">{session.fullName}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-[10px] text-emerald-400 font-extrabold uppercase tracking-wider">
                  {session.role === 'admin' ? 'Guru PAI' : `Siswa Kelas ${session.className}`}
                </span>
                {session.role === 'siswa' && session.username && (
                  <span className="text-[10px] text-slate-400 font-mono">({session.username})</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1 scrollbar-thin">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-emerald-400' : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Logout Button */}
        <div className="p-3 border-t border-white/10">
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-300 hover:text-rose-200 text-xs font-bold transition-all cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Keluar Aplikasi</span>
          </button>
        </div>
      </aside>
    </>
  );
};
