import React, { useState } from 'react';
import {
  MessageSquare,
  Plus,
  Search,
  Send,
  Pin,
  CheckCircle2,
  Trash2,
  Heart,
  ShieldCheck,
  Sparkles,
  User,
  Clock,
  Filter,
  X
} from 'lucide-react';
import { ForumThread, UserSession } from '../../types';
import { StorageService } from '../../services/storageService';

interface DiscussionForumViewProps {
  session: UserSession;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const TOPIC_CATEGORIES = [
  'Al-Qur\'an & Hadis (Juz Amma)',
  'Akidah (Iman & Asmaul Husna)',
  'Akhlak & Kurikulum Berbasis Cinta (KBC)',
  'Fikih (Praktik Shalat & Thaharah)',
  'Sejarah Peradaban Islam (Kisah Nabi)',
  'Tanya Jawab Tugas / Kuis PAI'
];

export const DiscussionForumView: React.FC<DiscussionForumViewProps> = ({
  session,
  showToast
}) => {
  const isAdmin = session.role === 'admin';
  const classes = StorageService.getClasses();

  const [selectedClassFilter, setSelectedClassFilter] = useState<string>(
    isAdmin ? 'all' : session.classId || 'all'
  );
  const [search, setSearch] = useState('');
  const [threads, setThreads] = useState<ForumThread[]>(
    StorageService.getForumThreads(isAdmin ? 'all' : session.classId)
  );

  // Create Thread Modal
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [formClassId, setFormClassId] = useState<string>(
    isAdmin ? 'all' : session.classId || 'c5'
  );
  const [formCategory, setFormCategory] = useState<string>(TOPIC_CATEGORIES[0]);
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');

  // Reply inputs per thread
  const [replyInputs, setReplyInputs] = useState<Record<string, string>>({});
  const [expandedThreadId, setExpandedThreadId] = useState<string | null>(
    threads[0]?.id || null
  );

  const refreshThreads = (clsFilter = selectedClassFilter) => {
    setThreads(StorageService.getForumThreads(clsFilter));
  };

  const handleClassFilterChange = (val: string) => {
    setSelectedClassFilter(val);
    refreshThreads(val);
  };

  const handleCreateThread = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      showToast('Judul pertanyaan dan isi diskusi wajib diisi!', 'error');
      return;
    }

    const cls = classes.find(c => c.id === formClassId);
    const className =
      formClassId === 'all'
        ? 'Semua Kelas'
        : cls
        ? cls.className
        : session.className || '5A';

    const created = StorageService.saveForumThread({
      classId: formClassId,
      className,
      topicCategory: formCategory,
      title: formTitle.trim(),
      content: formContent.trim(),
      authorId: session.userId,
      authorName: isAdmin ? `${session.fullName} (Guru PAI)` : session.fullName,
      authorRole: session.role
    });

    setCreateModalOpen(false);
    setFormTitle('');
    setFormContent('');
    refreshThreads();
    setExpandedThreadId(created.id);

    if (session.role === 'siswa') {
      showToast(
        'Alhamdulillah! Pertanyaan diskusi berhasil dikirim (+15 Poin XP Motivasi Belajar)!',
        'success'
      );
    } else {
      showToast('Topik diskusi baru berhasil diterbitkan oleh Guru PAI!', 'success');
    }
  };

  const handleSendReply = (threadId: string) => {
    const text = (replyInputs[threadId] || '').trim();
    if (!text) {
      showToast('Tuliskan tanggapan atau jawaban terlebih dahulu!', 'error');
      return;
    }

    StorageService.addForumReply(threadId, {
      authorId: session.userId,
      authorName: isAdmin ? `${session.fullName} (Guru PAI)` : session.fullName,
      authorRole: session.role,
      content: text
    });

    setReplyInputs(prev => ({ ...prev, [threadId]: '' }));
    refreshThreads();

    if (session.role === 'siswa') {
      showToast('Tanggapan santun berhasil dikirim (+15 Poin XP)!', 'success');
    } else {
      showToast('Jawaban terverifikasi Guru PAI berhasil dikirim!', 'success');
    }
  };

  const handleTogglePin = (threadId: string) => {
    StorageService.toggleThreadPin(threadId);
    refreshThreads();
    showToast('Status sematan (Pin) diskusi diperbarui', 'info');
  };

  const handleToggleResolved = (threadId: string) => {
    StorageService.toggleThreadResolved(threadId);
    refreshThreads();
    showToast('Status ketercapaian jawaban diskusi diperbarui', 'success');
  };

  const handleToggleLike = (threadId: string) => {
    StorageService.toggleThreadLike(threadId, session.userId);
    refreshThreads();
  };

  const handleDeleteThread = (threadId: string) => {
    StorageService.deleteForumThread(threadId);
    refreshThreads();
    showToast('Topik diskusi telah dihapus (Moderasi Guru PAI)', 'info');
  };

  const handleDeleteReply = (threadId: string, replyId: string) => {
    StorageService.deleteForumReply(threadId, replyId);
    refreshThreads();
    showToast('Balasan komentar telah dihapus oleh moderator', 'info');
  };

  const filteredThreads = threads.filter(t => {
    const matchSearch =
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.content.toLowerCase().includes(search.toLowerCase()) ||
      t.topicCategory.toLowerCase().includes(search.toLowerCase()) ||
      t.authorName.toLowerCase().includes(search.toLowerCase());
    return matchSearch;
  });

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="glass-strong rounded-3xl p-5 sm:p-6 border border-emerald-500/25 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
            <MessageSquare className="w-3.5 h-3.5" /> Ruang Tanya Jawab &amp; Moderasi Guru PAI (KBC)
          </div>
          <h2 className="text-lg sm:text-xl font-bold font-display text-white">
            Forum Diskusi PAI &amp; Budi Pekerti{' '}
            {!isAdmin && session.className ? `— Kelas ${session.className}` : 'Per Kelas'}
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Mari berdiskusi dengan bahasa yang santun dan penuh kasih sayang (Kurikulum Berbasis Cinta). Siswa yang aktif bertanya atau menjawab akan memperoleh tambahan <b>+15 Poin XP &amp; Lencana Duta Kasih Sayang</b>!
          </p>
        </div>

        <button
          type="button"
          onClick={() => setCreateModalOpen(true)}
          className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 cursor-pointer transition-all shrink-0"
        >
          <Plus className="w-4 h-4" /> + Buat Pertanyaan / Topik Diskusi
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="glass rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-emerald-400 shrink-0" />
          <select
            value={selectedClassFilter}
            onChange={e => handleClassFilterChange(e.target.value)}
            className="px-3.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-xs font-bold text-white cursor-pointer"
          >
            <option value="all">Semua Kelas &amp; Rombel</option>
            {classes.map(c => (
              <option key={c.id} value={c.id}>
                Forum Kelas {c.className}
              </option>
            ))}
          </select>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Cari pertanyaan atau materi PAI..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Threads List */}
      <div className="space-y-4">
        {filteredThreads.length === 0 ? (
          <div className="glass rounded-3xl p-10 text-center text-slate-400 border border-white/10">
            <MessageSquare className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-75" />
            <p className="text-sm font-bold text-white">Belum Ada Topik Diskusi pada Filter Ini</p>
            <p className="text-xs text-slate-400 mt-1">
              Jadilah yang pertama mengajukan pertanyaan seputar materi PAI dengan mengklik tombol di atas!
            </p>
          </div>
        ) : (
          filteredThreads.map(thread => {
            const isExpanded = expandedThreadId === thread.id;
            const likedByMe = thread.likes?.includes(session.userId);

            return (
              <div
                key={thread.id}
                className={`glass rounded-3xl p-5 sm:p-6 border transition-all shadow-lg space-y-4 ${
                  thread.isPinned
                    ? 'border-emerald-500/40 bg-emerald-950/10'
                    : 'border-white/10 hover:border-white/20'
                }`}
              >
                {/* Thread Header Badges */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    {thread.isPinned && (
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold flex items-center gap-1">
                        <Pin className="w-3 h-3" /> Disematkan Guru
                      </span>
                    )}
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                      {thread.className === 'Semua Kelas'
                        ? 'Semua Kelas'
                        : `Kelas ${thread.className}`}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 text-[10px] font-bold">
                      {thread.topicCategory}
                    </span>
                    {thread.isResolved && (
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/25 text-emerald-200 border border-emerald-400/40 text-[10px] font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Terjawab Guru PAI
                      </span>
                    )}
                  </div>

                  {/* Teacher Moderation Actions */}
                  {isAdmin && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleTogglePin(thread.id)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                          thread.isPinned
                            ? 'bg-amber-500/25 text-amber-200 border border-amber-500/40'
                            : 'bg-white/5 hover:bg-white/10 text-slate-300'
                        }`}
                        title="Sematkan Diskusi"
                      >
                        <Pin className="w-3 h-3" /> {thread.isPinned ? 'Lepas Pin' : 'Pin'}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleResolved(thread.id)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3 h-3" />{' '}
                        {thread.isResolved ? 'Buka Kembali' : 'Tandai Terjawab'}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteThread(thread.id)}
                        className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 cursor-pointer"
                        title="Hapus Topik Diskusi (Moderasi)"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Thread Title & Content */}
                <div>
                  <h3
                    onClick={() =>
                      setExpandedThreadId(isExpanded ? null : thread.id)
                    }
                    className="text-base sm:text-lg font-bold text-white hover:text-emerald-300 cursor-pointer transition-colors"
                  >
                    {thread.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-200 mt-2 leading-relaxed whitespace-pre-line">
                    {thread.content}
                  </p>
                </div>

                {/* Author & Action Footer */}
                <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2 text-slate-400">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white ${
                        thread.authorRole === 'admin'
                          ? 'bg-emerald-500'
                          : 'bg-cyan-600'
                      }`}
                    >
                      {thread.authorName.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-bold text-slate-200">{thread.authorName}</span>
                    {thread.authorRole === 'admin' && (
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    )}
                    <span>&bull;</span>
                    <span className="text-[11px]">
                      {new Date(thread.createdAt).toLocaleDateString('id-ID', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleToggleLike(thread.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                        likedByMe
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${likedByMe ? 'fill-rose-400 text-rose-400' : ''}`} />
                      <span>{thread.likes?.length || 0} Bermanfaat</span>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setExpandedThreadId(isExpanded ? null : thread.id)
                      }
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>{thread.replies.length} Balasan Diskusi</span>
                    </button>
                  </div>
                </div>

                {/* Expanded Replies & Reply Input */}
                {isExpanded && (
                  <div className="pt-3 space-y-3 border-t border-white/10">
                    {thread.replies.length === 0 ? (
                      <p className="text-xs text-slate-400 italic py-2">
                        Belum ada tanggapan. Mari tulis tanggapan santun pertama!
                      </p>
                    ) : (
                      <div className="space-y-2.5 pl-2 sm:pl-4 border-l-2 border-emerald-500/30">
                        {thread.replies.map(rep => (
                          <div
                            key={rep.id}
                            className={`p-3.5 rounded-2xl border space-y-1.5 ${
                              rep.isTeacherVerified
                                ? 'bg-emerald-950/30 border-emerald-500/40'
                                : 'bg-white/5 border-white/10'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-white">
                                  {rep.authorName}
                                </span>
                                {rep.isTeacherVerified && (
                                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                                    <ShieldCheck className="w-3 h-3" /> Jawaban Guru PAI
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                <span className="text-[10px] text-slate-400">
                                  {new Date(rep.createdAt).toLocaleDateString('id-ID', {
                                    day: 'numeric',
                                    month: 'short'
                                  })}
                                </span>
                                {isAdmin && (
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteReply(thread.id, rep.id)}
                                    className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                                    title="Hapus Balasan"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            </div>
                            <p className="text-xs text-slate-200 leading-relaxed whitespace-pre-line">
                              {rep.content}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Reply Form */}
                    <div className="flex flex-col sm:flex-row gap-2 pt-2">
                      <input
                        type="text"
                        value={replyInputs[thread.id] || ''}
                        onChange={e =>
                          setReplyInputs(prev => ({
                            ...prev,
                            [thread.id]: e.target.value
                          }))
                        }
                        onKeyDown={e => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSendReply(thread.id);
                          }
                        }}
                        placeholder={
                          isAdmin
                            ? 'Tulis bimbingan / jawaban terverifikasi Guru PAI...'
                            : 'Tulis tanggapan atau jawaban santunmu di sini...'
                        }
                        className="flex-1 px-4 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        type="button"
                        onClick={() => handleSendReply(thread.id)}
                        className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0 shadow-md"
                      >
                        <Send className="w-3.5 h-3.5" /> Kirim Balasan
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Create Thread Modal */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-xl border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-emerald-400" />
                Buat Topik Diskusi / Pertanyaan PAI
              </h3>
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateThread} className="p-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Target Kelas Diskusi
                  </label>
                  <select
                    value={formClassId}
                    onChange={e => setFormClassId(e.target.value)}
                    disabled={!isAdmin && !!session.classId}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs font-bold text-white"
                  >
                    <option value="all">Semua Kelas (Umum)</option>
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        Kelas {c.className}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Elemen / Topik Materi PAI
                  </label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs font-bold text-white"
                  >
                    {TOPIC_CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Judul Pertanyaan / Topik Diskusi <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder="Contoh: Bagaimana cara menjaga kekhusyukan shalat berjamaah?"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Uraian Pertanyaan / Pendapat <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={4}
                  value={formContent}
                  onChange={e => setFormContent(e.target.value)}
                  placeholder="Awali dengan salam dan sampaikan pertanyaanmu dengan bahasa yang santun..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm leading-relaxed"
                  required
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/25 cursor-pointer"
                >
                  Terbitkan Diskusi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
