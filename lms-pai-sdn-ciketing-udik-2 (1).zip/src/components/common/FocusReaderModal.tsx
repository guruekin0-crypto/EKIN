import React, { useState, useEffect, useRef } from 'react';
import {
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  Sun,
  Moon,
  BookOpen,
  X,
  CheckCircle2,
  Award,
  Sparkles,
  ArrowLeft
} from 'lucide-react';

export interface FocusReaderProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  badgeText?: string;
  arabicText?: string;
  htmlContent?: string;
  plainContent?: string;
  extraSections?: Array<{ label: string; content: string }>;
  onCompleteReading?: () => void;
  completedRewardLabel?: string;
}

export const FocusReaderModal: React.FC<FocusReaderProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  badgeText,
  arabicText,
  htmlContent,
  plainContent,
  extraSections,
  onCompleteReading,
  completedRewardLabel
}) => {
  const [fontSize, setFontSize] = useState<number>(18);
  const [lineHeight, setLineHeight] = useState<number>(1.85);
  const [theme, setTheme] = useState<'dark' | 'sepia' | 'light'>('dark');
  const [isNativeFullscreen, setIsNativeFullscreen] = useState<boolean>(false);
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [rewardClaimed, setRewardClaimed] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setRewardClaimed(false);
    setScrollProgress(0);
  }, [title, isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const toggleBrowserFullscreen = async () => {
    try {
      if (!document.fullscreenElement && containerRef.current) {
        await containerRef.current.requestFullscreen();
        setIsNativeFullscreen(true);
      } else if (document.fullscreenElement) {
        await document.exitFullscreen();
        setIsNativeFullscreen(false);
      }
    } catch (e) {
      // Fallback: modal already covers 100vw x 100vh without sidebar/header
      setIsNativeFullscreen(!isNativeFullscreen);
    }
  };

  const handleScroll = () => {
    const el = scrollAreaRef.current;
    if (!el) return;
    const maxScroll = el.scrollHeight - el.clientHeight;
    if (maxScroll <= 0) {
      setScrollProgress(100);
      return;
    }
    const pct = Math.min(100, Math.round((el.scrollTop / maxScroll) * 100));
    setScrollProgress(pct);
  };

  const themeClasses = {
    dark: {
      bg: 'bg-slate-950 text-slate-100',
      header: 'bg-slate-900/95 border-white/10 text-white',
      card: 'bg-slate-900/80 border-white/10',
      arabicBox: 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200',
      subtext: 'text-slate-400'
    },
    sepia: {
      bg: 'bg-[#f8f1e4] text-[#3c2f2f]',
      header: 'bg-[#efe4d2]/95 border-[#d8c7ab] text-[#2c221e]',
      card: 'bg-[#f3ead8] border-[#dfceb4]',
      arabicBox: 'bg-[#e8dec8] border-[#b79f78] text-[#1b4332]',
      subtext: 'text-[#6e5a4f]'
    },
    light: {
      bg: 'bg-slate-50 text-slate-900',
      header: 'bg-white/95 border-slate-200 text-slate-900',
      card: 'bg-white border-slate-200 shadow-sm',
      arabicBox: 'bg-emerald-50 border-emerald-200 text-emerald-900',
      subtext: 'text-slate-500'
    }
  }[theme];

  return (
    <div
      ref={containerRef}
      className={`fixed inset-0 z-[100] flex flex-col w-screen h-screen overflow-hidden transition-colors duration-300 ${themeClasses.bg}`}
    >
      {/* Reading Progress Bar */}
      <div className="w-full h-1 bg-black/20 shrink-0">
        <div
          className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all duration-150"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Top Distraction-Free Reader Toolbar */}
      <div
        className={`px-4 sm:px-8 py-3 border-b backdrop-blur-md flex flex-wrap items-center justify-between gap-3 shrink-0 ${themeClasses.header}`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => {
              if (document.fullscreenElement) {
                document.exitFullscreen().catch(() => {});
              }
              onClose();
            }}
            className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer transition-all shrink-0"
          >
            <ArrowLeft className="w-4 h-4" /> Keluar Focus Reader
          </button>

          <div className="min-w-0 hidden sm:block">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold uppercase tracking-wider">
                <BookOpen className="w-3 h-3 inline mr-1" /> Mode Baca Fokus (Layar Penuh)
              </span>
              {badgeText && (
                <span className="text-[11px] font-semibold opacity-75 truncate">{badgeText}</span>
              )}
            </div>
          </div>
        </div>

        {/* Typography & Theme Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Theme Switcher */}
          <div className="flex items-center rounded-xl p-1 bg-black/15 border border-white/10">
            <button
              type="button"
              onClick={() => setTheme('dark')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                theme === 'dark'
                  ? 'bg-emerald-500 text-white shadow'
                  : 'opacity-70 hover:opacity-100'
              }`}
              title="Tema Gelap Nyaman"
            >
              <Moon className="w-3 h-3" /> Gelap
            </button>
            <button
              type="button"
              onClick={() => setTheme('sepia')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                theme === 'sepia'
                  ? 'bg-amber-600 text-white shadow'
                  : 'opacity-70 hover:opacity-100'
              }`}
              title="Tema Sepia Klasik"
            >
              Sepia
            </button>
            <button
              type="button"
              onClick={() => setTheme('light')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-all ${
                theme === 'light'
                  ? 'bg-cyan-600 text-white shadow'
                  : 'opacity-70 hover:opacity-100'
              }`}
              title="Tema Terang"
            >
              <Sun className="w-3 h-3" /> Terang
            </button>
          </div>

          {/* Font Size Controls */}
          <div className="flex items-center gap-1 rounded-xl p-1 bg-black/15 border border-white/10">
            <button
              type="button"
              onClick={() => setFontSize(prev => Math.max(14, prev - 2))}
              className="px-2.5 py-1 rounded-lg hover:bg-white/10 text-xs font-bold cursor-pointer"
              title="Perkecil Huruf"
            >
              A-
            </button>
            <span className="text-[11px] font-mono px-1.5 opacity-80">{fontSize}px</span>
            <button
              type="button"
              onClick={() => setFontSize(prev => Math.min(28, prev + 2))}
              className="px-2.5 py-1 rounded-lg hover:bg-white/10 text-xs font-bold cursor-pointer"
              title="Perbesar Huruf"
            >
              A+
            </button>
          </div>

          {/* Line Spacing */}
          <button
            type="button"
            onClick={() => setLineHeight(prev => (prev >= 2.2 ? 1.6 : +(prev + 0.25).toFixed(2)))}
            className="px-2.5 py-1.5 rounded-xl bg-black/15 hover:bg-black/25 border border-white/10 text-[11px] font-bold cursor-pointer"
            title="Atur Spasi Baris"
          >
            Spasi {lineHeight}x
          </button>

          {/* Native Fullscreen Toggle */}
          <button
            type="button"
            onClick={toggleBrowserFullscreen}
            className="p-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 cursor-pointer"
            title="Layar Penuh Penuh (F11)"
          >
            {isNativeFullscreen ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Main Scrollable Reading Canvas */}
      <div
        ref={scrollAreaRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-4 sm:px-10 py-8 sm:py-12 scrollbar-thin"
      >
        <div className="max-w-3xl mx-auto space-y-8 pb-16">
          {/* Document Header */}
          <div className="space-y-3 border-b border-current/10 pb-6">
            {subtitle && (
              <p className="text-xs font-bold uppercase tracking-widest text-emerald-500">
                {subtitle}
              </p>
            )}
            <h1 className="text-2xl sm:text-4xl font-extrabold font-display leading-tight">
              {title}
            </h1>
          </div>

          {/* Optional Arabic Verse / Khat Naskh Block */}
          {arabicText && (
            <div className={`p-6 sm:p-8 rounded-3xl border text-right shadow-lg ${themeClasses.arabicBox}`}>
              <p
                className="khat-naskh font-arabic leading-loose"
                style={{ fontSize: `${fontSize + 8}px`, lineHeight: 2.3 }}
                dir="rtl"
              >
                {arabicText}
              </p>
            </div>
          )}

          {/* Main HTML or Plain Content */}
          {htmlContent && (
            <div
              className="leading-relaxed space-y-4"
              style={{ fontSize: `${fontSize}px`, lineHeight }}
              dangerouslySetInnerHTML={{ __html: htmlContent }}
            />
          )}

          {plainContent && (
            <div
              className="leading-relaxed whitespace-pre-line font-serif"
              style={{ fontSize: `${fontSize}px`, lineHeight }}
            >
              {plainContent}
            </div>
          )}

          {/* Extra Structured Sections (e.g., for Teaching Journals) */}
          {extraSections && extraSections.length > 0 && (
            <div className="space-y-5 pt-4">
              {extraSections.map((sec, idx) => (
                <div
                  key={idx}
                  className={`p-5 sm:p-6 rounded-2xl border ${themeClasses.card} space-y-2`}
                >
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-500">
                    {sec.label}
                  </h4>
                  <p
                    className="leading-relaxed whitespace-pre-line"
                    style={{ fontSize: `${fontSize}px`, lineHeight }}
                  >
                    {sec.content}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Complete Reading & Gamification Action */}
          <div className={`p-6 rounded-3xl border ${themeClasses.card} flex flex-col sm:flex-row items-center justify-between gap-4 mt-10`}>
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <p className="font-bold text-sm">
                  {rewardClaimed
                    ? 'Alhamdulillah! Bacaan Telah Ditandai Selesai'
                    : 'Sudah Selesai Membaca dengan Fokus?'}
                </p>
                <p className={`text-xs ${themeClasses.subtext}`}>
                  {completedRewardLabel ||
                    'Tandai selesai membaca untuk mencatat progres literasi PAI & memperoleh Poin XP.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
              {onCompleteReading && !rewardClaimed && (
                <button
                  type="button"
                  onClick={() => {
                    setRewardClaimed(true);
                    onCompleteReading();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 cursor-pointer transition-all"
                >
                  <Award className="w-4 h-4" /> Selesai Baca & Klaim Poin XP
                </button>
              )}

              {rewardClaimed && (
                <span className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Poin XP Tercatat
                </span>
              )}

              <button
                type="button"
                onClick={() => {
                  if (document.fullscreenElement) {
                    document.exitFullscreen().catch(() => {});
                  }
                  onClose();
                }}
                className="px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-500 font-bold text-xs cursor-pointer transition-colors"
              >
                Tutup Layar Penuh
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
