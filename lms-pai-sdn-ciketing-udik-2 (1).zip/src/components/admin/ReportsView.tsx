import React, { useState } from 'react';
import {
  BarChart3,
  Printer,
  FileSpreadsheet,
  TrendingUp,
  Award,
  AlertCircle,
  X,
  School,
  CheckCircle2
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { StorageService } from '../../services/storageService';

interface ReportsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ showToast }) => {
  const classes = StorageService.getClasses();
  const [selectedClass, setSelectedClass] = useState<string>(classes[0]?.id || '');
  const [selectedSemester, setSelectedSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');

  const [printModalOpen, setPrintModalOpen] = useState(false);

  const teacherProfile = StorageService.getTeacherProfile();
  const appSettings = StorageService.getAppSettings();

  const recap = StorageService.getClassRecap(selectedClass, selectedSemester);

  const exportExcel = () => {
    if (!recap.students.length) {
      showToast('Tidak ada data siswa untuk diekspor', 'error');
      return;
    }

    const exportData = recap.students.map((s, idx) => {
      const row: any = {
        'No': idx + 1,
        'NIS': s.nis,
        'Nama Lengkap Siswa': s.name
      };

      recap.quizzes.forEach((q, qIdx) => {
        row[`Kuis ${qIdx + 1}: ${q.title.substring(0, 25)}`] =
          s.quizScores[q.id] !== null ? s.quizScores[q.id] : '-';
      });

      row['Rata-rata Nilai'] = s.avg;
      row['Kategori KKTP'] =
        s.avg >= 85
          ? 'Sangat Baik'
          : s.avg >= 70
          ? 'Baik'
          : s.avg >= 60
          ? 'Cukup'
          : 'Perlu Bimbingan';

      return row;
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `Rekap_Nilai_${recap.className}`);
    XLSX.writeFile(
      wb,
      `Rekap_Nilai_PAI_${recap.className}_Semester_${selectedSemester}.xlsx`
    );
  };

  // Grade distributions
  const countSangatBaik = recap.students.filter(s => s.avg >= 85).length;
  const countBaik = recap.students.filter(s => s.avg >= 70 && s.avg < 85).length;
  const countCukup = recap.students.filter(s => s.avg >= 60 && s.avg < 70).length;
  const countPerluBimbingan = recap.students.filter(s => s.avg < 60 && s.quizCount > 0).length;

  return (
    <div className="space-y-5">
      {/* Top Filter and Actions */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Rombel Kelas
            </label>
            <select
              value={selectedClass}
              onChange={e => setSelectedClass(e.target.value)}
              className="w-full sm:w-48 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>
                  Kelas {c.className}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Semester
            </label>
            <select
              value={selectedSemester}
              onChange={e => setSelectedSemester(e.target.value as any)}
              className="w-full sm:w-36 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              <option value="Ganjil">Semester Ganjil</option>
              <option value="Genap">Semester Genap</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            onClick={exportExcel}
            className="px-4 py-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-bold text-xs sm:text-sm flex items-center gap-2 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" /> Export Excel
          </button>
          <button
            onClick={() => setPrintModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 font-bold text-xs sm:text-sm flex items-center gap-2 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" /> Cetak Raport Nilai
          </button>
        </div>
      </div>

      {/* KPI Stats Ribbon */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="glass rounded-2xl p-4 border border-white/10">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Rata-Rata Kelas
          </span>
          <p className="text-2xl font-extrabold font-display text-emerald-400 tabular-nums">
            {recap.stats.avgClass}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Skala nilai 100</p>
        </div>

        <div className="glass rounded-2xl p-4 border border-white/10">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Nilai Tertinggi
          </span>
          <p className="text-2xl font-extrabold font-display text-cyan-400 tabular-nums">
            {recap.stats.highest}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Pencapaian maksimal</p>
        </div>

        <div className="glass rounded-2xl p-4 border border-white/10">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Sangat Baik (≥85)
          </span>
          <p className="text-2xl font-extrabold font-display text-indigo-400 tabular-nums">
            {countSangatBaik} Siswa
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Predikat Istimewa</p>
        </div>

        <div className="glass rounded-2xl p-4 border border-white/10">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Perlu Bimbingan (&lt;60)
          </span>
          <p className="text-2xl font-extrabold font-display text-rose-400 tabular-nums">
            {countPerluBimbingan} Siswa
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Perlu Program Remedial</p>
        </div>
      </div>

      {/* Spreadsheet Matrix Table */}
      <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h4 className="font-bold text-sm text-white flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-400" /> Lembar Rekap Nilai Siswa Kelas {recap.className}
          </h4>
          <span className="text-xs text-slate-400 font-mono">
            {recap.students.length} Siswa &bull; {recap.quizzes.length} Paket Kuis
          </span>
        </div>

        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs min-w-[750px]">
            <thead className="bg-white/5 text-[10px] uppercase font-bold text-slate-400 border-b border-white/10">
              <tr>
                <th className="py-3 px-3 w-10 text-center">No</th>
                <th className="py-3 px-3 w-24">NIS</th>
                <th className="py-3 px-4 w-48">Nama Siswa</th>
                {recap.quizzes.map((q, idx) => (
                  <th
                    key={q.id}
                    className="py-3 px-3 text-center min-w-[90px] max-w-[140px] truncate"
                    title={q.title}
                  >
                    Kuis {idx + 1}
                  </th>
                ))}
                <th className="py-3 px-3 text-center w-24 text-emerald-400 font-bold">Rata-Rata</th>
                <th className="py-3 px-3 text-center w-28">Kategori KKTP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {recap.students.length === 0 ? (
                <tr>
                  <td colSpan={5 + recap.quizzes.length} className="text-center py-10 text-slate-400 italic">
                    Belum ada siswa di kelas ini.
                  </td>
                </tr>
              ) : (
                recap.students.map((s, index) => {
                  const kktpColor =
                    s.avg >= 85
                      ? 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30'
                      : s.avg >= 70
                      ? 'text-cyan-400 bg-cyan-500/15 border-cyan-500/30'
                      : s.avg >= 60
                      ? 'text-amber-400 bg-amber-500/15 border-amber-500/30'
                      : 'text-rose-400 bg-rose-500/15 border-rose-500/30';

                  const kktpLabel =
                    s.avg >= 85
                      ? 'Sangat Baik'
                      : s.avg >= 70
                      ? 'Baik'
                      : s.avg >= 60
                      ? 'Cukup'
                      : 'Remedial';

                  return (
                    <tr key={s.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-3 text-center font-mono text-slate-400">{index + 1}</td>
                      <td className="py-3 px-3 font-mono text-slate-400">{s.nis}</td>
                      <td className="py-3 px-4 font-bold text-white">{s.name}</td>
                      {recap.quizzes.map(q => {
                        const val = s.quizScores[q.id];
                        return (
                          <td key={q.id} className="py-3 px-3 text-center font-mono">
                            {val !== null ? (
                              <span className="font-bold text-slate-200">{val}</span>
                            ) : (
                              <span className="text-slate-600">-</span>
                            )}
                          </td>
                        );
                      })}
                      <td className="py-3 px-3 text-center font-extrabold text-emerald-400 font-mono text-sm">
                        {s.avg}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${kktpColor}`}
                        >
                          {kktpLabel}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Printable Grade Sheet Modal */}
      {printModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between no-print">
              <div>
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Printer className="w-5 h-5 text-indigo-400" /> Cetak Rekapitulasi Nilai Resmi
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Laporan hasil penilaian Pendidikan Agama Islam & Budi Pekerti
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> Cetak Dokumen
                </button>
                <button
                  onClick={() => setPrintModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 sm:p-10 overflow-y-auto flex-1 bg-white text-black font-serif text-sm">
              <div className="text-center pb-4 border-b-2 border-black mb-5">
                <h3 className="text-sm font-bold tracking-wider uppercase">
                  PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN
                </h3>
                <h2 className="text-base font-extrabold uppercase">
                  {teacherProfile.schoolName || 'SDN CIKETING UDIK 2 BANTARGEBANG'}
                </h2>
                <p className="text-xs italic text-gray-700">
                  {appSettings.schoolAddress || 'Jl. Raya Ciketing Udik No. 2, Bantargebang, Kota Bekasi'}
                </p>
                <div className="mt-3 py-1 border-t border-b border-black text-center font-bold text-xs uppercase tracking-widest">
                  DAFTAR REKAPITULASI NILAI ASESMEN PAI & BUDI PEKERTI
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                <div>
                  <p><strong>Kelas:</strong> {recap.className}</p>
                  <p><strong>Mata Pelajaran:</strong> Pendidikan Agama Islam</p>
                </div>
                <div className="text-right">
                  <p><strong>Semester:</strong> {selectedSemester}</p>
                  <p><strong>Tahun Ajaran:</strong> {appSettings.academicYear || '2026/2027'}</p>
                </div>
              </div>

              <table className="w-full border-collapse border border-black text-xs mb-8">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-black p-2 text-center w-8">No</th>
                    <th className="border border-black p-2 w-24">NIS</th>
                    <th className="border border-black p-2">Nama Siswa</th>
                    {recap.quizzes.map((q, i) => (
                      <th key={q.id} className="border border-black p-2 text-center w-16">
                        UH {i + 1}
                      </th>
                    ))}
                    <th className="border border-black p-2 text-center w-20">Rata-Rata</th>
                    <th className="border border-black p-2 text-center w-28">Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                  {recap.students.map((s, idx) => (
                    <tr key={s.id}>
                      <td className="border border-black p-2 text-center">{idx + 1}</td>
                      <td className="border border-black p-2 font-mono">{s.nis}</td>
                      <td className="border border-black p-2 font-bold">{s.name}</td>
                      {recap.quizzes.map(q => (
                        <td key={q.id} className="border border-black p-2 text-center font-mono">
                          {s.quizScores[q.id] !== null ? s.quizScores[q.id] : '-'}
                        </td>
                      ))}
                      <td className="border border-black p-2 text-center font-bold font-mono">
                        {s.avg}
                      </td>
                      <td className="border border-black p-2 text-center text-[10px]">
                        {s.avg >= 70 ? 'Tuntas' : 'Remedial'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="grid grid-cols-2 text-xs pt-4 break-inside-avoid">
                <div className="text-center">
                  <p>Mengetahui,</p>
                  <p>Kepala SDN Ciketing Udik 2</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{appSettings.principalName || 'Hj. Siti Rohmah, M.Pd.'}</p>
                  <p>NIP. {appSettings.principalNip || '-'}</p>
                </div>
                <div className="text-center">
                  <p>Bekasi, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                  <p>Guru Pendidikan Agama Islam</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{teacherProfile.fullName}</p>
                  <p>NIP. {teacherProfile.nip || '-'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
