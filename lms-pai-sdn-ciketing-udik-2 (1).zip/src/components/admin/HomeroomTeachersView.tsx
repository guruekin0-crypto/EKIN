import React, { useState } from 'react';
import {
  UserCheck,
  Users,
  RefreshCw,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Phone,
  Mail,
  School,
  CloudUpload,
  X,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { HomeroomTeacherProfile, TeachingDocType } from '../../types';
import { StorageService } from '../../services/storageService';

interface HomeroomTeachersViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onNavigate?: (viewId: string) => void;
}

const DOC_TYPES_CONFIG: Array<{ type: TeachingDocType; label: string; short: string }> = [
  { type: 'cp_atp', label: 'CP & ATP (BKPDM 020/2026)', short: 'CP/ATP' },
  { type: 'prota', label: 'Program Tahunan', short: 'Prota' },
  { type: 'promes', label: 'Program Semester', short: 'Promes' },
  { type: 'kktp', label: 'Kriteria Ketuntasan (KKTP)', short: 'KKTP' },
  { type: 'modul_ajar', label: 'Modul Ajar KBC', short: 'Modul Ajar' },
  { type: 'lkpd', label: 'LKPD Siswa', short: 'LKPD' }
];

export const HomeroomTeachersView: React.FC<HomeroomTeachersViewProps> = ({
  showToast,
  onNavigate
}) => {
  const [teachers, setTeachers] = useState<HomeroomTeacherProfile[]>(
    StorageService.getHomeroomTeachers()
  );
  const classes = StorageService.getClasses();
  const [isSyncing, setIsSyncing] = useState(false);

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<HomeroomTeacherProfile | null>(null);

  const [formClassId, setFormClassId] = useState(classes[0]?.id || 'c1');
  const [formTeacherName, setFormTeacherName] = useState('');
  const [formNip, setFormNip] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formAcademicYear, setFormAcademicYear] = useState('2026/2027');
  const [formUploadedDocs, setFormUploadedDocs] = useState<TeachingDocType[]>([
    'cp_atp',
    'prota',
    'promes'
  ]);
  const [formNotes, setFormNotes] = useState('');

  const refreshData = () => {
    setTeachers(StorageService.getHomeroomTeachers());
  };

  const handleSyncRombelAndCloud = async () => {
    setIsSyncing(true);
    try {
      const synced = StorageService.syncHomeroomRombelData();
      setTeachers(synced);
      const cloudRes = await StorageService.syncAllToSupabase();
      showToast(
        `Data ${synced.length} Wali Kelas, jumlah siswa per rombel, & Perangkat Ajar berhasil disinkronkan ke Supabase! (${cloudRes.uploadedCount} tabel)`,
        'success'
      );
    } catch (e) {
      showToast('Sinkronisasi data siswa per rombel selesai!', 'info');
    } finally {
      setIsSyncing(false);
    }
  };

  const openAddModal = () => {
    setEditingItem(null);
    setFormClassId(classes[0]?.id || 'c1');
    setFormTeacherName('');
    setFormNip('');
    setFormPhone('');
    setFormEmail('');
    setFormAcademicYear('2026/2027');
    setFormUploadedDocs(['cp_atp', 'prota', 'promes']);
    setFormNotes('');
    setModalOpen(true);
  };

  const openEditModal = (item: HomeroomTeacherProfile) => {
    setEditingItem(item);
    setFormClassId(item.classId);
    setFormTeacherName(item.teacherName);
    setFormNip(item.nip);
    setFormPhone(item.phone);
    setFormEmail(item.email || '');
    setFormAcademicYear(item.academicYear || '2026/2027');
    setFormUploadedDocs(item.uploadedDocTypes || []);
    setFormNotes(item.notes || '');
    setModalOpen(true);
  };

  const toggleDocTypeInForm = (docType: TeachingDocType) => {
    setFormUploadedDocs(prev =>
      prev.includes(docType) ? prev.filter(d => d !== docType) : [...prev, docType]
    );
  };

  const toggleDocStatusDirect = (teacher: HomeroomTeacherProfile, docType: TeachingDocType) => {
    const exists = teacher.uploadedDocTypes.includes(docType);
    const updatedDocs = exists
      ? teacher.uploadedDocTypes.filter(d => d !== docType)
      : [...teacher.uploadedDocTypes, docType];

    StorageService.saveHomeroomTeacher({
      ...teacher,
      uploadedDocTypes: updatedDocs
    });
    refreshData();
    showToast(
      `Status unggah ${docType.toUpperCase()} Kelas ${teacher.className} diperbarui`,
      'success'
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTeacherName.trim()) {
      showToast('Nama Guru Wali Kelas wajib diisi!', 'error');
      return;
    }

    const cls = classes.find(c => c.id === formClassId);
    const className = cls ? cls.className : '1A';
    const gradeLevel = className.replace(/\D/g, '') || '1';

    StorageService.saveHomeroomTeacher({
      id: editingItem?.id,
      classId: formClassId,
      className,
      gradeLevel,
      teacherName: formTeacherName.trim(),
      nip: formNip.trim() || '-',
      phone: formPhone.trim() || '-',
      email: formEmail.trim() || undefined,
      academicYear: formAcademicYear.trim() || '2026/2027',
      studentCount: cls?.studentCount || editingItem?.studentCount || 0,
      uploadedDocTypes: formUploadedDocs,
      notes: formNotes.trim()
    });

    setModalOpen(false);
    refreshData();
    showToast(
      editingItem
        ? 'Profil Wali Kelas berhasil diperbarui & disinkronkan!'
        : 'Data Wali Kelas baru berhasil ditambahkan!'
    );
  };

  const handleDelete = (item: HomeroomTeacherProfile) => {
    StorageService.deleteHomeroomTeacher(item.id);
    refreshData();
    showToast(`Data Wali Kelas ${item.className} telah dihapus`, 'info');
  };

  // Summary metrics
  const totalStudentsInRombels = teachers.reduce((acc, t) => acc + (t.studentCount || 0), 0);
  const fullyCompletedCount = teachers.filter(
    t => t.uploadedDocTypes.length >= DOC_TYPES_CONFIG.length
  ).length;
  const averageCompletionPct = teachers.length
    ? Math.round(
        (teachers.reduce((acc, t) => acc + t.uploadedDocTypes.length, 0) /
          (teachers.length * DOC_TYPES_CONFIG.length)) *
          100
      )
    : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="glass-strong rounded-3xl p-5 sm:p-6 border border-emerald-500/25 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
            <UserCheck className="w-3.5 h-3.5" /> Manajemen Wali Kelas &amp; Monitoring Perangkat Ajar
          </div>
          <h2 className="text-lg sm:text-xl font-bold font-display text-white">
            Profil Guru Wali Kelas &amp; Sinkronisasi Rombel SDN Ciketing Udik 2
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Kelola identitas wali kelas (Kelas 1 s.d. 6), sinkronkan jumlah siswa per rombongan belajar secara otomatis, dan pantau kelengkapan dokumen perangkat ajar Kurikulum Merdeka berbasis KBC (Kep. Kepala BKPDM No. 020 Tahun 2026).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleSyncRombelAndCloud}
            disabled={isSyncing}
            className="px-4 py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-bold text-xs flex items-center gap-2 cursor-pointer transition-all"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Siswa Rombel & Supabase'}
          </button>

          <button
            type="button"
            onClick={openAddModal}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4" /> + Tambah Wali Kelas
          </button>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-4 sm:p-5 border border-white/10 flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Total Wali Kelas Aktif
            </p>
            <p className="text-2xl sm:text-3xl font-extrabold text-white font-display mt-1">
              {teachers.length} <span className="text-xs font-normal text-slate-400">Rombel</span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <School className="w-6 h-6" />
          </div>
        </div>

        <div className="glass rounded-2xl p-4 sm:p-5 border border-white/10 flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Total Siswa Tersinkron
            </p>
            <p className="text-2xl sm:text-3xl font-extrabold text-cyan-300 font-display mt-1">
              {totalStudentsInRombels}{' '}
              <span className="text-xs font-normal text-slate-400">Peserta Didik</span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="glass rounded-2xl p-4 sm:p-5 border border-white/10 flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Ketercapaian Unggah Perangkat Ajar
            </p>
            <p className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-display mt-1">
              {averageCompletionPct}%{' '}
              <span className="text-xs font-normal text-slate-400">
                ({fullyCompletedCount}/{teachers.length} Lengkap)
              </span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Homeroom Teachers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {teachers.map(item => {
          const uploadedCount = item.uploadedDocTypes.length;
          const totalRequired = DOC_TYPES_CONFIG.length;
          const pct = Math.round((uploadedCount / totalRequired) * 100);
          const isComplete = uploadedCount >= totalRequired;

          return (
            <div
              key={item.id}
              className="glass rounded-3xl p-5 border border-white/10 hover:border-emerald-500/30 transition-all shadow-lg flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Header Row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex flex-col items-center justify-center text-white font-extrabold shadow-md shrink-0">
                      <span className="text-[9px] uppercase tracking-wider opacity-80">Kelas</span>
                      <span className="text-sm leading-none">{item.className}</span>
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-base text-white">{item.teacherName}</h4>
                      </div>
                      <p className="text-xs text-slate-400 font-mono">NIP: {item.nip || '-'}</p>
                      <div className="flex flex-wrap items-center gap-3 mt-1 text-[11px] text-slate-300">
                        <span className="flex items-center gap-1 text-emerald-400 font-bold">
                          <Users className="w-3.5 h-3.5" /> {item.studentCount} Siswa Rombel
                        </span>
                        {item.phone && item.phone !== '-' && (
                          <span className="flex items-center gap-1 text-slate-400">
                            <Phone className="w-3 h-3" /> {item.phone}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => openEditModal(item)}
                      className="p-2 rounded-xl bg-blue-500/15 hover:bg-blue-500/25 text-blue-400 cursor-pointer transition-colors"
                      title="Edit Wali Kelas"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(item)}
                      className="p-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 cursor-pointer transition-colors"
                      title="Hapus"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Progress Bar Perangkat Ajar */}
                <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-white/10 space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-200 flex items-center gap-1.5">
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> Status Unggah Perangkat Ajar (Klik untuk Ubah):
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isComplete
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {uploadedCount}/{totalRequired} Dokumen ({pct}%)
                    </span>
                  </div>

                  <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isComplete
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                          : 'bg-gradient-to-r from-amber-500 to-orange-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  {/* Checklist Chips */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 pt-1">
                    {DOC_TYPES_CONFIG.map(docCfg => {
                      const checked = item.uploadedDocTypes.includes(docCfg.type);
                      return (
                        <button
                          key={docCfg.type}
                          type="button"
                          onClick={() => toggleDocStatusDirect(item, docCfg.type)}
                          className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1.5 border text-left cursor-pointer transition-all ${
                            checked
                              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10'
                          }`}
                          title={`Klik untuk menandai ${docCfg.label}`}
                        >
                          {checked ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          ) : (
                            <AlertCircle className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          )}
                          <span className="truncate">{docCfg.short}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {item.notes && (
                  <p className="text-xs text-slate-300 italic bg-white/5 px-3 py-2 rounded-xl border border-white/5">
                    "{item.notes}"
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
                <span>
                  Sinkron Terakhir:{' '}
                  {new Date(item.lastSyncedAt).toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                  })}
                </span>
                {onNavigate && (
                  <button
                    type="button"
                    onClick={() => onNavigate('teaching-docs')}
                    className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    Buka Dokumen Kelas {item.gradeLevel} <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-emerald-400" />
                {editingItem ? 'Edit Profil Guru Wali Kelas' : 'Tambah Wali Kelas Baru'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 overflow-y-auto flex-1 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Pilih Rombel Kelas <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={formClassId}
                    onChange={e => setFormClassId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        Kelas {c.className} ({c.studentCount || 0} Siswa)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Tahun Ajaran
                  </label>
                  <input
                    type="text"
                    value={formAcademicYear}
                    onChange={e => setFormAcademicYear(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Nama Lengkap &amp; Gelar Guru Wali Kelas <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formTeacherName}
                  onChange={e => setFormTeacherName(e.target.value)}
                  placeholder="Contoh: Rina Marlina, S.Pd.SD"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    NIP Wali Kelas
                  </label>
                  <input
                    type="text"
                    value={formNip}
                    onChange={e => setFormNip(e.target.value)}
                    placeholder="198902142014022005"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Nomor HP / WhatsApp
                  </label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={e => setFormPhone(e.target.value)}
                    placeholder="0812-xxxx-xxxx"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-2">
                  Checklist Perangkat Ajar yang Sudah Diunggah (BKPDM No. 020/2026 KBC)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {DOC_TYPES_CONFIG.map(docCfg => {
                    const checked = formUploadedDocs.includes(docCfg.type);
                    return (
                      <button
                        key={docCfg.type}
                        type="button"
                        onClick={() => toggleDocTypeInForm(docCfg.type)}
                        className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                          checked
                            ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                            : 'bg-white/5 border-white/10 text-slate-400'
                        }`}
                      >
                        <CheckCircle2
                          className={`w-4 h-4 ${checked ? 'text-emerald-400' : 'text-slate-600'}`}
                        />
                        <span>{docCfg.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Catatan Pendampingan Kelas / Fokus KBC
                </label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  placeholder="Catatan koordinasi Guru PAI dengan Wali Kelas..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/25 cursor-pointer"
                >
                  Simpan &amp; Sinkronkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
