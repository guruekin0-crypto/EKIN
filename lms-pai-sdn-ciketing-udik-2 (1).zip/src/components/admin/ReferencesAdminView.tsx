import React, { useState } from 'react';
import {
  Library,
  Plus,
  Search,
  BookOpen,
  Volume2,
  Trash2,
  X,
  Sparkles
} from 'lucide-react';
import { ReadingReference } from '../../types';
import { StorageService } from '../../services/storageService';

interface ReferencesAdminViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ReferencesAdminView: React.FC<ReferencesAdminViewProps> = ({ showToast }) => {
  const [references, setReferences] = useState<ReadingReference[]>(StorageService.getReferences());
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [search, setSearch] = useState('');

  const [modalOpen, setModalOpen] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<'Juz Amma' | 'Doa Harian' | 'Kisah 25 Nabi'>('Juz Amma');
  const [formArabic, setFormArabic] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formTranslation, setFormTranslation] = useState('');

  // Audio simulation state
  const [playingRefId, setPlayingRefId] = useState<string | null>(null);

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const refreshRefs = () => {
    setReferences(StorageService.getReferences());
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      showToast('Judul referensi wajib diisi!', 'error');
      return;
    }

    StorageService.saveReference({
      title: formTitle.trim(),
      refType: formCategory === 'Juz Amma' ? 'juz_amma' : formCategory === 'Doa Harian' ? 'doa' : 'kisah_nabi',
      category: formCategory,
      arabicSnippet: formArabic.trim() || undefined,
      content: formContent.trim(),
      translation: formTranslation.trim() || undefined
    });

    setModalOpen(false);
    refreshRefs();
    showToast('Referensi bacaan berhasil ditambahkan ke perpustakaan');
  };

  const handleDelete = (id: string, title: string) => {
    setDeleteTarget({ id, title });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteReference(deleteTarget.id);
    refreshRefs();
    showToast(`Referensi "${deleteTarget.title}" berhasil dihapus`, 'info');
    setDeleteTarget(null);
  };

  const playMurottalAudio = (id: string) => {
    if (playingRefId === id) {
      setPlayingRefId(null);
      showToast('Audio dihentikan', 'info');
    } else {
      setPlayingRefId(id);
      showToast('Memutar audio tilawah Al-Qur\'an...', 'info');
    }
  };

  const filtered = references.filter(r => {
    const matchCat =
      activeCategory === 'all' ||
      r.category.toLowerCase().includes(activeCategory.toLowerCase());
    const matchSearch =
      r.title.toLowerCase().includes(search.toLowerCase()) ||
      r.content.toLowerCase().includes(search.toLowerCase()) ||
      (r.translation || '').toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="space-y-5">
      {/* Search and Category Filter Bar */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto flex-1">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari Surah, Doa, Kisah Nabi..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-xl border border-white/10 w-full sm:w-auto">
            {['all', 'Juz Amma', 'Doa Harian', 'Kisah 25 Nabi'].map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-emerald-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat === 'all' ? 'Semua Referensi' : cat}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => {
            setFormTitle('');
            setFormCategory('Juz Amma');
            setFormArabic('');
            setFormContent('');
            setFormTranslation('');
            setModalOpen(true);
          }}
          className="w-full md:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> + Tambah Bacaan
        </button>
      </div>

      {/* Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(r => (
          <div
            key={r.id}
            className="glass rounded-2xl p-5 border border-white/10 hover:border-emerald-500/30 transition-all shadow-md flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[11px]">
                  {r.category}
                </span>

                <button
                  onClick={() => playMurottalAudio(r.id)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    playingRefId === r.id
                      ? 'bg-cyan-500 text-white animate-pulse'
                      : 'bg-white/5 hover:bg-white/10 text-cyan-300 border border-white/10'
                  }`}
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>{playingRefId === r.id ? 'Berhenti' : 'Putar Audio'}</span>
                </button>
              </div>

              <h4 className="font-bold text-base text-white">{r.title}</h4>

              {r.arabicSnippet && (
                <div className="mt-3 p-3.5 rounded-xl bg-slate-900/80 border border-emerald-500/20 text-right">
                  <p className="khat-naskh text-emerald-300 leading-relaxed font-arabic">
                    {r.arabicSnippet}
                  </p>
                </div>
              )}

              <p className="text-xs text-slate-300 mt-2.5 leading-relaxed font-serif italic">
                {r.content}
              </p>

              {r.translation && (
                <div className="mt-2.5 pt-2 border-t border-white/5 text-[11px] text-slate-400 leading-relaxed">
                  <span className="font-bold text-slate-300">Arti/Terjemahan:</span> {r.translation}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-emerald-400" /> Referensi Terverifikasi
              </span>
              <button
                onClick={() => handleDelete(r.id, r.title)}
                className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 cursor-pointer transition-colors"
                title="Hapus Referensi"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal Add Reference */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-lg max-h-[90vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Library className="w-5 h-5 text-emerald-400" />
                Tambah Referensi Bacaan PAI
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 overflow-y-auto flex-1 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Kategori Referensi
                </label>
                <select
                  value={formCategory}
                  onChange={e => setFormCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                >
                  <option value="Juz Amma">Juz Amma (Surah Al-Qur'an)</option>
                  <option value="Doa Harian">Doa Sehari-hari Anak Shalih</option>
                  <option value="Kisah 25 Nabi">Kisah 25 Nabi & Rasul</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Nama Surah / Judul Doa <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder="Contoh: Surah Al-Kautsar / Doa Sebelum Tidur"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Teks Arab (Khat Naskh)
                </label>
                <textarea
                  rows={3}
                  dir="rtl"
                  value={formArabic}
                  onChange={e => setFormArabic(e.target.value)}
                  placeholder="Tuliskan ayat atau doa dalam bahasa Arab..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-emerald-300 font-arabic text-base leading-loose focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Teks Latin / Transliterasi / Uraian
                </label>
                <textarea
                  rows={2}
                  value={formContent}
                  onChange={e => setFormContent(e.target.value)}
                  placeholder="Bacaan latin atau uraian ringkas..."
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Arti / Terjemahan Bahasa Indonesia
                </label>
                <textarea
                  rows={2}
                  value={formTranslation}
                  onChange={e => setFormTranslation(e.target.value)}
                  placeholder="Terjemahan..."
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-md"
                >
                  Simpan Referensi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Referensi Bacaan?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus referensi bacaan{' '}
              <span className="text-white font-bold">"{deleteTarget.title}"</span> dari perpustakaan PAI? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
