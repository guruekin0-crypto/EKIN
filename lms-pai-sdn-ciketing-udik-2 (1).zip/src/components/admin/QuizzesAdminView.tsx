import React, { useState } from 'react';
import {
  FileQuestion,
  Plus,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Eye,
  Trash2,
  Edit2,
  X,
  Users,
  Check,
  CheckSquare
} from 'lucide-react';
import { Quiz, ClassItem, Question } from '../../types';
import { StorageService } from '../../services/storageService';

interface QuizzesAdminViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const QuizzesAdminView: React.FC<QuizzesAdminViewProps> = ({ showToast }) => {
  const [quizzes, setQuizzes] = useState<Quiz[]>(StorageService.getQuizzes());
  const classes = StorageService.getClasses();
  const allQuestions = StorageService.getQuestions();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);

  // Form states
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formClassId, setFormClassId] = useState(classes[0]?.id || '');
  const [formDuration, setFormDuration] = useState(30);
  const [formDeadline, setFormDeadline] = useState('2026-11-15T23:59');
  const [formRandomize, setFormRandomize] = useState(true);
  const [formShowScore, setFormShowScore] = useState(true);
  const [formSemester, setFormSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [formStatus, setFormStatus] = useState<'published' | 'draft' | 'closed'>('published');
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<string[]>([]);

  // Submissions Modal
  const [submissionsModalOpen, setSubmissionsModalOpen] = useState(false);
  const [activeQuizForSubmissions, setActiveQuizForSubmissions] = useState<Quiz | null>(null);

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const refreshQuizzes = () => {
    setQuizzes(StorageService.getQuizzes());
  };

  const openAddModal = () => {
    setEditingQuiz(null);
    setFormTitle('');
    setFormDesc('');
    setFormClassId(classes[0]?.id || '');
    setFormDuration(30);
    setFormDeadline('2026-11-20T23:59');
    setFormRandomize(true);
    setFormShowScore(true);
    setFormSemester('Ganjil');
    setFormStatus('published');
    // Pre-select first 5 questions
    setSelectedQuestionIds(allQuestions.slice(0, 5).map(q => q.id));
    setModalOpen(true);
  };

  const openEditModal = (q: Quiz) => {
    setEditingQuiz(q);
    setFormTitle(q.title);
    setFormDesc(q.description);
    setFormClassId(q.classId);
    setFormDuration(q.durationMinutes);
    setFormDeadline(q.deadline ? q.deadline.substring(0, 16) : '');
    setFormRandomize(q.randomize);
    setFormShowScore(q.showScoreImmediately);
    setFormSemester(q.semester);
    setFormStatus(q.status);
    setSelectedQuestionIds([...q.questionIds]);
    setModalOpen(true);
  };

  const toggleQuestionSelection = (qid: string) => {
    if (selectedQuestionIds.includes(qid)) {
      setSelectedQuestionIds(selectedQuestionIds.filter(id => id !== qid));
    } else {
      setSelectedQuestionIds([...selectedQuestionIds, qid]);
    }
  };

  const selectAllQuestions = () => {
    if (selectedQuestionIds.length === allQuestions.length) {
      setSelectedQuestionIds([]);
    } else {
      setSelectedQuestionIds(allQuestions.map(q => q.id));
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      showToast('Judul kuis wajib diisi!', 'error');
      return;
    }
    if (selectedQuestionIds.length === 0) {
      showToast('Pilih minimal 1 soal dari Bank Soal!', 'error');
      return;
    }

    const cls = classes.find(c => c.id === formClassId);
    StorageService.saveQuiz({
      id: editingQuiz ? editingQuiz.id : undefined,
      title: formTitle.trim(),
      description: formDesc.trim(),
      classId: formClassId,
      className: cls ? cls.className : '',
      durationMinutes: Number(formDuration) || 30,
      deadline: formDeadline ? new Date(formDeadline).toISOString() : undefined,
      randomize: formRandomize,
      showScoreImmediately: formShowScore,
      totalQuestions: selectedQuestionIds.length,
      status: formStatus,
      semester: formSemester,
      questionIds: selectedQuestionIds
    });

    setModalOpen(false);
    refreshQuizzes();
    showToast(editingQuiz ? 'Paket kuis diperbarui' : 'Paket kuis baru berhasil diterbitkan');
  };

  const handleDelete = (id: string, title: string) => {
    setDeleteTarget({ id, title });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteQuiz(deleteTarget.id);
    refreshQuizzes();
    showToast(`Kuis "${deleteTarget.title}" berhasil dihapus`, 'info');
    setDeleteTarget(null);
  };

  const viewSubmissions = (quiz: Quiz) => {
    setActiveQuizForSubmissions(quiz);
    setSubmissionsModalOpen(true);
  };

  const toggleStatusDirect = (quiz: Quiz) => {
    const nextStatus = quiz.status === 'published' ? 'closed' : 'published';
    StorageService.saveQuiz({
      ...quiz,
      status: nextStatus
    });
    refreshQuizzes();
    showToast(`Status kuis diubah menjadi: ${nextStatus.toUpperCase()}`, 'info');
  };

  return (
    <div className="space-y-5">
      {/* Top Bar */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-3 border border-white/10">
        <div>
          <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 font-display">
            <FileQuestion className="w-5 h-5 text-indigo-400" /> Manajemen Penilaian & Ujian PAI
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Buat dan pantau pengerjaan kuis harian, sumatif, dan ulangan daring siswa
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> + Buat Kuis Baru
        </button>
      </div>

      {/* Quizzes List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {quizzes.length === 0 ? (
          <div className="col-span-2 glass rounded-2xl p-10 text-center text-slate-400 italic">
            Belum ada paket kuis yang dibuat. Klik <b>"+ Buat Kuis Baru"</b> untuk merilis kuis pertama.
          </div>
        ) : (
          quizzes.map(quiz => {
            const isClosed = quiz.status === 'closed';
            const isDraft = quiz.status === 'draft';
            return (
              <div
                key={quiz.id}
                className="glass rounded-2xl p-5 border border-white/10 hover:border-indigo-500/40 transition-all shadow-lg flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[11px]">
                      Kelas {quiz.className || 'Semua'} &bull; Semester {quiz.semester}
                    </span>
                    <button
                      onClick={() => toggleStatusDirect(quiz)}
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider cursor-pointer border transition-colors ${
                        isClosed
                          ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                          : isDraft
                          ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                          : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      }`}
                    >
                      {quiz.status}
                    </button>
                  </div>

                  <h4 className="font-bold text-base text-white leading-snug">
                    {quiz.title}
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 line-clamp-2 leading-relaxed">
                    {quiz.description}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-white/5">
                  <div className="grid grid-cols-3 gap-2 text-[11px] text-slate-300">
                    <div className="flex items-center gap-1.5">
                      <FileQuestion className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{quiz.questionIds.length} Soal</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>{quiz.durationMinutes} Menit</span>
                    </div>
                    <div className="flex items-center gap-1.5 truncate">
                      <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="truncate">
                        {quiz.deadline
                          ? new Date(quiz.deadline).toLocaleDateString('id-ID', {
                              day: 'numeric',
                              month: 'short'
                            })
                          : 'Fleksibel'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1">
                    <button
                      onClick={() => viewSubmissions(quiz)}
                      className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-cyan-300 font-bold text-xs flex items-center gap-1.5 border border-white/10 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" /> Hasil Siswa
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => openEditModal(quiz)}
                        className="p-2 rounded-xl bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 cursor-pointer"
                        title="Edit Kuis"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(quiz.id, quiz.title)}
                        className="p-2 rounded-xl bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 cursor-pointer"
                        title="Hapus Kuis"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal Create / Edit Quiz */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <FileQuestion className="w-5 h-5 text-indigo-400" />
                {editingQuiz ? 'Edit Paket Kuis' : 'Rilis Paket Kuis Baru'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 overflow-y-auto flex-1 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Judul Kuis / Penilaian <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder="Contoh: Penilaian Harian PAI Bab 1 (Surah Al-Ma'un)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Deskripsi / Petunjuk Pengerjaan
                </label>
                <textarea
                  rows={2}
                  value={formDesc}
                  onChange={e => setFormDesc(e.target.value)}
                  placeholder="Petunjuk untuk siswa: awali dengan membaca basmalah..."
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Sasaran Kelas
                  </label>
                  <select
                    value={formClassId}
                    onChange={e => setFormClassId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        Kelas {c.className}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Durasi (Menit)
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="180"
                    value={formDuration}
                    onChange={e => setFormDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Batas Akhir (Deadline)
                  </label>
                  <input
                    type="datetime-local"
                    value={formDeadline}
                    onChange={e => setFormDeadline(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-[11px] font-mono cursor-pointer"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Status Rilis
                  </label>
                  <select
                    value={formStatus}
                    onChange={e => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="published">Published (Aktif)</option>
                    <option value="draft">Draft (Disimpan)</option>
                    <option value="closed">Closed (Ditutup)</option>
                  </select>
                </div>
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 rounded-2xl bg-white/5 border border-white/10">
                <label className="flex items-center gap-2.5 text-xs text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formRandomize}
                    onChange={e => setFormRandomize(e.target.checked)}
                    className="accent-emerald-500 w-4 h-4 cursor-pointer"
                  />
                  <span>Acak Urutan Soal (Randomize)</span>
                </label>

                <label className="flex items-center gap-2.5 text-xs text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formShowScore}
                    onChange={e => setFormShowScore(e.target.checked)}
                    className="accent-emerald-500 w-4 h-4 cursor-pointer"
                  />
                  <span>Tampilkan Nilai Langsung ke Siswa</span>
                </label>
              </div>

              {/* Question Selection from Bank */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300 uppercase">
                    Pilih Butir Soal dari Bank Soal ({selectedQuestionIds.length} Soal Dipilih):
                  </label>
                  <button
                    type="button"
                    onClick={selectAllQuestions}
                    className="text-[11px] font-bold text-emerald-400 hover:underline cursor-pointer"
                  >
                    {selectedQuestionIds.length === allQuestions.length
                      ? 'Batal Pilih Semua'
                      : 'Pilih Semua Soal'}
                  </button>
                </div>

                <div className="max-h-56 overflow-y-auto space-y-2 p-2 rounded-2xl bg-slate-900/80 border border-white/10">
                  {allQuestions.map(q => {
                    const isSelected = selectedQuestionIds.includes(q.id);
                    return (
                      <div
                        key={q.id}
                        onClick={() => toggleQuestionSelection(q.id)}
                        className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-start gap-3 ${
                          isSelected
                            ? 'bg-emerald-500/15 border-emerald-500/40 text-white'
                            : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          className="accent-emerald-500 w-4 h-4 mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold line-clamp-1">{q.question}</p>
                          <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                            <span>Kelas {q.classId}</span>
                            <span>&bull;</span>
                            <span className="uppercase">{q.questionType.replace('_', ' ')}</span>
                            <span>&bull;</span>
                            <span className="text-amber-400 font-bold">{q.scoreWeight} Poin</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
                >
                  Simpan & Rilis Kuis
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Submissions Modal */}
      {submissionsModalOpen && activeQuizForSubmissions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-2xl max-h-[85vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-white">
                  Rekap Pengerjaan Siswa
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {activeQuizForSubmissions.title} &bull; Kelas {activeQuizForSubmissions.className}
                </p>
              </div>
              <button
                onClick={() => setSubmissionsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-5 overflow-y-auto flex-1">
              <div className="overflow-x-auto w-full">
                <table className="w-full text-left text-xs min-w-[500px]">
                  <thead className="bg-white/5 text-[10px] uppercase font-bold text-slate-400">
                    <tr>
                      <th className="py-2.5 px-3 w-10 text-center">No</th>
                      <th className="py-2.5 px-3">Nama Siswa</th>
                      <th className="py-2.5 px-3 text-center">Nilai Angka</th>
                      <th className="py-2.5 px-3 text-center">% Nilai</th>
                      <th className="py-2.5 px-3 text-right">Waktu Selesai</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {StorageService.getStudents()
                      .filter(s => s.classId === activeQuizForSubmissions.classId)
                      .map((s, idx) => {
                        const scores = StorageService.getStudentScores(s.id);
                        const match = scores.find(x => x.quizId === activeQuizForSubmissions.id);
                        return (
                          <tr key={s.id} className="hover:bg-white/5">
                            <td className="py-2.5 px-3 text-center font-mono text-slate-400">
                              {idx + 1}
                            </td>
                            <td className="py-2.5 px-3 font-bold text-white">{s.fullName}</td>
                            <td className="py-2.5 px-3 text-center font-mono">
                              {match ? `${match.rawScore} / ${match.maxScore}` : '-'}
                            </td>
                            <td className="py-2.5 px-3 text-center">
                              {match ? (
                                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold font-mono">
                                  {match.percentage}
                                </span>
                              ) : (
                                <span className="text-slate-500 text-[11px] italic">
                                  Belum Mengerjakan
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-right text-slate-400 font-mono text-[11px]">
                              {match
                                ? new Date(match.createdAt).toLocaleDateString('id-ID', {
                                    day: 'numeric',
                                    month: 'short',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })
                                : '-'}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Paket Kuis?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus paket kuis{' '}
              <span className="text-white font-bold">"{deleteTarget.title}"</span>? Data pengerjaan siswa untuk kuis ini juga akan terhapus.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Kuis
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
