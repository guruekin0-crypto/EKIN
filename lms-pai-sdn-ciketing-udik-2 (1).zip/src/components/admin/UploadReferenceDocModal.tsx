import React, { useState } from 'react';
import {
  X,
  Upload,
  FileText,
  CheckCircle2,
  Trash2,
  Eye,
  Plus,
  Sparkles,
  BookOpen,
  Download,
  ArrowRight,
  Layers
} from 'lucide-react';
import {
  TeachingDocType,
  TeachingReferenceDoc,
  AppSettings,
  TeacherProfile
} from '../../types';
import {
  parseUploadedReferenceFile,
  convertRefDocToTeachingDocument
} from '../../utils/teachingDocImportHelper';
import { StorageService } from '../../services/storageService';

interface UploadReferenceDocModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultGrade?: string;
  defaultDocType?: TeachingDocType;
  appSettings: AppSettings;
  teacherProfile: TeacherProfile;
  onRefreshDocs: () => void;
  onUseAsManualReference: (refDoc: TeachingReferenceDoc, targetDocType?: TeachingDocType) => void;
  onUseAsAiReference: (refDoc: TeachingReferenceDoc) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const DOC_TYPE_LABELS: { id: TeachingDocType; label: string; short: string }[] = [
  { id: 'cp_atp', label: 'CP / ATP (Capaian & Alur Tujuan Pembelajaran)', short: 'CP/ATP' },
  { id: 'prota', label: 'Program Tahunan (Prota)', short: 'Prota' },
  { id: 'promes', label: 'Program Semester (Promes)', short: 'Promes' },
  { id: 'kktp', label: 'KKTP (Kriteria Ketercapaian Tujuan Pembelajaran)', short: 'KKTP' },
  { id: 'modul_ajar', label: 'Modul Ajar / RPP Merdeka', short: 'Modul Ajar' },
  { id: 'lkpd', label: 'LKPD (Lembar Kerja Peserta Didik)', short: 'LKPD' },
  { id: 'lainnya', label: 'Perangkat Ajar Lainnya (Silabus, Regulasi, Kisi-Kisi, dll.)', short: 'Lainnya' }
];

export const UploadReferenceDocModal: React.FC<UploadReferenceDocModalProps> = ({
  isOpen,
  onClose,
  defaultGrade = '5',
  defaultDocType = 'cp_atp',
  appSettings,
  teacherProfile,
  onRefreshDocs,
  onUseAsManualReference,
  onUseAsAiReference,
  showToast
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'library'>('upload');
  const [savedRefs, setSavedRefs] = useState<TeachingReferenceDoc[]>(
    StorageService.getTeachingRefDocs()
  );

  // Upload Form State
  const [docType, setDocType] = useState<TeachingDocType>(defaultDocType);
  const [classGrade, setClassGrade] = useState<string>(defaultGrade);
  const [semester, setSemester] = useState<'Ganjil' | 'Genap' | 'Tahunan'>('Ganjil');
  const [elementDomain, setElementDomain] = useState<string>("Al-Qur'an & Hadis");
  const [title, setTitle] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  // Parsed File State
  const [isParsing, setIsParsing] = useState(false);
  const [fileName, setFileName] = useState('');
  const [fileType, setFileType] = useState('');
  const [fileSizeKb, setFileSizeKb] = useState(0);
  const [dataUrl, setDataUrl] = useState('');
  const [extractedText, setExtractedText] = useState('');
  const [extractedRows, setExtractedRows] = useState<
    Array<{
      no: number;
      col1: string;
      col2: string;
      col3: string;
      col4?: string;
    }>
  >([]);

  // Previewing existing ref
  const [previewRef, setPreviewRef] = useState<TeachingReferenceDoc | null>(null);

  if (!isOpen) return null;

  const refreshSavedRefs = () => {
    setSavedRefs(StorageService.getTeachingRefDocs());
    onRefreshDocs();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 6 * 1024 * 1024) {
      showToast('Ukuran berkas maksimal 6 MB agar penyimpanan tetap optimal.', 'error');
      return;
    }

    setIsParsing(true);
    try {
      const parsed = await parseUploadedReferenceFile(file);
      setFileName(parsed.fileName);
      setFileType(parsed.fileType);
      setFileSizeKb(parsed.fileSizeKb);
      setDataUrl(parsed.dataUrl);
      setExtractedText(parsed.extractedText);
      setExtractedRows(parsed.extractedRows);

      if (!title.trim()) {
        const cleanTitle = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]+/g, ' ');
        setTitle(cleanTitle.toUpperCase());
      }

      showToast(
        `Dokumen "${file.name}" berhasil dibaca (${parsed.extractedRows.length} poin/baris terdeteksi)!`,
        'success'
      );
    } catch (err: any) {
      console.error(err);
      showToast('Gagal memproses file: ' + (err?.message || 'Kesalahan format'), 'error');
    } finally {
      setIsParsing(false);
    }
  };

  const buildRefPayload = (): Omit<TeachingReferenceDoc, 'id' | 'uploadedAt'> | null => {
    if (!fileName && !extractedText.trim()) {
      showToast('Silakan pilih/upload file dokumen atau tempelkan isi teks acuan terlebih dahulu!', 'error');
      return null;
    }

    const finalTitle =
      title.trim() ||
      (fileName ? fileName.replace(/\.[^/.]+$/, '').toUpperCase() : `DOKUMEN ACUAN ${docType.toUpperCase()}`);

    let finalRows = [...extractedRows].filter(r => r.col1.trim() || r.col2.trim());
    if (finalRows.length === 0 && extractedText.trim()) {
      const lines = extractedText
        .split('\n')
        .map(l => l.trim())
        .filter(l => l.length > 6);
      finalRows = lines.slice(0, 20).map((l, idx) => ({
        no: idx + 1,
        col1: l.replace(/^(\d+[\.\)]|-|\•)\s+/, ''),
        col2: finalTitle,
        col3: '4 JP',
        col4: 'Beriman, Bertakwa & Kasih Sayang (KBC)'
      }));
    }

    return {
      title: finalTitle,
      docType,
      classGrade,
      semester,
      elementDomain,
      fileName: fileName || 'Teks-Acuan-Manual.txt',
      fileType: fileType || 'text/plain',
      fileSizeKb: fileSizeKb || Math.max(1, Math.round(extractedText.length / 1024)),
      dataUrl: dataUrl || undefined,
      extractedText: extractedText.trim() || finalTitle,
      extractedRows: finalRows,
      notes: notes.trim() || undefined
    };
  };

  const handleSaveReferenceOnly = () => {
    const payload = buildRefPayload();
    if (!payload) return;

    const saved = StorageService.saveTeachingRefDoc(payload);
    refreshSavedRefs();
    resetUploadForm();
    setActiveTab('library');
    showToast(
      `Dokumen acuan "${saved.title}" berhasil disimpan sebagai sandaran referensi!`,
      'success'
    );
  };

  const handleSaveAndOpenManualForm = () => {
    const payload = buildRefPayload();
    if (!payload) return;

    const saved = StorageService.saveTeachingRefDoc(payload);
    refreshSavedRefs();
    resetUploadForm();
    onUseAsManualReference(saved, saved.docType);
  };

  const handleSaveAndConvertDirectly = () => {
    const payload = buildRefPayload();
    if (!payload) return;

    const savedRef = StorageService.saveTeachingRefDoc(payload);
    const convertedDoc = convertRefDocToTeachingDocument(
      savedRef,
      savedRef.docType,
      appSettings,
      teacherProfile
    );
    const savedDoc = StorageService.saveTeachingDoc(convertedDoc);
    refreshSavedRefs();
    resetUploadForm();
    onClose();
    showToast(
      `Dokumen "${savedDoc.title}" berhasil dimasukkan ke daftar Perangkat Ajar & disimpan sebagai acuan!`,
      'success'
    );
  };

  const resetUploadForm = () => {
    setFileName('');
    setFileType('');
    setFileSizeKb(0);
    setDataUrl('');
    setExtractedText('');
    setExtractedRows([]);
    setTitle('');
    setNotes('');
  };

  const handleDeleteRef = (id: string, refTitle: string) => {
    StorageService.deleteTeachingRefDoc(id);
    if (previewRef?.id === id) setPreviewRef(null);
    refreshSavedRefs();
    showToast(`Dokumen acuan "${refTitle}" telah dihapus.`, 'info');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md">
      <div className="glass-strong rounded-3xl w-full max-w-4xl max-h-[94vh] flex flex-col border border-cyan-500/35 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                Upload &amp; Pustaka Dokumen Acuan Perangkat Ajar (CP, ATP, Prota, dll.)
              </h3>
              <p className="text-[11px] text-slate-400">
                Upload dokumen CP, ATP, Prota, Promes, KKTP, Modul Ajar, atau Silabus sebagai sandaran/referensi mengisi perangkat ajar
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Tabs */}
        <div className="px-5 pt-3 bg-slate-900/60 border-b border-white/10 flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`px-4 py-2 rounded-t-xl text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'upload'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" /> Upload Dokumen Acuan Baru
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('library')}
            className={`px-4 py-2 rounded-t-xl text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'library'
                ? 'border-emerald-400 text-emerald-300 bg-emerald-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> Pustaka Dokumen Acuan Tersimpan ({savedRefs.length})
          </button>
        </div>

        {/* Content Body */}
        {activeTab === 'upload' ? (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5 scrollbar-thin">
            {/* Dropzone / File Input */}
            <div className="p-5 rounded-2xl border-2 border-dashed border-cyan-500/40 bg-cyan-500/5 hover:bg-cyan-500/10 transition-all text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center mx-auto border border-cyan-500/30">
                <Upload className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">
                  Pilih Berkas Dokumen Perangkat Ajar (CP, ATP, Prota, Promes, KKTP, RPP, Silabus)
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Mendukung format <b>Excel (.xlsx, .xls, .csv)</b>, <b>Word (.docx, .doc)</b>, <b>PDF (.pdf)</b>, dan <b>Teks (.txt, .json, .html)</b>
                </p>
              </div>

              <div className="flex items-center justify-center gap-3 pt-1">
                <label className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 cursor-pointer transition-all inline-flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  {isParsing ? 'Sedang Membaca Dokumen...' : 'Pilih File Dokumen dari Perangkat'}
                  <input
                    type="file"
                    accept=".pdf,.docx,.doc,.xlsx,.xls,.csv,.txt,.md,.json,.html"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>

                {fileName && (
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" /> {fileName} ({fileSizeKb} KB)
                  </span>
                )}
              </div>
            </div>

            {/* Metadata Categorization */}
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-white/10 space-y-4">
              <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" /> Identitas &amp; Kategori Dokumen Acuan
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                    Jenis Perangkat Ajar
                  </label>
                  <select
                    value={docType}
                    onChange={e => setDocType(e.target.value as TeachingDocType)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                  >
                    {DOC_TYPE_LABELS.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.short} - {t.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                    Sasaran Kelas
                  </label>
                  <select
                    value={classGrade}
                    onChange={e => setClassGrade(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                  >
                    <option value="all">Semua Kelas (Kelas 1-6)</option>
                    <option value="1">Kelas 1 (Fase A)</option>
                    <option value="2">Kelas 2 (Fase A)</option>
                    <option value="3">Kelas 3 (Fase B)</option>
                    <option value="4">Kelas 4 (Fase B)</option>
                    <option value="5">Kelas 5 (Fase C)</option>
                    <option value="6">Kelas 6 (Fase C)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                    Semester
                  </label>
                  <select
                    value={semester}
                    onChange={e => setSemester(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                  >
                    <option value="Ganjil">Semester Ganjil</option>
                    <option value="Genap">Semester Genap</option>
                    <option value="Tahunan">Tahunan (1 Tahun)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                    Elemen PAI
                  </label>
                  <select
                    value={elementDomain}
                    onChange={e => setElementDomain(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                  >
                    <option value="Al-Qur'an & Hadis">Al-Qur'an &amp; Hadis</option>
                    <option value="Akidah">Akidah</option>
                    <option value="Akhlak">Akhlak</option>
                    <option value="Fikih">Fikih</option>
                    <option value="Sejarah Peradaban Islam">Sejarah Peradaban Islam</option>
                    <option value="Semua Elemen PAI">Semua Elemen PAI</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                    Judul Dokumen Acuan / Referensi
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    placeholder="Contoh: SK CP & ATP PAI FASE C KELAS 5 TAHUN 2026"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                    Catatan Sandaran / Sumber Regulasi (Opsional)
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Contoh: Acuan Resmi Keputusan Kepala BKPDM / Kemenag..."
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Extracted Content & Editable Sandaran Text */}
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-emerald-500/25 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                    Isi Teks / Materi dari Dokumen Acuan (Sandaran Pengisian Perangkat Ajar)
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Hasil pembacaan otomatis dari file yang diupload. Anda juga dapat menyunting atau menempelkan (paste) rumusan CP/ATP/Materi di sini:
                  </p>
                </div>
                {extractedRows.length > 0 && (
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold">
                    {extractedRows.length} Baris / Butir Kompetensi Terdeteksi
                  </span>
                )}
              </div>

              <textarea
                rows={5}
                value={extractedText}
                onChange={e => setExtractedText(e.target.value)}
                placeholder="Ketika Anda mengupload file Word (.docx), Excel (.xlsx), atau Teks, isi dokumen akan otomatis muncul di sini. Jika mengupload PDF scan, Anda juga bisa menempelkan (paste) poin-poin CP/ATP di sini agar menjadi sandaran otomatis..."
                className="w-full p-3 rounded-xl bg-slate-950 border border-white/15 text-white text-xs leading-relaxed font-mono"
              />

              {/* Editable Extracted Rows Table Preview */}
              {extractedRows.length > 0 && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-cyan-300 uppercase">
                      Pratinjau Butir Tujuan / Materi yang Siap Dijadikan Sandaran ({extractedRows.length} Baris):
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setExtractedRows(prev => [
                          ...prev,
                          {
                            no: prev.length + 1,
                            col1: '',
                            col2: '',
                            col3: '4 JP'
                          }
                        ])
                      }
                      className="text-[11px] text-cyan-300 hover:text-cyan-200 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" /> Tambah Baris Acuan
                    </button>
                  </div>

                  <div className="max-h-48 overflow-y-auto rounded-xl border border-white/10 divide-y divide-white/5 bg-slate-950 p-2 space-y-1.5">
                    {extractedRows.map((row, idx) => (
                      <div key={idx} className="grid grid-cols-12 gap-2 items-center pt-1.5 first:pt-0">
                        <div className="col-span-1 text-center text-[11px] font-bold text-slate-400">
                          {idx + 1}.
                        </div>
                        <div className="col-span-5">
                          <input
                            type="text"
                            value={row.col1}
                            onChange={e => {
                              const val = e.target.value;
                              setExtractedRows(prev =>
                                prev.map((r, i) => (i === idx ? { ...r, col1: val } : r))
                              );
                            }}
                            placeholder="Tujuan Pembelajaran / Aspek"
                            className="w-full px-2.5 py-1 rounded bg-slate-900 border border-white/10 text-white text-xs"
                          />
                        </div>
                        <div className="col-span-4">
                          <input
                            type="text"
                            value={row.col2}
                            onChange={e => {
                              const val = e.target.value;
                              setExtractedRows(prev =>
                                prev.map((r, i) => (i === idx ? { ...r, col2: val } : r))
                              );
                            }}
                            placeholder="Materi Pokok / Uraian"
                            className="w-full px-2.5 py-1 rounded bg-slate-900 border border-white/10 text-white text-xs"
                          />
                        </div>
                        <div className="col-span-1">
                          <input
                            type="text"
                            value={row.col3}
                            onChange={e => {
                              const val = e.target.value;
                              setExtractedRows(prev =>
                                prev.map((r, i) => (i === idx ? { ...r, col3: val } : r))
                              );
                            }}
                            placeholder="JP"
                            className="w-full px-2 py-1 rounded bg-slate-900 border border-white/10 text-cyan-300 text-xs text-center"
                          />
                        </div>
                        <div className="col-span-1 text-right">
                          <button
                            type="button"
                            onClick={() =>
                              setExtractedRows(prev => prev.filter((_, i) => i !== idx))
                            }
                            className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* 3 Action Buttons Footer */}
            <div className="pt-3 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
              <button
                type="button"
                onClick={handleSaveReferenceOnly}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white text-xs font-bold cursor-pointer transition-all flex items-center justify-center gap-1.5"
              >
                <BookOpen className="w-4 h-4 text-cyan-400" />
                1. Simpan ke Pustaka Acuan Saja
              </button>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveAndOpenManualForm}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-blue-500/25 cursor-pointer transition-all flex items-center gap-1.5"
                >
                  <ArrowRight className="w-4 h-4" />
                  2. Jadikan Sandaran &amp; Buka Form Input Manual
                </button>

                <button
                  type="button"
                  onClick={handleSaveAndConvertDirectly}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/25 cursor-pointer transition-all flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  3. Masukkan Langsung ke Perangkat Ajar
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* LIBRARY TAB: SAVED REFERENCE DOCUMENTS */
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4 scrollbar-thin">
            {savedRefs.length === 0 ? (
              <div className="p-10 rounded-2xl bg-slate-900/60 border border-white/10 text-center space-y-3">
                <FileText className="w-10 h-10 text-slate-400 mx-auto" />
                <h4 className="font-bold text-white text-sm">
                  Belum Ada Dokumen Acuan / Referensi yang Diupload
                </h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Silakan upload dokumen CP, ATP, Prota, Promes, atau Silabus pada tab <b>"Upload Dokumen Acuan Baru"</b> untuk dijadikan sandaran pengisian perangkat ajar.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('upload')}
                  className="px-4 py-2 rounded-xl bg-cyan-500 text-white text-xs font-bold cursor-pointer"
                >
                  + Upload Dokumen Acuan Sekarang
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3">
                {savedRefs.map(ref => {
                  const typeInfo =
                    DOC_TYPE_LABELS.find(t => t.id === ref.docType) || DOC_TYPE_LABELS[0];
                  return (
                    <div
                      key={ref.id}
                      className="p-4 rounded-2xl bg-slate-900/80 border border-white/10 hover:border-cyan-500/40 transition-all space-y-3"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <div className="flex flex-wrap items-center gap-2 mb-1">
                            <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold uppercase">
                              Acuan {typeInfo.short}
                            </span>
                            <span className="px-2 py-0.5 rounded-md bg-white/10 text-slate-300 text-[10px] font-semibold">
                              {ref.classGrade === 'all' ? 'Semua Kelas (1-6)' : `Kelas ${ref.classGrade}`} &bull; {ref.semester}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              📎 {ref.fileName} ({ref.fileSizeKb} KB)
                            </span>
                          </div>
                          <h4 className="font-bold text-sm text-white">{ref.title}</h4>
                          <p className="text-xs text-slate-300 line-clamp-2 mt-1">
                            {ref.extractedText}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              setPreviewRef(previewRef?.id === ref.id ? null : ref)
                            }
                            className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5 text-cyan-400" />
                            {previewRef?.id === ref.id ? 'Tutup Isi' : 'Lihat Isi'}
                          </button>
                          {ref.dataUrl && (
                            <a
                              href={ref.dataUrl}
                              download={ref.fileName}
                              className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-emerald-300 text-xs font-bold flex items-center gap-1"
                              title="Unduh File Asli"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={() => handleDeleteRef(ref.id, ref.title)}
                            className="p-1.5 rounded-xl text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                            title="Hapus Dokumen Acuan"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {previewRef?.id === ref.id && (
                        <div className="p-3.5 rounded-xl bg-slate-950 border border-white/10 space-y-3 text-xs">
                          {ref.dataUrl && ref.fileName.toLowerCase().endsWith('.pdf') && (
                            <div className="space-y-1">
                              <span className="text-[11px] font-bold text-cyan-300 block">
                                Pratinjau Dokumen PDF Asli:
                              </span>
                              <iframe
                                src={ref.dataUrl}
                                title={ref.title}
                                className="w-full h-72 rounded-lg border border-white/15 bg-white"
                              />
                            </div>
                          )}
                          <div>
                            <span className="text-[11px] font-bold text-emerald-400 block mb-1">
                              Teks / Isi Sandaran Acuan:
                            </span>
                            <div className="max-h-44 overflow-y-auto whitespace-pre-line text-slate-300 font-mono text-[11px] p-2.5 rounded-lg bg-slate-900">
                              {ref.extractedText}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Action Bar: Use this reference to fill CP/ATP, Prota, Promes, KKTP, Modul Ajar, LKPD, or AI */}
                      <div className="pt-2.5 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[10px] font-bold text-cyan-300 uppercase mr-1">
                            Gunakan Sebagai Sandaran Isi Manual:
                          </span>
                          {DOC_TYPE_LABELS.map(t => (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => onUseAsManualReference(ref, t.id)}
                              className="px-2.5 py-1 rounded-lg bg-blue-500/15 hover:bg-blue-500/30 border border-blue-500/30 text-blue-200 text-[11px] font-bold cursor-pointer transition-colors"
                            >
                              Isi {t.short}
                            </button>
                          ))}
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onUseAsAiReference(ref)}
                            className="px-3 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Sparkles className="w-3 h-3" /> Jadikan Acuan AI
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
