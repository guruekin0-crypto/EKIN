import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Search,
  Printer,
  FileSpreadsheet,
  Edit2,
  Trash2,
  X,
  Sparkles,
  BookOpen,
  Clock,
  Calendar,
  CheckCircle2,
  ArrowUp,
  ArrowDown,
  LayoutGrid,
  List,
  Wand2,
  ChevronRight,
  School,
  Check
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { ClassTopicItem } from '../../types';
import { StorageService } from '../../services/storageService';

interface CurriculumPerClassViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const CurriculumPerClassView: React.FC<CurriculumPerClassViewProps> = ({ showToast }) => {
  const [selectedGrade, setSelectedGrade] = useState<string>('5');
  const [selectedSemester, setSelectedSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  const [topics, setTopics] = useState<ClassTopicItem[]>(
    StorageService.getClassTopics(selectedGrade, selectedSemester)
  );

  const [modalOpen, setModalOpen] = useState(false);
  const [editingTopic, setEditingTopic] = useState<ClassTopicItem | null>(null);

  // Form states for manual input
  const [formChapterNo, setFormChapterNo] = useState<number>(1);
  const [formChapterTitle, setFormChapterTitle] = useState('');
  const [formDomain, setFormDomain] = useState('Al-Qur\'an & Hadis');
  const [formObjective, setFormObjective] = useState('');
  const [formSubTopicsText, setFormSubTopicsText] = useState('');
  const [formAllocationJP, setFormAllocationJP] = useState<number>(12);
  const [formTargetMonth, setFormTargetMonth] = useState('Juli - Agustus');
  const [formStatus, setFormStatus] = useState<'Tuntas' | 'Sedang Berjalan' | 'Belum Terlaksana'>('Belum Terlaksana');
  const [formResources, setFormResources] = useState('Buku Siswa PAI Kemendikbudristek, Mushaf Al-Qur\'an');
  const [formNotes, setFormNotes] = useState('');

  // AI Generator Modal
  const [aiModalOpen, setAiModalOpen] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);

  // Print Modal
  const [printModalOpen, setPrintModalOpen] = useState(false);

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const teacherProfile = StorageService.getTeacherProfile();
  const appSettings = StorageService.getAppSettings();

  const refreshTopics = (grade = selectedGrade, sem = selectedSemester) => {
    setTopics(StorageService.getClassTopics(grade, sem));
  };

  const handleGradeChange = (grade: string) => {
    setSelectedGrade(grade);
    refreshTopics(grade, selectedSemester);
  };

  const handleSemesterChange = (sem: 'Ganjil' | 'Genap') => {
    setSelectedSemester(sem);
    refreshTopics(selectedGrade, sem);
  };

  const openAddModal = () => {
    setEditingTopic(null);
    const nextChapter = topics.length > 0 ? Math.max(...topics.map(t => t.chapterNo)) + 1 : 1;
    setFormChapterNo(nextChapter);
    setFormChapterTitle('');
    setFormDomain('Al-Qur\'an & Hadis');
    setFormObjective('');
    setFormSubTopicsText('');
    setFormAllocationJP(12);
    setFormTargetMonth(selectedSemester === 'Ganjil' ? 'Juli - Agustus' : 'Januari - Februari');
    setFormStatus('Belum Terlaksana');
    setFormResources(`Buku Siswa PAI Kelas ${selectedGrade} Kemendikbudristek, Al-Qur'an`);
    setFormNotes('');
    setModalOpen(true);
  };

  const openEditModal = (t: ClassTopicItem) => {
    setEditingTopic(t);
    setFormChapterNo(t.chapterNo);
    setFormChapterTitle(t.chapterTitle);
    setFormDomain(t.domain);
    setFormObjective(t.learningObjective);
    setFormSubTopicsText(t.subTopics.join('\n'));
    setFormAllocationJP(t.timeAllocationJP);
    setFormTargetMonth(t.targetMonth || '');
    setFormStatus(t.status);
    setFormResources(t.learningResources || '');
    setFormNotes(t.notes || '');
    setModalOpen(true);
  };

  const handleSaveTopic = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formChapterTitle.trim()) {
      showToast('Judul Bab / Materi Pokok wajib diisi!', 'error');
      return;
    }

    const subTopicsArray = formSubTopicsText
      .split('\n')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    StorageService.saveClassTopic({
      id: editingTopic ? editingTopic.id : undefined,
      classGrade: selectedGrade,
      semester: selectedSemester,
      chapterNo: Number(formChapterNo) || 1,
      chapterTitle: formChapterTitle.trim(),
      domain: formDomain,
      learningObjective: formObjective.trim() || `Memahami dan mengamalkan nilai-nilai pokok materi ${formChapterTitle}.`,
      subTopics: subTopicsArray.length ? subTopicsArray : [formChapterTitle.trim()],
      timeAllocationJP: Number(formAllocationJP) || 12,
      targetMonth: formTargetMonth.trim(),
      status: formStatus,
      learningResources: formResources.trim(),
      notes: formNotes.trim()
    });

    setModalOpen(false);
    refreshTopics();
    showToast(editingTopic ? 'Materi pokok berhasil diperbarui' : 'Materi pokok baru berhasil ditambahkan');
  };

  const handleDeleteTopic = (id: string, title: string) => {
    setDeleteTarget({ id, title });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteClassTopic(deleteTarget.id);
    refreshTopics();
    showToast(`Materi pokok "${deleteTarget.title}" berhasil dihapus`, 'info');
    setDeleteTarget(null);
  };

  const updateStatusDirect = (id: string, newStatus: 'Tuntas' | 'Sedang Berjalan' | 'Belum Terlaksana') => {
    const item = topics.find(t => t.id === id);
    if (!item) return;
    StorageService.saveClassTopic({
      ...item,
      status: newStatus
    });
    refreshTopics();
    showToast(`Status bab diubah ke: ${newStatus}`, 'info');
  };

  const moveOrder = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= topics.length) return;

    const list = [...topics];
    const temp = list[index];
    list[index] = list[targetIndex];
    list[targetIndex] = temp;

    // Re-assign chapter numbers sequentially
    list.forEach((item, idx) => {
      item.chapterNo = idx + 1;
      StorageService.saveClassTopic(item);
    });

    refreshTopics();
  };

  // AI Auto-Generator for Kurikulum Merdeka PAI Syllabus
  const handleGenerateCurriculumAI = () => {
    setAiGenerating(true);
    setTimeout(() => {
      let sampleChapters: Omit<ClassTopicItem, 'id'>[] = [];

      if (selectedSemester === 'Ganjil') {
        sampleChapters = [
          {
            classGrade: selectedGrade,
            semester: 'Ganjil',
            chapterNo: 1,
            chapterTitle: `Bab 1: Meneladani Ayat Suci Al-Qur'an (Kelas ${selectedGrade})`,
            subTopics: [
              'Membaca Ayat dengan Kaidah Tajwid Tartil',
              'Menghafal Teks Surah Pilihan',
              'Kandungan Makna dan Asbabun Nuzul',
              'Penerapan Karakter Mulia dalam Kehidupan'
            ],
            domain: 'Al-Qur\'an & Hadis',
            learningObjective: `Peserta didik mampu melafalkan, menghafal, dan memahami makna surah pokok kelas ${selectedGrade} dengan tajwid yang tepat serta membiasakan tadarus harian.`,
            timeAllocationJP: 12,
            targetMonth: 'Juli - Agustus',
            status: 'Tuntas',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade} Kemendikbudristek, Juz Amma`
          },
          {
            classGrade: selectedGrade,
            semester: 'Ganjil',
            chapterNo: 2,
            chapterTitle: `Bab 2: Mengenal Keagungan Asmaul Husna (Kelas ${selectedGrade})`,
            subTopics: [
              'Menghafal Lafaz Asmaul Husna',
              'Memahami Arti Sifat-Sifat Mulia Allah',
              'Meneladani Asmaul Husna dalam Keseharian'
            ],
            domain: 'Akidah',
            learningObjective: 'Peserta didik mampu menjelaskan makna Asmaul Husna pilihan dan meneladani sifat-sifat mulia Allah dalam kemandirian dan kejujuran.',
            timeAllocationJP: 12,
            targetMonth: 'September',
            status: 'Sedang Berjalan',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade}, Poster Kaligrafi`
          },
          {
            classGrade: selectedGrade,
            semester: 'Ganjil',
            chapterNo: 3,
            chapterTitle: `Bab 3: Membiasakan Akhlak Terpuji & Adab Islami`,
            subTopics: [
              'Adab Menghormati Guru dan Orang Tua (Birrul Walidain)',
              'Menjaga Lisan dan Menjauhi Sifat Tercela',
              'Tolong-Menolong dalam Kebaikan (Ta\'awun)'
            ],
            domain: 'Akhlak',
            learningObjective: 'Peserta didik mampu mempraktikkan adab sopan santun kepada orang tua, guru, dan teman serta menjauhi perbuatan tercela.',
            timeAllocationJP: 9,
            targetMonth: 'Oktober',
            status: 'Belum Terlaksana',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade}, Lembar Kerja Siswa`
          },
          {
            classGrade: selectedGrade,
            semester: 'Ganjil',
            chapterNo: 4,
            chapterTitle: `Bab 4: Ibadah Praktis & Ketentuan Fiqih`,
            subTopics: [
              'Ketentuan dan Syarat Sah Ibadah',
              'Praktik Ibadah Terbimbing',
              'Hikmah Mendirikan Ibadah Tepat Waktu'
            ],
            domain: 'Fiqih',
            learningObjective: 'Peserta didik memahami rukun dan syarat sah ibadah serta mampu mempraktikkannya secara benar dan disiplin.',
            timeAllocationJP: 12,
            targetMonth: 'November',
            status: 'Belum Terlaksana',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade}, Perlengkapan Ibadah`
          },
          {
            classGrade: selectedGrade,
            semester: 'Ganjil',
            chapterNo: 5,
            chapterTitle: `Bab 5: Kisah Keteladanan Nabi & Tokoh Islam`,
            subTopics: [
              'Kisah Perjuangan Dakwah',
              'Sikap Sabar, Tabah, dan Pemaaf',
              'Mengambil Ibrah (Pelajaran) Berharga'
            ],
            domain: 'Sejarah Peradaban Islam',
            learningObjective: 'Peserta didik mampu menceritakan kisah keteladanan tokoh Islam dan meneladani kegigihan serta keluhuran budi pekerti beliau.',
            timeAllocationJP: 12,
            targetMonth: 'Desember',
            status: 'Belum Terlaksana',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade}, Peta Cerita Bergambar`
          }
        ];
      } else {
        sampleChapters = [
          {
            classGrade: selectedGrade,
            semester: 'Genap',
            chapterNo: 1,
            chapterTitle: `Bab 1: Harmoni dan Kedamaian Hidup Bersama (Kelas ${selectedGrade})`,
            subTopics: [
              'Membaca Ayat Tentang Persaudaraan dan Perdamaian',
              'Saling Menghargai dalam Keragaman',
              'Menjaga Kerukunan Antarteman di Sekolah'
            ],
            domain: 'Al-Qur\'an & Hadis',
            learningObjective: 'Peserta didik mampu mengamalkan prinsip toleransi dan menjaga kedamaian di lingkungan sekolah dan tempat tinggal.',
            timeAllocationJP: 12,
            targetMonth: 'Januari - Februari',
            status: 'Belum Terlaksana',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade}`
          },
          {
            classGrade: selectedGrade,
            semester: 'Genap',
            chapterNo: 2,
            chapterTitle: `Bab 2: Memperkokoh Keimanan dan Ketaqwaan`,
            subTopics: [
              'Memahami Rukun Iman Terkait',
              'Menghayati Pengawasan Allah (Muraqabah)',
              'Memperbanyak Amal Shalih Sehari-hari'
            ],
            domain: 'Akidah',
            learningObjective: 'Peserta didik meyakini rukun iman dengan teguh dan termotivasi untuk rajin berbuat kebajikan.',
            timeAllocationJP: 12,
            targetMonth: 'Maret',
            status: 'Belum Terlaksana',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade}`
          },
          {
            classGrade: selectedGrade,
            semester: 'Genap',
            chapterNo: 3,
            chapterTitle: `Bab 3: Zakat, Kurban, dan Kepedulian Sosial`,
            subTopics: [
              'Makna Berbagi Rizki dalam Islam',
              'Ketentuan dan Hikmah Kurban/Zakat',
              'Menumbuhkan Rasa Kasih Sayang Sesama'
            ],
            domain: 'Fiqih',
            learningObjective: 'Peserta didik memahami konsep berbagi dalam Islam dan gemar menolong teman yang membutuhkan.',
            timeAllocationJP: 12,
            targetMonth: 'April - Mei',
            status: 'Belum Terlaksana',
            learningResources: `Buku Siswa PAI Kelas ${selectedGrade}`
          }
        ];
      }

      sampleChapters.forEach(chap => {
        StorageService.saveClassTopic(chap);
      });

      setAiGenerating(false);
      setAiModalOpen(false);
      refreshTopics();
      showToast(`Silabus Kurikulum Merdeka PAI Kelas ${selectedGrade} Semester ${selectedSemester} berhasil dirumuskan ✨`, 'success');
    }, 600);
  };

  const exportExcel = () => {
    if (topics.length === 0) {
      showToast('Tidak ada materi pada kelas/semester ini untuk diekspor', 'error');
      return;
    }

    const exportData = topics.map(t => ({
      'Bab': `Bab ${t.chapterNo}`,
      'Materi Pokok / Judul Bab': t.chapterTitle,
      'Lingkup Materi': t.domain,
      'Capaian / Tujuan Pembelajaran': t.learningObjective,
      'Sub-Materi / Pokok Bahasan': t.subTopics.join('; '),
      'Alokasi Waktu (JP)': `${t.timeAllocationJP} JP`,
      'Target Waktu Pelaksanaan': t.targetMonth || '-',
      'Status Pelaksanaan': t.status,
      'Sumber Belajar': t.learningResources || '-'
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `Materi_Kls${selectedGrade}_${selectedSemester}`);
    XLSX.writeFile(
      wb,
      `Daftar_Materi_PAI_Kelas_${selectedGrade}_Semester_${selectedSemester}_SDN_Ciketing_Udik_2.xlsx`
    );
  };

  const filtered = topics.filter(t => {
    const matchSearch =
      t.chapterTitle.toLowerCase().includes(search.toLowerCase()) ||
      t.domain.toLowerCase().includes(search.toLowerCase()) ||
      t.learningObjective.toLowerCase().includes(search.toLowerCase()) ||
      t.subTopics.some(s => s.toLowerCase().includes(search.toLowerCase()));
    return matchSearch;
  });

  const totalJP = topics.reduce((acc, curr) => acc + (curr.timeAllocationJP || 0), 0);
  const countTuntas = topics.filter(t => t.status === 'Tuntas').length;

  return (
    <div className="space-y-5">
      {/* Top Banner / Breadcrumb */}
      <div className="glass-strong rounded-3xl p-5 border border-emerald-500/25 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold mb-2">
              <Layers className="w-3.5 h-3.5" /> Program Pembelajaran & Alur Tujuan Pembelajaran (ATP)
            </div>
            <h2 className="text-lg sm:text-xl font-bold font-display text-white">
              Daftar Materi Pokok PAI per Kelas & Semester
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
              Input dan kelola silabus materi pokok, sub-bahasan, capaian pembelajaran, alokasi JP, dan target bulan kurikulum merdeka untuk setiap tingkatan kelas.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => setAiModalOpen(true)}
              className="px-3.5 py-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4" /> Susun Kurikulum AI
            </button>

            <button
              onClick={() => setPrintModalOpen(true)}
              className="px-3.5 py-2.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" /> Cetak Promes / Silabus
            </button>

            <button
              onClick={exportExcel}
              className="px-3.5 py-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4" /> Export Excel
            </button>

            <button
              onClick={openAddModal}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
            >
              <Plus className="w-4 h-4" /> + Input Materi Pokok
            </button>
          </div>
        </div>
      </div>

      {/* Grade Selector & Semester Tabs */}
      <div className="glass rounded-2xl p-4 sm:p-5 border border-white/10 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Class Grade Selector */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs font-bold uppercase text-slate-400 mr-1 shrink-0">
              Pilih Tingkat:
            </span>
            {['1', '2', '3', '4', '5', '6'].map(grade => {
              const isSelected = selectedGrade === grade;
              return (
                <button
                  key={grade}
                  onClick={() => handleGradeChange(grade)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0 ${
                    isSelected
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/25 ring-2 ring-emerald-400/40'
                      : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                  }`}
                >
                  Kelas {grade}
                </button>
              );
            })}
          </div>

          {/* Semester Selector */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-xl border border-white/10 shrink-0">
            {(['Ganjil', 'Genap'] as const).map(sem => (
              <button
                key={sem}
                onClick={() => handleSemesterChange(sem)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedSemester === sem
                    ? 'bg-emerald-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Semester {sem}
              </button>
            ))}
          </div>
        </div>

        {/* Search & Stats Strip */}
        <div className="pt-3 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari materi pokok, sub-bab, atau CP..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end text-xs">
            <div className="flex items-center gap-2 text-slate-300 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10">
              <span>Total: <b className="text-white">{topics.length} Bab</b></span>
              <span>&bull;</span>
              <span>Alokasi: <b className="text-cyan-300">{totalJP} JP</b></span>
              <span>&bull;</span>
              <span>Tuntas: <b className="text-emerald-400">{countTuntas}</b></span>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center p-0.5 bg-slate-900 rounded-lg border border-white/10">
              <button
                onClick={() => setViewMode('cards')}
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === 'cards' ? 'bg-white/15 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Tampilan Kartu Alur"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === 'table' ? 'bg-white/15 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Tampilan Tabel Matriks"
              >
                <List className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content Display */}
      {viewMode === 'cards' ? (
        <div className="space-y-4">
          {filtered.length === 0 ? (
            <div className="glass rounded-2xl p-12 text-center text-slate-400 border border-white/10 space-y-3">
              <BookOpen className="w-10 h-10 text-emerald-400 mx-auto opacity-70" />
              <p className="text-sm font-bold text-white">
                Belum ada daftar materi untuk Kelas {selectedGrade} Semester {selectedSemester}.
              </p>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Silakan klik tombol <b>"+ Input Materi Pokok"</b> untuk menambahkan materi manual, atau gunakan <b>"Susun Kurikulum AI"</b> untuk mendapatkan template otomatis.
              </p>
            </div>
          ) : (
            filtered.map((topic, index) => {
              const statusColor =
                topic.status === 'Tuntas'
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : topic.status === 'Sedang Berjalan'
                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  : 'bg-white/10 text-slate-300 border-white/10';

              return (
                <div
                  key={topic.id}
                  className="glass rounded-3xl p-5 sm:p-6 border border-white/10 hover:border-emerald-500/30 transition-all shadow-md space-y-4"
                >
                  {/* Card Header */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/5 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-extrabold text-xs shadow-md font-mono shrink-0">
                        {topic.chapterNo}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-bold text-[10px]">
                            {topic.domain}
                          </span>
                          <span className="text-xs text-slate-400 font-semibold flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-400" /> {topic.timeAllocationJP} JP
                          </span>
                          {topic.targetMonth && (
                            <span className="text-xs text-slate-400 font-semibold flex items-center gap-1">
                              <Calendar className="w-3 h-3 text-emerald-400" /> {topic.targetMonth}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Direct Status Switcher */}
                      <select
                        value={topic.status}
                        onChange={e => updateStatusDirect(topic.id, e.target.value as any)}
                        className={`px-3 py-1 rounded-xl text-xs font-bold border ${statusColor} cursor-pointer outline-none bg-slate-900`}
                      >
                        <option value="Belum Terlaksana">Belum Terlaksana</option>
                        <option value="Sedang Berjalan">Sedang Berjalan</option>
                        <option value="Tuntas">Tuntas</option>
                      </select>

                      {/* Order Controls */}
                      <button
                        onClick={() => moveOrder(index, 'up')}
                        disabled={index === 0}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed text-slate-300"
                        title="Geser Naik"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => moveOrder(index, 'down')}
                        disabled={index === filtered.length - 1}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed text-slate-300"
                        title="Geser Turun"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => openEditModal(topic)}
                        className="p-1.5 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 cursor-pointer"
                        title="Edit Materi"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteTopic(topic.id, topic.chapterTitle)}
                        className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 cursor-pointer"
                        title="Hapus Materi"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Title & Objective */}
                  <div>
                    <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                      {topic.chapterTitle}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1.5 leading-relaxed bg-white/5 p-3 rounded-2xl border border-white/5">
                      <span className="font-bold text-emerald-400">Tujuan / Capaian Pembelajaran:</span>{' '}
                      {topic.learningObjective}
                    </p>
                  </div>

                  {/* Sub Topics List */}
                  {topic.subTopics.length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                        Pokok Bahasan / Sub-Materi Pelajaran:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {topic.subTopics.map((sub, sIdx) => (
                          <div
                            key={sIdx}
                            className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 text-xs text-slate-200 flex items-start gap-2"
                          >
                            <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                              {sIdx + 1}
                            </span>
                            <span className="flex-1 leading-snug">{sub}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Footer Resource */}
                  {topic.learningResources && (
                    <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400">
                      <span>Sumber: {topic.learningResources}</span>
                      {topic.notes && <span className="italic">Catatan: {topic.notes}</span>}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      ) : (
        /* Matrix Table View */
        <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto w-full">
            <table className="w-full text-left text-xs min-w-[850px]">
              <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400 font-bold border-b border-white/10">
                <tr>
                  <th className="py-3 px-3 w-12 text-center">Bab</th>
                  <th className="py-3 px-4 w-44">Materi Pokok</th>
                  <th className="py-3 px-3 w-28">Lingkup</th>
                  <th className="py-3 px-4">Tujuan Pembelajaran</th>
                  <th className="py-3 px-4 w-52">Sub-Materi</th>
                  <th className="py-3 px-3 w-20 text-center">Alokasi</th>
                  <th className="py-3 px-3 w-28 text-center">Status</th>
                  <th className="py-3 px-3 w-20 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filtered.map(topic => (
                  <tr key={topic.id} className="hover:bg-white/5 align-top">
                    <td className="py-3.5 px-3 text-center font-bold font-mono text-emerald-400">
                      Bab {topic.chapterNo}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-white">{topic.chapterTitle}</td>
                    <td className="py-3.5 px-3 text-cyan-300 font-medium">{topic.domain}</td>
                    <td className="py-3.5 px-4 text-slate-300 leading-relaxed text-[11px]">
                      {topic.learningObjective}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 text-[11px]">
                      <ul className="list-disc list-inside space-y-0.5">
                        {topic.subTopics.map((s, idx) => (
                          <li key={idx} className="truncate">{s}</li>
                        ))}
                      </ul>
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono font-bold text-amber-300">
                      {topic.timeAllocationJP} JP
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/10 text-slate-300 border border-white/10">
                        {topic.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right whitespace-nowrap">
                      <button
                        onClick={() => openEditModal(topic)}
                        className="p-1.5 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 mr-1"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteTopic(topic.id, topic.chapterTitle)}
                        className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Add / Edit Topic */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                  Tingkat Kelas {selectedGrade} &bull; Semester {selectedSemester}
                </span>
                <h3 className="font-bold text-base text-white flex items-center gap-2 mt-0.5">
                  <Layers className="w-5 h-5 text-emerald-400" />
                  {editingTopic ? 'Edit Materi Pokok' : 'Input Manual Materi Pokok Baru'}
                </h3>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTopic} className="p-5 overflow-y-auto flex-1 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Nomor Bab <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formChapterNo}
                    onChange={e => setFormChapterNo(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Lingkup Elemen PAI
                  </label>
                  <select
                    value={formDomain}
                    onChange={e => setFormDomain(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Al-Qur'an & Hadis">Al-Qur'an & Hadis</option>
                    <option value="Akidah">Akidah</option>
                    <option value="Akhlak">Akhlak</option>
                    <option value="Fiqih">Fiqih</option>
                    <option value="Sejarah Peradaban Islam">Sejarah Peradaban Islam (SPI)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Alokasi Waktu (JP)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formAllocationJP}
                    onChange={e => setFormAllocationJP(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Judul Bab / Materi Pokok <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formChapterTitle}
                  onChange={e => setFormChapterTitle(e.target.value)}
                  placeholder="Contoh: Bab 1: Menyayangi Anak Yatim (Surah Al-Ma'un)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300 uppercase">
                    Capaian / Tujuan Pembelajaran (CP / TP)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const topic = formChapterTitle || 'Materi PAI';
                      setFormObjective(
                        `Melalui kegiatan pembelajaran berbasis pengalaman bermakna dan tadarus, peserta didik kelas ${selectedGrade} mampu memahami konsep pokok "${topic}" dengan tepat, menunjukkan budi pekerti luhur, dan membiasakan penerapannya dalam kehidupan sehari-hari.`
                      );
                      showToast('Tujuan pembelajaran dirumuskan ✨', 'success');
                    }}
                    className="text-[11px] font-bold text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" /> Bantu Rumuskan
                  </button>
                </div>
                <textarea
                  rows={3}
                  value={formObjective}
                  onChange={e => setFormObjective(e.target.value)}
                  placeholder="Rumusan kompetensi dan tujuan yang ingin dicapai siswa..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm leading-relaxed focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Sub-Materi / Rincian Pokok Bahasan (1 Baris = 1 Sub-Bahasan)
                </label>
                <textarea
                  rows={4}
                  value={formSubTopicsText}
                  onChange={e => setFormSubTopicsText(e.target.value)}
                  placeholder="Contoh:&#10;Membaca Surah dengan Tartil&#10;Menghafal Teks Surah&#10;Kandungan Makna dan Perilaku Peduli Sesama"
                  className="w-full p-3 rounded-xl bg-white/5 border border-white/15 text-white text-xs leading-relaxed focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Target Bulan / Minggu Pelaksanaan
                  </label>
                  <input
                    type="text"
                    value={formTargetMonth}
                    onChange={e => setFormTargetMonth(e.target.value)}
                    placeholder="Contoh: Juli - Agustus / Minggu 1-3"
                    className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/15 text-white text-xs"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Status Pelaksanaan
                  </label>
                  <select
                    value={formStatus}
                    onChange={e => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Belum Terlaksana">Belum Terlaksana</option>
                    <option value="Sedang Berjalan">Sedang Berjalan</option>
                    <option value="Tuntas">Tuntas</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Sumber & Bahan Belajar
                </label>
                <input
                  type="text"
                  value={formResources}
                  onChange={e => setFormResources(e.target.value)}
                  placeholder="Contoh: Buku Siswa PAI Kemendikbudristek, Al-Qur'an Juz Amma"
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/15 text-white text-xs"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
                >
                  Simpan Materi Pokok
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal AI Generator */}
      {aiModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-md p-6 border border-white/20 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                Susun Silabus Kurikulum Merdeka AI
              </h3>
              <button
                onClick={() => setAiModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              AI akan menyusun daftar materi pokok resmi Kurikulum Merdeka PAI & Budi Pekerti untuk <b>Kelas {selectedGrade} Semester {selectedSemester}</b> lengkap dengan sub-materi, alokasi waktu JP, dan capaian pembelajaran.
            </p>

            <div className="p-3.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/25 text-xs text-cyan-200 space-y-1">
              <div>&bull; Sasaran: <b>Kelas {selectedGrade} SD</b></div>
              <div>&bull; Semester: <b>Semester {selectedSemester}</b></div>
              <div>&bull; Standar: <b>Kemendikbudristek & Kemenag RI</b></div>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setAiModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={aiGenerating}
                onClick={handleGenerateCurriculumAI}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {aiGenerating ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Menyusun Silabus...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-3.5 h-3.5" /> Susun Sekarang
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Official Printable Program Semester (Promes) Modal */}
      {printModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between no-print">
              <div>
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Printer className="w-5 h-5 text-indigo-400" /> Cetak Program Semester / Daftar Materi PAI
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Dokumen resmi Alur Tujuan Pembelajaran & Silabus PAI Kelas {selectedGrade}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> Cetak Dokumen
                </button>
                <button
                  onClick={() => setPrintModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 sm:p-10 overflow-y-auto flex-1 bg-white text-black font-serif text-sm">
              <div className="text-center pb-4 border-b-2 border-black mb-5">
                <h3 className="text-sm font-bold tracking-wider uppercase">
                  PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN
                </h3>
                <h2 className="text-base font-extrabold uppercase">
                  {teacherProfile.schoolName || 'SDN CIKETING UDIK 2 BANTARGEBANG'}
                </h2>
                <p className="text-xs italic text-gray-700">
                  {appSettings.schoolAddress || 'Jl. Raya Ciketing Udik No. 2, Bantargebang, Kota Bekasi'}
                </p>
                <div className="mt-3 py-1 border-t border-b border-black text-center font-bold text-xs uppercase tracking-widest">
                  DAFTAR MATERI POKOK & PROGRAM SEMESTER PAI & BUDI PEKERTI
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                <div>
                  <p><strong>Satuan Pendidikan:</strong> {teacherProfile.schoolName}</p>
                  <p><strong>Mata Pelajaran:</strong> Pendidikan Agama Islam & Budi Pekerti</p>
                  <p><strong>Tingkat Kelas:</strong> Kelas {selectedGrade} (Fase Kurikulum Merdeka)</p>
                </div>
                <div className="text-right">
                  <p><strong>Semester:</strong> {selectedSemester}</p>
                  <p><strong>Tahun Ajaran:</strong> {appSettings.academicYear || '2026/2027'}</p>
                  <p><strong>Guru Pengampu:</strong> {teacherProfile.fullName}</p>
                </div>
              </div>

              <table className="w-full border-collapse border border-black text-xs mb-8">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-black p-2 text-center w-10">Bab</th>
                    <th className="border border-black p-2 w-48">Materi Pokok / Bab</th>
                    <th className="border border-black p-2 w-28">Lingkup</th>
                    <th className="border border-black p-2">Tujuan / Capaian Pembelajaran</th>
                    <th className="border border-black p-2 w-32">Sub-Materi Pokok</th>
                    <th className="border border-black p-2 text-center w-14">Alokasi</th>
                    <th className="border border-black p-2 text-center w-20">Target</th>
                  </tr>
                </thead>
                <tbody>
                  {topics.map(t => (
                    <tr key={t.id} className="align-top">
                      <td className="border border-black p-2 text-center font-bold">Bab {t.chapterNo}</td>
                      <td className="border border-black p-2 font-bold">{t.chapterTitle}</td>
                      <td className="border border-black p-2">{t.domain}</td>
                      <td className="border border-black p-2">{t.learningObjective}</td>
                      <td className="border border-black p-2 text-[10px]">
                        {t.subTopics.join(', ')}
                      </td>
                      <td className="border border-black p-2 text-center font-bold">{t.timeAllocationJP} JP</td>
                      <td className="border border-black p-2 text-center">{t.targetMonth || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="grid grid-cols-2 text-xs pt-4 break-inside-avoid">
                <div className="text-center">
                  <p>Mengetahui,</p>
                  <p>Kepala SDN Ciketing Udik 2</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{appSettings.principalName || 'Hj. Siti Rohmah, M.Pd.'}</p>
                  <p>NIP. {appSettings.principalNip || '-'}</p>
                </div>
                <div className="text-center">
                  <p>Bekasi, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                  <p>Guru Pendidikan Agama Islam</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{teacherProfile.fullName}</p>
                  <p>NIP. {teacherProfile.nip || '-'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Materi Pokok?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus materi pokok{' '}
              <span className="text-white font-bold">"{deleteTarget.title}"</span> dari daftar silabus Kelas {selectedGrade}? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Materi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
