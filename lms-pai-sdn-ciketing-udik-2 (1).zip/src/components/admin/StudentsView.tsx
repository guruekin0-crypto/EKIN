import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Printer,
  FileSpreadsheet,
  Edit2,
  Trash2,
  X,
  Key,
  School,
  Download
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Student, ClassItem } from '../../types';
import { StorageService } from '../../services/storageService';

interface StudentsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const StudentsView: React.FC<StudentsViewProps> = ({ showToast }) => {
  const [students, setStudents] = useState<Student[]>(StorageService.getStudents());
  const [classes] = useState<ClassItem[]>(StorageService.getClasses());
  const [search, setSearch] = useState('');
  const [selectedClass, setSelectedClass] = useState<string>('');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Form inputs
  const [formName, setFormName] = useState('');
  const [formNis, setFormNis] = useState('');
  const [formClassId, setFormClassId] = useState('');
  const [formPassword, setFormPassword] = useState('');

  // Print Cards Modal state
  const [printCardsModalOpen, setPrintCardsModalOpen] = useState(false);

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  const refreshStudents = () => {
    setStudents(StorageService.getStudents());
  };

  const openAddModal = () => {
    setEditingStudent(null);
    setFormName('');
    setFormNis('');
    setFormClassId(selectedClass || (classes[0]?.id || ''));
    setFormPassword('');
    setModalOpen(true);
  };

  const openEditModal = (s: Student) => {
    setEditingStudent(s);
    setFormName(s.fullName);
    setFormNis(s.nis === '-' ? '' : s.nis);
    setFormClassId(s.classId);
    setFormPassword(s.password || '');
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formClassId) {
      showToast('Nama Lengkap & Kelas wajib diisi!', 'error');
      return;
    }

    StorageService.saveStudent({
      id: editingStudent ? editingStudent.id : undefined,
      fullName: formName.trim(),
      nis: formNis.trim() || '-',
      classId: formClassId,
      password: formPassword.trim() || undefined
    });

    setModalOpen(false);
    refreshStudents();
    showToast(editingStudent ? 'Data siswa berhasil diperbarui' : 'Siswa berhasil ditambahkan');
  };

  const handleDelete = (id: string, name: string) => {
    setDeleteTarget({ id, name });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteStudent(deleteTarget.id);
    refreshStudents();
    showToast(`Data siswa ${deleteTarget.name} berhasil dihapus`, 'info');
    setDeleteTarget(null);
  };

  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!selectedClass) {
      showToast('Harap pilih Kelas terlebih dahulu pada filter kelas sebelum upload!', 'error');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows: any[] = XLSX.utils.sheet_to_json(sheet);

        const itemsToInsert = rows
          .map(row => {
            const keys = Object.keys(row);
            const nameKey = keys.find(k => k.toLowerCase().includes('nama'));
            const nisKey = keys.find(k => k.toLowerCase().includes('nis'));
            return nameKey
              ? {
                  fullName: String(row[nameKey]).trim(),
                  nis: nisKey ? String(row[nisKey]).trim() : '',
                  classId: selectedClass
                }
              : null;
          })
          .filter(Boolean) as { fullName: string; nis?: string; classId: string }[];

        if (itemsToInsert.length === 0) {
          showToast('Format Excel tidak sesuai. Pastikan ada kolom "Nama"', 'error');
          return;
        }

        const added = StorageService.importBulkStudents(itemsToInsert);
        refreshStudents();
        showToast(`Berhasil menambahkan ${added.length} siswa baru secara otomatis!`, 'success');
      } catch (err: any) {
        showToast(`Gagal membaca Excel: ${err.message}`, 'error');
      }
      e.target.value = '';
    };
    reader.readAsArrayBuffer(file);
  };

  const downloadExcelTemplate = () => {
    const ws = XLSX.utils.json_to_sheet([
      { 'No': 1, 'NIS': '2021001', 'Nama Lengkap': 'Ahmad Fauzi Pratama' },
      { 'No': 2, 'NIS': '2021002', 'Nama Lengkap': 'Siti Nur Aisyah' }
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template_Siswa');
    XLSX.writeFile(wb, 'Format_Import_Siswa_SDN_Ciketing_Udik_2.xlsx');
  };

  const filtered = students.filter(s => {
    const matchClass = !selectedClass || s.classId === selectedClass;
    const matchSearch =
      s.fullName.toLowerCase().includes(search.toLowerCase()) ||
      s.nis.toLowerCase().includes(search.toLowerCase()) ||
      s.username.toLowerCase().includes(search.toLowerCase());
    return matchClass && matchSearch;
  });

  const studentsToPrint = selectedClass
    ? students.filter(s => s.classId === selectedClass)
    : students;

  const triggerWindowPrint = () => {
    window.print();
  };

  return (
    <div className="space-y-5">
      {/* Action Header */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col xl:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full xl:w-auto flex-1">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari nama, NIS, username..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <select
            value={selectedClass}
            onChange={e => setSelectedClass(e.target.value)}
            className="w-full sm:w-48 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            <option value="">Semua Rombel Kelas</option>
            {classes.map(c => (
              <option key={c.id} value={c.id}>
                Kelas {c.className} ({c.studentCount || 0} anak)
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto justify-end">
          <button
            onClick={() => setPrintCardsModalOpen(true)}
            className="flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" /> Cetak Kartu Login
          </button>

          <label className="flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer">
            <FileSpreadsheet className="w-4 h-4" /> Import Excel
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleImportExcel}
              className="hidden"
            />
          </label>

          <button
            onClick={downloadExcelTemplate}
            title="Download Template Format Excel"
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={openAddModal}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4" /> + Tambah Siswa
          </button>
        </div>
      </div>

      {/* Students Data Table */}
      <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs sm:text-sm min-w-[760px]">
            <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400 font-bold border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4 w-12 text-center">No</th>
                <th className="py-3.5 px-4 w-28">NIS</th>
                <th className="py-3.5 px-4">Nama Lengkap Siswa</th>
                <th className="py-3.5 px-4 w-24 text-center">Kelas</th>
                <th className="py-3.5 px-4 w-32 font-mono">Username</th>
                <th className="py-3.5 px-4 w-28 font-mono">Password</th>
                <th className="py-3.5 px-4 w-24 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400 italic">
                    Belum ada data siswa yang cocok dengan pencarian / filter.
                  </td>
                </tr>
              ) : (
                filtered.map((s, index) => (
                  <tr key={s.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-3 px-4 text-center font-mono text-slate-400">{index + 1}</td>
                    <td className="py-3 px-4 font-mono text-slate-300">{s.nis}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-7 h-7 rounded-full flex items-center justify-center font-bold text-white text-[11px] shrink-0"
                          style={{ backgroundColor: s.avatarColor || '#10b981' }}
                        >
                          {s.fullName.charAt(0)}
                        </div>
                        <span className="font-bold text-white">{s.fullName}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[11px]">
                        Kelas {s.className || '-'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-cyan-300 font-bold tracking-wider">
                      {s.username}
                    </td>
                    <td className="py-3 px-4 font-mono text-amber-300 font-bold tracking-wider">
                      {s.password || '-'}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => openEditModal(s)}
                        className="p-1.5 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 transition-colors mr-1 cursor-pointer"
                        title="Edit Siswa"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(s.id, s.fullName)}
                        className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 transition-colors cursor-pointer"
                        title="Hapus Siswa"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Student */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="glass-strong rounded-2xl w-full max-w-md border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                {editingStudent ? 'Edit Biodata Siswa' : 'Tambah Siswa Baru'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                  Nama Lengkap Siswa <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="Nama sesuai akta kelahiran"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                  Nomor Induk Siswa (NIS)
                </label>
                <input
                  type="text"
                  value={formNis}
                  onChange={e => setFormNis(e.target.value)}
                  placeholder="Contoh: 2021001"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                  Rombel Kelas <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formClassId}
                  onChange={e => setFormClassId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500 cursor-pointer"
                  required
                >
                  <option value="">-- Pilih Rombel Kelas --</option>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>
                      Kelas {c.className}
                    </option>
                  ))}
                </select>
              </div>

              {editingStudent && (
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                    Password Akun
                  </label>
                  <input
                    type="text"
                    value={formPassword}
                    onChange={e => setFormPassword(e.target.value)}
                    placeholder="Ubah password siswa"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
              )}

              {!editingStudent && (
                <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 text-xs text-emerald-300 leading-relaxed">
                  <b>Username otomatis</b> akan digenerate berurutan (misal: <code>5A01</code>, <code>5A02</code>) dan password acak 6 digit siap cetak kartu.
                </div>
              )}

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
                >
                  Simpan Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Cetak Kartu Login Siswa */}
      {printCardsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between no-print">
              <div>
                <h3 className="font-bold text-base sm:text-lg text-white flex items-center gap-2">
                  <Printer className="w-5 h-5 text-indigo-400" /> Pratinjau Kartu Login LMS PAI
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Menampilkan {studentsToPrint.length} kartu siswa{' '}
                  {selectedClass ? `(Kelas Terpilih)` : `(Semua Kelas)`}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={triggerWindowPrint}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> Cetak Sekarang
                </button>
                <button
                  onClick={() => setPrintCardsModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Scrollable Printable Cards Grid */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-slate-900/50 print:bg-white print:p-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 print:grid-cols-2 print:gap-4">
                {studentsToPrint.map(s => (
                  <div
                    key={s.id}
                    className="bg-white text-slate-900 rounded-2xl p-4 border-2 border-dashed border-slate-300 shadow-md break-inside-avoid print:border-black"
                  >
                    <div className="text-center pb-2.5 mb-2.5 border-b border-slate-200">
                      <p className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-800">
                        SDN CIKETING UDIK 2 BANTARGEBANG
                      </p>
                      <h4 className="text-xs font-bold text-slate-800 tracking-tight">
                        KARTU LOGIN SISWA LMS PAI
                      </h4>
                    </div>

                    <div className="space-y-1.5 text-xs">
                      <div className="flex items-center">
                        <span className="w-20 font-semibold text-slate-500 text-[11px]">Nama:</span>
                        <span className="flex-1 font-bold truncate text-slate-900">{s.fullName}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-20 font-semibold text-slate-500 text-[11px]">Kelas:</span>
                        <span className="font-bold text-slate-900">Kelas {s.className || '-'}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-20 font-semibold text-slate-500 text-[11px]">Username:</span>
                        <span className="font-mono font-bold text-blue-600 tracking-wider text-sm">
                          {s.username}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-20 font-semibold text-slate-500 text-[11px]">Password:</span>
                        <span className="font-mono font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 tracking-widest text-xs">
                          {s.password || '-'}
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[9px] text-slate-400">
                      <span>Simpan kartu ini dengan baik</span>
                      <span>TA 2026/2027</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Data Siswa?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus data siswa{' '}
              <span className="text-white font-bold">{deleteTarget.name}</span>? Akun login dan riwayat nilai siswa ini akan terhapus.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Siswa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
