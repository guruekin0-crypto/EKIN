import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Plus,
  Edit2,
  Trash2,
  Printer,
  FileQuestion,
  X,
  Check,
  CheckCircle2,
  Wand2,
  Type,
  Send,
  Save,
  Layers,
  Archive,
  ArrowLeftRight,
  TextCursorInput
} from 'lucide-react';
import { Question, QuestionType } from '../../types';
import { StorageService } from '../../services/storageService';
import { generateAiQuestions } from '../../services/aiQuestionService';

interface CreateQuestionsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onNavigateToBank?: () => void;
  onNavigateToQuizzes?: () => void;
}

const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  pg_standar: 'Pilihan Ganda Standar',
  pg_kompleks: 'Pilihan Ganda Kompleks',
  benar_salah: 'Benar / Salah',
  menjodohkan: 'Menjodohkan (Pasangan)',
  isian_singkat: 'Isian Singkat',
  essay: 'Uraian / Essay'
};

export const CreateQuestionsView: React.FC<CreateQuestionsViewProps> = ({
  showToast,
  onNavigateToBank,
  onNavigateToQuizzes
}) => {
  const teacherProfile = StorageService.getTeacherProfile();
  const appSettings = StorageService.getAppSettings();
  const classes = StorageService.getClasses();

  const activeSchoolName =
    appSettings.schoolName || teacherProfile.schoolName || 'SDN Ciketing Udik 2 Bantargebang';

  // Mode: 'ai' or 'manual'
  const [creationMode, setCreationMode] = useState<'ai' | 'manual'>('ai');

  // Staged Questions list currently being composed / reviewed
  const [stagedQuestions, setStagedQuestions] = useState<Question[]>([]);

  // Whether to save to Bank Soal (Default: true)
  const [saveToBankSoal, setSaveToBankSoal] = useState<boolean>(true);

  // AI Generator Form States
  const [aiGrade, setAiGrade] = useState('5');
  const [aiSemester, setAiSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');

  // Pull topics dynamically from "Materi Pokok Per Kelas"
  const classTopicsForGrade = StorageService.getClassTopics(aiGrade, aiSemester);
  const allClassTopics = StorageService.getClassTopics();
  const availableTopics =
    classTopicsForGrade.length > 0 ? classTopicsForGrade : allClassTopics;

  const [aiTopic, setAiTopic] = useState<string>(() => {
    const initialList = StorageService.getClassTopics('5', 'Ganjil');
    if (initialList.length > 0) return initialList[0].chapterTitle;
    return 'custom';
  });
  const [aiCustomTopic, setAiCustomTopic] = useState('');
  const [aiQuestionType, setAiQuestionType] = useState<string>('per_type');
  const [aiCount, setAiCount] = useState<number>(5);

  // Per-question-type manual count state
  const [aiTypeCounts, setAiTypeCounts] = useState<Record<QuestionType, number>>({
    pg_standar: 2,
    pg_kompleks: 1,
    benar_salah: 1,
    menjodohkan: 1,
    isian_singkat: 0,
    essay: 0
  });
  const [aiGenerating, setAiGenerating] = useState(false);

  // Sync topic dropdown when grade or semester changes
  useEffect(() => {
    const topics = StorageService.getClassTopics(aiGrade, aiSemester);
    if (topics.length > 0) {
      if (aiTopic !== 'custom' && !topics.some(t => t.chapterTitle === aiTopic)) {
        setAiTopic(topics[0].chapterTitle);
      }
    } else if (allClassTopics.length === 0) {
      setAiTopic('custom');
    }
  }, [aiGrade, aiSemester]);

  // Calculate total count when in per_type mode
  const totalFromTypeCounts = (Object.values(aiTypeCounts) as number[]).reduce(
    (acc, val) => acc + (Number(val) || 0),
    0
  );

  const handleSingleTypeChange = (selectedType: string) => {
    setAiQuestionType(selectedType);
    if (selectedType !== 'per_type' && selectedType !== 'all') {
      const qt = selectedType as QuestionType;
      const currentTotal = Math.max(1, aiCount || 5);
      setAiTypeCounts({
        pg_standar: qt === 'pg_standar' ? currentTotal : 0,
        pg_kompleks: qt === 'pg_kompleks' ? currentTotal : 0,
        benar_salah: qt === 'benar_salah' ? currentTotal : 0,
        menjodohkan: qt === 'menjodohkan' ? currentTotal : 0,
        isian_singkat: qt === 'isian_singkat' ? currentTotal : 0,
        essay: qt === 'essay' ? currentTotal : 0
      });
    }
  };

  const handleTypeCountChange = (qt: QuestionType, val: number) => {
    const cleanVal = Math.max(0, Math.min(50, isNaN(val) ? 0 : val));
    const updated = {
      ...aiTypeCounts,
      [qt]: cleanVal
    };
    setAiTypeCounts(updated);
    const newSum = (Object.values(updated) as number[]).reduce((a, b) => a + b, 0);
    if (newSum > 0) {
      setAiCount(newSum);
    }
  };

  const toggleTypeEnabled = (qt: QuestionType) => {
    const current = aiTypeCounts[qt] || 0;
    handleTypeCountChange(qt, current > 0 ? 0 : 1);
  };

  // Manual Composer Form States
  const [manualType, setManualType] = useState<QuestionType>('pg_standar');
  const [manualGrade, setManualGrade] = useState('5');
  const [manualSemester, setManualSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [manualScoreWeight, setManualScoreWeight] = useState(10);
  const [manualStimulus, setManualStimulus] = useState('');
  const [manualDomain, setManualDomain] = useState("Al-Qur'an & Hadis");
  const [manualQuestion, setManualQuestion] = useState('');
  const [manualArabic, setManualArabic] = useState('');
  const [manualOptions, setManualOptions] = useState<string[]>(['', '', '', '']);
  const [manualMatchingPairs, setManualMatchingPairs] = useState<
    Array<{ left: string; right: string }>
  >([
    { left: '', right: '' },
    { left: '', right: '' },
    { left: '', right: '' }
  ]);
  const [manualCorrectSingle, setManualCorrectSingle] = useState('');
  const [manualCorrectMulti, setManualCorrectMulti] = useState<string[]>([]);
  const [manualExplanation, setManualExplanation] = useState('');

  // Editing single question in Staging
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  // Send to Student (Publish Quiz) Modal State
  const [publishModalOpen, setPublishModalOpen] = useState(false);
  const [quizTitle, setQuizTitle] = useState('');
  const [quizTargetClassId, setQuizTargetClassId] = useState('5');
  const [quizDuration, setQuizDuration] = useState(30);
  const [quizDeadline, setQuizDeadline] = useState(
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16)
  );
  const [quizRandomize, setQuizRandomize] = useState(true);

  // Print Modal State
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [printViewTab, setPrintViewTab] = useState<'blueprint' | 'questions' | 'rubric'>(
    'blueprint'
  );

  // Trigger AI Generation
  const handleGenerateAI = async (e: React.FormEvent) => {
    e.preventDefault();
    const chosenTopic = aiTopic === 'custom' ? aiCustomTopic.trim() : aiTopic.trim();
    if (!chosenTopic) {
      showToast('Pilih materi pokok atau ketik topik sendiri terlebih dahulu!', 'error');
      return;
    }

    const effectiveCount =
      aiQuestionType === 'per_type' ? totalFromTypeCounts : Math.max(1, Number(aiCount) || 1);

    if (effectiveCount <= 0) {
      showToast('Tentukan minimal 1 butir soal untuk digenerate!', 'error');
      return;
    }

    setAiGenerating(true);

    const activeTypeCounts: Partial<Record<QuestionType, number>> | undefined =
      aiQuestionType === 'per_type'
        ? aiTypeCounts
        : aiQuestionType !== 'all'
        ? ({ [aiQuestionType as QuestionType]: effectiveCount } as Partial<Record<QuestionType, number>>)
        : undefined;

    try {
      const result = await generateAiQuestions({
        topic: chosenTopic,
        grade: aiGrade,
        semester: aiSemester,
        count: effectiveCount,
        schoolName: activeSchoolName,
        questionType: aiQuestionType,
        typeCounts: activeTypeCounts
      });

      if (result.questions && result.questions.length > 0) {
        setStagedQuestions(result.questions);
        setQuizTitle(`Asesmen PAI: ${chosenTopic} (Kelas ${aiGrade})`);
        setQuizTargetClassId(aiGrade);
        showToast(
          `Berhasil merumuskan ${result.questions.length} butir soal model TKA berpendekatan KBC untuk ${activeSchoolName}! ✨`,
          'success'
        );
      }
    } catch (err: any) {
      showToast('Gagal merumuskan soal: ' + (err?.message || 'Terjadi kesalahan sistem'), 'error');
    } finally {
      setAiGenerating(false);
    }
  };

  // Add Manually Composed Question to Staged list
  const handleAddManualQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualQuestion.trim()) {
      showToast('Pertanyaan soal wajib diisi!', 'error');
      return;
    }

    let correctAnswer: string | string[] = '';
    let finalOptions: string[] = [];
    let finalMatchingPairs: Array<{ left: string; right: string }> | undefined = undefined;

    if (manualType === 'pg_standar' || manualType === 'benar_salah') {
      if (!manualCorrectSingle.trim()) {
        showToast('Pilih kunci jawaban yang benar!', 'error');
        return;
      }
      correctAnswer = manualCorrectSingle.trim();
      finalOptions =
        manualType === 'benar_salah'
          ? ['Benar', 'Salah']
          : manualOptions.filter(o => o.trim() !== '');
    } else if (manualType === 'pg_kompleks') {
      if (manualCorrectMulti.length === 0) {
        showToast('Pilih minimal 1 opsi jawaban yang benar untuk PG Kompleks!', 'error');
        return;
      }
      correctAnswer = manualCorrectMulti;
      finalOptions = manualOptions.filter(o => o.trim() !== '');
    } else if (manualType === 'menjodohkan') {
      const validPairs = manualMatchingPairs.filter(
        p => p.left.trim() !== '' && p.right.trim() !== ''
      );
      if (validPairs.length < 2) {
        showToast('Isi minimal 2 pasangan pernyataan & jawaban untuk soal Menjodohkan!', 'error');
        return;
      }
      finalMatchingPairs = validPairs.map(p => ({
        left: p.left.trim(),
        right: p.right.trim()
      }));
      finalOptions = finalMatchingPairs.map(p => `${p.left} ➔ ${p.right}`);
      correctAnswer = finalMatchingPairs.map(p => `${p.left} = ${p.right}`);
    } else if (manualType === 'isian_singkat') {
      if (!manualCorrectSingle.trim()) {
        showToast('Isi kunci jawaban singkat terlebih dahulu!', 'error');
        return;
      }
      correctAnswer = manualCorrectSingle.trim();
      finalOptions = [];
    } else {
      // essay
      correctAnswer = manualCorrectSingle.trim() || 'Rubrik evaluasi pendidik';
      finalOptions = [];
    }

    const newQ: Question = {
      id:
        'q-staged-' +
        Date.now().toString(36) +
        '-' +
        Math.random().toString(36).substring(2, 6),
      questionType: manualType,
      classId: manualGrade,
      className: `Tingkat Kelas ${manualGrade}`,
      semester: manualSemester,
      domain: manualDomain,
      approach: 'Kurikulum Berbasis Cinta (KBC)',
      scoreWeight: Number(manualScoreWeight) || 10,
      stimulus: manualStimulus.trim(),
      arabicText: manualArabic.trim() || undefined,
      question: manualQuestion.trim(),
      options: finalOptions,
      matchingPairs: finalMatchingPairs,
      correctAnswer,
      explanation: manualExplanation.trim()
    };

    if (editingIndex !== null) {
      const updated = [...stagedQuestions];
      updated[editingIndex] = newQ;
      setStagedQuestions(updated);
      setEditingIndex(null);
      showToast('Butir soal berhasil diperbarui di daftar draf.', 'info');
    } else {
      setStagedQuestions(prev => [...prev, newQ]);
      showToast('Butir soal berhasil ditambahkan ke daftar draf.', 'success');
    }

    // Reset manual form fields
    setManualQuestion('');
    setManualStimulus('');
    setManualArabic('');
    setManualOptions(['', '', '', '']);
    setManualMatchingPairs([
      { left: '', right: '' },
      { left: '', right: '' },
      { left: '', right: '' }
    ]);
    setManualCorrectSingle('');
    setManualCorrectMulti([]);
    setManualExplanation('');
  };

  const removeStagedQuestion = (index: number) => {
    setStagedQuestions(prev => prev.filter((_, i) => i !== index));
    showToast('Butir soal dihapus dari daftar draf.', 'info');
  };

  const editStagedQuestion = (q: Question, idx: number) => {
    setEditingIndex(idx);
    setCreationMode('manual');
    setManualType(q.questionType);
    setManualGrade(q.classId);
    setManualSemester(q.semester);
    setManualScoreWeight(q.scoreWeight);
    setManualStimulus(q.stimulus || '');
    setManualDomain(q.domain || "Al-Qur'an & Hadis");
    setManualQuestion(q.question);
    setManualArabic(q.arabicText || '');
    setManualOptions(q.options && q.options.length ? [...q.options] : ['', '', '', '']);
    if (q.questionType === 'menjodohkan') {
      setManualMatchingPairs(
        q.matchingPairs && q.matchingPairs.length >= 2
          ? q.matchingPairs.map(p => ({ ...p }))
          : [
              { left: '', right: '' },
              { left: '', right: '' },
              { left: '', right: '' }
            ]
      );
    } else if (q.questionType === 'pg_kompleks') {
      setManualCorrectMulti(
        Array.isArray(q.correctAnswer) ? q.correctAnswer : [q.correctAnswer]
      );
      setManualCorrectSingle('');
    } else {
      setManualCorrectSingle(
        typeof q.correctAnswer === 'string'
          ? q.correctAnswer
          : q.correctAnswer[0] || ''
      );
      setManualCorrectMulti([]);
    }
    setManualExplanation(q.explanation || '');
  };

  // Save to Bank Soal only
  const handleSaveToBankOnly = () => {
    if (stagedQuestions.length === 0) {
      showToast('Belum ada butir soal untuk disimpan!', 'error');
      return;
    }

    stagedQuestions.forEach(q => StorageService.saveQuestion(q));
    showToast(`${stagedQuestions.length} butir soal berhasil disimpan ke Bank Soal!`, 'success');
    if (onNavigateToBank) {
      onNavigateToBank();
    }
  };

  // Publish as Quiz to Students
  const handleConfirmPublishQuiz = () => {
    if (stagedQuestions.length === 0) {
      showToast('Belum ada butir soal untuk dikirim ke siswa!', 'error');
      return;
    }
    if (!quizTitle.trim()) {
      showToast('Judul kuis wajib diisi!', 'error');
      return;
    }

    let finalQuestionIds: string[] = [];

    if (saveToBankSoal) {
      stagedQuestions.forEach(q => {
        const saved = StorageService.saveQuestion(q);
        finalQuestionIds.push(saved.id);
      });
      StorageService.saveQuiz({
        title: quizTitle.trim(),
        description: `Asesmen Kurikulum Merdeka PAI ${activeSchoolName} (Pendekatan KBC). Waktu pengerjaan ${quizDuration} menit.`,
        classId: quizTargetClassId,
        durationMinutes: Number(quizDuration) || 30,
        deadline: quizDeadline,
        randomize: quizRandomize,
        showScoreImmediately: true,
        totalQuestions: stagedQuestions.length,
        status: 'published',
        semester: stagedQuestions[0]?.semester || 'Ganjil',
        questionIds: finalQuestionIds
      });
      showToast(
        `Kuis berhasil diterbitkan ke siswa & ${stagedQuestions.length} soal disimpan ke Bank Soal! 🚀`,
        'success'
      );
    } else {
      const quizQuestions = stagedQuestions.map((q, idx) => ({
        ...q,
        id: q.id || `q-custom-${Date.now()}-${idx}`
      }));
      finalQuestionIds = quizQuestions.map(q => q.id);

      StorageService.saveQuiz({
        title: quizTitle.trim(),
        description: `Asesmen Latihan PAI ${activeSchoolName} (Soal Mandiri/Khusus). Waktu pengerjaan ${quizDuration} menit.`,
        classId: quizTargetClassId,
        durationMinutes: Number(quizDuration) || 30,
        deadline: quizDeadline,
        randomize: quizRandomize,
        showScoreImmediately: true,
        totalQuestions: stagedQuestions.length,
        status: 'published',
        semester: stagedQuestions[0]?.semester || 'Ganjil',
        questionIds: finalQuestionIds,
        customQuestions: quizQuestions
      });
      showToast(
        `Kuis berhasil diterbitkan langsung ke siswa tanpa disimpan ke Bank Soal! 🚀`,
        'success'
      );
    }

    setPublishModalOpen(false);
    if (onNavigateToQuizzes) {
      onNavigateToQuizzes();
    }
  };

  const triggerBrowserPrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl glass-strong border border-cyan-500/30 p-5 sm:p-7 shadow-xl">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-bold mb-3">
              <Sparkles className="w-3.5 h-3.5" /> Generator Soal AI &amp; Kisi-Kisi Asesmen
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
              Studio Perumusan Soal PAI &amp; Budi Pekerti
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              Pilih materi langsung dari menu <b>Materi Pokok Per Kelas</b> atau ketik topik sendiri. Mendukung soal <b>Pilihan Ganda, PG Kompleks, Benar/Salah, Menjodohkan, Isian Singkat, dan Essay</b> dengan pengaturan jumlah soal manual per jenis soal.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {onNavigateToBank && (
              <button
                onClick={onNavigateToBank}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-2 cursor-pointer transition-all border border-white/10"
              >
                <Archive className="w-4 h-4 text-emerald-400" /> Buka Bank Soal
              </button>
            )}
            {stagedQuestions.length > 0 && (
              <>
                <button
                  onClick={() => setPrintModalOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-blue-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Printer className="w-4 h-4" /> Cetak Soal &amp; Kisi-Kisi
                </button>
                <button
                  onClick={() => setPublishModalOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer transition-all"
                >
                  <Send className="w-4 h-4" /> Kirim ke Siswa
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Creation Mode Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-3">
        <button
          onClick={() => setCreationMode('ai')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-all ${
            creationMode === 'ai'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-200" /> Rumuskan dengan AI (Otomatis)
        </button>
        <button
          onClick={() => {
            setCreationMode('manual');
            setEditingIndex(null);
          }}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-all ${
            creationMode === 'manual'
              ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Plus className="w-4 h-4" /> Tulis Soal Mandiri (Manual)
        </button>
      </div>

      {/* MAIN BUILDER AREA */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: Input Form */}
        <div className="lg:col-span-5 space-y-4">
          {creationMode === 'ai' ? (
            /* AI GENERATOR FORM */
            <form
              onSubmit={handleGenerateAI}
              className="glass rounded-3xl p-5 border border-cyan-500/30 space-y-4 shadow-lg"
            >
              <div className="flex items-center gap-2.5 pb-3 border-b border-white/10">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
                  <Wand2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Parameter Generator AI</h3>
                  <p className="text-[11px] text-slate-400">
                    Kurikulum Merdeka, TKA Stimulus &amp; Khat Naskh
                  </p>
                </div>
              </div>

              {/* Tingkat Kelas & Semester */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                    Tingkat Kelas
                  </label>
                  <select
                    value={aiGrade}
                    onChange={e => setAiGrade(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="1">Kelas 1 (Fase A)</option>
                    <option value="2">Kelas 2 (Fase A)</option>
                    <option value="3">Kelas 3 (Fase B)</option>
                    <option value="4">Kelas 4 (Fase B)</option>
                    <option value="5">Kelas 5 (Fase C)</option>
                    <option value="6">Kelas 6 (Fase C)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                    Semester
                  </label>
                  <select
                    value={aiSemester}
                    onChange={e => setAiSemester(e.target.value as 'Ganjil' | 'Genap')}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Ganjil">Semester Ganjil</option>
                    <option value="Genap">Semester Genap</option>
                  </select>
                </div>
              </div>

              {/* Penentuan Materi dari Menu Materi Pokok Per Kelas + Ketik Topik Sendiri */}
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <label className="text-xs font-bold text-slate-300 uppercase flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" /> Tema / Materi Pokok Per Kelas
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (aiTopic === 'custom' && availableTopics.length > 0) {
                        setAiTopic(availableTopics[0].chapterTitle);
                      } else {
                        setAiTopic('custom');
                      }
                    }}
                    className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                  >
                    {aiTopic === 'custom' && availableTopics.length > 0
                      ? 'Pilih dari Daftar Materi Pokok'
                      : '+ Ketik Topik Sendiri'}
                  </button>
                </div>

                <select
                  value={aiTopic}
                  onChange={e => {
                    setAiTopic(e.target.value);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                >
                  {classTopicsForGrade.length > 0 ? (
                    <optgroup
                      label={`Materi Pokok Kelas ${aiGrade} • Semester ${aiSemester} (${classTopicsForGrade.length} Bab)`}
                    >
                      {classTopicsForGrade.map(t => (
                        <option key={t.id} value={t.chapterTitle}>
                          Bab {t.chapterNo}: {t.chapterTitle} ({t.domain})
                        </option>
                      ))}
                    </optgroup>
                  ) : availableTopics.length > 0 ? (
                    <optgroup label="Daftar Materi Pokok Tersedia">
                      {availableTopics.map(t => (
                        <option key={t.id} value={t.chapterTitle}>
                          Kelas {t.classGrade} ({t.semester}) - Bab {t.chapterNo}: {t.chapterTitle}
                        </option>
                      ))}
                    </optgroup>
                  ) : null}
                  <option value="custom">✍️ + Ketik Topik / Materi Sendiri (Manual)</option>
                </select>

                <p className="text-[10px] text-slate-400">
                  Sumber daftar: Menu <b>Materi Pokok Per Kelas</b> (Kelas {aiGrade} Semester{' '}
                  {aiSemester}). Pilih opsi paling bawah untuk mengetik topik sendiri.
                </p>
              </div>

              {aiTopic === 'custom' && (
                <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 space-y-1.5">
                  <label className="text-xs font-bold text-cyan-300 uppercase block">
                    Ketik Topik / Materi Sendiri (Manual) <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={aiCustomTopic}
                    onChange={e => setAiCustomTopic(e.target.value)}
                    placeholder="Contoh: Surah Al-Ma'un, Adab Kepada Guru, atau Kisah Nabi Muhammad SAW..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/90 border border-cyan-500/40 text-white text-xs font-semibold focus:outline-none focus:border-cyan-400"
                    required
                  />
                </div>
              )}

              {/* Mode Bentuk Soal & Jumlah Soal Manual */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                    Mode Jenis Soal
                  </label>
                  <select
                    value={aiQuestionType}
                    onChange={e => handleSingleTypeChange(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="per_type">Atur Jumlah Per Jenis Soal (Manual)</option>
                    <option value="pg_standar">Khusus Pilihan Ganda Standar</option>
                    <option value="pg_kompleks">Khusus PG Kompleks</option>
                    <option value="benar_salah">Khusus Benar / Salah</option>
                    <option value="menjodohkan">Khusus Menjodohkan (Pasangan)</option>
                    <option value="isian_singkat">Khusus Isian Singkat</option>
                    <option value="essay">Khusus Uraian / Essay</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                    Total Jumlah Soal (Ketik Manual)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={aiQuestionType === 'per_type' ? totalFromTypeCounts : aiCount}
                    onChange={e => {
                      const val = Math.max(1, Math.min(50, Number(e.target.value) || 1));
                      setAiCount(val);
                      if (aiQuestionType !== 'per_type' && aiQuestionType !== 'all') {
                        const qt = aiQuestionType as QuestionType;
                        setAiTypeCounts({
                          pg_standar: qt === 'pg_standar' ? val : 0,
                          pg_kompleks: qt === 'pg_kompleks' ? val : 0,
                          benar_salah: qt === 'benar_salah' ? val : 0,
                          menjodohkan: qt === 'menjodohkan' ? val : 0,
                          isian_singkat: qt === 'isian_singkat' ? val : 0,
                          essay: qt === 'essay' ? val : 0
                        });
                      } else if (aiQuestionType === 'per_type') {
                        setAiTypeCounts(prev => ({
                          ...prev,
                          pg_standar: val,
                          pg_kompleks: 0,
                          benar_salah: 0,
                          menjodohkan: 0,
                          isian_singkat: 0,
                          essay: 0
                        }));
                      }
                    }}
                    placeholder="Ketik jumlah soal..."
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-cyan-500/40 text-white text-xs font-bold font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Per-Question-Type Manual Count Input Panel */}
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-white/15 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-cyan-300 uppercase tracking-wider">
                    Rincian Jenis Soal &amp; Jumlah Per Jenis (Ketik Manual)
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 font-mono text-[11px] font-bold">
                    Total:{' '}
                    {aiQuestionType === 'per_type' ? totalFromTypeCounts : aiCount} Butir
                  </span>
                </div>

                <div className="space-y-1.5">
                  {(
                    [
                      'pg_standar',
                      'pg_kompleks',
                      'benar_salah',
                      'menjodohkan',
                      'isian_singkat',
                      'essay'
                    ] as QuestionType[]
                  ).map(qt => {
                    const countVal = aiTypeCounts[qt] || 0;
                    const isChecked = countVal > 0;
                    return (
                      <div
                        key={qt}
                        className={`flex items-center justify-between gap-2 p-2 rounded-xl border transition-all ${
                          isChecked
                            ? 'bg-cyan-500/10 border-cyan-500/35 text-white'
                            : 'bg-white/5 border-white/5 text-slate-400'
                        }`}
                      >
                        <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer flex-1 select-none">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {
                              setAiQuestionType('per_type');
                              toggleTypeEnabled(qt);
                            }}
                            className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
                          />
                          <span>{QUESTION_TYPE_LABELS[qt]}</span>
                        </label>

                        <div className="flex items-center gap-1.5">
                          <input
                            type="number"
                            min={0}
                            max={50}
                            value={countVal}
                            onChange={e => {
                              setAiQuestionType('per_type');
                              handleTypeCountChange(qt, parseInt(e.target.value, 10));
                            }}
                            className="w-16 px-2 py-1 rounded-lg bg-slate-950 border border-white/20 text-white text-center font-mono text-xs font-bold focus:outline-none focus:border-cyan-400"
                          />
                          <span className="text-[10px] text-slate-400">soal</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-[11px] text-slate-300 space-y-1">
                <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Konteks Sekolah Otomatis:
                </div>
                <p>
                  Soal akan menyebutkan nama sekolah: <b>"{activeSchoolName}"</b> pada narasi
                  stimulus cerita.
                </p>
              </div>

              <button
                type="submit"
                disabled={aiGenerating}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-600 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
              >
                {aiGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    AI Sedang Merumuskan Soal...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-200" />
                    Generate{' '}
                    {aiQuestionType === 'per_type' ? totalFromTypeCounts : aiCount} Soal AI Sekarang
                  </>
                )}
              </button>
            </form>
          ) : (
            /* MANUAL COMPOSER FORM */
            <form
              onSubmit={handleAddManualQuestion}
              className="glass rounded-3xl p-5 border border-emerald-500/30 space-y-4 shadow-lg"
            >
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                    <Plus className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white">
                      {editingIndex !== null ? 'Edit Butir Soal' : 'Tulis Soal Baru (Manual)'}
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Mendukung PG, Kompleks, B/S, Menjodohkan, Isian Singkat &amp; Essay
                    </p>
                  </div>
                </div>
                {editingIndex !== null && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingIndex(null);
                      setManualQuestion('');
                      setManualStimulus('');
                    }}
                    className="text-xs text-rose-400 hover:underline cursor-pointer"
                  >
                    Batal Edit
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Jenis / Bentuk Soal
                  </label>
                  <select
                    value={manualType}
                    onChange={e => setManualType(e.target.value as QuestionType)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="pg_standar">PG Standar (1 Jawaban)</option>
                    <option value="pg_kompleks">PG Kompleks (Multi Jawaban)</option>
                    <option value="benar_salah">Benar / Salah</option>
                    <option value="menjodohkan">Menjodohkan (Pasangan)</option>
                    <option value="isian_singkat">Isian Singkat</option>
                    <option value="essay">Uraian / Essay</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Tingkat Kelas
                  </label>
                  <select
                    value={manualGrade}
                    onChange={e => setManualGrade(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="1">Kelas 1</option>
                    <option value="2">Kelas 2</option>
                    <option value="3">Kelas 3</option>
                    <option value="4">Kelas 4</option>
                    <option value="5">Kelas 5</option>
                    <option value="6">Kelas 6</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Semester
                  </label>
                  <select
                    value={manualSemester}
                    onChange={e => setManualSemester(e.target.value as 'Ganjil' | 'Genap')}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Ganjil">Semester Ganjil</option>
                    <option value="Genap">Semester Genap</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Bobot Poin Soal
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={manualScoreWeight}
                    onChange={e => setManualScoreWeight(Number(e.target.value) || 10)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Stimulus TKA (Cerita / Kasus Keseharian di {activeSchoolName})
                </label>
                <textarea
                  value={manualStimulus}
                  onChange={e => setManualStimulus(e.target.value)}
                  rows={2}
                  placeholder={`Contoh: Saat istirahat di ${activeSchoolName}, Farhan melihat bekal Ahmad terjatuh...`}
                  className="w-full p-3 rounded-xl bg-white/5 border border-white/15 text-white text-xs leading-relaxed focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Ayat / Hadis Arab (Khat Naskh Berharakat)
                </label>
                <input
                  type="text"
                  value={manualArabic}
                  onChange={e => setManualArabic(e.target.value)}
                  dir="rtl"
                  placeholder="Contoh: أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm font-serif focus:outline-none focus:border-emerald-500 text-right"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Pertanyaan / Instruksi Soal <span className="text-rose-400">*</span>
                </label>
                <textarea
                  value={manualQuestion}
                  onChange={e => setManualQuestion(e.target.value)}
                  rows={2}
                  placeholder="Ketik kalimat pertanyaan pemantik nalar siswa..."
                  className="w-full p-3 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              {/* Type-specific Answer Inputs */}
              {manualType === 'pg_standar' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase block">
                    Pilihan Jawaban &amp; Kunci (Pilih radio untuk jawaban benar)
                  </label>
                  {['A', 'B', 'C', 'D'].map((label, idx) => (
                    <div key={label} className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="manualCorrect"
                        checked={
                          manualCorrectSingle === manualOptions[idx] &&
                          manualOptions[idx] !== ''
                        }
                        onChange={() => setManualCorrectSingle(manualOptions[idx])}
                        className="w-4 h-4 text-emerald-500 cursor-pointer"
                      />
                      <span className="w-5 text-xs font-bold text-slate-400">{label}.</span>
                      <input
                        type="text"
                        value={manualOptions[idx] || ''}
                        onChange={e => {
                          const updated = [...manualOptions];
                          const oldVal = updated[idx];
                          updated[idx] = e.target.value;
                          setManualOptions(updated);
                          if (manualCorrectSingle === oldVal) {
                            setManualCorrectSingle(e.target.value);
                          }
                        }}
                        placeholder={`Pilihan ${label}`}
                        className="flex-1 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  ))}
                </div>
              )}

              {manualType === 'pg_kompleks' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase block">
                    Pilihan Jawaban (Centang semua jawaban yang benar)
                  </label>
                  {['A', 'B', 'C', 'D'].map((label, idx) => {
                    const val = manualOptions[idx] || '';
                    const isChecked = manualCorrectMulti.includes(val) && val !== '';
                    return (
                      <div key={label} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={e => {
                            if (e.target.checked) {
                              setManualCorrectMulti(prev => [...prev, val]);
                            } else {
                              setManualCorrectMulti(prev => prev.filter(v => v !== val));
                            }
                          }}
                          className="w-4 h-4 text-emerald-500 rounded cursor-pointer"
                        />
                        <span className="w-5 text-xs font-bold text-slate-400">{label}.</span>
                        <input
                          type="text"
                          value={val}
                          onChange={e => {
                            const updated = [...manualOptions];
                            updated[idx] = e.target.value;
                            setManualOptions(updated);
                          }}
                          placeholder={`Pilihan ${label}`}
                          className="flex-1 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-emerald-500"
                        />
                      </div>
                    );
                  })}
                </div>
              )}

              {manualType === 'benar_salah' && (
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Kunci Jawaban Benar / Salah
                  </label>
                  <div className="flex gap-4">
                    {['Benar', 'Salah'].map(val => (
                      <label
                        key={val}
                        className="flex items-center gap-2 text-xs text-white cursor-pointer"
                      >
                        <input
                          type="radio"
                          name="bsOption"
                          checked={manualCorrectSingle === val}
                          onChange={() => setManualCorrectSingle(val)}
                        />
                        <span>
                          Pernyataan adalah <b>{val}</b>
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {manualType === 'menjodohkan' && (
                <div className="space-y-2.5 p-3.5 rounded-2xl bg-slate-900/70 border border-emerald-500/30">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-emerald-300 uppercase flex items-center gap-1.5">
                      <ArrowLeftRight className="w-3.5 h-3.5" /> Pasangan Soal Menjodohkan
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        setManualMatchingPairs(prev => [...prev, { left: '', right: '' }])
                      }
                      className="text-[11px] font-bold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                    >
                      + Tambah Baris Pasangan
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Isi Lajur Kiri (Pernyataan/Premis) dan Lajur Kanan (Pasangan Jawaban yang
                    Benar).
                  </p>
                  {manualMatchingPairs.map((pair, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-1.5 items-center">
                      <span className="col-span-1 text-[11px] font-mono text-slate-400 font-bold">
                        {idx + 1}.
                      </span>
                      <input
                        type="text"
                        value={pair.left}
                        onChange={e => {
                          const updated = [...manualMatchingPairs];
                          updated[idx] = { ...updated[idx], left: e.target.value };
                          setManualMatchingPairs(updated);
                        }}
                        placeholder="Lajur Kiri (Pernyataan)"
                        className="col-span-5 px-2.5 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs"
                      />
                      <span className="col-span-1 text-center text-emerald-400 font-bold text-xs">
                        ➔
                      </span>
                      <input
                        type="text"
                        value={pair.right}
                        onChange={e => {
                          const updated = [...manualMatchingPairs];
                          updated[idx] = { ...updated[idx], right: e.target.value };
                          setManualMatchingPairs(updated);
                        }}
                        placeholder="Lajur Kanan (Pasangan)"
                        className="col-span-4 px-2.5 py-1.5 rounded-lg bg-white/5 border border-emerald-500/30 text-emerald-200 text-xs"
                      />
                      <button
                        type="button"
                        disabled={manualMatchingPairs.length <= 2}
                        onClick={() =>
                          setManualMatchingPairs(prev => prev.filter((_, i) => i !== idx))
                        }
                        className="col-span-1 text-slate-400 hover:text-rose-400 disabled:opacity-30 flex justify-center cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {manualType === 'isian_singkat' && (
                <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-amber-500/30 space-y-1.5">
                  <label className="text-xs font-bold text-amber-300 uppercase flex items-center gap-1.5">
                    <TextCursorInput className="w-3.5 h-3.5" /> Kunci Jawaban Isian Singkat{' '}
                    <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={manualCorrectSingle}
                    onChange={e => setManualCorrectSingle(e.target.value)}
                    placeholder="Contoh: Al-Amin / Dapat dipercaya (pisahkan dengan / jika ada alternatif)"
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-amber-500/40 text-white text-xs font-bold"
                  />
                  <p className="text-[10px] text-slate-400">
                    Jawaban siswa akan dinilai otomatis (tidak peka huruf besar/kecil).
                  </p>
                </div>
              )}

              {manualType === 'essay' && (
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Pedoman / Kunci Jawaban Uraian (Essay)
                  </label>
                  <textarea
                    rows={2}
                    value={manualCorrectSingle}
                    onChange={e => setManualCorrectSingle(e.target.value)}
                    placeholder="Tuliskan kata kunci atau pedoman penskoran jawaban uraian..."
                    className="w-full p-3 rounded-xl bg-white/5 border border-white/15 text-white text-xs"
                  />
                </div>
              )}

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Penjelasan / Hikmah KBC
                </label>
                <input
                  type="text"
                  value={manualExplanation}
                  onChange={e => setManualExplanation(e.target.value)}
                  placeholder="Mengapa jawaban ini benar menurut ajaran cinta kasih Islam?"
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                {editingIndex !== null ? 'Simpan Pembaruan Butir' : 'Tambahkan ke Draf Soal'}
              </button>
            </form>
          )}
        </div>

        {/* RIGHT COLUMN: Staged Questions Review & Dispatch Toolbar */}
        <div className="lg:col-span-7 space-y-4">
          {/* Staging Control Header */}
          <div className="glass rounded-3xl p-4 sm:p-5 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
                <h3 className="font-bold text-sm sm:text-base text-white">
                  Daftar Draf Soal ({stagedQuestions.length} Butir)
                </h3>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Periksa butir soal, sesuaikan opsi penyimpanan, lalu cetak atau kirim ke siswa.
              </p>
            </div>

            <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 border border-white/15">
              <input
                type="checkbox"
                id="saveToBankCheckbox"
                checked={saveToBankSoal}
                onChange={e => setSaveToBankSoal(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-500 cursor-pointer"
              />
              <label
                htmlFor="saveToBankCheckbox"
                className="text-xs font-bold text-slate-200 cursor-pointer select-none"
              >
                Simpan ke Bank Soal
              </label>
            </div>
          </div>

          {/* Staged Question Cards List */}
          {stagedQuestions.length === 0 ? (
            <div className="glass rounded-3xl p-10 text-center space-y-3 border border-white/10">
              <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mx-auto text-slate-400">
                <FileQuestion className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-white text-base">Belum Ada Soal di Draf</h4>
              <p className="text-slate-400 text-xs max-w-md mx-auto leading-relaxed">
                Gunakan formulir di sebelah kiri untuk menghasilkan soal otomatis dengan AI (berdasarkan Materi Pokok Per Kelas atau Topik Sendiri) atau menulis soal manual.
              </p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {stagedQuestions.map((q, idx) => (
                <div
                  key={q.id || idx}
                  className="glass rounded-2xl p-4 sm:p-5 border border-white/10 hover:border-emerald-500/40 transition-all shadow-md space-y-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-300 font-bold text-xs flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md bg-cyan-500/15 border border-cyan-500/30 text-[10px] font-bold text-cyan-300 uppercase">
                        {QUESTION_TYPE_LABELS[q.questionType] || q.questionType}
                      </span>
                      <span className="text-[10px] text-slate-300 font-semibold">
                        Kelas {q.classId} &bull; {q.domain} &bull; Bobot {q.scoreWeight} Poin
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => editStagedQuestion(q, idx)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 cursor-pointer transition-colors"
                        title="Edit Butir Ini"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => removeStagedQuestion(idx)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer transition-colors"
                        title="Hapus Butir Ini"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Stimulus TKA */}
                  {q.stimulus && (
                    <div className="p-3 rounded-xl bg-slate-900/70 border border-white/10 text-xs text-slate-300 leading-relaxed italic">
                      <span className="font-bold text-amber-300 not-italic block mb-0.5">
                        Stimulus TKA:
                      </span>
                      {q.stimulus}
                    </div>
                  )}

                  {/* Arabic Khat Naskh */}
                  {q.arabicText && (
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-right">
                      <p className="font-serif text-lg text-emerald-300 leading-loose" dir="rtl">
                        {q.arabicText}
                      </p>
                    </div>
                  )}

                  {/* Question Prompt */}
                  <h4 className="font-bold text-sm text-white leading-snug">{q.question}</h4>

                  {/* Matching Pairs Display for menjodohkan */}
                  {q.questionType === 'menjodohkan' &&
                  q.matchingPairs &&
                  q.matchingPairs.length > 0 ? (
                    <div className="rounded-xl border border-emerald-500/30 overflow-hidden text-xs">
                      <div className="grid grid-cols-2 bg-emerald-500/15 font-bold text-emerald-300 p-2 border-b border-emerald-500/30">
                        <span>Lajur Kiri (Pernyataan)</span>
                        <span>Lajur Kanan (Pasangan Kunci)</span>
                      </div>
                      {q.matchingPairs.map((pair, pi) => (
                        <div
                          key={pi}
                          className="grid grid-cols-2 p-2 border-b border-white/5 last:border-b-0 bg-white/5 text-slate-200 gap-2"
                        >
                          <span>
                            {pi + 1}. {pair.left}
                          </span>
                          <span className="text-emerald-300 font-semibold">➔ {pair.right}</span>
                        </div>
                      ))}
                    </div>
                  ) : q.questionType === 'isian_singkat' || q.questionType === 'essay' ? (
                    <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-200">
                      <span className="font-bold text-emerald-400">
                        Kunci Jawaban ({QUESTION_TYPE_LABELS[q.questionType]}):{' '}
                      </span>
                      {Array.isArray(q.correctAnswer)
                        ? q.correctAnswer.join(', ')
                        : q.correctAnswer}
                    </div>
                  ) : (
                    q.options &&
                    q.options.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        {q.options.map((opt, oi) => {
                          const optLabel = String.fromCharCode(65 + oi);
                          const isCorrect = Array.isArray(q.correctAnswer)
                            ? q.correctAnswer.includes(opt)
                            : q.correctAnswer === opt;
                          return (
                            <div
                              key={oi}
                              className={`p-2 rounded-xl border flex items-center gap-2 ${
                                isCorrect
                                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 font-bold'
                                  : 'bg-white/5 border-white/5 text-slate-300'
                              }`}
                            >
                              <span className="font-mono text-slate-400">{optLabel}.</span>
                              <span className="flex-1">{opt}</span>
                              {isCorrect && (
                                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )
                  )}

                  {/* Explanation */}
                  {q.explanation && (
                    <div className="pt-2 border-t border-white/5 text-[11px] text-slate-400">
                      <span className="font-bold text-emerald-400">Hikmah KBC:</span>{' '}
                      {q.explanation}
                    </div>
                  )}
                </div>
              ))}

              {/* Bottom Quick Action Bar */}
              <div className="glass rounded-2xl p-4 border border-white/10 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-300">
                  Status Simpan:{' '}
                  <span
                    className={
                      saveToBankSoal
                        ? 'text-emerald-400 font-bold'
                        : 'text-amber-400 font-bold'
                    }
                  >
                    {saveToBankSoal
                      ? '✓ Akan Tersimpan ke Bank Soal'
                      : '✕ Tidak Disimpan ke Bank Soal (Langsung ke Siswa)'}
                  </span>
                </div>

                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => setPrintModalOpen(true)}
                    className="px-4 py-2 rounded-xl bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 border border-blue-500/40 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" /> Cetak Soal &amp; Kisi-Kisi
                  </button>

                  {saveToBankSoal && (
                    <button
                      onClick={handleSaveToBankOnly}
                      className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Save className="w-3.5 h-3.5 text-emerald-400" /> Simpan Saja ke Bank Soal
                    </button>
                  )}

                  <button
                    onClick={() => setPublishModalOpen(true)}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-md shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer transition-all"
                  >
                    <Send className="w-3.5 h-3.5" /> Kirim ke Siswa (Terbitkan Kuis)
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* PUBLISH TO STUDENT MODAL */}
      {publishModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="glass-strong rounded-3xl w-full max-w-xl border border-emerald-500/30 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Terbitkan Kuis ke Siswa</h3>
                  <p className="text-[11px] text-slate-400">
                    Kirim {stagedQuestions.length} butir soal agar dapat langsung dikerjakan siswa
                  </p>
                </div>
              </div>
              <button
                onClick={() => setPublishModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Judul Kuis / Paket Asesmen <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={quizTitle}
                  onChange={e => setQuizTitle(e.target.value)}
                  placeholder="Contoh: Asesmen Sumatif PAI Bab 1: Surah Al-Ma'un"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Kelas Sasaran
                  </label>
                  <select
                    value={quizTargetClassId}
                    onChange={e => setQuizTargetClassId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  >
                    <option value="1">Tingkat Kelas 1</option>
                    <option value="2">Tingkat Kelas 2</option>
                    <option value="3">Tingkat Kelas 3</option>
                    <option value="4">Tingkat Kelas 4</option>
                    <option value="5">Tingkat Kelas 5</option>
                    <option value="6">Tingkat Kelas 6</option>
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        Rombel {c.className}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Durasi Pengerjaan (Menit)
                  </label>
                  <input
                    type="number"
                    value={quizDuration}
                    onChange={e => setQuizDuration(Number(e.target.value))}
                    min={5}
                    max={180}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Batas Waktu Pengumpulan (Deadline)
                </label>
                <input
                  type="datetime-local"
                  value={quizDeadline}
                  onChange={e => setQuizDeadline(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs"
                />
              </div>

              <div className="flex items-center gap-2 p-3 rounded-xl bg-white/5 border border-white/10">
                <input
                  type="checkbox"
                  id="randomizeCheck"
                  checked={quizRandomize}
                  onChange={e => setQuizRandomize(e.target.checked)}
                  className="w-4 h-4 text-emerald-500 rounded"
                />
                <label htmlFor="randomizeCheck" className="text-xs text-slate-200 cursor-pointer">
                  Acak urutan soal untuk setiap siswa (Mencegah menyontek)
                </label>
              </div>

              <div
                className={`p-3.5 rounded-2xl border text-xs leading-relaxed ${
                  saveToBankSoal
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                }`}
              >
                <b>Opsi Penyimpanan:</b>{' '}
                {saveToBankSoal ? (
                  <span>
                    Butir soal akan <b>disimpan permanen ke Bank Soal</b> dan sekaligus
                    dipublikasikan sebagai kuis siswa.
                  </span>
                ) : (
                  <span>
                    Butir soal <b>TIDAK akan disimpan ke Bank Soal</b>, melainkan langsung
                    diterbitkan sebagai kuis khusus siswa saja.
                  </span>
                )}
              </div>
            </div>

            <div className="p-4 border-t border-white/10 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setPublishModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmPublishQuiz}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition-all flex items-center gap-1.5"
              >
                <Send className="w-4 h-4" /> Terbitkan ke Siswa Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRINT OFFICIAL MODAL (KISI-KISI, NASKAH SOAL, RUBRIK) */}
      {printModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md overflow-y-auto">
          <div className="bg-white text-black w-full max-w-4xl min-h-[90vh] rounded-2xl shadow-2xl p-6 sm:p-10 my-6 relative print:p-0 print:m-0 print:w-full print:shadow-none print:rounded-none">
            <div className="no-print flex flex-col sm:flex-row items-center justify-between pb-6 mb-6 border-b border-slate-200 gap-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Cetak Format Resmi Kurikulum Merdeka
                </span>
              </div>

              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                <button
                  onClick={() => setPrintViewTab('blueprint')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                    printViewTab === 'blueprint'
                      ? 'bg-white shadow text-black'
                      : 'text-slate-600 hover:text-black'
                  }`}
                >
                  1. Kisi-Kisi Asesmen
                </button>
                <button
                  onClick={() => setPrintViewTab('questions')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                    printViewTab === 'questions'
                      ? 'bg-white shadow text-black'
                      : 'text-slate-600 hover:text-black'
                  }`}
                >
                  2. Naskah Soal Siswa
                </button>
                <button
                  onClick={() => setPrintViewTab('rubric')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                    printViewTab === 'rubric'
                      ? 'bg-white shadow text-black'
                      : 'text-slate-600 hover:text-black'
                  }`}
                >
                  3. Kunci &amp; Pembahasan
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={triggerBrowserPrint}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer transition-colors"
                >
                  <Printer className="w-4 h-4" /> Cetak ke Printer / PDF
                </button>
                <button
                  onClick={() => setPrintModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer transition-colors"
                >
                  Tutup
                </button>
              </div>
            </div>

            {/* PRINT KOP SURAT RESMI */}
            <div className="border-b-[3px] border-double border-black pb-3 mb-6 flex items-center gap-5">
              <img
                src={
                  appSettings.appLogoUrl ||
                  'https://jhlryjdhotxtndavacpd.supabase.co/storage/v1/object/public/logo/logo.png'
                }
                alt="Logo Sekolah"
                className="w-20 h-20 object-contain shrink-0"
                onError={e => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="text-center flex-1">
                <h4 className="text-xs sm:text-sm font-semibold tracking-wider uppercase">
                  PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN
                </h4>
                <h2 className="text-base sm:text-xl font-extrabold uppercase tracking-wide mt-0.5">
                  {activeSchoolName}
                </h2>
                <p className="text-[11px] text-slate-700 mt-1 leading-tight">
                  {appSettings.schoolAddress ||
                    'Jl. Raya Ciketing Udik No. 2, Kec. Bantargebang, Kota Bekasi, Jawa Barat'}
                </p>
                <p className="text-[10px] text-slate-600 mt-0.5 font-mono">
                  Mata Pelajaran: Pendidikan Agama Islam &amp; Budi Pekerti &bull; Kurikulum
                  Merdeka
                </p>
              </div>
            </div>

            {/* TAB 1: KISI-KISI ASESMEN RESMI */}
            {printViewTab === 'blueprint' && (
              <div className="space-y-4 text-xs">
                <div className="text-center my-4">
                  <h3 className="text-base font-extrabold uppercase underline tracking-wide">
                    KISI-KISI ASESMEN SUMATIF / FORMATIF PAI &amp; BUDI PEKERTI
                  </h3>
                  <p className="text-slate-700 mt-0.5 font-medium">
                    Tingkat Kelas: {stagedQuestions[0]?.classId || aiGrade} &bull; Semester:{' '}
                    {stagedQuestions[0]?.semester || aiSemester} &bull; Tahun Ajaran:{' '}
                    {appSettings.academicYear || '2026/2027'}
                  </p>
                </div>

                <table className="w-full border border-black border-collapse text-left">
                  <thead>
                    <tr className="bg-slate-100 border-b border-black font-bold">
                      <th className="p-2 border-r border-black text-center w-8">No</th>
                      <th className="p-2 border-r border-black">Elemen Capaian</th>
                      <th className="p-2 border-r border-black">Indikator Soal &amp; Stimulus</th>
                      <th className="p-2 border-r border-black text-center w-28">Bentuk Soal</th>
                      <th className="p-2 border-r border-black text-center w-12">No. Soal</th>
                      <th className="p-2 text-center w-12">Bobot</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stagedQuestions.map((q, idx) => (
                      <tr key={idx} className="border-b border-black">
                        <td className="p-2 border-r border-black text-center">{idx + 1}</td>
                        <td className="p-2 border-r border-black font-semibold">
                          {q.domain || "Al-Qur'an & Hadis"}
                        </td>
                        <td className="p-2 border-r border-black">
                          {q.stimulus ? (
                            <span className="italic text-slate-700 block mb-1">
                              Stimulus: {q.stimulus.slice(0, 100)}...
                            </span>
                          ) : null}
                          <span>
                            Disajikan stimulus, peserta didik mampu menjawab pertanyaan nalar
                            tentang {q.question.slice(0, 60)}...
                          </span>
                        </td>
                        <td className="p-2 border-r border-black text-center">
                          {QUESTION_TYPE_LABELS[q.questionType] || q.questionType}
                        </td>
                        <td className="p-2 border-r border-black text-center font-bold">
                          {idx + 1}
                        </td>
                        <td className="p-2 text-center font-bold">{q.scoreWeight || 10}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* TAB 2: NASKAH SOAL UJIAN SISWA */}
            {printViewTab === 'questions' && (
              <div className="space-y-5 text-xs">
                <div className="border border-black p-3 rounded flex justify-between">
                  <div>
                    <p>
                      <b>Nama Siswa :</b>{' '}
                      ..............................................................
                    </p>
                    <p className="mt-1">
                      <b>Kelas / Rombel :</b> Kelas {stagedQuestions[0]?.classId || aiGrade} (
                      {activeSchoolName})
                    </p>
                  </div>
                  <div>
                    <p>
                      <b>No. Absen :</b> ................
                    </p>
                    <p className="mt-1">
                      <b>Hari/Tgl :</b> ....................................
                    </p>
                  </div>
                </div>

                <div className="text-center my-3">
                  <h3 className="text-sm font-extrabold uppercase underline">
                    {quizTitle || 'LEMBAR ASESMEN PAI & BUDI PEKERTI'}
                  </h3>
                  <p className="italic text-[11px] text-slate-600 mt-0.5">
                    Petunjuk: Awali dengan Basmalah, bacalah stimulus dengan teliti, dan jawablah
                    dengan jujur.
                  </p>
                </div>

                <div className="space-y-5">
                  {stagedQuestions.map((q, idx) => (
                    <div key={idx} className="space-y-2">
                      <div className="flex items-start gap-2">
                        <span className="font-bold">{idx + 1}.</span>
                        <div className="flex-1 space-y-2">
                          {q.stimulus && (
                            <div className="border border-black/40 p-2.5 bg-slate-50 italic rounded text-justify">
                              <b>Bacalah cerita berikut ini!</b>
                              <p className="mt-0.5">{q.stimulus}</p>
                            </div>
                          )}

                          {q.arabicText && (
                            <div
                              className="text-right p-2 font-serif text-base leading-loose"
                              dir="rtl"
                            >
                              {q.arabicText}
                            </div>
                          )}

                          <p className="font-semibold">{q.question}</p>

                          {q.questionType === 'menjodohkan' &&
                          q.matchingPairs &&
                          q.matchingPairs.length > 0 ? (
                            <table className="w-full border border-black border-collapse text-xs mt-1">
                              <thead>
                                <tr className="bg-slate-100">
                                  <th className="border border-black p-1.5 text-left">
                                    Pernyataan (Lajur A)
                                  </th>
                                  <th className="border border-black p-1.5 text-left">
                                    Pilihan Pasangan (Lajur B)
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                {q.matchingPairs.map((pair, pi) => {
                                  const shiftedRight =
                                    q.matchingPairs![(pi + 1) % q.matchingPairs!.length].right;
                                  return (
                                    <tr key={pi}>
                                      <td className="border border-black p-1.5">
                                        {pi + 1}. {pair.left} ( .... )
                                      </td>
                                      <td className="border border-black p-1.5">
                                        {String.fromCharCode(65 + pi)}. {shiftedRight}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          ) : q.questionType === 'isian_singkat' ? (
                            <p className="pt-1">
                              <b>Jawaban Singkat:</b>{' '}
                              ....................................................................................
                            </p>
                          ) : q.questionType === 'essay' ? (
                            <div className="space-y-2 pt-1">
                              <p>
                                <b>Jawaban Uraian:</b>
                              </p>
                              <div className="border-b border-dotted border-black h-5" />
                              <div className="border-b border-dotted border-black h-5" />
                            </div>
                          ) : (
                            q.options &&
                            q.options.length > 0 && (
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-2 pt-1">
                                {q.options.map((opt, oi) => (
                                  <div key={oi}>
                                    <b>{String.fromCharCode(65 + oi)}.</b> {opt}
                                  </div>
                                ))}
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: KUNCI JAWABAN & PEMBAHASAN */}
            {printViewTab === 'rubric' && (
              <div className="space-y-4 text-xs">
                <div className="text-center my-3">
                  <h3 className="text-sm font-extrabold uppercase underline">
                    KUNCI JAWABAN &amp; PEMBAHASAN ASESMEN (PEGANGAN GURU)
                  </h3>
                  <p className="text-slate-600 mt-0.5">
                    Mata Pelajaran: PAI &amp; Budi Pekerti &bull; Pendekatan Kurikulum Berbasis
                    Cinta (KBC)
                  </p>
                </div>

                <table className="w-full border border-black border-collapse text-left">
                  <thead>
                    <tr className="bg-slate-100 border-b border-black font-bold">
                      <th className="p-2 border-r border-black text-center w-10">No</th>
                      <th className="p-2 border-r border-black w-28">Bentuk</th>
                      <th className="p-2 border-r border-black w-48">Kunci Jawaban</th>
                      <th className="p-2 border-r border-black">Pembahasan Nilai Luhur &amp; KBC</th>
                      <th className="p-2 text-center w-14">Bobot</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stagedQuestions.map((q, idx) => (
                      <tr key={idx} className="border-b border-black">
                        <td className="p-2 border-r border-black text-center font-bold">
                          {idx + 1}
                        </td>
                        <td className="p-2 border-r border-black">
                          {QUESTION_TYPE_LABELS[q.questionType] || q.questionType}
                        </td>
                        <td className="p-2 border-r border-black font-bold">
                          {Array.isArray(q.correctAnswer)
                            ? q.correctAnswer.join('; ')
                            : q.correctAnswer}
                        </td>
                        <td className="p-2 border-r border-black text-slate-700">
                          {q.explanation ||
                            'Jawaban mencerminkan pemahaman nilai budi pekerti dan kasih sayang.'}
                        </td>
                        <td className="p-2 text-center font-bold">{q.scoreWeight || 10}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* DUAL SIGNATURE BLOCK */}
            <div className="mt-12 pt-6 border-t border-black/40 flex justify-between text-xs">
              <div className="text-center w-64">
                <p>Mengetahui,</p>
                <p className="font-bold">Kepala Sekolah</p>
                <div className="h-20" />
                <p className="font-bold underline uppercase">
                  {appSettings.principalName || '........................................'}
                </p>
                <p>NIP. {appSettings.principalNip || '................................'}</p>
              </div>

              <div className="text-center w-64">
                <p>
                  Bekasi,{' '}
                  {new Date().toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </p>
                <p className="font-bold">Guru Pendidikan Agama Islam &amp; BP</p>
                <div className="h-20" />
                <p className="font-bold underline uppercase">
                  {teacherProfile.fullName || '........................................'}
                </p>
                <p>NIP. {teacherProfile.nip || '................................'}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
