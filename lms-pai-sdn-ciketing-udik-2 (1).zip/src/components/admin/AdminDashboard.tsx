import React, { useState } from 'react';
import {
  Users,
  FileQuestion,
  BookText,
  TrendingUp,
  Sparkles,
  NotebookPen,
  CalendarCheck,
  FilePlus,
  BarChart3,
  School,
  ArrowRight,
  Clock,
  CheckCircle2,
  Layers,
  FileSpreadsheet,
  Database,
  Calendar,
  Plus,
  Trash2,
  Edit2,
  AlertTriangle,
  HeartHandshake,
  Cloud,
  RefreshCw,
  UserCheck,
  MessageSquare,
  Award,
  X,
  BrainCircuit,
  Send,
  BookOpen,
  ClipboardCheck,
  Download,
  Target,
  Filter,
  Terminal
} from 'lucide-react';
import { StorageService } from '../../services/storageService';
import { SupabaseService, DEFAULT_SUPABASE_URL } from '../../services/supabaseService';
import {
  analyzeAllStudentsKktp,
  requestAiDeepRemedialAnalysis
} from '../../services/aiRemedialService';
import {
  AcademicCalendarEvent,
  CalendarEventCategory,
  RemedialRecommendation
} from '../../types';
import { SupabaseSqlEditorModal } from '../common/SupabaseSqlEditorModal';

interface AdminDashboardProps {
  onNavigate: (viewId: string) => void;
  showToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const CATEGORY_STYLES: Record<
  CalendarEventCategory,
  { label: string; badge: string; dot: string }
> = {
  agenda: {
    label: 'Agenda Sekolah',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    dot: 'bg-emerald-400'
  },
  libur: {
    label: 'Hari Libur Resmi',
    badge: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
    dot: 'bg-rose-400'
  },
  ujian: {
    label: 'Jadwal Ujian Penting',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    dot: 'bg-amber-400'
  },
  kbc_ibadah: {
    label: 'Pembiasaan KBC & Ibadah',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    dot: 'bg-cyan-400'
  }
};

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate, showToast }) => {
  const [students, setStudents] = useState(() => StorageService.getStudents());
  const [quizzes, setQuizzes] = useState(() => StorageService.getQuizzes());
  const [classes, setClasses] = useState(() => StorageService.getClasses());
  const [journals, setJournals] = useState(() => StorageService.getJournals());
  const [teachingDocs, setTeachingDocs] = useState(() => StorageService.getTeachingDocs());
  const [homeroomTeachers, setHomeroomTeachers] = useState(() => StorageService.getHomeroomTeachers());
  const [forumThreads, setForumThreads] = useState(() => StorageService.getForumThreads());
  const [gamificationList, setGamificationList] = useState(() => StorageService.getAllStudentsGamification());
  const [allScores, setAllScores] = useState(() => StorageService.getScores());

  // Academic Calendar State
  const [calendarEvents, setCalendarEvents] = useState<AcademicCalendarEvent[]>(() =>
    StorageService.getCalendarEvents()
  );
  const [calFilter, setCalFilter] = useState<string>('all');
  const [calModalOpen, setCalModalOpen] = useState(false);
  const [editingCalEvent, setEditingCalEvent] = useState<AcademicCalendarEvent | null>(null);
  const [calTitle, setCalTitle] = useState('');
  const [calDate, setCalDate] = useState(new Date().toISOString().split('T')[0]);
  const [calEndDate, setCalEndDate] = useState('');
  const [calCategory, setCalCategory] = useState<CalendarEventCategory>('agenda');
  const [calTargetClass, setCalTargetClass] = useState('');
  const [calDescription, setCalDescription] = useState('');

  // Supabase Cloud Sync, SQL Editor & Reset State
  const [isSyncingCloud, setIsSyncingCloud] = useState(false);
  const [isCleaningDemo, setIsCleaningDemo] = useState(false);
  const [showSqlEditorModal, setShowSqlEditorModal] = useState(false);
  const [showResetFreshModal, setShowResetFreshModal] = useState(false);
  const [isResettingFreshData, setIsResettingFreshData] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() =>
    SupabaseService.getLastSyncTime()
  );

  // AI KKTP Remedial & Special Assignment State
  const [kktpThreshold, setKktpThreshold] = useState<number>(75);
  const [remedialClassFilter, setRemedialClassFilter] = useState<string>('all');
  const [remedialCategoryFilter, setRemedialCategoryFilter] = useState<string>('all');
  const [remedialRefreshTick, setRemedialRefreshTick] = useState<number>(0);
  const [selectedRemedialStudent, setSelectedRemedialStudent] =
    useState<RemedialRecommendation | null>(null);
  const [isAnalyzingStudentId, setIsAnalyzingStudentId] = useState<string | null>(null);
  const [isBatchAnalyzing, setIsBatchAnalyzing] = useState<boolean>(false);

  const notify = (msg: string, type: 'success' | 'error' | 'info' = 'success') => {
    if (showToast) showToast(msg, type);
  };

  const refreshDashboardData = () => {
    setStudents(StorageService.getStudents());
    setQuizzes(StorageService.getQuizzes());
    setClasses(StorageService.getClasses());
    setJournals(StorageService.getJournals());
    setTeachingDocs(StorageService.getTeachingDocs());
    setHomeroomTeachers(StorageService.getHomeroomTeachers());
    setForumThreads(StorageService.getForumThreads());
    setGamificationList(StorageService.getAllStudentsGamification());
    setCalendarEvents(StorageService.getCalendarEvents());
    setAllScores(StorageService.getScores());
    setRemedialRefreshTick(t => t + 1);
  };

  // Automatic KKTP Analysis across all classes & students
  const kktpAnalysis = React.useMemo(
    () => analyzeAllStudentsKktp(kktpThreshold),
    [kktpThreshold, remedialRefreshTick]
  );

  const filteredRemedialList = kktpAnalysis.recommendations.filter(rec => {
    const matchClass = remedialClassFilter === 'all' || rec.classId === remedialClassFilter;
    const matchCat =
      remedialCategoryFilter === 'all' ||
      (remedialCategoryFilter === 'bimbingan' && rec.kktpCategory === 'Perlu Bimbingan (0-60)') ||
      (remedialCategoryFilter === 'cukup' &&
        rec.kktpCategory === 'Cukup / Mendekati KKTP (61-74)') ||
      (remedialCategoryFilter === 'belum_ujian' &&
        rec.kktpCategory === 'Belum Mengikuti Evaluasi') ||
      (remedialCategoryFilter === 'assigned' && rec.status === 'assigned');
    return matchClass && matchCat;
  });

  const handleAnalyzeSingleStudentAi = async (rec: RemedialRecommendation) => {
    setIsAnalyzingStudentId(rec.studentId);
    try {
      const settings = StorageService.getAppSettings();
      const updated = await requestAiDeepRemedialAnalysis(
        rec,
        settings.schoolName || 'SDN Ciketing Udik 2 Bantargebang'
      );
      setRemedialRefreshTick(t => t + 1);
      if (selectedRemedialStudent && selectedRemedialStudent.studentId === rec.studentId) {
        setSelectedRemedialStudent(updated);
      }
      notify(
        `Rekomendasi Materi Remedial & Penugasan Khusus AI untuk ${rec.studentName} berhasil diperbarui!`,
        'success'
      );
    } catch (err) {
      notify('Analisis diagnostik KBC selesai diperbarui.', 'info');
    } finally {
      setIsAnalyzingStudentId(null);
    }
  };

  const handleBatchAnalyzeAi = async () => {
    if (filteredRemedialList.length === 0) return;
    setIsBatchAnalyzing(true);
    try {
      const settings = StorageService.getAppSettings();
      const schoolName = settings.schoolName || 'SDN Ciketing Udik 2 Bantargebang';
      // Process up to 6 priority students in batch for snappy UX
      const targets = filteredRemedialList.slice(0, 6);
      for (const rec of targets) {
        await requestAiDeepRemedialAnalysis(rec, schoolName);
      }
      setRemedialRefreshTick(t => t + 1);
      notify(
        `Berhasil menganalisis & menyusun ulang paket remedial AI untuk ${targets.length} siswa prioritas di bawah KKTP!`,
        'success'
      );
    } catch (err) {
      notify('Analisis massal KKTP selesai.', 'info');
    } finally {
      setIsBatchAnalyzing(false);
    }
  };

  const handleAssignRemedial = (rec: RemedialRecommendation) => {
    const profile = StorageService.getTeacherProfile();
    const { updatedPlan } = StorageService.assignRemedialToStudent(
      rec,
      profile.fullName || 'Guru PAI'
    );
    setRemedialRefreshTick(t => t + 1);
    if (selectedRemedialStudent && selectedRemedialStudent.studentId === rec.studentId) {
      setSelectedRemedialStudent(updatedPlan);
    }
    notify(
      `Materi Remedial "${rec.remedialMaterial.title}" & Penugasan Khusus telah dikirim ke Kelas ${rec.className} untuk ${rec.studentName} (Tersinkron ke IndexedDB & Supabase)!`,
      'success'
    );
  };

  const handleAssignAllFilteredRemedial = () => {
    const unassigned = filteredRemedialList.filter(r => r.status !== 'assigned');
    if (unassigned.length === 0) {
      notify('Seluruh siswa pada filter ini sudah ditugaskan paket remedialnya.', 'info');
      return;
    }
    const profile = StorageService.getTeacherProfile();
    unassigned.forEach(rec => {
      StorageService.assignRemedialToStudent(rec, profile.fullName || 'Guru PAI');
    });
    setRemedialRefreshTick(t => t + 1);
    notify(
      `Berhasil menugaskan Materi Remedial & Penugasan Khusus kepada ${unassigned.length} siswa yang belum mencapai KKTP!`,
      'success'
    );
  };

  const handleDownloadRemedialSheet = (rec: RemedialRecommendation) => {
    const profile = StorageService.getTeacherProfile();
    const settings = StorageService.getAppSettings();
    const content = [
      `====================================================================`,
      `LEMBAR MATERI REMEDIAL & PENUGASAN KHUSUS BERBASIS AI (KKTP)`,
      `${(settings.schoolName || 'SDN CIKETING UDIK 2 BANTARGEBANG').toUpperCase()}`,
      `Pedoman: Keputusan Kepala BKPDM Nomor 020 Tahun 2026 (Pendekatan KBC)`,
      `====================================================================`,
      ``,
      `IDENTITAS PESERTA DIDIK`,
      `Nama Siswa        : ${rec.studentName}`,
      `NIS               : ${rec.nis}`,
      `Kelas / Fase      : Kelas ${rec.className} (Tingkat ${rec.gradeLevel} SD)`,
      `Nilai Saat Ini    : ${rec.currentAvg} (Standar KKTP: ${rec.kktpThreshold} | Selisih: -${rec.gapPoints} Poin)`,
      `Kategori KKTP     : ${rec.kktpCategory}`,
      `Elemen PAI Fokus  : ${rec.primaryDomain}`,
      ``,
      `--------------------------------------------------------------------`,
      `A. ANALISIS DIAGNOSTIK OTOMATIS (PENDEKATAN KBC)`,
      `--------------------------------------------------------------------`,
      rec.diagnosticSummary,
      ``,
      `--------------------------------------------------------------------`,
      `B. MATERI REMEDIAL TERARAH`,
      `--------------------------------------------------------------------`,
      `Judul Materi : ${rec.remedialMaterial.title}`,
      `Ringkasan    :`,
      rec.remedialMaterial.summary,
      ``,
      `Poin Inti Pemahaman & Pengamalan:`,
      ...rec.remedialMaterial.keyPoints.map((pt, i) => `${i + 1}. ${pt}`),
      ``,
      `Dalil Ayat Al-Qur'an / Hadis Pilihan:`,
      `${rec.remedialMaterial.arabicVerse}`,
      `Artinya: "${rec.remedialMaterial.arabicTranslation}"`,
      ``,
      `Refleksi Kalbu KBC:`,
      `"${rec.remedialMaterial.kbcReflection}"`,
      ``,
      `--------------------------------------------------------------------`,
      `C. PENUGASAN KHUSUS SISWA (${rec.specialAssignment.type.toUpperCase()})`,
      `--------------------------------------------------------------------`,
      `Judul Penugasan   : ${rec.specialAssignment.title}`,
      `Target Kompetensi : ${rec.specialAssignment.targetCompetency}`,
      `Batas Waktu       : ${rec.specialAssignment.deadlineDays} Hari`,
      ``,
      `Langkah Kerja Siswa:`,
      ...rec.specialAssignment.instructions.map((ins, i) => `${i + 1}. ${ins}`),
      ``,
      `Panduan Pendampingan Orang Tua di Rumah:`,
      rec.specialAssignment.parentGuidance,
      ``,
      `Rubrik Evaluasi Ketuntasan KKTP:`,
      rec.specialAssignment.evaluationRubric,
      ``,
      `--------------------------------------------------------------------`,
      `Disusun oleh Guru PAI : ${profile.fullName} (NIP. ${profile.nip})`,
      `Mengetahui Kepsek     : ${settings.principalName} (NIP. ${settings.principalNip})`,
      `====================================================================`
    ].join('\n');

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Lembar_Remedial_KKTP_${rec.studentName.replace(/\s+/g, '_')}_Kelas_${rec.className}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    notify(`Lembar Remedial & Penugasan Khusus ${rec.studentName} berhasil diunduh!`, 'success');
  };

  // Class Recaps & Analytics Calculation (100% Real Data — tanpa angka demo/fallback palsu)
  const classAnalytics = classes.map(c => {
    const recap = StorageService.getClassRecap(c.id);
    const totalStudents = recap.students.length;
    const gradedStudents = recap.students.filter(s => s.quizCount > 0);
    const avgScore = gradedStudents.length > 0 ? recap.stats.avgClass : 0;
    const tuntasCount = gradedStudents.filter(s => s.avg >= kktpThreshold).length;
    const ketuntasanPct =
      gradedStudents.length > 0
        ? Math.min(100, Math.round((tuntasCount / gradedStudents.length) * 100))
        : 0;

    return {
      id: c.id,
      className: c.className,
      homeroom: c.homeroom,
      studentCount: totalStudents,
      gradedCount: gradedStudents.length,
      avgScore,
      ketuntasanPct,
      students: recap.students
    };
  });

  const classesWithGrades = classAnalytics.filter(c => c.gradedCount > 0);

  const avgOverall = classesWithGrades.length
    ? Math.round(classesWithGrades.reduce((a, b) => a + b.avgScore, 0) / classesWithGrades.length)
    : 0;

  const avgKetuntasanOverall = classesWithGrades.length
    ? Math.round(
        classesWithGrades.reduce((a, b) => a + b.ketuntasanPct, 0) / classesWithGrades.length
      )
    : 0;

  // Hitung Tren Ketuntasan Bulanan berdasarkan data nilai nyata di StorageService.getScores()
  const monthlyTrend = [
    { label: 'Jul', monthNum: 7 },
    { label: 'Agu', monthNum: 8 },
    { label: 'Sep', monthNum: 9 },
    { label: 'Okt', monthNum: 10 }
  ].map(m => {
    const monthScores = allScores.filter(sc => {
      if (!sc.createdAt) return false;
      const d = new Date(sc.createdAt);
      return !isNaN(d.getTime()) && d.getMonth() + 1 === m.monthNum;
    });
    if (monthScores.length === 0) {
      return { m: m.label, v: 0 };
    }
    const passed = monthScores.filter(sc => sc.percentage >= kktpThreshold).length;
    return {
      m: m.label,
      v: Math.min(100, Math.round((passed / monthScores.length) * 100))
    };
  });

  // Identify students needing special KBC mentoring (HANYA siswa yang sudah memiliki nilai di bawah KKTP)
  const studentsNeedingMentoring: Array<{
    id: string;
    nis: string;
    name: string;
    className: string;
    avg: number;
    quizCount: number;
    recommendation: string;
  }> = [];

  classAnalytics.forEach(cls => {
    cls.students.forEach(st => {
      if (st.quizCount > 0 && st.avg < kktpThreshold) {
        studentsNeedingMentoring.push({
          id: st.id,
          nis: st.nis,
          name: st.name,
          className: cls.className,
          avg: st.avg,
          quizCount: st.quizCount,
          recommendation:
            'Remedial terbimbing pendekatan kasih sayang (KBC) & tutor sebaya'
        });
      }
    });
  });

  const handleSyncSupabaseNow = async () => {
    setIsSyncingCloud(true);
    try {
      await StorageService.flushOfflineQueue();
      const res = await StorageService.syncAllToSupabase();
      await StorageService.pullAllFromSupabase();
      refreshDashboardData();
      setLastSyncTime(SupabaseService.getLastSyncTime());
      notify(res.message, 'success');
    } catch (e) {
      notify('Data tersinkron pada penyimpanan hibrida Supabase', 'info');
    } finally {
      setIsSyncingCloud(false);
    }
  };

  const handleCleanDemoDataNow = async () => {
    setIsCleaningDemo(true);
    try {
      const res = await StorageService.cleanDemoDataKeepRealData();
      refreshDashboardData();
      setLastSyncTime(SupabaseService.getLastSyncTime());
      notify(res.message, 'success');
    } finally {
      setIsCleaningDemo(false);
    }
  };

  const handleConfirmResetFreshData = async () => {
    setIsResettingFreshData(true);
    try {
      const res = await StorageService.resetToFreshEmptyData();
      setShowResetFreshModal(false);
      notify(res.message, 'success');
      setTimeout(() => window.location.reload(), 800);
    } finally {
      setIsResettingFreshData(false);
    }
  };

  // Calendar CRUD handlers
  const openAddCalendarModal = () => {
    setEditingCalEvent(null);
    setCalTitle('');
    setCalDate(new Date().toISOString().split('T')[0]);
    setCalEndDate('');
    setCalCategory('agenda');
    setCalTargetClass('');
    setCalDescription('');
    setCalModalOpen(true);
  };

  const openEditCalendarModal = (ev: AcademicCalendarEvent) => {
    setEditingCalEvent(ev);
    setCalTitle(ev.title);
    setCalDate(ev.date);
    setCalEndDate(ev.endDate || '');
    setCalCategory(ev.category);
    setCalTargetClass(ev.targetClass || '');
    setCalDescription(ev.description);
    setCalModalOpen(true);
  };

  const handleSaveCalendarEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!calTitle.trim() || !calDate) {
      notify('Judul agenda dan tanggal wajib diisi!', 'error');
      return;
    }

    StorageService.saveCalendarEvent({
      id: editingCalEvent?.id,
      title: calTitle.trim(),
      date: calDate,
      endDate: calEndDate || undefined,
      category: calCategory,
      targetClass: calTargetClass,
      description: calDescription.trim() || 'Agenda resmi pembelajaran PAI & Budi Pekerti.',
      createdBy: 'Guru PAI'
    });

    setCalendarEvents(StorageService.getCalendarEvents());
    setCalModalOpen(false);
    notify(
      editingCalEvent
        ? 'Agenda Kalender Akademik diperbarui & tersinkron ke Beranda Siswa!'
        : 'Agenda Kalender Akademik ditambahkan & langsung tampil di Beranda Siswa!'
    );
  };

  const handleDeleteCalendarEvent = (id: string) => {
    StorageService.deleteCalendarEvent(id);
    setCalendarEvents(StorageService.getCalendarEvents());
    notify('Agenda kalender akademik dihapus', 'info');
  };

  const filteredCalendarEvents = calendarEvents.filter(
    ev => calFilter === 'all' || ev.category === calFilter
  );

  const stats = [
    {
      label: 'Siswa Terdaftar',
      value: students.length,
      unit: `${classes.length} Rombel Aktif`,
      icon: Users,
      color: 'from-emerald-500 to-teal-500'
    },
    {
      label: 'Kuis & Evaluasi',
      value: quizzes.length,
      unit: `${journals.length} Jurnal Mengajar`,
      icon: FileQuestion,
      color: 'from-cyan-500 to-blue-500'
    },
    {
      label: 'Rata-rata Kelas',
      value: `${avgOverall}`,
      unit: `${avgKetuntasanOverall}% Tuntas KKTP`,
      icon: TrendingUp,
      color: 'from-amber-500 to-orange-500'
    },
    {
      label: 'Forum Diskusi PAI',
      value: `${forumThreads.length} Topik`,
      unit: `${classes.length} Kelas Aktif`,
      icon: MessageSquare,
      color: 'from-indigo-500 to-purple-500'
    }
  ];

  const quickActions = [
    {
      id: 'e-kinerja',
      label: 'E-Kinerja Harian',
      desc: 'Identitas otomatis, RKH, Rencana Aksi, Tindak Lanjut & Multi-Foto',
      icon: CalendarCheck,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
    },
    {
      id: 'discussion-forum',
      label: 'Forum Diskusi Kelas',
      desc: 'Moderasi tanya jawab siswa per kelas & verifikasi jawaban PAI',
      icon: MessageSquare,
      color: 'text-pink-400 bg-pink-500/10 border-pink-500/30'
    },
    {
      id: 'create-questions',
      label: 'Buat Soal (AI)',
      desc: 'Generator soal model TKA stimulus & opsi simpan',
      icon: Sparkles,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/30'
    },
    {
      id: 'questions',
      label: 'Bank Soal PAI',
      desc: 'Repositori butir soal tersimpan & cetak kisi-kisi',
      icon: Database,
      color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30'
    },
    {
      id: 'journals',
      label: 'Jurnal Mengajar AI',
      desc: 'Catat kegiatan belajar, Focus Reader & cetak tab baru',
      icon: NotebookPen,
      color: 'text-teal-400 bg-teal-500/10 border-teal-500/30'
    },
    {
      id: 'attendance',
      label: 'Absensi Siswa',
      desc: 'Input kehadiran kelas & rekap bulan',
      icon: CalendarCheck,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/30'
    },
    {
      id: 'materials',
      label: 'Bahan Materi (Focus Reader)',
      desc: 'Ringkasan teks, khat Arab & mode baca layar penuh',
      icon: BookText,
      color: 'text-rose-400 bg-rose-500/10 border-rose-500/30'
    },
    {
      id: 'reports',
      label: 'Rekap Nilai Siswa',
      desc: 'Lihat daftar nilai & cetak raport resmi',
      icon: BarChart3,
      color: 'text-violet-400 bg-violet-500/10 border-violet-500/30'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner + Supabase Cloud Status Bar */}
      <div className="relative overflow-hidden rounded-3xl glass-strong border border-emerald-500/25 p-5 sm:p-7 shadow-xl space-y-4">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" /> Portal Pendidik PAI &amp; Budi Pekerti
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-bold">
                ⚖️ Regulasi: Kep. Kepala BKPDM No. 020 Th 2026 (Pendekatan KBC)
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
              Assalamu'alaikum, Selamat Datang di LMS PAI SDN Ciketing Udik 2
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              Kelola pembelajaran PAI &amp; Budi Pekerti, analitik ketuntasan kelas berbasis Supabase, kalender akademik, dan forum diskusi terarah.
            </p>
          </div>
          <div className="flex flex-wrap gap-2.5 shrink-0">
            <button
              onClick={() => onNavigate('e-kinerja')}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer transition-all"
            >
              <ClipboardCheck className="w-4 h-4 text-amber-200" /> E-Kinerja Harian
            </button>
            <button
              onClick={() => onNavigate('discussion-forum')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs border border-white/10 flex items-center gap-2 cursor-pointer transition-all"
            >
              <MessageSquare className="w-4 h-4 text-pink-400" /> Forum Diskusi
            </button>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {stats.map((s, idx) => {
          const Icon = s.icon;
          return (
            <div
              key={idx}
              className="glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between hover:border-white/20 transition-all shadow-md"
            >
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  {s.label}
                </span>
                <div
                  className={`w-9 h-9 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center text-white shadow`}
                >
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl font-extrabold font-display text-white tabular-nums">
                  {s.value}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">{s.unit}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* ============================================================================
          DASBOR ANALITIK PERFORMA KELAS, TREN KETUNTASAN & PENDAMPINGAN KHUSUS (SUPABASE)
         ============================================================================ */}
      <div className="glass rounded-3xl p-5 sm:p-6 border border-emerald-500/25 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base sm:text-lg font-bold font-display text-white">
                Dasbor Analitik Pembelajaran PAI &amp; Tren Ketuntasan (Data Supabase)
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Grafik perbandingan nilai rata-rata per kelas, tren ketuntasan KKTP, dan deteksi dini siswa yang memerlukan pendampingan khusus berbasis kasih sayang (KBC).
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="px-3.5 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
          >
            Lihat Matriks Raport Lengkap <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left 7 Cols: Grafik Performa Rata-rata Kelas & Tren Ketuntasan */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-200 uppercase tracking-wider">
                Grafik Performa Rata-Rata Kelas &amp; Ketuntasan Belajar (KKTP ≥ {kktpThreshold})
              </span>
              <div className="flex items-center gap-3 text-[11px]">
                <span className="flex items-center gap-1 text-emerald-300">
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block" /> Nilai Rata-rata
                </span>
                <span className="flex items-center gap-1 text-cyan-300">
                  <span className="w-2.5 h-2.5 rounded-sm bg-cyan-400 inline-block" /> % Ketuntasan
                </span>
              </div>
            </div>

            <div className="space-y-3 bg-slate-900/60 p-4 rounded-2xl border border-white/10">
              {classAnalytics.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  Belum ada data kelas/rombel. Silakan tambahkan kelas pada menu Daftar Kelas.
                </div>
              ) : (
                classAnalytics.map(item => (
                  <div key={item.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">
                        Kelas {item.className}{' '}
                        <span className="text-slate-400 font-normal">
                          ({item.studentCount} Siswa
                          {item.gradedCount === 0 ? ' • Belum ada nilai' : ` • ${item.gradedCount} Dinilai`})
                        </span>
                      </span>
                      <div className="flex items-center gap-3 font-mono text-xs">
                        <span className="text-emerald-300 font-bold">
                          Rata-rata: {item.avgScore}
                        </span>
                        <span className="text-cyan-300 font-bold">
                          Tuntas: {item.ketuntasanPct}%
                        </span>
                      </div>
                    </div>
                    <div className="w-full h-3 rounded-full bg-white/5 overflow-hidden flex gap-0.5 p-0.5">
                      <div
                        className="h-full rounded-l-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                        style={{ width: `${item.avgScore}%` }}
                        title={`Rata-rata Kelas ${item.className}: ${item.avgScore}`}
                      />
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-400 transition-all duration-500"
                        style={{ width: `${item.ketuntasanPct}%` }}
                        title={`Ketuntasan Belajar: ${item.ketuntasanPct}%`}
                      />
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Monthly Mastery Trend Mini Chart */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Tren Ketuntasan Semester Ganjil 2026/2027
                </p>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  {allScores.length === 0
                    ? 'Data nilai evaluasi masih kosong (0%). Grafik akan terisi otomatis saat ada nilai siswa.'
                    : 'Berdasarkan rekapitulasi nilai evaluasi aktual siswa per bulan (Pendekatan KBC)'}
                </p>
              </div>
              <div className="flex items-end gap-3 h-16 shrink-0">
                {monthlyTrend.map((pt, i) => (
                  <div key={i} className="flex flex-col items-center gap-1">
                    <span className="text-[10px] font-mono font-bold text-emerald-300">
                      {pt.v}%
                    </span>
                    <div
                      className="w-7 rounded-t-lg bg-gradient-to-t from-emerald-600 to-teal-400 transition-all duration-500"
                      style={{ height: `${pt.v > 0 ? Math.max(12, Math.round((pt.v / 100) * 42)) : 4}px` }}
                    />
                    <span className="text-[10px] text-slate-400">{pt.m}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right 5 Cols: Daftar Siswa yang Memerlukan Pendampingan Khusus */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-slate-900/60 p-4 rounded-2xl border border-white/10 space-y-3">
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  <HeartHandshake className="w-4 h-4 text-amber-400" /> Daftar Siswa Perlu Pendampingan Khusus (KBC)
                </h4>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                  {studentsNeedingMentoring.length} Siswa
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mb-3">
                Siswa yang telah mengikuti evaluasi dengan nilai di bawah KKTP ({kktpThreshold}) untuk diberikan bimbingan penuh kasih sayang:
              </p>

              {studentsNeedingMentoring.length === 0 ? (
                <div className="p-6 rounded-xl bg-white/5 border border-white/10 text-center space-y-1.5">
                  <CheckCircle2 className="w-7 h-7 text-emerald-400 mx-auto" />
                  <p className="text-xs font-bold text-white">
                    {allScores.length === 0
                      ? 'Belum Ada Data Nilai Evaluasi Siswa'
                      : 'Tidak Ada Siswa di Bawah KKTP'}
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {allScores.length === 0
                      ? 'Data nilai saat ini masih kosong (0 nilai). Daftar ini hanya akan menampilkan siswa apabila sudah ada nilai evaluasi yang berada di bawah KKTP.'
                      : 'Seluruh siswa yang telah mengikuti evaluasi telah mencapai standar ketuntasan KKTP.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1 scrollbar-thin">
                  {studentsNeedingMentoring.slice(0, 5).map(st => (
                    <div
                      key={st.id}
                      className="p-3 rounded-xl bg-white/5 border border-white/10 hover:border-amber-500/40 transition-all space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-xs font-bold text-white">{st.name}</span>
                          <span className="ml-2 px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold">
                            Kelas {st.className}
                          </span>
                        </div>
                        <span className="text-xs font-mono font-bold text-amber-300">
                          Nilai: {st.avg}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-snug">
                        <b className="text-cyan-300">Tindak Lanjut KBC:</b> {st.recommendation}
                      </p>
                      <div className="pt-1 flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            const found = kktpAnalysis.recommendations.find(
                              r => r.studentId === st.id
                            );
                            if (found) setSelectedRemedialStudent(found);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/30 text-amber-200 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all"
                        >
                          <BrainCircuit className="w-3 h-3 text-amber-300" /> Lihat Rekomendasi AI Remedial
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Sumber: Skor &amp; Aktivitas Supabase</span>
              <button
                type="button"
                onClick={() => onNavigate('students')}
                className="text-emerald-400 hover:underline font-bold cursor-pointer"
              >
                Kelola Data Siswa &rarr;
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================================
          ASISTEN AI ANALISIS KETUNTASAN KKTP, MATERI REMEDIAL & PENUGASAN KHUSUS
         ============================================================================ */}
      <div className="glass rounded-3xl p-5 sm:p-6 border border-amber-500/30 shadow-xl space-y-5 relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-56 h-56 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />

        {/* Header & KKTP Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-white/10 pb-4 relative z-10">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="p-2 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-slate-950 shadow-lg shadow-amber-500/20">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <h3 className="text-base sm:text-lg font-bold font-display text-white">
                Asisten AI Analisis Ketuntasan KKTP, Materi Remedial &amp; Penugasan Khusus
              </h3>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-[10px] font-bold uppercase tracking-wider">
                Otomatis &bull; Pendekatan KBC
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Menganalisis otomatis hasil nilai evaluasi siswa terhadap standar Kriteria Ketercapaian Tujuan Pembelajaran (KKTP) &amp; menyarankan materi suplemen remedial serta penugasan khusus berbasis AI (Kep. Kepala BKPDM No. 020 Tahun 2026).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/30">
              <Target className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[11px] font-bold text-slate-300">Standar KKTP:</span>
              <select
                value={kktpThreshold}
                onChange={e => setKktpThreshold(Number(e.target.value))}
                className="bg-transparent text-xs font-extrabold text-amber-300 focus:outline-none cursor-pointer"
              >
                <option value={70} className="bg-slate-900 text-white">70 (Minimum)</option>
                <option value={75} className="bg-slate-900 text-white">75 (Standar SD)</option>
                <option value={78} className="bg-slate-900 text-white">78 (Optimal KBC)</option>
                <option value={80} className="bg-slate-900 text-white">80 (Unggulan)</option>
              </select>
            </div>

            <button
              type="button"
              onClick={handleBatchAnalyzeAi}
              disabled={isBatchAnalyzing || filteredRemedialList.length === 0}
              className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className={`w-3.5 h-3.5 text-amber-300 ${isBatchAnalyzing ? 'animate-spin' : ''}`} />
              {isBatchAnalyzing ? 'Menganalisis dengan AI...' : 'Analisis Ulang AI Massal'}
            </button>

            <button
              type="button"
              onClick={handleAssignAllFilteredRemedial}
              disabled={filteredRemedialList.length === 0}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" /> Tugaskan Semua Paket Remedial
            </button>
          </div>
        </div>

        {/* 4 Automatic Diagnostic Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 relative z-10">
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-emerald-500/25 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase">Siswa Tuntas KKTP (&ge;{kktpThreshold})</p>
              <p className="text-2xl font-extrabold font-display text-emerald-400 mt-0.5">
                {kktpAnalysis.passedCount}{' '}
                <span className="text-xs font-normal text-slate-400">
                  / {kktpAnalysis.totalStudents} Siswa
                </span>
              </p>
              <p className="text-[11px] text-emerald-300/90 mt-1">
                Ketuntasan Aktual:{' '}
                <b>
                  {Math.round(
                    (kktpAnalysis.passedCount / Math.max(1, kktpAnalysis.totalStudents)) * 100
                  )}
                  %
                </b>
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-rose-500/25 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase">Perlu Remedial (&lt;{kktpThreshold})</p>
              <p className="text-2xl font-extrabold font-display text-rose-400 mt-0.5">
                {kktpAnalysis.recommendations.length}{' '}
                <span className="text-xs font-normal text-slate-400">Siswa</span>
              </p>
              <p className="text-[11px] text-rose-300/90 mt-1">
                {kktpAnalysis.belowKktpCount} nilai &lt;{kktpThreshold} &bull; {kktpAnalysis.noQuizCount} belum kuis
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-amber-500/25 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase">Rata-rata Defisit KKTP</p>
              <p className="text-2xl font-extrabold font-display text-amber-300 mt-0.5">
                -{kktpAnalysis.avgGap}{' '}
                <span className="text-xs font-normal text-slate-400">Poin</span>
              </p>
              <p className="text-[11px] text-amber-200/90 mt-1 truncate max-w-[180px]">
                Fokus:{' '}
                <b>
                  {Object.entries(kktpAnalysis.domainBreakdown).sort((a, b) => b[1] - a[1])[0]?.[0] ||
                    'Al-Qur\'an & Hadis'}
                </b>
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-300">
              <Target className="w-5 h-5" />
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-cyan-500/25 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase">Status Intervensi Remedial</p>
              <p className="text-2xl font-extrabold font-display text-cyan-300 mt-0.5">
                {kktpAnalysis.assignedCount}{' '}
                <span className="text-xs font-normal text-slate-400">
                  / {kktpAnalysis.recommendations.length} Ditugaskan
                </span>
              </p>
              <p className="text-[11px] text-cyan-200/90 mt-1">
                Tersimpan di Modul Materi &amp; Supabase
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-300">
              <ClipboardCheck className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/70 border border-white/10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mr-1">
              <Filter className="w-3.5 h-3.5 text-amber-400" /> Filter Diagnosis:
            </span>

            <select
              value={remedialClassFilter}
              onChange={e => setRemedialClassFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-950 border border-white/15 text-xs font-bold text-white cursor-pointer"
            >
              <option value="all">Semua Kelas (1A - 6A)</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>
                  Kelas {c.className} ({c.homeroom})
                </option>
              ))}
            </select>

            <select
              value={remedialCategoryFilter}
              onChange={e => setRemedialCategoryFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-950 border border-white/15 text-xs font-bold text-white cursor-pointer"
            >
              <option value="all">Semua Kategori Belum Tuntas ({kktpAnalysis.recommendations.length})</option>
              <option value="bimbingan">Perlu Bimbingan Intensif (Nilai 0 - 60)</option>
              <option value="cukup">Cukup / Mendekati KKTP (Nilai 61 - {kktpThreshold - 1})</option>
              <option value="belum_ujian">Belum Mengikuti Evaluasi Kuis</option>
              <option value="assigned">Sudah Ditugaskan Paket Remedial</option>
            </select>
          </div>

          <span className="text-[11px] text-slate-400">
            Menampilkan <b className="text-white">{filteredRemedialList.length}</b> rekomendasi paket remedial AI
          </span>
        </div>

        {/* List of Student AI Remedial & Special Assignment Recommendations */}
        {filteredRemedialList.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900/40 border border-white/10 text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <p className="text-sm font-bold text-white">
              Alhamdulillah! Tidak ada siswa pada filter ini yang berada di bawah standar KKTP ({kktpThreshold}).
            </p>
            <p className="text-xs text-slate-400">
              Ubah filter kelas/kategori atau sesuaikan ambang KKTP di atas untuk melihat rekomendasi penguatan lainnya.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {filteredRemedialList.map(rec => {
              const isAssigned = rec.status === 'assigned';
              const isAnalyzingThis = isAnalyzingStudentId === rec.studentId;
              const badgeStyle =
                rec.kktpCategory === 'Perlu Bimbingan (0-60)'
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                  : rec.kktpCategory === 'Belum Mengikuti Evaluasi'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30';

              return (
                <div
                  key={rec.id}
                  className="p-4 sm:p-5 rounded-2xl bg-slate-900/75 border border-white/10 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-3">
                    {/* Top Row: Student Info & Score vs KKTP */}
                    <div className="flex flex-wrap items-start justify-between gap-2 border-b border-white/10 pb-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h4 className="text-sm font-bold text-white">{rec.studentName}</h4>
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                            Kelas {rec.className}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${badgeStyle}`}>
                            {rec.kktpCategory}
                          </span>
                          {isAssigned && (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-500/25 border border-emerald-400/40 text-emerald-200 text-[10px] font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> Remedial Aktif
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          NIS: {rec.nis} &bull; Elemen Prioritas:{' '}
                          <b className="text-amber-300">{rec.primaryDomain}</b>
                        </p>
                      </div>

                      <div className="text-right">
                        <div className="flex items-center gap-1.5 justify-end">
                          <span className="text-xs text-slate-400">Nilai:</span>
                          <span className="text-base font-extrabold font-mono text-rose-400">
                            {rec.currentAvg}
                          </span>
                          <span className="text-xs text-slate-500">/ KKTP {rec.kktpThreshold}</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-amber-300">
                          Defisit -{rec.gapPoints} Poin dari KKTP
                        </span>
                      </div>
                    </div>

                    {/* Weak Quizzes Pills */}
                    {rec.weakQuizzes.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">
                          Evaluasi Belum Tuntas:
                        </span>
                        {rec.weakQuizzes.map((wq, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded-lg bg-white/5 border border-white/10 text-[10px] text-slate-200"
                          >
                            {wq.quizTitle}:{' '}
                            <b className="text-amber-300">
                              {wq.score !== null ? `${wq.score}` : 'Belum Ujian'}
                            </b>
                          </span>
                        ))}
                      </div>
                    )}

                    {/* AI Diagnostic Summary */}
                    <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-slate-200 leading-relaxed">
                      <span className="font-bold text-amber-300 flex items-center gap-1 mb-1">
                        <Sparkles className="w-3.5 h-3.5" /> Analisis Diagnostik AI (Pendekatan KBC):
                      </span>
                      {rec.diagnosticSummary}
                    </div>

                    {/* Two Columns: Materi Remedial & Penugasan Khusus */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1">
                            <BookOpen className="w-3.5 h-3.5" /> Rekomendasi Materi Remedial
                          </span>
                        </div>
                        <p className="text-xs font-bold text-white leading-snug">
                          {rec.remedialMaterial.title}
                        </p>
                        <p className="text-[11px] text-slate-300 line-clamp-2">
                          {rec.remedialMaterial.summary}
                        </p>
                        <p
                          className="text-xs font-arabic text-emerald-300 text-right pt-1 truncate"
                          dir="rtl"
                        >
                          {rec.remedialMaterial.arabicVerse}
                        </p>
                      </div>

                      <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1">
                            <ClipboardCheck className="w-3.5 h-3.5" /> Penugasan Khusus AI
                          </span>
                          <span className="text-[10px] font-bold text-amber-300">
                            {rec.specialAssignment.deadlineDays} Hari
                          </span>
                        </div>
                        <p className="text-xs font-bold text-white leading-snug">
                          {rec.specialAssignment.title}
                        </p>
                        <p className="text-[10px] text-cyan-200/90 font-semibold">
                          Tipe: {rec.specialAssignment.type}
                        </p>
                        <ul className="text-[11px] text-slate-300 list-disc list-inside space-y-0.5 line-clamp-2">
                          {rec.specialAssignment.instructions.slice(0, 2).map((ins, i) => (
                            <li key={i} className="truncate">
                              {ins}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  {/* Card Footer Action Buttons */}
                  <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedRemedialStudent(rec)}
                        className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                      >
                        <BookOpen className="w-3.5 h-3.5 text-cyan-300" /> Detail Lengkap
                      </button>

                      <button
                        type="button"
                        onClick={() => handleAnalyzeSingleStudentAi(rec)}
                        disabled={isAnalyzingThis}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/30 text-amber-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all disabled:opacity-50"
                      >
                        <RefreshCw
                          className={`w-3.5 h-3.5 text-amber-300 ${
                            isAnalyzingThis ? 'animate-spin' : ''
                          }`}
                        />
                        {isAnalyzingThis ? 'Menganalisis...' : 'Generate Ulang AI'}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownloadRemedialSheet(rec)}
                        className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 cursor-pointer"
                        title="Unduh Lembar Kerja Remedial & Penugasan Khusus"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleAssignRemedial(rec)}
                      className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all ${
                        isAssigned
                          ? 'bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30'
                          : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-md shadow-emerald-500/20'
                      }`}
                    >
                      <Send className="w-3.5 h-3.5" />
                      {isAssigned ? 'Kirim Ulang ke Kelas' : 'Tugaskan Materi & Remedial'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ============================================================================
          KALENDER AKADEMIK SEKOLAH & AGENDA PAI (TERLIHAT DI DASHBOARD SISWA)
         ============================================================================ */}
      <div className="glass rounded-3xl p-5 sm:p-6 border border-cyan-500/25 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-cyan-400" />
              <h3 className="text-base sm:text-lg font-bold font-display text-white">
                Kalender Akademik &amp; Jadwal Penting PAI (Sinkron ke Dashboard Siswa)
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Catat agenda sekolah, hari libur resmi, jadwal ujian asesmen, dan kegiatan pembiasaan KBC agar langsung terlihat di Beranda Siswa.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={calFilter}
              onChange={e => setCalFilter(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-xs font-bold text-white cursor-pointer"
            >
              <option value="all">Semua Kategori Agenda</option>
              <option value="agenda">Agenda Sekolah</option>
              <option value="ujian">Jadwal Ujian Penting</option>
              <option value="libur">Hari Libur</option>
              <option value="kbc_ibadah">Pembiasaan KBC &amp; Ibadah</option>
            </select>

            <button
              type="button"
              onClick={openAddCalendarModal}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-500/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" /> + Catat Agenda Kalender
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filteredCalendarEvents.map(ev => {
            const style = CATEGORY_STYLES[ev.category] || CATEGORY_STYLES.agenda;
            return (
              <div
                key={ev.id}
                className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-500/40 transition-all flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${style.badge}`}
                    >
                      {style.label}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openEditCalendarModal(ev)}
                        className="p-1 text-slate-400 hover:text-blue-400 cursor-pointer"
                        title="Edit Agenda"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteCalendarEvent(ev.id)}
                        className="p-1 text-slate-400 hover:text-rose-400 cursor-pointer"
                        title="Hapus Agenda"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h4 className="font-bold text-sm text-white leading-snug">{ev.title}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                    {ev.description}
                  </p>
                </div>

                <div className="pt-2.5 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="font-mono font-bold text-cyan-300">
                    📅 {ev.date}
                    {ev.endDate ? ` s.d. ${ev.endDate}` : ''}
                  </span>
                  <span className="text-slate-400">
                    {ev.targetClass ? `Kelas ${ev.targetClass}` : 'Semua Kelas'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Split Section: Quick Actions & Recent Updates */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Menu Actions (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 font-display">
              <School className="w-4 h-4 text-emerald-400" /> Menu Utama Pembelajaran Guru PAI
            </h3>
            <span className="text-xs text-slate-400">Pilih modul tugas</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {quickActions.map(action => {
              const Icon = action.icon;
              return (
                <button
                  key={action.id}
                  onClick={() => onNavigate(action.id)}
                  className="p-4 rounded-2xl glass hover:bg-white/5 border border-white/10 hover:border-emerald-500/40 text-left transition-all group flex flex-col justify-between gap-3 cursor-pointer shadow-sm"
                >
                  <div className="flex items-center justify-between w-full">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${action.color} group-hover:scale-105 transition-transform`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                      {action.label}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      {action.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Sidebar: Jurnal Mengajar Terakhir & Info */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 font-display">
              <Clock className="w-4 h-4 text-cyan-400" /> Jurnal Mengajar Terbaru
            </h3>
            <button
              onClick={() => onNavigate('journals')}
              className="text-xs font-bold text-cyan-400 hover:underline cursor-pointer"
            >
              Lihat Semua
            </button>
          </div>

          <div className="glass rounded-2xl p-4 border border-white/10 space-y-3">
            {journals.slice(0, 3).map(j => (
              <div
                key={j.id}
                className="p-3.5 rounded-xl bg-white/5 border border-white/5 space-y-2 hover:border-white/10 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-emerald-400">
                    Kelas {j.className}
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">{j.date}</span>
                </div>
                <p className="text-xs font-bold text-white line-clamp-1">{j.topic}</p>
                <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">
                  {j.learningObjective}
                </p>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px]">
                  <span className="text-emerald-300 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Status: {j.status}
                  </span>
                  <span className="text-slate-400">
                    {j.absentStudents.length > 0
                      ? `${j.absentStudents.length} siswa absen`
                      : 'Semua hadir'}
                  </span>
                </div>
              </div>
            ))}

            <button
              onClick={() => onNavigate('journals')}
              className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <NotebookPen className="w-3.5 h-3.5" /> Buka Lembar Jurnal Mengajar
            </button>
          </div>

          {/* Quick Islamic Tip Box */}
          <div className="glass rounded-2xl p-4 border border-amber-500/20 bg-amber-500/5">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-amber-300">
                  Pedoman Kurikulum Berbasis Cinta (KBC):
                </p>
                <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                  "Mengacu Keputusan Kepala BKPDM Nomor 020 Tahun 2026: Menumbuhkan generasi qur'ani yang berakhlak mulia melalui keteladanan ibadah, empati kepada sesama, dan cinta Al-Qur'an."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal Add / Edit Calendar Event */}
      {calModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-lg border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-cyan-400" />
                {editingCalEvent ? 'Edit Agenda Kalender Akademik' : 'Tambah Agenda Kalender Akademik'}
              </h3>
              <button
                type="button"
                onClick={() => setCalModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCalendarEvent} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Nama Agenda / Hari Libur / Jadwal Ujian <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={calTitle}
                  onChange={e => setCalTitle(e.target.value)}
                  placeholder="Contoh: Penilaian Sumatif Akhir Semester Ganjil PAI"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Tanggal Mulai <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="date"
                    value={calDate}
                    onChange={e => setCalDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Tanggal Selesai (Opsional)
                  </label>
                  <input
                    type="date"
                    value={calEndDate}
                    onChange={e => setCalEndDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Kategori Agenda
                  </label>
                  <select
                    value={calCategory}
                    onChange={e => setCalCategory(e.target.value as CalendarEventCategory)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  >
                    <option value="agenda">Agenda Sekolah</option>
                    <option value="ujian">Jadwal Ujian Penting</option>
                    <option value="libur">Hari Libur Resmi</option>
                    <option value="kbc_ibadah">Pembiasaan KBC &amp; Ibadah</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Sasaran Kelas
                  </label>
                  <select
                    value={calTargetClass}
                    onChange={e => setCalTargetClass(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  >
                    <option value="">Semua Tingkat Kelas (1 - 6)</option>
                    <option value="1">Kelas 1</option>
                    <option value="2">Kelas 2</option>
                    <option value="3">Kelas 3</option>
                    <option value="4">Kelas 4</option>
                    <option value="5">Kelas 5</option>
                    <option value="6">Kelas 6</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Keterangan / Pesan untuk Siswa
                </label>
                <textarea
                  rows={3}
                  value={calDescription}
                  onChange={e => setCalDescription(e.target.value)}
                  placeholder="Rincian kegiatan atau persiapan yang perlu dilakukan siswa..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCalModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 cursor-pointer"
                >
                  Simpan &amp; Tampilkan ke Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================================
          MODAL DETAIL & KUSTOMISASI REKOMENDASI REMEDIAL AI & PENUGASAN KHUSUS
         ============================================================================ */}
      {selectedRemedialStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="glass rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col border border-amber-500/30 shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 bg-gradient-to-r from-amber-900/50 via-slate-900 to-emerald-950/60 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-300">
                  <BrainCircuit className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base sm:text-lg font-bold font-display text-white">
                      Paket Remedial &amp; Penugasan Khusus AI: {selectedRemedialStudent.studentName}
                    </h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">
                      Kelas {selectedRemedialStudent.className}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    Nilai Rata-rata: <b className="text-rose-400">{selectedRemedialStudent.currentAvg}</b> &bull; Standar KKTP:{' '}
                    <b className="text-amber-300">{selectedRemedialStudent.kktpThreshold}</b> (Defisit -{selectedRemedialStudent.gapPoints} Poin) &bull; Elemen:{' '}
                    <b className="text-cyan-300">{selectedRemedialStudent.primaryDomain}</b>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRemedialStudent(null)}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-5 scrollbar-thin">
              {/* 1. Diagnostik */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" /> 1. Hasil Analisis Diagnostik AI (Pendekatan KBC)
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Kategori: <b className="text-amber-200">{selectedRemedialStudent.kktpCategory}</b>
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                  {selectedRemedialStudent.diagnosticSummary}
                </p>
              </div>

              {/* 2. Materi Remedial */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/25 space-y-3">
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4" /> 2. Rekomendasi Materi Suplemen Remedial
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold">
                    {selectedRemedialStudent.remedialMaterial.domain}
                  </span>
                </div>

                <h4 className="text-sm sm:text-base font-bold text-white">
                  {selectedRemedialStudent.remedialMaterial.title}
                </h4>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {selectedRemedialStudent.remedialMaterial.summary}
                </p>

                <div className="p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-500/30 space-y-1.5">
                  <p
                    className="text-base sm:text-lg font-arabic text-emerald-200 text-right leading-loose"
                    dir="rtl"
                  >
                    {selectedRemedialStudent.remedialMaterial.arabicVerse}
                  </p>
                  <p className="text-xs text-emerald-300/90 italic">
                    Artinya: &ldquo;{selectedRemedialStudent.remedialMaterial.arabicTranslation}&rdquo;
                  </p>
                </div>

                <div className="space-y-1.5">
                  <p className="text-xs font-bold text-slate-200">Poin Inti Pemahaman Remedial:</p>
                  <ul className="space-y-1">
                    {selectedRemedialStudent.remedialMaterial.keyPoints.map((pt, idx) => (
                      <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                        <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-amber-200 italic">
                  <b className="not-italic text-amber-300">Pesan Kasih Sayang (KBC): </b>
                  &ldquo;{selectedRemedialStudent.remedialMaterial.kbcReflection}&rdquo;
                </div>
              </div>

              {/* 3. Penugasan Khusus */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-cyan-500/25 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                  <span className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                    <ClipboardCheck className="w-4 h-4" /> 3. Penugasan Khusus Terarah (LKPD Remedial)
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 text-[10px] font-bold">
                    {selectedRemedialStudent.specialAssignment.type} &bull; Tenggat{' '}
                    {selectedRemedialStudent.specialAssignment.deadlineDays} Hari
                  </span>
                </div>

                <h4 className="text-sm sm:text-base font-bold text-white">
                  {selectedRemedialStudent.specialAssignment.title}
                </h4>

                <p className="text-xs text-slate-300">
                  <b className="text-cyan-300">Target Kompetensi (BKPDM No. 020/2026):</b>{' '}
                  {selectedRemedialStudent.specialAssignment.targetCompetency}
                </p>

                <div className="space-y-1.5">
                  <p className="text-xs font-bold text-slate-200">Instruksi Langkah Pengerjaan Siswa:</p>
                  <ul className="space-y-1.5">
                    {selectedRemedialStudent.specialAssignment.instructions.map((ins, idx) => (
                      <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                        <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span>{ins}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-300">
                    <p className="font-bold text-amber-300 mb-1">Panduan Pendampingan Orang Tua:</p>
                    {selectedRemedialStudent.specialAssignment.parentGuidance}
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-300">
                    <p className="font-bold text-emerald-300 mb-1">Rubrik Penilaian Ketuntasan:</p>
                    {selectedRemedialStudent.specialAssignment.evaluationRubric}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-5 bg-slate-900/90 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleAnalyzeSingleStudentAi(selectedRemedialStudent)}
                  disabled={isAnalyzingStudentId === selectedRemedialStudent.studentId}
                  className="px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw
                    className={`w-3.5 h-3.5 ${
                      isAnalyzingStudentId === selectedRemedialStudent.studentId ? 'animate-spin' : ''
                    }`}
                  />
                  Generate Variasi Baru dengan AI
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadRemedialSheet(selectedRemedialStudent)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-cyan-300" /> Unduh Lembar Remedial (.txt)
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedRemedialStudent(null)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="button"
                  onClick={() => handleAssignRemedial(selectedRemedialStudent)}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" /> Terbitkan Materi &amp; Tugaskan ke Siswa
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
