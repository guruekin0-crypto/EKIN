import React, { useState, useEffect } from 'react';
import {
  CalendarCheck,
  Calendar,
  CheckCircle,
  FileSpreadsheet,
  Printer,
  Save,
  CheckCheck,
  School
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { ClassItem, Student, AttendanceRecord } from '../../types';
import { StorageService } from '../../services/storageService';

interface AttendanceViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({ showToast }) => {
  const classes = StorageService.getClasses();
  const [activeTab, setActiveTab] = useState<'daily' | 'monthly'>('daily');

  // Daily State
  const [dailyClass, setDailyClass] = useState<string>(classes[0]?.id || '');
  const [dailyDate, setDailyDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [dailyRows, setDailyRows] = useState<
    { studentId: string; nis: string; fullName: string; status: 'Hadir' | 'Sakit' | 'Izin' | 'Alpa'; notes: string }[]
  >([]);

  // Monthly State
  const [monthlyClass, setMonthlyClass] = useState<string>(classes[0]?.id || '');
  const [monthlyMonth, setMonthlyMonth] = useState<string>(new Date().toISOString().substring(0, 7));
  const [monthlyRecap, setMonthlyRecap] = useState<any>(null);

  // Load Daily Attendance
  useEffect(() => {
    if (!dailyClass || !dailyDate) return;
    const students = StorageService.getStudents().filter(s => s.classId === dailyClass);
    const existing = StorageService.getAttendance(dailyClass, dailyDate);
    const existingMap = new Map(existing.map(e => [e.studentId, e]));

    const rows = students.map(s => {
      const rec = existingMap.get(s.id);
      return {
        studentId: s.id,
        nis: s.nis,
        fullName: s.fullName,
        status: (rec?.status || 'Hadir') as 'Hadir' | 'Sakit' | 'Izin' | 'Alpa',
        notes: rec?.notes || ''
      };
    });
    setDailyRows(rows);
  }, [dailyClass, dailyDate]);

  // Load Monthly Recap
  const loadMonthly = () => {
    if (!monthlyClass || !monthlyMonth) return;
    const data = StorageService.getMonthlyAttendance(monthlyClass, monthlyMonth);
    setMonthlyRecap(data);
  };

  useEffect(() => {
    loadMonthly();
  }, [monthlyClass, monthlyMonth]);

  const setAllStatus = (status: 'Hadir' | 'Sakit' | 'Izin' | 'Alpa') => {
    setDailyRows(prev => prev.map(r => ({ ...r, status })));
    showToast(`Semua siswa diatur ke status: ${status}`, 'info');
  };

  const updateRowStatus = (studentId: string, status: 'Hadir' | 'Sakit' | 'Izin' | 'Alpa') => {
    setDailyRows(prev =>
      prev.map(r => (r.studentId === studentId ? { ...r, status } : r))
    );
  };

  const updateRowNotes = (studentId: string, notes: string) => {
    setDailyRows(prev =>
      prev.map(r => (r.studentId === studentId ? { ...r, notes } : r))
    );
  };

  const handleSaveDaily = () => {
    StorageService.saveAttendance(
      dailyClass,
      dailyDate,
      dailyRows.map(r => ({
        studentId: r.studentId,
        status: r.status,
        notes: r.notes
      }))
    );
    showToast('Presensi kehadiran harian berhasil disimpan!', 'success');
  };

  const exportMonthlyExcel = () => {
    if (!monthlyRecap || !monthlyRecap.students.length) {
      showToast('Tidak ada data untuk diekspor', 'error');
      return;
    }

    const exportData = monthlyRecap.students.map((s: any, idx: number) => {
      const totalDays = s.hadir + s.sakit + s.izin + s.alpa;
      const pct = totalDays > 0 ? Math.round((s.hadir / totalDays) * 100) : 100;
      return {
        'No': idx + 1,
        'NIS': s.nis,
        'Nama Lengkap': s.fullName,
        'Hadir (H)': s.hadir,
        'Sakit (S)': s.sakit,
        'Izin (I)': s.izin,
        'Alpa (A)': s.alpa,
        'Persentase Kehadiran': `${pct}%`
      };
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `Rekap_${monthlyRecap.className}`);
    XLSX.writeFile(wb, `Rekap_Absensi_${monthlyRecap.className}_${monthlyMonth}.xlsx`);
  };

  const statusColors = {
    Hadir: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    Sakit: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    Izin: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    Alpa: 'bg-rose-500/20 text-rose-300 border-rose-500/40'
  };

  return (
    <div className="space-y-5">
      {/* Tab Switcher */}
      <div className="glass rounded-2xl p-2 flex items-center gap-2 max-w-md border border-white/10">
        <button
          onClick={() => setActiveTab('daily')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'daily'
              ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/25'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <CalendarCheck className="w-4 h-4" /> Presensi Harian
        </button>
        <button
          onClick={() => setActiveTab('monthly')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'monthly'
              ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/25'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" /> Rekap Bulanan
        </button>
      </div>

      {activeTab === 'daily' ? (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-3 border border-white/10">
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
              <div className="w-full sm:w-auto">
                <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Pilih Rombel Kelas
                </label>
                <select
                  value={dailyClass}
                  onChange={e => setDailyClass(e.target.value)}
                  className="w-full sm:w-48 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                >
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>
                      Kelas {c.className}
                    </option>
                  ))}
                </select>
              </div>

              <div className="w-full sm:w-auto">
                <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Hari & Tanggal
                </label>
                <input
                  type="date"
                  value={dailyDate}
                  onChange={e => setDailyDate(e.target.value)}
                  className="w-full sm:w-48 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
              <button
                onClick={() => setAllStatus('Hadir')}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-emerald-400 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <CheckCheck className="w-3.5 h-3.5" /> Set Semua Hadir
              </button>
              <button
                onClick={handleSaveDaily}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" /> Simpan Presensi
              </button>
            </div>
          </div>

          {/* Daily Table */}
          <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
            <div className="overflow-x-auto w-full">
              <table className="w-full text-left text-xs sm:text-sm min-w-[650px]">
                <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400 font-bold border-b border-white/10">
                  <tr>
                    <th className="py-3.5 px-4 w-12 text-center">No</th>
                    <th className="py-3.5 px-4">Nama Siswa</th>
                    <th className="py-3.5 px-4 w-44 text-center">Status Kehadiran</th>
                    <th className="py-3.5 px-4">Catatan / Keterangan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {dailyRows.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="text-center py-10 text-slate-400 italic">
                        Tidak ada siswa di kelas ini.
                      </td>
                    </tr>
                  ) : (
                    dailyRows.map((r, index) => (
                      <tr key={r.studentId} className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-4 text-center font-mono text-slate-400">
                          {index + 1}
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="font-bold text-white">{r.fullName}</p>
                          <p className="text-[10px] text-slate-400 font-mono">NIS: {r.nis}</p>
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <div className="inline-flex rounded-xl p-1 bg-white/5 border border-white/10 gap-1">
                            {(['Hadir', 'Sakit', 'Izin', 'Alpa'] as const).map(st => (
                              <button
                                key={st}
                                onClick={() => updateRowStatus(r.studentId, st)}
                                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                  r.status === st
                                    ? statusColors[st] + ' border'
                                    : 'text-slate-400 hover:text-white'
                                }`}
                              >
                                {st}
                              </button>
                            ))}
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          <input
                            type="text"
                            value={r.notes}
                            onChange={e => updateRowNotes(r.studentId, e.target.value)}
                            placeholder="Catatan izin/sakit..."
                            className="w-full px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500 placeholder-slate-500"
                          />
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Monthly Recap Tab */
        <div className="space-y-4">
          <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-3 border border-white/10">
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
              <div className="w-full sm:w-auto">
                <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Pilih Rombel Kelas
                </label>
                <select
                  value={monthlyClass}
                  onChange={e => setMonthlyClass(e.target.value)}
                  className="w-full sm:w-48 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                >
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>
                      Kelas {c.className}
                    </option>
                  ))}
                </select>
              </div>

              <div className="w-full sm:w-auto">
                <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Bulan Rekapitulasi
                </label>
                <input
                  type="month"
                  value={monthlyMonth}
                  onChange={e => setMonthlyMonth(e.target.value)}
                  className="w-full sm:w-48 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto justify-end">
              <button
                onClick={exportMonthlyExcel}
                className="px-4 py-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-bold text-xs sm:text-sm flex items-center gap-2 transition-colors cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4" /> Export Excel
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 font-bold text-xs sm:text-sm flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Printer className="w-4 h-4" /> Cetak Rekap
              </button>
            </div>
          </div>

          <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
            <div className="overflow-x-auto w-full">
              <table className="w-full text-left text-xs sm:text-sm min-w-[700px]">
                <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400 font-bold border-b border-white/10">
                  <tr>
                    <th className="py-3.5 px-4 w-12 text-center">No</th>
                    <th className="py-3.5 px-4 w-28">NIS</th>
                    <th className="py-3.5 px-4">Nama Lengkap Siswa</th>
                    <th className="py-3.5 px-3 text-center text-emerald-400">Hadir</th>
                    <th className="py-3.5 px-3 text-center text-blue-400">Sakit</th>
                    <th className="py-3.5 px-3 text-center text-amber-400">Izin</th>
                    <th className="py-3.5 px-3 text-center text-rose-400">Alpa</th>
                    <th className="py-3.5 px-4 text-center">% Kehadiran</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {!monthlyRecap || monthlyRecap.students.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center py-10 text-slate-400 italic">
                        Belum ada data absensi pada bulan terpilih.
                      </td>
                    </tr>
                  ) : (
                    monthlyRecap.students.map((s: any, index: number) => {
                      const total = s.hadir + s.sakit + s.izin + s.alpa;
                      const pct = total > 0 ? Math.round((s.hadir / total) * 100) : 100;
                      return (
                        <tr key={s.studentId} className="hover:bg-white/5 transition-colors">
                          <td className="py-3.5 px-4 text-center font-mono text-slate-400">
                            {index + 1}
                          </td>
                          <td className="py-3.5 px-4 font-mono text-slate-400">{s.nis}</td>
                          <td className="py-3.5 px-4 font-bold text-white">{s.fullName}</td>
                          <td className="py-3.5 px-3 text-center font-bold text-emerald-400">
                            {s.hadir}
                          </td>
                          <td className="py-3.5 px-3 text-center font-bold text-blue-400">
                            {s.sakit}
                          </td>
                          <td className="py-3.5 px-3 text-center font-bold text-amber-400">
                            {s.izin}
                          </td>
                          <td className="py-3.5 px-3 text-center font-bold text-rose-400">
                            {s.alpa}
                          </td>
                          <td className="py-3.5 px-4 text-center font-bold text-slate-200">
                            {pct}%
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
