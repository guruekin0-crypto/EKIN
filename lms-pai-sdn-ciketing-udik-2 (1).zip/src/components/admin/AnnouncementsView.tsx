import React, { useState } from 'react';
import {
  Megaphone,
  Plus,
  Trash2,
  Calendar,
  X,
  Users,
  School
} from 'lucide-react';
import { Announcement, ClassItem } from '../../types';
import { StorageService } from '../../services/storageService';

interface AnnouncementsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AnnouncementsView: React.FC<AnnouncementsViewProps> = ({ showToast }) => {
  const [announcements, setAnnouncements] = useState<Announcement[]>(
    StorageService.getAnnouncements()
  );
  const classes = StorageService.getClasses();

  const [modalOpen, setModalOpen] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formBody, setFormBody] = useState('');
  const [formTarget, setFormTarget] = useState<'all' | 'class_id'>('all');
  const [formClassId, setFormClassId] = useState(classes[0]?.id || '');

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const refreshAnnouncements = () => {
    setAnnouncements(StorageService.getAnnouncements());
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formBody.trim()) {
      showToast('Judul dan isi pengumuman wajib diisi!', 'error');
      return;
    }

    StorageService.saveAnnouncement({
      title: formTitle.trim(),
      body: formBody.trim(),
      target: formTarget,
      classId: formTarget === 'class_id' ? formClassId : undefined,
      createdBy: 'Guru PAI'
    });

    setModalOpen(false);
    refreshAnnouncements();
    showToast('Pengumuman berhasil disiarkan ke siswa');
  };

  const handleDelete = (id: string, title: string) => {
    setDeleteTarget({ id, title });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteAnnouncement(deleteTarget.id);
    refreshAnnouncements();
    showToast(`Pengumuman "${deleteTarget.title}" berhasil dihapus`, 'info');
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-5">
      {/* Top Bar */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-3 border border-white/10">
        <div>
          <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 font-display">
            <Megaphone className="w-5 h-5 text-amber-400" /> Siaran Informasi & Pengumuman
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Kirimkan informasi penting kepada seluruh siswa atau rombel kelas tertentu
          </p>
        </div>

        <button
          onClick={() => {
            setFormTitle('');
            setFormBody('');
            setFormTarget('all');
            setFormClassId(classes[0]?.id || '');
            setModalOpen(true);
          }}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> + Buat Pengumuman
        </button>
      </div>

      {/* Announcements List */}
      <div className="space-y-3.5">
        {announcements.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center text-slate-400 italic">
            Belum ada siaran pengumuman. Klik <b>"+ Buat Pengumuman"</b> untuk menyiarkan informasi baru.
          </div>
        ) : (
          announcements.map(ann => (
            <div
              key={ann.id}
              className="glass rounded-2xl p-5 border border-white/10 hover:border-amber-500/30 transition-all shadow-md space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/5 pb-2.5">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-xs">
                    Sasaran: {ann.targetLabel || (ann.target === 'all' ? 'Semua Siswa' : 'Kelas')}
                  </span>
                  <span className="text-slate-500 text-xs">&bull;</span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(ann.createdAt).toLocaleDateString('id-ID', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </span>
                </div>

                <button
                  onClick={() => handleDelete(ann.id, ann.title)}
                  className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 cursor-pointer transition-colors"
                  title="Hapus Pengumuman"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <h4 className="font-bold text-base text-white">{ann.title}</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                {ann.body}
              </p>
            </div>
          ))
        )}
      </div>

      {/* Modal Add Announcement */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-lg max-h-[90vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-amber-400" />
                Buat Pengumuman Baru
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 overflow-y-auto flex-1 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Target Sasaran Pengumuman
                </label>
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => setFormTarget('all')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                      formTarget === 'all'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-white/5 border-white/10 text-slate-400'
                    }`}
                  >
                    Semua Siswa
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormTarget('class_id')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                      formTarget === 'class_id'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-white/5 border-white/10 text-slate-400'
                    }`}
                  >
                    Rombel Kelas Tertentu
                  </button>
                </div>

                {formTarget === 'class_id' && (
                  <select
                    value={formClassId}
                    onChange={e => setFormClassId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-xs text-white"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        Khusus Kelas {c.className}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Judul Pengumuman <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder="Contoh: Jadwal Ujian Harian PAI & Budi Pekerti"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Isi Pesan Pengumuman <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={4}
                  value={formBody}
                  onChange={e => setFormBody(e.target.value)}
                  placeholder="Ketik isi pengumuman atau instruksi untuk siswa..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs leading-relaxed focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-md"
                >
                  Siarkan Pengumuman
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Pengumuman?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus pengumuman{' '}
              <span className="text-white font-bold">"{deleteTarget.title}"</span>? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
