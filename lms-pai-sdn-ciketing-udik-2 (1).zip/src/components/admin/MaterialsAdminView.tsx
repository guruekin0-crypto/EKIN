import React, { useState } from 'react';
import {
  BookText,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  X,
  Type,
  Video,
  FileText,
  ExternalLink,
  Sparkles,
  Maximize2
} from 'lucide-react';
import { Material } from '../../types';
import { StorageService } from '../../services/storageService';
import { FocusReaderModal } from '../common/FocusReaderModal';

interface MaterialsAdminViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const MaterialsAdminView: React.FC<MaterialsAdminViewProps> = ({ showToast }) => {
  const [materials, setMaterials] = useState<Material[]>(StorageService.getMaterials());
  const classes = StorageService.getClasses();
  const [search, setSearch] = useState('');
  const [filterGrade, setFilterGrade] = useState('');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingMat, setEditingMat] = useState<Material | null>(null);

  // Form states
  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState<'text' | 'video' | 'link'>('text');
  const [formContent, setFormContent] = useState('');
  const [formUrl, setFormUrl] = useState('');
  const [formClassId, setFormClassId] = useState('5');
  const [formSubject, setFormSubject] = useState('PAI & Budi Pekerti');
  const [formSemester, setFormSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');

  // Reader Preview Modal
  const [previewMat, setPreviewMat] = useState<Material | null>(null);
  const [focusMat, setFocusMat] = useState<Material | null>(null);

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const refreshMaterials = () => {
    setMaterials(StorageService.getMaterials());
  };

  const openAddModal = () => {
    setEditingMat(null);
    setFormTitle('');
    setFormType('text');
    setFormContent('');
    setFormUrl('');
    setFormClassId('5');
    setFormSubject('PAI & Budi Pekerti');
    setFormSemester('Ganjil');
    setModalOpen(true);
  };

  const openEditModal = (m: Material) => {
    setEditingMat(m);
    setFormTitle(m.title);
    setFormType((m.contentType as any) || 'text');
    setFormContent(m.contentText);
    setFormUrl(m.fileUrl || '');
    setFormClassId(m.classId);
    setFormSubject(m.subject || 'PAI & Budi Pekerti');
    setFormSemester(m.semester || 'Ganjil');
    setModalOpen(true);
  };

  const insertArabicToContent = (arabicText: string) => {
    setFormContent(prev => prev + `\n<p dir="rtl" style="font-family: 'Amiri', serif; font-size: 1.45rem; text-align: right; line-height: 2.2;">${arabicText}</p>\n`);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      showToast('Judul bahan materi wajib diisi!', 'error');
      return;
    }

    StorageService.saveMaterial({
      id: editingMat ? editingMat.id : undefined,
      title: formTitle.trim(),
      contentType: formType,
      contentText: formContent.trim(),
      fileUrl: formUrl.trim() || undefined,
      classId: formClassId,
      className: `Tingkat Kelas ${formClassId}`,
      subject: formSubject.trim(),
      semester: formSemester
    });

    setModalOpen(false);
    refreshMaterials();
    showToast(editingMat ? 'Bahan materi diperbarui' : 'Bahan materi berhasil disimpan');
  };

  const handleDelete = (id: string, title: string) => {
    setDeleteTarget({ id, title });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteMaterial(deleteTarget.id);
    setMaterials(prev => prev.filter(m => m.id !== deleteTarget.id));
    if (editingMat?.id === deleteTarget.id) {
      setModalOpen(false);
      setEditingMat(null);
    }
    if (previewMat?.id === deleteTarget.id) {
      setPreviewMat(null);
    }
    showToast(`Materi "${deleteTarget.title}" berhasil dihapus`, 'info');
    setDeleteTarget(null);
  };

  const filtered = materials.filter(m => {
    const matchSearch =
      m.title.toLowerCase().includes(search.toLowerCase()) ||
      m.contentText.toLowerCase().includes(search.toLowerCase());
    const matchGrade = !filterGrade || m.classId === filterGrade;
    return matchSearch && matchGrade;
  });

  return (
    <div className="space-y-5">
      {/* Search and Action Bar */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto flex-1">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari materi pembelajaran..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <select
            value={filterGrade}
            onChange={e => setFilterGrade(e.target.value)}
            className="w-full sm:w-44 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs text-white"
          >
            <option value="">Semua Tingkat Kelas</option>
            <option value="1">Tingkat Kelas 1</option>
            <option value="2">Tingkat Kelas 2</option>
            <option value="3">Tingkat Kelas 3</option>
            <option value="4">Tingkat Kelas 4</option>
            <option value="5">Tingkat Kelas 5</option>
            <option value="6">Tingkat Kelas 6</option>
          </select>
        </div>

        <button
          onClick={openAddModal}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> + Tambah Bahan Materi
        </button>
      </div>

      {/* Materials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-2 glass rounded-2xl p-10 text-center text-slate-400 italic">
            Belum ada bahan materi yang ditambahkan. Klik <b>"+ Tambah Bahan Materi"</b> untuk membuat materi baru.
          </div>
        ) : (
          filtered.map(mat => (
            <div
              key={mat.id}
              className="glass rounded-2xl p-5 border border-white/10 hover:border-emerald-500/40 transition-all shadow-md flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold text-[11px]">
                    Tingkat Kelas {mat.classId || 'Semua'} &bull; Semester {mat.semester}
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                    {mat.contentType}
                  </span>
                </div>

                <h4 className="font-bold text-base text-white leading-snug">
                  {mat.title}
                </h4>

                <div
                  className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed opacity-90 prose prose-invert max-w-none"
                  dangerouslySetInnerHTML={{
                    __html: mat.contentText ? mat.contentText.replace(/<[^>]*>/g, ' ') : ''
                  }}
                />
              </div>

              <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setPreviewMat(mat)}
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5 text-cyan-400" /> Ringkas
                  </button>
                  <button
                    onClick={() => setFocusMat(mat)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Buka Mode Baca Fokus Layar Penuh Tanpa Sidebar/Header"
                  >
                    <Maximize2 className="w-3.5 h-3.5" /> Focus Reader
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      openEditModal(mat);
                    }}
                    className="p-2 rounded-xl bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 cursor-pointer transition-colors"
                    title="Edit Materi"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(mat.id, mat.title);
                    }}
                    className="p-2 rounded-xl bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 cursor-pointer transition-colors"
                    title="Hapus Materi"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal Add / Edit Material */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <BookText className="w-5 h-5 text-emerald-400" />
                {editingMat ? 'Edit Bahan Materi' : 'Tambah Bahan Materi Baru (PAI)'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 overflow-y-auto flex-1 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Judul Materi Pembelajaran <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder="Contoh: Mengenal dan Mengamalkan Surah Al-Ma'un"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Tipe Konten
                  </label>
                  <select
                    value={formType}
                    onChange={e => setFormType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="text">Teks / Rangkuman</option>
                    <option value="video">Video Pembelajaran</option>
                    <option value="link">Dokumen / Tautan Luar</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Tingkat Kelas
                  </label>
                  <select
                    value={formClassId}
                    onChange={e => setFormClassId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="">Semua Tingkat (Umum)</option>
                    <option value="1">Kelas 1</option>
                    <option value="2">Kelas 2</option>
                    <option value="3">Kelas 3</option>
                    <option value="4">Kelas 4</option>
                    <option value="5">Kelas 5</option>
                    <option value="6">Kelas 6</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Semester
                  </label>
                  <select
                    value={formSemester}
                    onChange={e => setFormSemester(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Mata Pelajaran
                  </label>
                  <input
                    type="text"
                    value={formSubject}
                    onChange={e => setFormSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  />
                </div>
              </div>

              {formType === 'video' && (
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    URL Video YouTube
                  </label>
                  <input
                    type="url"
                    value={formUrl}
                    onChange={e => setFormUrl(e.target.value)}
                    placeholder="Contoh: https://www.youtube.com/watch?v=..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs"
                  />
                </div>
              )}

              {/* Fast Arabic Snippet Buttons */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-300 uppercase flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-emerald-400" /> Sisipkan Teks Ayat / Doa Arab
                  </label>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  <button
                    type="button"
                    onClick={() => insertArabicToContent('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-emerald-300 text-xs font-arabic border border-white/10"
                  >
                    + Basmalah
                  </button>
                  <button
                    type="button"
                    onClick={() => insertArabicToContent('أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ ۝ فَذَٰلِكَ الَّذِي يَدُعُّ الْيَتِيمَ ۝ وَلَا يَحُضُّ عَلَىٰ طَعَامِ الْمِسْكِينِ')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-emerald-300 text-xs font-arabic border border-white/10"
                  >
                    + Al-Ma'un 1-3
                  </button>
                  <button
                    type="button"
                    onClick={() => insertArabicToContent('رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-emerald-300 text-xs font-arabic border border-white/10"
                  >
                    + Doa Orang Tua
                  </button>
                </div>

                <textarea
                  rows={8}
                  value={formContent}
                  onChange={e => setFormContent(e.target.value)}
                  placeholder="Ketik isi materi pembelajaran lengkap di sini. Anda dapat menyisipkan ayat Arab dan format HTML..."
                  className="w-full p-4 rounded-2xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm font-mono leading-relaxed focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                {editingMat ? (
                  <button
                    type="button"
                    onClick={() => handleDelete(editingMat.id, editingMat.title)}
                    className="px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Trash2 className="w-4 h-4" /> Hapus Materi
                  </button>
                ) : <div />}
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
                  >
                    Simpan Bahan Materi
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reader Preview Modal */}
      {previewMat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                  Tingkat Kelas {previewMat.classId || 'Umum'} &bull; Semester {previewMat.semester}
                </span>
                <h3 className="font-bold text-base sm:text-lg text-white">{previewMat.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleDelete(previewMat.id, previewMat.title)}
                  className="px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Hapus
                </button>
                <button
                  onClick={() => setPreviewMat(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto flex-1 bg-slate-900/40 text-slate-100 text-sm leading-relaxed space-y-4">
              <div
                className="prose prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: previewMat.contentText }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Bahan Materi?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus bahan materi{' '}
              <span className="text-white font-bold">"{deleteTarget.title}"</span>? Tindakan ini akan menghapus materi dari sistem dan tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Focus Reader Modal */}
      <FocusReaderModal
        isOpen={!!focusMat}
        onClose={() => setFocusMat(null)}
        title={focusMat?.title || ''}
        subtitle={`Bahan Materi Guru PAI • Tingkat Kelas ${focusMat?.classId || 'Semua'} • Semester ${focusMat?.semester || 'Ganjil'}`}
        badgeText={focusMat?.subject || 'PAI & Budi Pekerti'}
        htmlContent={focusMat?.contentText}
      />
    </div>
  );
};
