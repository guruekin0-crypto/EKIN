import React, { useState } from 'react';
import { School, Plus, Search, Edit2, Trash2, X, Users } from 'lucide-react';
import { ClassItem } from '../../types';
import { StorageService } from '../../services/storageService';

interface ClassesViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ClassesView: React.FC<ClassesViewProps> = ({ showToast }) => {
  const [classes, setClasses] = useState<ClassItem[]>(StorageService.getClasses());
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassItem | null>(null);

  // Form states
  const [formClassName, setFormClassName] = useState('');
  const [formHomeroom, setFormHomeroom] = useState('');
  const [formYear, setFormYear] = useState('2026/2027');

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  const refreshClasses = () => {
    setClasses(StorageService.getClasses());
  };

  const openAddModal = () => {
    setEditingClass(null);
    setFormClassName('');
    setFormHomeroom('');
    setFormYear('2026/2027');
    setModalOpen(true);
  };

  const openEditModal = (c: ClassItem) => {
    setEditingClass(c);
    setFormClassName(c.className);
    setFormHomeroom(c.homeroom);
    setFormYear(c.academicYear);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formClassName.trim()) {
      showToast('Nama kelas wajib diisi!', 'error');
      return;
    }

    StorageService.saveClass({
      id: editingClass ? editingClass.id : undefined,
      className: formClassName.trim().toUpperCase(),
      homeroom: formHomeroom.trim() || '-',
      academicYear: formYear.trim() || '2026/2027'
    });

    setModalOpen(false);
    refreshClasses();
    showToast(editingClass ? 'Data kelas berhasil diperbarui' : 'Kelas baru berhasil ditambahkan');
  };

  const handleDelete = (id: string, name: string) => {
    setDeleteTarget({ id, name });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteClass(deleteTarget.id);
    refreshClasses();
    showToast(`Kelas ${deleteTarget.name} berhasil dihapus`, 'info');
    setDeleteTarget(null);
  };

  const filtered = classes.filter(
    c =>
      c.className.toLowerCase().includes(search.toLowerCase()) ||
      c.homeroom.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      {/* Top Bar */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Cari kelas / wali kelas..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <button
          onClick={openAddModal}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
        >
          <Plus className="w-4 h-4" /> Tambah Rombel Kelas
        </button>
      </div>

      {/* Classes Table */}
      <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs sm:text-sm min-w-[550px]">
            <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400 font-bold border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4 w-14 text-center">No</th>
                <th className="py-3.5 px-4 w-32">Nama Kelas</th>
                <th className="py-3.5 px-4">Wali Kelas</th>
                <th className="py-3.5 px-4 w-36 text-center">Tahun Ajaran</th>
                <th className="py-3.5 px-4 w-28 text-center">Jumlah Siswa</th>
                <th className="py-3.5 px-4 w-28 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-400 italic">
                    Tidak ditemukan data kelas.
                  </td>
                </tr>
              ) : (
                filtered.map((c, index) => (
                  <tr key={c.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-3.5 px-4 text-center font-mono text-slate-400">
                      {index + 1}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                          {c.className}
                        </div>
                        <span className="font-bold text-white">Kelas {c.className}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 font-medium">{c.homeroom}</td>
                    <td className="py-3.5 px-4 text-center font-mono text-slate-400">
                      {c.academicYear}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                        <Users className="w-3 h-3" /> {c.studentCount || 0} anak
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => openEditModal(c)}
                        className="p-2 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 transition-colors mr-1 cursor-pointer"
                        title="Edit Kelas"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(c.id, c.className)}
                        className="p-2 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 transition-colors cursor-pointer"
                        title="Hapus Kelas"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="glass-strong rounded-2xl w-full max-w-md border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
                <School className="w-4 h-4 text-emerald-400" />
                {editingClass ? 'Edit Rombel Kelas' : 'Tambah Rombel Kelas Baru'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                  Nama Kelas <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formClassName}
                  onChange={e => setFormClassName(e.target.value)}
                  placeholder="Contoh: 5A, 5B, 6A"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                  Wali Kelas
                </label>
                <input
                  type="text"
                  value={formHomeroom}
                  onChange={e => setFormHomeroom(e.target.value)}
                  placeholder="Nama Lengkap & Gelar Wali Kelas"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                  Tahun Ajaran
                </label>
                <input
                  type="text"
                  value={formYear}
                  onChange={e => setFormYear(e.target.value)}
                  placeholder="2026/2027"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
                >
                  Simpan Kelas
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Data Kelas?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus <span className="text-white font-bold">Kelas {deleteTarget.name}</span>? Data siswa dalam rombel ini akan tetap aman tersimpan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Kelas
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
