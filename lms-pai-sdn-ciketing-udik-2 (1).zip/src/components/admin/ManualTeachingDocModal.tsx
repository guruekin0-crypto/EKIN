import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  CheckCircle2,
  FileText,
  Layers,
  BookOpen,
  Upload,
  Wand2,
  Eye,
  Link as LinkIcon,
  Sparkles
} from 'lucide-react';
import {
  TeachingDocument,
  TeachingDocType,
  TeachingReferenceDoc,
  AppSettings,
  TeacherProfile
} from '../../types';
import { REGULASI_RESMI_BKPDM } from '../../utils/printDocumentHelper';
import { StorageService } from '../../services/storageService';
import { parseUploadedReferenceFile } from '../../utils/teachingDocImportHelper';

interface ManualTeachingDocModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (doc: Omit<TeachingDocument, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => void;
  editingDoc?: TeachingDocument | null;
  initialReferenceDoc?: TeachingReferenceDoc | null;
  defaultGrade?: string;
  defaultDocType?: TeachingDocType;
  appSettings: AppSettings;
  teacherProfile: TeacherProfile;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const DOC_TYPE_OPTIONS: { id: TeachingDocType; label: string; short: string }[] = [
  { id: 'cp_atp', label: 'CP / ATP (Capaian & Alur Tujuan Pembelajaran)', short: 'CP/ATP' },
  { id: 'prota', label: 'Program Tahunan (Prota)', short: 'Prota' },
  { id: 'promes', label: 'Program Semester (Promes)', short: 'Promes' },
  { id: 'kktp', label: 'KKTP (Kriteria Ketercapaian Tujuan Pembelajaran)', short: 'KKTP' },
  { id: 'modul_ajar', label: 'Modul Ajar / RPP Merdeka', short: 'Modul Ajar' },
  { id: 'lkpd', label: 'LKPD (Lembar Kerja Peserta Didik)', short: 'LKPD' },
  { id: 'lainnya', label: 'Perangkat Ajar Lainnya (Silabus, Kisi-Kisi, Remedial, dll.)', short: 'Lainnya' }
];

const SUB_KATEGORI_LAINNYA = [
  'Silabus Pembelajaran PAI & Budi Pekerti',
  'Kisi-Kisi & Kartu Soal Asesmen Sumatif',
  'Program Remedial & Pengayaan PAI',
  'Instrumen & Rubrik Penilaian Sikap / Praktik Ibadah',
  'Jurnal Refleksi Pembelajaran Guru & Siswa',
  'Kurikulum Operasional Satuan Pendidikan (KOSP) PAI',
  'Jadwal Tatap Muka & Kalender Pekan Efektif',
  'Daftar Buku Teks & Referensi Pembelajaran PAI',
  'Dokumen Administrasi Lainnya'
];

export const ManualTeachingDocModal: React.FC<ManualTeachingDocModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingDoc,
  initialReferenceDoc,
  defaultGrade = '5',
  defaultDocType = 'cp_atp',
  appSettings,
  teacherProfile,
  showToast
}) => {
  const [docType, setDocType] = useState<TeachingDocType>(defaultDocType);
  const [classGrade, setClassGrade] = useState<string>(defaultGrade === 'all' ? '5' : defaultGrade);
  const [semester, setSemester] = useState<'Ganjil' | 'Genap' | 'Tahunan'>('Ganjil');
  const [elementDomain, setElementDomain] = useState<string>("Al-Qur'an & Hadis");
  const [title, setTitle] = useState<string>('');
  const [summary, setSummary] = useState<string>('');
  const [targetBab, setTargetBab] = useState<string>('');
  const [alokasiWaktuJP, setAlokasiWaktuJP] = useState<number>(12);
  const [catatanTambahan, setCatatanTambahan] = useState<string>('');

  // Sandaran / Reference Document State
  const [availableRefs, setAvailableRefs] = useState<TeachingReferenceDoc[]>([]);
  const [selectedRefDoc, setSelectedRefDoc] = useState<TeachingReferenceDoc | null>(null);
  const [showRefViewer, setShowRefViewer] = useState<boolean>(false);
  const [isUploadingQuickRef, setIsUploadingQuickRef] = useState<boolean>(false);

  // 1. State for CP / ATP
  const [capaianPembelajaran, setCapaianPembelajaran] = useState<string>('');
  const [atpRows, setAtpRows] = useState<
    Array<{
      no: number;
      tujuan: string;
      materi: string;
      elemen: string;
      alokasiJP: number;
      profilPancasilaKBC: string;
      indikator: string;
    }>
  >([
    {
      no: 1,
      tujuan: '',
      materi: '',
      elemen: "Al-Qur'an & Hadis",
      alokasiJP: 4,
      profilPancasilaKBC: 'Beriman, Bertakwa & Kasih Sayang (KBC)',
      indikator: ''
    }
  ]);

  // 2. State for PROTA
  const [protaRows, setProtaRows] = useState<
    Array<{
      no: number;
      semester: 'Ganjil' | 'Genap';
      elemen: string;
      materiPokok: string;
      tujuanPembelajaran: string;
      alokasiJP: number;
      keterangan: string;
    }>
  >([
    {
      no: 1,
      semester: 'Ganjil',
      elemen: "Al-Qur'an & Hadis",
      materiPokok: '',
      tujuanPembelajaran: '',
      alokasiJP: 12,
      keterangan: 'Semester Ganjil'
    }
  ]);

  // 3. State for PROMES
  const [promesRows, setPromesRows] = useState<
    Array<{
      no: number;
      materiPokok: string;
      tujuanPembelajaran: string;
      alokasiJP: number;
      bulanPelaksanaan: string;
      pekanEfektif: string;
    }>
  >([
    {
      no: 1,
      materiPokok: '',
      tujuanPembelajaran: '',
      alokasiJP: 12,
      bulanPelaksanaan: 'Juli - Agustus',
      pekanEfektif: '4, 4, 4'
    }
  ]);

  // 4. State for KKTP
  const [kktpRows, setKktpRows] = useState<
    Array<{
      no: number;
      tujuanPembelajaran: string;
      indikatorKetuntasan: string;
      perluBimbingan: string;
      cukup: string;
      baik: string;
      sangatBaik: string;
      tindakLanjutKBC: string;
    }>
  >([
    {
      no: 1,
      tujuanPembelajaran: '',
      indikatorKetuntasan: '',
      perluBimbingan: 'Belum mencapai ketuntasan dasar, perlu pendampingan penuh kasih sayang (0-60).',
      cukup: 'Mencapai sebagian indikator dasar namun masih butuh bimbingan (61-75).',
      baik: 'Mencapai ketuntasan indikator dengan baik dan mandiri (76-88).',
      sangatBaik: 'Sangat mahir, tuntas sempurna, dan mampu menjadi tutor sebaya (89-100).',
      tindakLanjutKBC: 'Bimbingan personal ramah anak & apresiasi motivasi KBC.'
    }
  ]);

  // 5. State for MODUL AJAR (RPP)
  const [maAlokasiWaktuText, setMaAlokasiWaktuText] = useState('3 Pertemuan (9 JP x 35 Menit)');
  const [maKompetensiAwal, setMaKompetensiAwal] = useState('');
  const [maProfilPancasilaText, setMaProfilPancasilaText] = useState(
    'Beriman, Bertakwa kepada Tuhan YME dan Berakhlak Mulia\nGotong Royong & Kasih Sayang (KBC)\nMandiri & Bernalar Kritis'
  );
  const [maSaranaPrasaranaText, setMaSaranaPrasaranaText] = useState(
    "Buku Siswa & Guru PAI Kemendikbudristek\nMushaf Al-Qur'an / Juz Amma\nLKPD & Media Visual"
  );
  const [maTargetPesertaDidik, setMaTargetPesertaDidik] = useState('Peserta Didik Reguler');
  const [maModelPembelajaran, setMaModelPembelajaran] = useState(
    'Tatap Muka - Problem Based Learning (PBL) dengan Pendekatan Cinta (KBC)'
  );
  const [maTujuanPembelajaranText, setMaTujuanPembelajaranText] = useState('');
  const [maPemahamanBermakna, setMaPemahamanBermakna] = useState('');
  const [maPertanyaanPemantikText, setMaPertanyaanPemantikText] = useState('');
  const [maPendahuluanText, setMaPendahuluanText] = useState('');
  const [maKegiatanIntiText, setMaKegiatanIntiText] = useState('');
  const [maPenutupText, setMaPenutupText] = useState('');
  const [maAsesmenDiagnostik, setMaAsesmenDiagnostik] = useState('Tanya jawab lisan pemetaan kesiapan belajar.');
  const [maAsesmenFormatif, setMaAsesmenFormatif] = useState('Observasi sikap KBC, diskusi kelompok, dan unjuk kerja.');
  const [maAsesmenSumatif, setMaAsesmenSumatif] = useState('Tes tertulis / evaluasi akhir bab.');
  const [maPengayaanRemedial, setMaPengayaanRemedial] = useState(
    'Remedial: Pendampingan tutor sebaya penuh kelembutan. Pengayaan: Membaca referensi kisah teladan tambahan.'
  );
  const [maRefleksi, setMaRefleksi] = useState(
    'Apakah siswa merasa senang, dicintai, dan memahami nilai kebaikan hari ini?'
  );
  const [maBahanBacaan, setMaBahanBacaan] = useState('');
  const [maGlosarium, setMaGlosarium] = useState('');
  const [maDaftarPustaka, setMaDaftarPustaka] = useState(
    'Buku Panduan Guru & Siswa PAI dan Budi Pekerti SD Kurikulum Merdeka.'
  );

  // 6. State for LKPD
  const [lkpdJudulAktivitas, setLkpdJudulAktivitas] = useState('');
  const [lkpdTemaKBC, setLkpdTemaKBC] = useState('Menebar Kasih Sayang & Berakhlak Mulia');
  const [lkpdPetunjukText, setLkpdPetunjukText] = useState(
    'Bacalah Basmalah sebelum mengerjakan lembar aktivitas.\nSimak materi dan cerita dengan saksama.\nJawablah pertanyaan dengan jujur dan santun.'
  );
  const [lkpdStimulusCerita, setLkpdStimulusCerita] = useState('');
  const [lkpdArabicText, setLkpdArabicText] = useState('');
  const [lkpdArabicArti, setLkpdArabicArti] = useState('');
  const [lkpdLangkahText, setLkpdLangkahText] = useState(
    '1. Amati cerita dan ayat pilihan di atas.\n2. Diskusikan bersama teman sebangku dengan santun.\n3. Tuliskan hasil jawabanmu pada kolom yang tersedia.'
  );
  const [lkpdTugasList, setLkpdTugasList] = useState<
    Array<{
      nomor: number;
      instruksi: string;
      tipe: 'isian' | 'pilihan' | 'centang';
      opsiText: string;
    }>
  >([
    {
      nomor: 1,
      instruksi: '',
      tipe: 'isian',
      opsiText: ''
    }
  ]);
  const [lkpdRefleksiCinta, setLkpdRefleksiCinta] = useState(
    'Tuliskan satu kebaikan yang ingin kamu amalkan untuk membahagiakan orang tua dan gurumu hari ini!'
  );
  const [lkpdRubrikNilai, setLkpdRubrikNilai] = useState(
    'Ketepatan Jawaban (50%), Sikap & Kejujuran (30%), Kerapian (20%). Total Skor = 100.'
  );

  // 7. State for DOKUMEN LAINNYA
  const [lainnyaSubKategori, setLainnyaSubKategori] = useState(SUB_KATEGORI_LAINNYA[0]);
  const [lainnyaTujuan, setLainnyaTujuan] = useState('');
  const [lainnyaUraian, setLainnyaUraian] = useState('');
  const [lainnyaRows, setLainnyaRows] = useState<
    Array<{
      no: number;
      aspek: string;
      uraian: string;
      keterangan: string;
    }>
  >([
    {
      no: 1,
      aspek: '',
      uraian: '',
      keterangan: ''
    }
  ]);
  const [lainnyaTautan, setLainnyaTautan] = useState('');
  const [lainnyaLampiran, setLainnyaLampiran] = useState<{
    fileName: string;
    fileType: string;
    dataUrl: string;
  } | null>(null);

  const getFaseByGrade = (grade: string): 'Fase A' | 'Fase B' | 'Fase C' => {
    if (grade === '1' || grade === '2') return 'Fase A';
    if (grade === '3' || grade === '4') return 'Fase B';
    return 'Fase C';
  };

  // Apply a Reference Document (Sandaran) into the active manual form fields
  const applyReferenceDocToForm = (ref: TeachingReferenceDoc, targetType: TeachingDocType) => {
    const grade = ref.classGrade === 'all' ? classGrade : ref.classGrade;
    const fase = getFaseByGrade(grade);
    const typeObj = DOC_TYPE_OPTIONS.find(t => t.id === targetType);

    setClassGrade(grade);
    setElementDomain(ref.elementDomain || "Al-Qur'an & Hadis");
    setTargetBab(ref.title);
    setTitle(
      `${(typeObj?.short || 'PERANGKAT AJAR').toUpperCase()} PAI KELAS ${grade} (${fase}): ${ref.title.toUpperCase()}`
    );
    setSummary(
      `Disusun berdasarkan sandaran Dokumen Acuan "${ref.title}" (${ref.fileName}) pada Kelas ${grade} (${fase}).`
    );

    const rows =
      ref.extractedRows && ref.extractedRows.length > 0
        ? ref.extractedRows
        : [
            {
              no: 1,
              col1: `Memahami dan mengamalkan materi pokok dari dokumen acuan ${ref.title}`,
              col2: ref.title,
              col3: '4 JP',
              col4: 'Beriman, Bertakwa & Kasih Sayang (KBC)'
            }
          ];

    const parseJP = (val?: string): number => {
      if (!val) return 4;
      const m = String(val).match(/\d+/);
      return m ? Math.min(36, Math.max(1, Number(m[0]))) : 4;
    };

    if (targetType === 'cp_atp') {
      setCapaianPembelajaran(
        ref.extractedText ||
          `Pada akhir ${fase} (Kelas ${grade}), peserta didik mampu memahami dan mengamalkan materi sesuai dokumen acuan ${ref.title}.`
      );
      setAtpRows(
        rows.map((r, idx) => ({
          no: idx + 1,
          tujuan: r.col1,
          materi: r.col2 || ref.title,
          elemen: ref.elementDomain || elementDomain,
          alokasiJP: parseJP(r.col3),
          profilPancasilaKBC: r.col4 || 'Beriman, Bertakwa & Kasih Sayang (KBC)',
          indikator: `Tercapainya kompetensi sesuai acuan: ${r.col1}`
        }))
      );
    } else if (targetType === 'prota') {
      setSemester('Tahunan');
      setProtaRows(
        rows.map((r, idx) => ({
          no: idx + 1,
          semester: idx % 2 === 0 ? 'Ganjil' : 'Genap',
          elemen: ref.elementDomain || elementDomain,
          materiPokok: r.col2 || r.col1,
          tujuanPembelajaran: r.col1,
          alokasiJP: parseJP(r.col3),
          keterangan: r.col4 || `Acuan: ${ref.fileName}`
        }))
      );
    } else if (targetType === 'promes') {
      setPromesRows(
        rows.map((r, idx) => ({
          no: idx + 1,
          materiPokok: r.col2 || r.col1,
          tujuanPembelajaran: r.col1,
          alokasiJP: parseJP(r.col3),
          bulanPelaksanaan:
            r.col4 || (semester === 'Genap' ? 'Januari - Maret' : 'Juli - September'),
          pekanEfektif: `${parseJP(r.col3)}`
        }))
      );
    } else if (targetType === 'kktp') {
      setKktpRows(
        rows.map((r, idx) => ({
          no: idx + 1,
          tujuanPembelajaran: r.col1,
          indikatorKetuntasan: r.col2 || `Ketuntasan indikator: ${r.col1}`,
          perluBimbingan: 'Belum mencapai indikator dasar pada dokumen acuan (0-60).',
          cukup: 'Mencapai sebagian indikator dasar namun butuh bimbingan (61-75).',
          baik: 'Mencapai ketuntasan indikator sesuai acuan dengan baik (76-88).',
          sangatBaik: 'Sangat mahir, tuntas sempurna, dan menjadi teladan (89-100).',
          tindakLanjutKBC: 'Pendampingan ramah anak & motivasi Kurikulum Berbasis Cinta (KBC).'
        }))
      );
    } else if (targetType === 'modul_ajar') {
      setMaKompetensiAwal(
        ref.extractedText.substring(0, 350) ||
          `Peserta didik memahami konsep awal berdasarkan dokumen acuan ${ref.title}.`
      );
      setMaTujuanPembelajaranText(rows.map(r => r.col1).join('\n'));
      setMaPemahamanBermakna(
        `Mengamalkan nilai-nilai utama dari ${ref.title} dengan hati yang penuh cinta kasih kepada Allah SWT dan sesama.`
      );
      setMaPertanyaanPemantikText(
        `Apa pesan kebaikan utama yang terdapat dalam materi ${ref.title}?\nBagaimana cara kita mempraktikkannya di sekolah dan di rumah?`
      );
      setMaPendahuluanText(
        `Guru membuka pembelajaran dengan salam hangat, doa bersama, dan tadarus surah pendek.\nGuru menyampaikan tujuan pembelajaran berdasarkan acuan ${ref.title}.`
      );
      setMaKegiatanIntiText(
        rows
          .map((r, idx) => `Tahap ${idx + 1}: Pembahasan dan aktivitas siswa mengenai "${r.col1}".`)
          .join('\n')
      );
      setMaPenutupText(
        `Peserta didik bersama guru menyimpulkan pembelajaran hari ini.\nRefleksi kalbu (KBC) dan doa penutup majelis.`
      );
      setMaBahanBacaan(ref.extractedText.substring(0, 500) || ref.title);
    } else if (targetType === 'lkpd') {
      setLkpdJudulAktivitas(`Lembar Aktivitas Siswa: ${ref.title}`);
      setLkpdStimulusCerita(ref.extractedText.substring(0, 400) || `Materi Acuan: ${ref.title}`);
      setLkpdTugasList(
        rows.slice(0, 6).map((r, idx) => ({
          nomor: idx + 1,
          instruksi: `Jelaskan pemahamanmu dan contoh penerapan dari: "${r.col1}"!`,
          tipe: 'isian' as const,
          opsiText: ''
        }))
      );
    } else if (targetType === 'lainnya') {
      setLainnyaTujuan(`Disusun berdasarkan dokumen acuan "${ref.title}" (${ref.fileName}).`);
      setLainnyaUraian(ref.extractedText || ref.title);
      setLainnyaRows(
        rows.map((r, idx) => ({
          no: idx + 1,
          aspek: r.col1,
          uraian: r.col2 || r.col1,
          keterangan: r.col3 || 'Sesuai Acuan'
        }))
      );
      if (ref.dataUrl) {
        setLainnyaLampiran({
          fileName: ref.fileName,
          fileType: ref.fileType,
          dataUrl: ref.dataUrl
        });
      }
    }
  };

  // Initialize form when modal opens
  useEffect(() => {
    if (!isOpen) return;

    const allRefs = StorageService.getTeachingRefDocs();
    setAvailableRefs(allRefs);

    if (editingDoc) {
      setDocType(editingDoc.docType);
      setClassGrade(editingDoc.classGrade || '5');
      setSemester(editingDoc.semester || 'Ganjil');
      setElementDomain(editingDoc.meta?.elementDomain || "Al-Qur'an & Hadis");
      setTitle(editingDoc.title || '');
      setSummary(editingDoc.summary || '');
      setTargetBab(editingDoc.meta?.targetBab || '');
      setAlokasiWaktuJP(editingDoc.meta?.alokasiWaktuJP || 12);
      setCatatanTambahan(editingDoc.contentData?.catatanTambahan || '');

      const cd = editingDoc.contentData || {};

      if (cd.sandaranAcuan?.referenceId) {
        const foundRef = allRefs.find(r => r.id === cd.sandaranAcuan?.referenceId) || null;
        setSelectedRefDoc(foundRef);
      } else {
        setSelectedRefDoc(null);
      }

      if (cd.capaianPembelajaran) setCapaianPembelajaran(cd.capaianPembelajaran);
      if (cd.alurTujuanPembelajaran && cd.alurTujuanPembelajaran.length > 0) {
        setAtpRows(
          cd.alurTujuanPembelajaran.map((item, idx) => ({
            no: item.no || idx + 1,
            tujuan: item.tujuan || '',
            materi: item.materi || '',
            elemen: item.elemen || editingDoc.meta?.elementDomain || "Al-Qur'an & Hadis",
            alokasiJP: item.alokasiJP || 4,
            profilPancasilaKBC: item.profilPancasilaKBC || 'Beriman, Bertakwa & Kasih Sayang (KBC)',
            indikator: item.indikator || ''
          }))
        );
      }

      if (cd.protaItems && cd.protaItems.length > 0) {
        setProtaRows(
          cd.protaItems.map((item, idx) => ({
            no: item.no || idx + 1,
            semester: item.semester || 'Ganjil',
            elemen: item.elemen || "Al-Qur'an & Hadis",
            materiPokok: item.materiPokok || '',
            tujuanPembelajaran: item.tujuanPembelajaran || '',
            alokasiJP: item.alokasiJP || 12,
            keterangan: item.keterangan || ''
          }))
        );
      }

      if (cd.promesItems && cd.promesItems.length > 0) {
        setPromesRows(
          cd.promesItems.map((item, idx) => ({
            no: item.no || idx + 1,
            materiPokok: item.materiPokok || '',
            tujuanPembelajaran: item.tujuanPembelajaran || '',
            alokasiJP: item.alokasiJP || 12,
            bulanPelaksanaan:
              item.distribusiBulan?.map(b => b.bulan).join(', ') || 'Juli - Agustus',
            pekanEfektif:
              item.distribusiBulan?.[0]?.minggu?.filter(m => m > 0).join(', ') || '4, 4, 4'
          }))
        );
      }

      if (cd.kktpItems && cd.kktpItems.length > 0) {
        setKktpRows(
          cd.kktpItems.map((item, idx) => ({
            no: item.no || idx + 1,
            tujuanPembelajaran: item.tujuanPembelajaran || '',
            indikatorKetuntasan: item.indikatorKetuntasan || '',
            perluBimbingan: item.kriteria?.perluBimbingan || '',
            cukup: item.kriteria?.cukup || '',
            baik: item.kriteria?.baik || '',
            sangatBaik: item.kriteria?.sangatBaik || '',
            tindakLanjutKBC: item.tindakLanjutKBC || ''
          }))
        );
      }

      if (cd.modulAjar) {
        const ma = cd.modulAjar;
        setMaAlokasiWaktuText(ma.identitas?.alokasiWaktu || '3 Pertemuan (9 JP)');
        setMaKompetensiAwal(ma.kompetensiAwal || '');
        setMaProfilPancasilaText((ma.profilPelajarPancasilaKBC || []).join('\n'));
        setMaSaranaPrasaranaText((ma.saranaPrasarana || []).join('\n'));
        setMaTargetPesertaDidik(ma.targetPesertaDidik || 'Peserta Didik Reguler');
        setMaModelPembelajaran(ma.modelPembelajaran || 'Problem Based Learning (PBL)');
        setMaTujuanPembelajaranText((ma.komponenInti?.tujuanPembelajaran || []).join('\n'));
        setMaPemahamanBermakna(ma.komponenInti?.pemahamanBermakna || '');
        setMaPertanyaanPemantikText((ma.komponenInti?.pertanyaanPemantik || []).join('\n'));
        setMaPendahuluanText((ma.komponenInti?.kegiatanPembelajaran?.pendahuluan || []).join('\n'));
        setMaKegiatanIntiText((ma.komponenInti?.kegiatanPembelajaran?.kegiatanInti || []).join('\n'));
        setMaPenutupText((ma.komponenInti?.kegiatanPembelajaran?.penutup || []).join('\n'));
        setMaAsesmenDiagnostik(ma.komponenInti?.asesmen?.diagnostik || '');
        setMaAsesmenFormatif(ma.komponenInti?.asesmen?.formatif || '');
        setMaAsesmenSumatif(ma.komponenInti?.asesmen?.sumatif || '');
        setMaPengayaanRemedial(ma.komponenInti?.pengayaanRemedial || '');
        setMaRefleksi(ma.komponenInti?.refleksi || '');
        setMaBahanBacaan(ma.lampiran?.bahanBacaan || '');
        setMaGlosarium(ma.lampiran?.glosarium || '');
        setMaDaftarPustaka(ma.lampiran?.daftarPustaka || '');
      }

      if (cd.lkpd) {
        const l = cd.lkpd;
        setLkpdJudulAktivitas(l.judulAktivitas || '');
        setLkpdTemaKBC(l.temaNilaiKBC || '');
        setLkpdPetunjukText((l.petunjukBelajar || []).join('\n'));
        setLkpdStimulusCerita(l.stimulusCerita || '');
        setLkpdArabicText(l.arabicSnippet?.text || '');
        setLkpdArabicArti(l.arabicSnippet?.arti || '');
        setLkpdLangkahText((l.langkahAktivitas || []).join('\n'));
        if (l.tugasSiswa && l.tugasSiswa.length > 0) {
          setLkpdTugasList(
            l.tugasSiswa.map((t, idx) => ({
              nomor: t.nomor || idx + 1,
              instruksi: t.instruksi || '',
              tipe: t.tipe || 'isian',
              opsiText: (t.opsi || []).join('\n')
            }))
          );
        }
        setLkpdRefleksiCinta(l.refleksiCinta || '');
        setLkpdRubrikNilai(l.rubrikNilai || '');
      }

      if (cd.dokumenLainnya) {
        const dl = cd.dokumenLainnya;
        setLainnyaSubKategori(dl.subKategori || SUB_KATEGORI_LAINNYA[0]);
        setLainnyaTujuan(dl.tujuanDokumen || '');
        setLainnyaUraian(dl.uraianIsi || '');
        if (dl.tabelBaris && dl.tabelBaris.length > 0) {
          setLainnyaRows(dl.tabelBaris);
        }
        setLainnyaTautan(dl.tautanBukti || '');
        setLainnyaLampiran(dl.lampiranFile || null);
      }
    } else {
      const initGrade = defaultGrade === 'all' ? '5' : defaultGrade;
      const initType = defaultDocType;
      setDocType(initType);
      setClassGrade(initGrade);
      setSemester(initType === 'prota' ? 'Tahunan' : 'Ganjil');
      setElementDomain("Al-Qur'an & Hadis");
      setTargetBab('');
      setAlokasiWaktuJP(12);
      setCatatanTambahan('');
      setLainnyaLampiran(null);
      setLainnyaTautan('');

      if (initialReferenceDoc) {
        setSelectedRefDoc(initialReferenceDoc);
        setShowRefViewer(true);
        applyReferenceDocToForm(initialReferenceDoc, initType);
      } else {
        setSelectedRefDoc(null);
        setShowRefViewer(false);
        const fase = getFaseByGrade(initGrade);
        const typeObj = DOC_TYPE_OPTIONS.find(t => t.id === initType);
        setTitle(
          `${(typeObj?.short || 'PERANGKAT AJAR').toUpperCase()} PAI & BUDI PEKERTI KELAS ${initGrade} (${fase})`
        );
        setSummary(
          `Dokumen ${typeObj?.label || 'Perangkat Ajar'} Kelas ${initGrade} (${fase}) Kurikulum Merdeka Berbasis Cinta (KBC).`
        );
      }
    }
  }, [isOpen, editingDoc, initialReferenceDoc, defaultGrade, defaultDocType]);

  // Quick upload reference file directly inside the Manual Form
  const handleQuickRefFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 6 * 1024 * 1024) {
      showToast('Ukuran berkas acuan maksimal 6 MB.', 'error');
      return;
    }

    setIsUploadingQuickRef(true);
    try {
      const parsed = await parseUploadedReferenceFile(file);
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]+/g, ' ').toUpperCase();
      const savedRef = StorageService.saveTeachingRefDoc({
        title: cleanName,
        docType,
        classGrade,
        semester,
        elementDomain,
        fileName: parsed.fileName,
        fileType: parsed.fileType,
        fileSizeKb: parsed.fileSizeKb,
        dataUrl: parsed.dataUrl,
        extractedText: parsed.extractedText,
        extractedRows: parsed.extractedRows
      });

      setAvailableRefs(StorageService.getTeachingRefDocs());
      setSelectedRefDoc(savedRef);
      setShowRefViewer(true);
      applyReferenceDocToForm(savedRef, docType);

      showToast(
        `Dokumen acuan "${savedRef.fileName}" berhasil diupload & dijadikan sandaran pengisian!`,
        'success'
      );
    } catch (err: any) {
      console.error(err);
      showToast('Gagal memproses file acuan: ' + (err?.message || 'Kesalahan format'), 'error');
    } finally {
      setIsUploadingQuickRef(false);
    }
  };

  const handleDocTypeChange = (newType: TeachingDocType) => {
    setDocType(newType);
    if (selectedRefDoc && !editingDoc) {
      applyReferenceDocToForm(selectedRefDoc, newType);
    } else if (!editingDoc) {
      const fase = getFaseByGrade(classGrade);
      const typeObj = DOC_TYPE_OPTIONS.find(t => t.id === newType);
      if (newType === 'prota') setSemester('Tahunan');
      setTitle(
        `${(typeObj?.short || 'PERANGKAT AJAR').toUpperCase()} PAI & BUDI PEKERTI KELAS ${classGrade} (${fase})`
      );
      setSummary(
        `Dokumen ${typeObj?.label || 'Perangkat Ajar'} Kelas ${classGrade} (${fase}) Kurikulum Merdeka Berbasis Cinta (KBC).`
      );
    }
  };

  const handleFillQuickTemplate = () => {
    if (selectedRefDoc) {
      applyReferenceDocToForm(selectedRefDoc, docType);
      showToast(
        `Form berhasil diisi otomatis berdasarkan Sandaran Dokumen Acuan "${selectedRefDoc.title}"!`,
        'success'
      );
      return;
    }

    const fase = getFaseByGrade(classGrade);
    const topicName = targetBab.trim() || `Materi Pokok PAI Kelas ${classGrade}`;

    if (docType === 'cp_atp') {
      setCapaianPembelajaran(
        `Pada akhir ${fase} (Kelas ${classGrade}), peserta didik mampu memahami dan mengamalkan nilai-nilai ${elementDomain} tentang "${topicName}" dengan penuh kesadaran, santun, serta membiasakan akhlak mulia berlandaskan Kurikulum Berbasis Cinta (KBC).`
      );
      setAtpRows([
        {
          no: 1,
          tujuan: `Memahami makna dan pesan pokok materi ${topicName} dengan benar.`,
          materi: topicName,
          elemen: elementDomain,
          alokasiJP: 4,
          profilPancasilaKBC: 'Beriman, Bertakwa & Kasih Sayang (KBC)',
          indikator: `Mampu menjelaskan 3 pesan utama dari materi ${topicName}.`
        },
        {
          no: 2,
          tujuan: `Mempraktikkan bacaan / pengamalan materi ${topicName} dalam kehidupan sehari-hari di sekolah dan rumah.`,
          materi: topicName,
          elemen: elementDomain,
          alokasiJP: 4,
          profilPancasilaKBC: 'Mandiri, Gotong Royong & Beradab',
          indikator: `Mampu mendemonstrasikan penerapan ${topicName} secara tertib dan santun.`
        }
      ]);
    } else if (docType === 'prota') {
      setProtaRows([
        {
          no: 1,
          semester: 'Ganjil',
          elemen: "Al-Qur'an & Hadis",
          materiPokok: topicName,
          tujuanPembelajaran: `Memahami dan melafalkan dalil pokok ${topicName} dengan tartil.`,
          alokasiJP: 12,
          keterangan: 'Semester Ganjil'
        },
        {
          no: 2,
          semester: 'Ganjil',
          elemen: 'Akidah & Akhlak',
          materiPokok: 'Meneladani Asmaul Husna & Adab Kasih Sayang Sesama',
          tujuanPembelajaran: 'Membiasakan sikap santun, jujur, dan peduli kepada teman sebaya.',
          alokasiJP: 12,
          keterangan: 'Semester Ganjil'
        },
        {
          no: 3,
          semester: 'Genap',
          elemen: 'Fikih & Ibadah',
          materiPokok: 'Tata Cara Ibadah Praktis & Ketertiban Berjamaah',
          tujuanPembelajaran: 'Melaksanakan ibadah harian dengan tertib dan gembira.',
          alokasiJP: 12,
          keterangan: 'Semester Genap'
        }
      ]);
    } else if (docType === 'promes') {
      setPromesRows([
        {
          no: 1,
          materiPokok: topicName,
          tujuanPembelajaran: `Memahami dan mempraktikkan kandungan materi ${topicName}.`,
          alokasiJP: 12,
          bulanPelaksanaan: semester === 'Genap' ? 'Januari - Februari' : 'Juli - Agustus',
          pekanEfektif: '4, 4, 4'
        },
        {
          no: 2,
          materiPokok: 'Pembiasaan Akhlak Terpuji & Kasih Sayang (KBC)',
          tujuanPembelajaran: 'Menerapkan adab sopan santun terhadap orang tua, guru, dan teman.',
          alokasiJP: 9,
          bulanPelaksanaan: semester === 'Genap' ? 'Maret' : 'September',
          pekanEfektif: '3, 3, 3'
        }
      ]);
    } else if (docType === 'kktp') {
      setKktpRows([
        {
          no: 1,
          tujuanPembelajaran: `Memahami dan mengamalkan materi "${topicName}" dengan benar dan santun.`,
          indikatorKetuntasan: `Ketepatan pemahaman konsep, kelancaran praktik, serta sikap kasih sayang dalam belajar.`,
          perluBimbingan: 'Belum mampu memahami konsep dasar meski telah dibimbing (Skor 0-60).',
          cukup: 'Mampu memahami sebagian materi namun masih memerlukan arahan guru (Skor 61-75).',
          baik: 'Mampu memahami dan mempraktikkan materi dengan lancar dan mandiri (Skor 76-88).',
          sangatBaik: 'Sangat menguasai materi dan mampu membimbing teman sebaya dengan santun (Skor 89-100).',
          tindakLanjutKBC: 'Pendampingan personal penuh kasih sayang dan tutor sebaya.'
        }
      ]);
    } else if (docType === 'modul_ajar') {
      setMaKompetensiAwal(`Peserta didik memiliki pengetahuan awal dasar mengenai ${topicName} dan antusias dalam belajar.`);
      setMaTujuanPembelajaranText(
        `Peserta didik mampu memahami konsep pokok ${topicName} dengan benar.\nPeserta didik mampu mempraktikkan nilai kasih sayang (KBC) dari materi ${topicName} dalam keseharian.`
      );
      setMaPemahamanBermakna(
        `Mempelajari ${topicName} menumbuhkan rasa cinta kepada Allah SWT, Rasul-Nya, dan kasih sayang kepada sesama teman.`
      );
      setMaPertanyaanPemantikText(
        `Mengapa kita perlu memahami dan mengamalkan ${topicName}?\nBagaimana cara kita menerapkan kebaikan tersebut di sekolah dan di rumah?`
      );
      setMaPendahuluanText(
        `Guru membuka pembelajaran dengan salam hangat, sapaan kasih sayang, dan doa bersama.\nMengecek kehadiran siswa dan melakukan tadarus surah pendek bersama.\nGuru menyampaikan apersepsi dan tujuan pembelajaran materi ${topicName}.`
      );
      setMaKegiatanIntiText(
        `Peserta didik mengamati penjelasan/media pembelajaran tentang ${topicName}.\nPeserta didik berdiskusi secara berkelompok dengan santun dan saling menghargai.\nPeserta didik mempresentasikan hasil kerja kelompok dan mempraktikkan nilai kebaikan.\nGuru memberikan apresiasi dan penguatan materi berbasis Kurikulum Berbasis Cinta (KBC).`
      );
      setMaPenutupText(
        `Peserta didik bersama guru menyimpulkan pembelajaran hari ini.\nMelakukan refleksi perasaan dan rencana aksi kebaikan di rumah.\nMenutup kelas dengan hamdalah dan doa penutup majelis.`
      );
      setMaBahanBacaan(`Ringkasan materi ${topicName} dari Buku Teks PAI & Budi Pekerti Kelas ${classGrade}.`);
      setMaGlosarium(`KBC: Kurikulum Berbasis Cinta; Mahabbah: Kasih sayang; Ta'awun: Tolong-menolong.`);
    } else if (docType === 'lkpd') {
      setLkpdJudulAktivitas(`Lembar Aktivitas Siswa: ${topicName}`);
      setLkpdStimulusCerita(
        `Di sekolah, anak-anak kelas ${classGrade} sedang belajar tentang ${topicName} dengan penuh semangat dan saling membantu teman yang kesulitan.`
      );
      setLkpdTugasList([
        {
          nomor: 1,
          instruksi: `Jelaskan 3 hikmah atau manfaat utama dari mempelajari ${topicName}!`,
          tipe: 'isian',
          opsiText: ''
        },
        {
          nomor: 2,
          instruksi: `Tuliskan contoh perilaku baik yang sesuai dengan materi ${topicName} ketika berada di sekolah!`,
          tipe: 'isian',
          opsiText: ''
        }
      ]);
    } else if (docType === 'lainnya') {
      setLainnyaTujuan(`Sebagai pedoman pelaksanaan dan dokumentasi ${lainnyaSubKategori} Kelas ${classGrade}.`);
      setLainnyaUraian(
        `Dokumen ${lainnyaSubKategori} ini disusun secara manual oleh Guru PAI & Budi Pekerti untuk Kelas ${classGrade} (${fase}) Semester ${semester} dengan mengacu pada Kurikulum Merdeka dan pendekatan Kurikulum Berbasis Cinta (KBC).`
      );
      setLainnyaRows([
        {
          no: 1,
          aspek: `Komponen Utama (${elementDomain})`,
          uraian: `Pelaksanaan dan pemetaan materi ${topicName}.`,
          keterangan: `${alokasiWaktuJP} JP`
        },
        {
          no: 2,
          aspek: 'Evaluasi & Tindak Lanjut',
          uraian: 'Penilaian autentik dan pembinaan akhlak mulia siswa.',
          keterangan: 'Terlaksana'
        }
      ]);
    }

    showToast('Contoh kerangka dasar berhasil diisi! Silakan sesuaikan isinya.', 'info');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      showToast('Ukuran file maksimal 4 MB.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setLainnyaLampiran({
        fileName: file.name,
        fileType: file.type || 'application/octet-stream',
        dataUrl: reader.result as string
      });
      showToast(`File "${file.name}" berhasil dilampirkan!`, 'success');
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('Judul Perangkat Ajar wajib diisi!', 'error');
      return;
    }

    const fase = getFaseByGrade(classGrade);
    const schoolName = appSettings.schoolName || teacherProfile.schoolName || 'SDN Ciketing Udik 2 Bantargebang';
    const teacherName = teacherProfile.fullName || 'Guru PAI & Budi Pekerti';
    const teacherNip = teacherProfile.nip || '-';
    const principalName = appSettings.principalName || 'Kepala Sekolah';
    const principalNip = appSettings.principalNip || '-';
    const academicYear = appSettings.academicYear || '2026/2027';

    const contentData: TeachingDocument['contentData'] = {
      catatanTambahan: catatanTambahan.trim() || undefined,
      sandaranAcuan: selectedRefDoc
        ? {
            referenceId: selectedRefDoc.id,
            referenceTitle: selectedRefDoc.title,
            fileName: selectedRefDoc.fileName,
            fileType: selectedRefDoc.fileType,
            dataUrl: selectedRefDoc.dataUrl,
            ringkasanAcuan: selectedRefDoc.extractedText.substring(0, 1200)
          }
        : undefined
    };

    if (docType === 'cp_atp') {
      contentData.capaianPembelajaran =
        capaianPembelajaran.trim() ||
        `Capaian Pembelajaran PAI & Budi Pekerti Kelas ${classGrade} (${fase}) Elemen ${elementDomain}.`;
      contentData.alurTujuanPembelajaran = atpRows
        .filter(r => r.tujuan.trim() || r.materi.trim())
        .map((r, idx) => ({
          no: idx + 1,
          tujuan: r.tujuan.trim() || `Tujuan Pembelajaran ${idx + 1}`,
          materi: r.materi.trim() || targetBab || `Materi Kelas ${classGrade}`,
          elemen: r.elemen || elementDomain,
          alokasiJP: Number(r.alokasiJP) || 4,
          profilPancasilaKBC: r.profilPancasilaKBC.trim() || 'Beriman, Bertakwa & Kasih Sayang (KBC)',
          indikator: r.indikator.trim() || '-'
        }));
      if (contentData.alurTujuanPembelajaran.length === 0) {
        showToast('Minimal isi 1 baris Tujuan Pembelajaran (ATP)!', 'error');
        return;
      }
    } else if (docType === 'prota') {
      const validProta = protaRows
        .filter(r => r.materiPokok.trim() || r.tujuanPembelajaran.trim())
        .map((r, idx) => ({
          no: idx + 1,
          semester: r.semester,
          elemen: r.elemen || elementDomain,
          materiPokok: r.materiPokok.trim() || `Bab ${idx + 1}`,
          tujuanPembelajaran: r.tujuanPembelajaran.trim() || '-',
          alokasiJP: Number(r.alokasiJP) || 9,
          keterangan: r.keterangan.trim() || '-'
        }));
      if (validProta.length === 0) {
        showToast('Minimal isi 1 baris Materi Pokok pada Program Tahunan (Prota)!', 'error');
        return;
      }
      const jpGanjil = validProta
        .filter(r => r.semester === 'Ganjil')
        .reduce((acc, cur) => acc + cur.alokasiJP, 0);
      const jpGenap = validProta
        .filter(r => r.semester === 'Genap')
        .reduce((acc, cur) => acc + cur.alokasiJP, 0);
      contentData.protaItems = validProta;
      contentData.totalJPGanjil = jpGanjil;
      contentData.totalJPGenap = jpGenap;
      contentData.totalJPTahunan = jpGanjil + jpGenap;
    } else if (docType === 'promes') {
      const validPromes = promesRows
        .filter(r => r.materiPokok.trim() || r.tujuanPembelajaran.trim())
        .map((r, idx) => {
          const pekanNums = r.pekanEfektif
            .split(',')
            .map(s => Number(s.trim()))
            .filter(n => !isNaN(n) && n > 0);
          return {
            no: idx + 1,
            materiPokok: r.materiPokok.trim() || `Materi ${idx + 1}`,
            tujuanPembelajaran: r.tujuanPembelajaran.trim() || '-',
            alokasiJP: Number(r.alokasiJP) || 9,
            distribusiBulan: [
              {
                bulan: r.bulanPelaksanaan.trim() || 'Juli - Agustus',
                minggu: pekanNums.length > 0 ? pekanNums : [Number(r.alokasiJP) || 9]
              }
            ]
          };
        });
      if (validPromes.length === 0) {
        showToast('Minimal isi 1 baris Materi pada Program Semester (Promes)!', 'error');
        return;
      }
      contentData.promesItems = validPromes;
    } else if (docType === 'kktp') {
      const validKktp = kktpRows
        .filter(r => r.tujuanPembelajaran.trim() || r.indikatorKetuntasan.trim())
        .map((r, idx) => ({
          no: idx + 1,
          tujuanPembelajaran: r.tujuanPembelajaran.trim() || `Tujuan Pembelajaran ${idx + 1}`,
          indikatorKetuntasan: r.indikatorKetuntasan.trim() || '-',
          kriteria: {
            perluBimbingan: r.perluBimbingan.trim() || 'Perlu bimbingan dasar (0-60)',
            cukup: r.cukup.trim() || 'Cukup menguasai (61-75)',
            baik: r.baik.trim() || 'Baik dan tuntas (76-88)',
            sangatBaik: r.sangatBaik.trim() || 'Sangat baik & teladan (89-100)'
          },
          tindakLanjutKBC: r.tindakLanjutKBC.trim() || 'Pendampingan penuh kasih sayang (KBC)'
        }));
      if (validKktp.length === 0) {
        showToast('Minimal isi 1 baris Tujuan Pembelajaran & Kriteria pada KKTP!', 'error');
        return;
      }
      contentData.kktpItems = validKktp;
    } else if (docType === 'modul_ajar') {
      const splitLines = (txt: string, fallback: string[]) => {
        const arr = txt
          .split('\n')
          .map(s => s.trim())
          .filter(Boolean);
        return arr.length > 0 ? arr : fallback;
      };
      contentData.modulAjar = {
        identitas: {
          penyusun: teacherName,
          instansi: schoolName,
          faseKelas: `${fase} / Kelas ${classGrade}`,
          semester: semester,
          materiPokok: targetBab.trim() || title.trim(),
          alokasiWaktu: maAlokasiWaktuText.trim() || `${alokasiWaktuJP} JP`
        },
        kompetensiAwal:
          maKompetensiAwal.trim() ||
          `Peserta didik memiliki pengetahuan dasar terkait materi ${targetBab || title}.`,
        profilPelajarPancasilaKBC: splitLines(maProfilPancasilaText, [
          'Beriman, Bertakwa kepada Tuhan YME, dan Berakhlak Mulia',
          'Gotong Royong & Kasih Sayang (KBC)'
        ]),
        saranaPrasarana: splitLines(maSaranaPrasaranaText, [
          'Buku Teks PAI & Budi Pekerti',
          "Al-Qur'an / Juz Amma",
          'LKPD'
        ]),
        targetPesertaDidik: maTargetPesertaDidik.trim() || `Peserta Didik Kelas ${classGrade}`,
        modelPembelajaran: maModelPembelajaran.trim() || 'Problem Based Learning (PBL) & KBC',
        komponenInti: {
          tujuanPembelajaran: splitLines(maTujuanPembelajaranText, [
            `Memahami dan mengamalkan nilai-nilai materi ${targetBab || title}.`
          ]),
          pemahamanBermakna:
            maPemahamanBermakna.trim() ||
            'Mengamalkan ajaran Islam dengan hati yang penuh cinta kasih kepada Allah SWT dan sesama.',
          pertanyaanPemantik: splitLines(maPertanyaanPemantikText, [
            'Mengapa kita harus berbuat baik dan menyayangi sesama?'
          ]),
          kegiatanPembelajaran: {
            pendahuluan: splitLines(maPendahuluanText, [
              'Guru membuka kelas dengan salam, doa bersama, dan sapaan hangat.',
              'Guru menyampaikan tujuan pembelajaran.'
            ]),
            kegiatanInti: splitLines(maKegiatanIntiText, [
              'Peserta didik menyimak penjelasan materi pokok.',
              'Peserta didik berdiskusi kelompok dan mengerjakan LKPD.',
              'Guru memberikan penguatan materi berbasis KBC.'
            ]),
            penutup: splitLines(maPenutupText, [
              'Siswa dan guru menyimpulkan materi pembelajaran.',
              'Refleksi dan doa penutup majelis.'
            ])
          },
          asesmen: {
            diagnostik: maAsesmenDiagnostik.trim() || 'Tanya jawab awal pembelajaran.',
            formatif: maAsesmenFormatif.trim() || 'Observasi sikap dan unjuk kerja.',
            sumatif: maAsesmenSumatif.trim() || 'Evaluasi tertulis akhir bab.'
          },
          pengayaanRemedial:
            maPengayaanRemedial.trim() || 'Pendampingan remedial ramah anak & pengayaan.',
          refleksi: maRefleksi.trim() || 'Refleksi pembelajaran guru dan peserta didik.'
        },
        lampiran: {
          bahanBacaan: maBahanBacaan.trim() || `Buku Siswa PAI Kelas ${classGrade}.`,
          glosarium: maGlosarium.trim() || 'KBC (Kurikulum Berbasis Cinta).',
          daftarPustaka:
            maDaftarPustaka.trim() || 'Kemendikbudristek RI & Kementerian Agama RI.'
        }
      };
    } else if (docType === 'lkpd') {
      const splitLines = (txt: string, fallback: string[]) => {
        const arr = txt
          .split('\n')
          .map(s => s.trim())
          .filter(Boolean);
        return arr.length > 0 ? arr : fallback;
      };
      const tugasCleaned = lkpdTugasList
        .filter(t => t.instruksi.trim())
        .map((t, idx) => {
          const opsiArr = t.opsiText
            .split('\n')
            .map(s => s.trim())
            .filter(Boolean);
          return {
            nomor: idx + 1,
            instruksi: t.instruksi.trim(),
            tipe: t.tipe,
            opsi: t.tipe !== 'isian' && opsiArr.length > 0 ? opsiArr : undefined
          };
        });

      contentData.lkpd = {
        judulAktivitas: lkpdJudulAktivitas.trim() || title.trim(),
        temaNilaiKBC: lkpdTemaKBC.trim() || 'Menebar Kasih Sayang & Akhlak Mulia',
        petunjukBelajar: splitLines(lkpdPetunjukText, [
          'Bacalah Basmalah sebelum mengerjakan tugas.',
          'Kerjakan soal dengan jujur dan teliti.'
        ]),
        stimulusCerita: lkpdStimulusCerita.trim(),
        arabicSnippet: lkpdArabicText.trim()
          ? {
              text: lkpdArabicText.trim(),
              arti: lkpdArabicArti.trim() || '-'
            }
          : undefined,
        langkahAktivitas: splitLines(lkpdLangkahText, [
          '1. Bacalah materi dan stimulus dengan cermat.',
          '2. Jawablah pertanyaan di bawah ini.'
        ]),
        tugasSiswa:
          tugasCleaned.length > 0
            ? tugasCleaned
            : [
                {
                  nomor: 1,
                  instruksi: `Jelaskan pesan kebaikan dari materi ${targetBab || title}!`,
                  tipe: 'isian'
                }
              ],
        refleksiCinta:
          lkpdRefleksiCinta.trim() ||
          'Kebaikan apa yang sudah kamu lakukan hari ini untuk sahabatmu?',
        rubrikNilai: lkpdRubrikNilai.trim() || 'Skor Maksimal: 100.'
      };
    } else if (docType === 'lainnya') {
      const cleanedRows = lainnyaRows
        .filter(r => r.aspek.trim() || r.uraian.trim())
        .map((r, idx) => ({
          no: idx + 1,
          aspek: r.aspek.trim() || `Komponen ${idx + 1}`,
          uraian: r.uraian.trim() || '-',
          keterangan: r.keterangan.trim() || '-'
        }));

      contentData.dokumenLainnya = {
        subKategori: lainnyaSubKategori.trim() || 'Perangkat Ajar Pendukung PAI',
        tujuanDokumen: lainnyaTujuan.trim() || summary.trim(),
        uraianIsi: lainnyaUraian.trim() || '-',
        tabelBaris: cleanedRows.length > 0 ? cleanedRows : undefined,
        tautanBukti: lainnyaTautan.trim() || undefined,
        lampiranFile: lainnyaLampiran || undefined
      };
    }

    onSave({
      id: editingDoc?.id,
      docType,
      classGrade,
      semester,
      academicYear,
      title: title.trim(),
      summary:
        summary.trim() ||
        `Dokumen Perangkat Ajar PAI & Budi Pekerti Kelas ${classGrade} (${fase}) Semester ${semester}.`,
      schoolName,
      teacherName,
      teacherNip,
      principalName,
      principalNip,
      regulasi: REGULASI_RESMI_BKPDM,
      meta: {
        fase,
        elementDomain,
        alokasiWaktuJP: Number(alokasiWaktuJP) || 12,
        targetBab: targetBab.trim() || title.trim(),
        pendekatan: 'Kurikulum Berbasis Cinta (KBC)',
        regulasi: REGULASI_RESMI_BKPDM
      },
      contentData
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md">
      <div className="glass-strong rounded-3xl w-full max-w-4xl max-h-[94vh] flex flex-col border border-emerald-500/30 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                {editingDoc ? 'Edit Manual Perangkat Ajar' : 'Input Manual Perangkat Ajar PAI'}
              </h3>
              <p className="text-[11px] text-slate-400">
                Susun atau sunting manual CP/ATP, Prota, Promes, KKTP, Modul Ajar, LKPD, &amp; Dokumen Lainnya
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleFillQuickTemplate}
              className="px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Isi contoh kerangka atau tarik dari dokumen acuan"
            >
              <Wand2 className="w-3.5 h-3.5" />
              {selectedRefDoc ? 'Isi dari Dokumen Acuan' : 'Isi Contoh Kerangka'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5 scrollbar-thin">
          {/* =================================================================== */}
          {/* PANEL SANDARAN DOKUMEN ACUAN / REFERENSI (CP, ATP, PROTA, DLL.)     */}
          {/* =================================================================== */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900/90 to-indigo-950/70 border border-cyan-500/35 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider">
                  Sandaran Dokumen Acuan / Referensi (CP, ATP, Prota, Silabus)
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <label className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all">
                  <Upload className="w-3.5 h-3.5" />
                  {isUploadingQuickRef ? 'Membaca File...' : '+ Upload Dokumen Acuan di Sini'}
                  <input
                    type="file"
                    accept=".pdf,.docx,.doc,.xlsx,.xls,.csv,.txt,.md,.json,.html"
                    onChange={handleQuickRefFileUpload}
                    className="hidden"
                  />
                </label>

                {selectedRefDoc && (
                  <button
                    type="button"
                    onClick={() => setShowRefViewer(!showRefViewer)}
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-cyan-400" />
                    {showRefViewer ? 'Sembunyikan Acuan' : 'Lihat Isi Acuan'}
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
              <div className="sm:col-span-8">
                <select
                  value={selectedRefDoc?.id || ''}
                  onChange={e => {
                    const id = e.target.value;
                    if (!id) {
                      setSelectedRefDoc(null);
                      setShowRefViewer(false);
                      return;
                    }
                    const found = availableRefs.find(r => r.id === id) || null;
                    setSelectedRefDoc(found);
                    if (found) {
                      setShowRefViewer(true);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-white text-xs font-semibold"
                >
                  <option value="">
                    -- Pilih Dokumen Acuan / CP yang Sudah Diupload ({availableRefs.length} Tersedia) --
                  </option>
                  {availableRefs.map(r => (
                    <option key={r.id} value={r.id}>
                      [{r.docType.toUpperCase()} - Kelas {r.classGrade}] {r.title} ({r.fileName})
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-4 flex items-center gap-2">
                <button
                  type="button"
                  disabled={!selectedRefDoc}
                  onClick={() => {
                    if (selectedRefDoc) {
                      applyReferenceDocToForm(selectedRefDoc, docType);
                      showToast(
                        `Kolom ${docType.toUpperCase()} berhasil diisi mengacu pada "${selectedRefDoc.title}"!`,
                        'success'
                      );
                    }
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Tarik Isi dari Acuan Ini
                </button>
              </div>
            </div>

            {/* Collapsible Split Viewer of the Active Reference Document */}
            {selectedRefDoc && showRefViewer && (
              <div className="p-3.5 rounded-xl bg-slate-950/95 border border-cyan-500/30 space-y-3 text-xs">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <div>
                    <span className="font-bold text-cyan-300">
                      📌 Sandaran Aktif: {selectedRefDoc.title}
                    </span>
                    <span className="text-[11px] text-slate-400 ml-2">
                      ({selectedRefDoc.fileName})
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                    Bisa Disalin / Dijadikan Acuan Langsung
                  </span>
                </div>

                {selectedRefDoc.dataUrl &&
                  selectedRefDoc.fileName.toLowerCase().endsWith('.pdf') && (
                    <iframe
                      src={selectedRefDoc.dataUrl}
                      title={selectedRefDoc.title}
                      className="w-full h-60 rounded-lg border border-white/15 bg-white"
                    />
                  )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                      Teks Lengkap Dokumen Acuan:
                    </span>
                    <div className="max-h-40 overflow-y-auto p-2.5 rounded-lg bg-slate-900 border border-white/10 text-slate-200 whitespace-pre-line font-mono text-[11px]">
                      {selectedRefDoc.extractedText}
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                      Butir Kompetensi / Materi Acuan ({selectedRefDoc.extractedRows?.length || 0} Poin):
                    </span>
                    <div className="max-h-40 overflow-y-auto p-2.5 rounded-lg bg-slate-900 border border-white/10 space-y-1.5 text-[11px]">
                      {(selectedRefDoc.extractedRows || []).map((r, i) => (
                        <div key={i} className="pb-1.5 border-b border-white/5 last:border-none">
                          <b className="text-cyan-300">{i + 1}. {r.col1}</b>
                          {r.col2 && r.col2 !== r.col1 && (
                            <p className="text-slate-400 text-[10px]">Materi: {r.col2} ({r.col3})</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick Type Selector Pills */}
          <div>
            <label className="text-xs font-bold text-emerald-300 uppercase tracking-wider block mb-2">
              1. Pilih Jenis Perangkat Ajar yang Akan Diinput Manual:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
              {DOC_TYPE_OPTIONS.map(opt => {
                const active = docType === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleDocTypeChange(opt.id)}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border text-center transition-all cursor-pointer ${
                      active
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white border-emerald-400 shadow-md shadow-emerald-500/20'
                        : 'bg-slate-900/80 hover:bg-white/10 text-slate-300 border-white/10'
                    }`}
                  >
                    {opt.short}
                  </button>
                );
              })}
            </div>
          </div>

          {/* General Metadata Section */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 space-y-4">
            <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" /> 2. Identitas Umum Dokumen
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Tingkat Kelas &amp; Fase
                </label>
                <select
                  value={classGrade}
                  onChange={e => setClassGrade(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                >
                  <option value="1">Kelas 1 (Fase A)</option>
                  <option value="2">Kelas 2 (Fase A)</option>
                  <option value="3">Kelas 3 (Fase B)</option>
                  <option value="4">Kelas 4 (Fase B)</option>
                  <option value="5">Kelas 5 (Fase C)</option>
                  <option value="6">Kelas 6 (Fase C)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Semester
                </label>
                <select
                  value={semester}
                  onChange={e => setSemester(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                >
                  <option value="Ganjil">Semester Ganjil</option>
                  <option value="Genap">Semester Genap</option>
                  <option value="Tahunan">Tahunan (1 Tahun)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Elemen PAI
                </label>
                <select
                  value={elementDomain}
                  onChange={e => setElementDomain(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                >
                  <option value="Al-Qur'an & Hadis">Al-Qur'an &amp; Hadis</option>
                  <option value="Akidah">Akidah</option>
                  <option value="Akhlak">Akhlak</option>
                  <option value="Fikih">Fikih</option>
                  <option value="Sejarah Peradaban Islam">Sejarah Peradaban Islam</option>
                  <option value="Semua Elemen PAI">Semua Elemen PAI (Lengkap)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Total Alokasi (JP)
                </label>
                <input
                  type="number"
                  min={1}
                  value={alokasiWaktuJP}
                  onChange={e => setAlokasiWaktuJP(Number(e.target.value) || 12)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Judul Dokumen Perangkat Ajar <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="Contoh: ALUR TUJUAN PEMBELAJARAN (ATP) PAI KELAS 5"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs sm:text-sm font-semibold focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Materi Pokok / Bab Target
                </label>
                <input
                  type="text"
                  value={targetBab}
                  onChange={e => setTargetBab(e.target.value)}
                  placeholder="Contoh: Bab 1 Menyayangi Anak Yatim (QS. Al-Ma'un)"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                Ringkasan / Deskripsi Singkat Dokumen
              </label>
              <input
                type="text"
                value={summary}
                onChange={e => setSummary(e.target.value)}
                placeholder="Ringkasan singkat tujuan perangkat ajar ini..."
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* =================================================================== */}
          {/* SPECIFIC FORM BY DOCUMENT TYPE                                      */}
          {/* =================================================================== */}

          {/* 1. CP / ATP FORM */}
          {docType === 'cp_atp' && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-blue-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-blue-300 uppercase tracking-wider">
                  3. Isi Manual Capaian Pembelajaran (CP) &amp; Alur Tujuan Pembelajaran (ATP)
                </h4>
                <button
                  type="button"
                  onClick={() =>
                    setAtpRows(prev => [
                      ...prev,
                      {
                        no: prev.length + 1,
                        tujuan: '',
                        materi: targetBab || '',
                        elemen: elementDomain,
                        alokasiJP: 4,
                        profilPancasilaKBC: 'Beriman, Bertakwa & Kasih Sayang (KBC)',
                        indikator: ''
                      }
                    ])
                  }
                  className="px-3 py-1.5 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-blue-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> + Tambah Baris ATP
                </button>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Narasi Capaian Pembelajaran (CP) Fase / Elemen
                </label>
                <textarea
                  rows={3}
                  value={capaianPembelajaran}
                  onChange={e => setCapaianPembelajaran(e.target.value)}
                  placeholder="Tuliskan rumusan Capaian Pembelajaran (CP) pada fase dan kelas ini..."
                  className="w-full p-3 rounded-xl bg-slate-950 border border-white/15 text-white text-xs leading-relaxed"
                />
              </div>

              <div className="space-y-3">
                <label className="text-[11px] font-bold text-slate-300 uppercase block">
                  Daftar Alur Tujuan Pembelajaran (ATP) ({atpRows.length} Baris)
                </label>
                {atpRows.map((row, index) => (
                  <div
                    key={index}
                    className="p-3.5 rounded-xl bg-slate-950/90 border border-white/10 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-blue-400">
                        Alur Tujuan Pembelajaran (ATP) #{index + 1}
                      </span>
                      {atpRows.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setAtpRows(prev => prev.filter((_, i) => i !== index))}
                          className="text-rose-400 hover:text-rose-300 text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Hapus Baris
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Tujuan Pembelajaran (TP) *
                        </label>
                        <input
                          type="text"
                          value={row.tujuan}
                          onChange={e => {
                            const val = e.target.value;
                            setAtpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, tujuan: val } : r))
                            );
                          }}
                          placeholder="Contoh: Peserta didik mampu membaca QS. Al-Ma'un dengan tartil..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Materi Pokok / Bab
                        </label>
                        <input
                          type="text"
                          value={row.materi}
                          onChange={e => {
                            const val = e.target.value;
                            setAtpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, materi: val } : r))
                            );
                          }}
                          placeholder="Materi pokok..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Indikator Ketercapaian
                        </label>
                        <input
                          type="text"
                          value={row.indikator}
                          onChange={e => {
                            const val = e.target.value;
                            setAtpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, indikator: val } : r))
                            );
                          }}
                          placeholder="Indikator ketercapaian tujuan..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Profil Pelajar &amp; Nilai KBC
                        </label>
                        <input
                          type="text"
                          value={row.profilPancasilaKBC}
                          onChange={e => {
                            const val = e.target.value;
                            setAtpRows(prev =>
                              prev.map((r, i) =>
                                i === index ? { ...r, profilPancasilaKBC: val } : r
                              )
                            );
                          }}
                          placeholder="Beriman, Kasih Sayang..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Alokasi Waktu (JP)
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={row.alokasiJP}
                          onChange={e => {
                            const val = Number(e.target.value) || 4;
                            setAtpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, alokasiJP: val } : r))
                            );
                          }}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. PROTA FORM */}
          {docType === 'prota' && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-emerald-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                  3. Isi Manual Program Tahunan (Prota)
                </h4>
                <button
                  type="button"
                  onClick={() =>
                    setProtaRows(prev => [
                      ...prev,
                      {
                        no: prev.length + 1,
                        semester: 'Ganjil',
                        elemen: elementDomain,
                        materiPokok: '',
                        tujuanPembelajaran: '',
                        alokasiJP: 12,
                        keterangan: ''
                      }
                    ])
                  }
                  className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> + Tambah Bab / Materi Prota
                </button>
              </div>

              <div className="space-y-3">
                {protaRows.map((row, index) => (
                  <div
                    key={index}
                    className="p-3.5 rounded-xl bg-slate-950/90 border border-white/10 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-400">
                        Baris Prota #{index + 1}
                      </span>
                      {protaRows.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setProtaRows(prev => prev.filter((_, i) => i !== index))}
                          className="text-rose-400 hover:text-rose-300 text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Hapus Baris
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Semester</label>
                        <select
                          value={row.semester}
                          onChange={e => {
                            const val = e.target.value as 'Ganjil' | 'Genap';
                            setProtaRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, semester: val } : r))
                            );
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        >
                          <option value="Ganjil">Semester Ganjil</option>
                          <option value="Genap">Semester Genap</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Materi Pokok / Judul Bab *
                        </label>
                        <input
                          type="text"
                          value={row.materiPokok}
                          onChange={e => {
                            const val = e.target.value;
                            setProtaRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, materiPokok: val } : r))
                            );
                          }}
                          placeholder="Contoh: Bab 1 Menyayangi Anak Yatim"
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Alokasi Waktu (JP)
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={row.alokasiJP}
                          onChange={e => {
                            const val = Number(e.target.value) || 9;
                            setProtaRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, alokasiJP: val } : r))
                            );
                          }}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Tujuan Pembelajaran
                        </label>
                        <input
                          type="text"
                          value={row.tujuanPembelajaran}
                          onChange={e => {
                            const val = e.target.value;
                            setProtaRows(prev =>
                              prev.map((r, i) =>
                                i === index ? { ...r, tujuanPembelajaran: val } : r
                              )
                            );
                          }}
                          placeholder="Tujuan pembelajaran bab ini..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Keterangan
                        </label>
                        <input
                          type="text"
                          value={row.keterangan}
                          onChange={e => {
                            const val = e.target.value;
                            setProtaRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, keterangan: val } : r))
                            );
                          }}
                          placeholder="Contoh: Tuntas Sumatif 1"
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. PROMES FORM */}
          {docType === 'promes' && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-cyan-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider">
                  3. Isi Manual Program Semester (Promes)
                </h4>
                <button
                  type="button"
                  onClick={() =>
                    setPromesRows(prev => [
                      ...prev,
                      {
                        no: prev.length + 1,
                        materiPokok: '',
                        tujuanPembelajaran: '',
                        alokasiJP: 12,
                        bulanPelaksanaan: semester === 'Genap' ? 'Januari - Februari' : 'Juli - Agustus',
                        pekanEfektif: '4, 4, 4'
                      }
                    ])
                  }
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> + Tambah Baris Promes
                </button>
              </div>

              <div className="space-y-3">
                {promesRows.map((row, index) => (
                  <div
                    key={index}
                    className="p-3.5 rounded-xl bg-slate-950/90 border border-white/10 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-400">
                        Baris Promes #{index + 1}
                      </span>
                      {promesRows.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setPromesRows(prev => prev.filter((_, i) => i !== index))}
                          className="text-rose-400 hover:text-rose-300 text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Hapus Baris
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Materi Pokok / Sub-Bab *
                        </label>
                        <input
                          type="text"
                          value={row.materiPokok}
                          onChange={e => {
                            const val = e.target.value;
                            setPromesRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, materiPokok: val } : r))
                            );
                          }}
                          placeholder="Materi pokok..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Tujuan Pembelajaran
                        </label>
                        <input
                          type="text"
                          value={row.tujuanPembelajaran}
                          onChange={e => {
                            const val = e.target.value;
                            setPromesRows(prev =>
                              prev.map((r, i) =>
                                i === index ? { ...r, tujuanPembelajaran: val } : r
                              )
                            );
                          }}
                          placeholder="Tujuan pembelajaran..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Alokasi Waktu (JP)
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={row.alokasiJP}
                          onChange={e => {
                            const val = Number(e.target.value) || 9;
                            setPromesRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, alokasiJP: val } : r))
                            );
                          }}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Bulan Pelaksanaan
                        </label>
                        <input
                          type="text"
                          value={row.bulanPelaksanaan}
                          onChange={e => {
                            const val = e.target.value;
                            setPromesRows(prev =>
                              prev.map((r, i) =>
                                i === index ? { ...r, bulanPelaksanaan: val } : r
                              )
                            );
                          }}
                          placeholder="Contoh: Juli - Agustus"
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Rincian JP per Pekan (Pisahkan Koma)
                        </label>
                        <input
                          type="text"
                          value={row.pekanEfektif}
                          onChange={e => {
                            const val = e.target.value;
                            setPromesRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, pekanEfektif: val } : r))
                            );
                          }}
                          placeholder="Contoh: 4, 4, 4"
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. KKTP FORM */}
          {docType === 'kktp' && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-amber-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  3. Isi Manual Rubrik KKTP (Kriteria Ketercapaian Tujuan Pembelajaran)
                </h4>
                <button
                  type="button"
                  onClick={() =>
                    setKktpRows(prev => [
                      ...prev,
                      {
                        no: prev.length + 1,
                        tujuanPembelajaran: '',
                        indikatorKetuntasan: '',
                        perluBimbingan: 'Belum mencapai ketuntasan dasar (0-60).',
                        cukup: 'Mencapai sebagian indikator dasar (61-75).',
                        baik: 'Mencapai ketuntasan indikator dengan baik (76-88).',
                        sangatBaik: 'Sangat mahir dan menjadi teladan (89-100).',
                        tindakLanjutKBC: 'Pendampingan ramah anak & motivasi KBC.'
                      }
                    ])
                  }
                  className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> + Tambah TP / Rubrik KKTP
                </button>
              </div>

              <div className="space-y-4">
                {kktpRows.map((row, index) => (
                  <div
                    key={index}
                    className="p-4 rounded-xl bg-slate-950/90 border border-white/10 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-400">
                        Instrumen KKTP #{index + 1}
                      </span>
                      {kktpRows.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setKktpRows(prev => prev.filter((_, i) => i !== index))}
                          className="text-rose-400 hover:text-rose-300 text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Hapus
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Tujuan Pembelajaran (TP) *
                        </label>
                        <input
                          type="text"
                          value={row.tujuanPembelajaran}
                          onChange={e => {
                            const val = e.target.value;
                            setKktpRows(prev =>
                              prev.map((r, i) =>
                                i === index ? { ...r, tujuanPembelajaran: val } : r
                              )
                            );
                          }}
                          placeholder="Rumusan Tujuan Pembelajaran..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Indikator Ketercapaian
                        </label>
                        <input
                          type="text"
                          value={row.indikatorKetuntasan}
                          onChange={e => {
                            const val = e.target.value;
                            setKktpRows(prev =>
                              prev.map((r, i) =>
                                i === index ? { ...r, indikatorKetuntasan: val } : r
                              )
                            );
                          }}
                          placeholder="Indikator asesmen..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                      <div>
                        <label className="text-[10px] text-rose-300 font-bold block mb-0.5">
                          Perlu Bimbingan (0-60)
                        </label>
                        <textarea
                          rows={2}
                          value={row.perluBimbingan}
                          onChange={e => {
                            const val = e.target.value;
                            setKktpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, perluBimbingan: val } : r))
                            );
                          }}
                          className="w-full p-2 rounded-lg bg-slate-900 border border-rose-500/20 text-white text-[11px]"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-amber-300 font-bold block mb-0.5">
                          Cukup (61-75)
                        </label>
                        <textarea
                          rows={2}
                          value={row.cukup}
                          onChange={e => {
                            const val = e.target.value;
                            setKktpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, cukup: val } : r))
                            );
                          }}
                          className="w-full p-2 rounded-lg bg-slate-900 border border-amber-500/20 text-white text-[11px]"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-blue-300 font-bold block mb-0.5">
                          Baik (76-88)
                        </label>
                        <textarea
                          rows={2}
                          value={row.baik}
                          onChange={e => {
                            const val = e.target.value;
                            setKktpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, baik: val } : r))
                            );
                          }}
                          className="w-full p-2 rounded-lg bg-slate-900 border border-blue-500/20 text-white text-[11px]"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-emerald-300 font-bold block mb-0.5">
                          Sangat Baik (89-100)
                        </label>
                        <textarea
                          rows={2}
                          value={row.sangatBaik}
                          onChange={e => {
                            const val = e.target.value;
                            setKktpRows(prev =>
                              prev.map((r, i) => (i === index ? { ...r, sangatBaik: val } : r))
                            );
                          }}
                          className="w-full p-2 rounded-lg bg-slate-900 border border-emerald-500/20 text-white text-[11px]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] text-emerald-400 font-bold block mb-0.5">
                        Tindak Lanjut Pendekatan Kasih Sayang (KBC)
                      </label>
                      <input
                        type="text"
                        value={row.tindakLanjutKBC}
                        onChange={e => {
                          const val = e.target.value;
                          setKktpRows(prev =>
                            prev.map((r, i) => (i === index ? { ...r, tindakLanjutKBC: val } : r))
                          );
                        }}
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. MODUL AJAR (RPP) FORM */}
          {docType === 'modul_ajar' && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-purple-500/30 space-y-4">
              <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                3. Isi Manual Komponen Modul Ajar (RPP Kurikulum Merdeka)
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Rincian Alokasi Waktu
                  </label>
                  <input
                    type="text"
                    value={maAlokasiWaktuText}
                    onChange={e => setMaAlokasiWaktuText(e.target.value)}
                    placeholder="Contoh: 3 Pertemuan (9 JP x 35 Menit)"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Model Pembelajaran
                  </label>
                  <input
                    type="text"
                    value={maModelPembelajaran}
                    onChange={e => setMaModelPembelajaran(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Target Peserta Didik
                  </label>
                  <input
                    type="text"
                    value={maTargetPesertaDidik}
                    onChange={e => setMaTargetPesertaDidik(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Kompetensi Awal
                </label>
                <textarea
                  rows={2}
                  value={maKompetensiAwal}
                  onChange={e => setMaKompetensiAwal(e.target.value)}
                  placeholder="Kompetensi prasyarat atau pengetahuan awal peserta didik..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Profil Pelajar Pancasila &amp; KBC (1 per baris)
                  </label>
                  <textarea
                    rows={3}
                    value={maProfilPancasilaText}
                    onChange={e => setMaProfilPancasilaText(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Sarana &amp; Prasarana (1 per baris)
                  </label>
                  <textarea
                    rows={3}
                    value={maSaranaPrasaranaText}
                    onChange={e => setMaSaranaPrasaranaText(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-emerald-300 uppercase font-bold block mb-1">
                    Tujuan Pembelajaran (1 TP per baris) *
                  </label>
                  <textarea
                    rows={3}
                    value={maTujuanPembelajaranText}
                    onChange={e => setMaTujuanPembelajaranText(e.target.value)}
                    placeholder="Ketik setiap Tujuan Pembelajaran pada baris baru..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-emerald-300 uppercase font-bold block mb-1">
                    Pertanyaan Pemantik (1 per baris)
                  </label>
                  <textarea
                    rows={3}
                    value={maPertanyaanPemantikText}
                    onChange={e => setMaPertanyaanPemantikText(e.target.value)}
                    placeholder="Ketik pertanyaan pemantik diskusi..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-emerald-300 uppercase font-bold block mb-1">
                  Pemahaman Bermakna (Integrasi Kurikulum Berbasis Cinta)
                </label>
                <textarea
                  rows={2}
                  value={maPemahamanBermakna}
                  onChange={e => setMaPemahamanBermakna(e.target.value)}
                  placeholder="Pemahaman bermakna yang menyentuh kalbu siswa..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-amber-300 uppercase font-bold block mb-1">
                    A. Kegiatan Pendahuluan (1 per baris)
                  </label>
                  <textarea
                    rows={4}
                    value={maPendahuluanText}
                    onChange={e => setMaPendahuluanText(e.target.value)}
                    placeholder="Langkah-langkah pendahuluan..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-emerald-300 uppercase font-bold block mb-1">
                    B. Kegiatan Inti (1 per baris)
                  </label>
                  <textarea
                    rows={4}
                    value={maKegiatanIntiText}
                    onChange={e => setMaKegiatanIntiText(e.target.value)}
                    placeholder="Langkah-langkah kegiatan inti..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-cyan-300 uppercase font-bold block mb-1">
                    C. Kegiatan Penutup (1 per baris)
                  </label>
                  <textarea
                    rows={4}
                    value={maPenutupText}
                    onChange={e => setMaPenutupText(e.target.value)}
                    placeholder="Langkah-langkah penutup & doa..."
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Asesmen Diagnostik
                  </label>
                  <input
                    type="text"
                    value={maAsesmenDiagnostik}
                    onChange={e => setMaAsesmenDiagnostik(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Asesmen Formatif
                  </label>
                  <input
                    type="text"
                    value={maAsesmenFormatif}
                    onChange={e => setMaAsesmenFormatif(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Asesmen Sumatif
                  </label>
                  <input
                    type="text"
                    value={maAsesmenSumatif}
                    onChange={e => setMaAsesmenSumatif(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 6. LKPD FORM */}
          {docType === 'lkpd' && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-rose-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-rose-300 uppercase tracking-wider">
                  3. Isi Manual Lembar Kerja Peserta Didik (LKPD)
                </h4>
                <button
                  type="button"
                  onClick={() =>
                    setLkpdTugasList(prev => [
                      ...prev,
                      {
                        nomor: prev.length + 1,
                        instruksi: '',
                        tipe: 'isian',
                        opsiText: ''
                      }
                    ])
                  }
                  className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> + Tambah Soal / Aktivitas LKPD
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Judul Aktivitas LKPD
                  </label>
                  <input
                    type="text"
                    value={lkpdJudulAktivitas}
                    onChange={e => setLkpdJudulAktivitas(e.target.value)}
                    placeholder="Contoh: Petualangan Sahabat Al-Qur'an"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Tema Nilai Kasih Sayang (KBC)
                  </label>
                  <input
                    type="text"
                    value={lkpdTemaKBC}
                    onChange={e => setLkpdTemaKBC(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Stimulus Cerita / Pengantar Materi LKPD
                </label>
                <textarea
                  rows={2}
                  value={lkpdStimulusCerita}
                  onChange={e => setLkpdStimulusCerita(e.target.value)}
                  placeholder="Tuliskan cerita kontekstual atau pengantar singkat..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-amber-300 uppercase font-bold block mb-1">
                    Teks Arab / Dalil Pilihan (Opsional)
                  </label>
                  <input
                    type="text"
                    dir="rtl"
                    value={lkpdArabicText}
                    onChange={e => setLkpdArabicText(e.target.value)}
                    placeholder="بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-sm font-serif"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Arti / Terjemahan Dalil (Opsional)
                  </label>
                  <input
                    type="text"
                    value={lkpdArabicArti}
                    onChange={e => setLkpdArabicArti(e.target.value)}
                    placeholder="Terjemahan ayat atau hadis..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[11px] font-bold text-slate-300 uppercase block">
                  Daftar Pertanyaan / Tugas Siswa di LKPD
                </label>
                {lkpdTugasList.map((tugas, index) => (
                  <div
                    key={index}
                    className="p-3.5 rounded-xl bg-slate-950/90 border border-white/10 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-rose-400">
                        Tugas / Soal #{index + 1}
                      </span>
                      {lkpdTugasList.length > 1 && (
                        <button
                          type="button"
                          onClick={() =>
                            setLkpdTugasList(prev => prev.filter((_, i) => i !== index))
                          }
                          className="text-rose-400 hover:text-rose-300 text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Hapus Soal
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                      <div className="sm:col-span-3">
                        <input
                          type="text"
                          value={tugas.instruksi}
                          onChange={e => {
                            const val = e.target.value;
                            setLkpdTugasList(prev =>
                              prev.map((t, i) => (i === index ? { ...t, instruksi: val } : t))
                            );
                          }}
                          placeholder="Tuliskan instruksi tugas atau pertanyaan..."
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                      <div>
                        <select
                          value={tugas.tipe}
                          onChange={e => {
                            const val = e.target.value as 'isian' | 'pilihan' | 'centang';
                            setLkpdTugasList(prev =>
                              prev.map((t, i) => (i === index ? { ...t, tipe: val } : t))
                            );
                          }}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        >
                          <option value="isian">Uraian / Isian</option>
                          <option value="pilihan">Pilihan Ganda</option>
                          <option value="centang">Daftar Centang</option>
                        </select>
                      </div>
                    </div>

                    {tugas.tipe !== 'isian' && (
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">
                          Opsi Jawaban (Pisahkan per baris)
                        </label>
                        <textarea
                          rows={2}
                          value={tugas.opsiText}
                          onChange={e => {
                            const val = e.target.value;
                            setLkpdTugasList(prev =>
                              prev.map((t, i) => (i === index ? { ...t, opsiText: val } : t))
                            );
                          }}
                          placeholder="Opsi A&#10;Opsi B&#10;Opsi C"
                          className="w-full p-2 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7. DOKUMEN LAINNYA FORM */}
          {docType === 'lainnya' && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-teal-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-teal-300 uppercase tracking-wider">
                  3. Isi Manual Perangkat Ajar Lainnya (Silabus, Kisi-Kisi, Remedial, dll.)
                </h4>
                <button
                  type="button"
                  onClick={() =>
                    setLainnyaRows(prev => [
                      ...prev,
                      {
                        no: prev.length + 1,
                        aspek: '',
                        uraian: '',
                        keterangan: ''
                      }
                    ])
                  }
                  className="px-3 py-1.5 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 text-teal-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> + Tambah Baris Tabel
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Pilih Jenis / Sub-Kategori Dokumen
                  </label>
                  <select
                    value={lainnyaSubKategori}
                    onChange={e => setLainnyaSubKategori(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-bold"
                  >
                    {SUB_KATEGORI_LAINNYA.map(cat => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Tujuan / Sasaran Dokumen
                  </label>
                  <input
                    type="text"
                    value={lainnyaTujuan}
                    onChange={e => setLainnyaTujuan(e.target.value)}
                    placeholder="Contoh: Pedoman pelaksanaan remedial dan pengayaan siswa..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Uraian Lengkap / Isi Dokumen Perangkat Ajar
                </label>
                <textarea
                  rows={4}
                  value={lainnyaUraian}
                  onChange={e => setLainnyaUraian(e.target.value)}
                  placeholder="Tuliskan isi lengkap perangkat ajar, langkah kegiatan, atau deskripsi dokumen di sini..."
                  className="w-full p-3 rounded-xl bg-slate-950 border border-white/15 text-white text-xs leading-relaxed"
                />
              </div>

              <div className="space-y-2.5">
                <label className="text-[11px] font-bold text-slate-300 uppercase block">
                  Tabel Matriks / Komponen Dokumen (Opsional)
                </label>
                {lainnyaRows.map((row, index) => (
                  <div
                    key={index}
                    className="grid grid-cols-1 sm:grid-cols-12 gap-2 p-2.5 rounded-xl bg-slate-950/90 border border-white/10 items-center"
                  >
                    <div className="sm:col-span-4">
                      <input
                        type="text"
                        value={row.aspek}
                        onChange={e => {
                          const val = e.target.value;
                          setLainnyaRows(prev =>
                            prev.map((r, i) => (i === index ? { ...r, aspek: val } : r))
                          );
                        }}
                        placeholder="Aspek / Materi / Indikator"
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                      />
                    </div>
                    <div className="sm:col-span-5">
                      <input
                        type="text"
                        value={row.uraian}
                        onChange={e => {
                          const val = e.target.value;
                          setLainnyaRows(prev =>
                            prev.map((r, i) => (i === index ? { ...r, uraian: val } : r))
                          );
                        }}
                        placeholder="Uraian kegiatan / butir instrumen..."
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <input
                        type="text"
                        value={row.keterangan}
                        onChange={e => {
                          const val = e.target.value;
                          setLainnyaRows(prev =>
                            prev.map((r, i) => (i === index ? { ...r, keterangan: val } : r))
                          );
                        }}
                        placeholder="JP / Ket"
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-white text-xs"
                      />
                    </div>
                    <div className="sm:col-span-1 text-right">
                      {lainnyaRows.length > 1 && (
                        <button
                          type="button"
                          onClick={() =>
                            setLainnyaRows(prev => prev.filter((_, i) => i !== index))
                          }
                          className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded-lg cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-white/10">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1 flex items-center gap-1">
                    <LinkIcon className="w-3 h-3 text-cyan-400" /> Link Google Drive / Dokumen (Opsional)
                  </label>
                  <input
                    type="text"
                    value={lainnyaTautan}
                    onChange={e => setLainnyaTautan(e.target.value)}
                    placeholder="https://drive.google.com/..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1 flex items-center gap-1">
                    <Upload className="w-3 h-3 text-emerald-400" /> Upload File Dokumen PDF/Word (Opsional)
                  </label>
                  <div className="flex items-center gap-2">
                    <label className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold cursor-pointer border border-white/15 shrink-0">
                      Pilih File...
                      <input
                        type="file"
                        accept=".pdf,.doc,.docx,.xls,.xlsx"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                    {lainnyaLampiran ? (
                      <div className="flex items-center gap-1.5 text-xs text-emerald-300 truncate">
                        <span className="truncate">{lainnyaLampiran.fileName}</span>
                        <button
                          type="button"
                          onClick={() => setLainnyaLampiran(null)}
                          className="text-rose-400 hover:text-rose-300 p-1"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-500">Belum ada file dipilih</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Optional Additional Notes for All Document Types */}
          {docType !== 'lainnya' && (
            <div className="p-3.5 rounded-2xl bg-slate-900/40 border border-white/10">
              <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                Catatan Tambahan Guru (Opsional - Akan Tampil di Cetakan)
              </label>
              <textarea
                rows={2}
                value={catatanTambahan}
                onChange={e => setCatatanTambahan(e.target.value)}
                placeholder="Tambahkan catatan khusus, penyesuaian kelas, atau keterangan tambahan bila diperlukan..."
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs"
              />
            </div>
          )}

          {/* Footer Submit */}
          <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
            <span className="text-[11px] text-slate-400">
              {selectedRefDoc
                ? `📌 Tersandar pada Dokumen Acuan: "${selectedRefDoc.title}"`
                : '💡 Dokumen yang disimpan langsung siap dicetak resmi dengan Kop Sekolah & Tanda Tangan.'}
            </span>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs sm:text-sm font-bold shadow-lg shadow-emerald-500/25 cursor-pointer transition-all flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                {editingDoc ? 'Simpan Perubahan Dokumen' : 'Simpan Perangkat Ajar Manual'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
