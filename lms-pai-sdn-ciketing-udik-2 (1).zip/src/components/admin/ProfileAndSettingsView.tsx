import React, { useState, useMemo } from 'react';
import {
  User,
  Settings,
  Building2,
  Save,
  RotateCcw,
  School,
  Image as ImageIcon,
  CheckCircle2,
  Cloud,
  RefreshCw,
  Monitor,
  Copy,
  Database,
  Trash2,
  AlertTriangle,
  Download,
  FileSpreadsheet,
  FileJson,
  Upload,
  ShieldCheck,
  Terminal,
  Sparkles
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { StorageService } from '../../services/storageService';
import { SupabaseService, DEFAULT_SUPABASE_URL, DEFAULT_SUPABASE_ANON_KEY } from '../../services/supabaseService';
import { IndexedDbService, OfflineSyncStatus } from '../../services/indexedDbService';
import { TeacherProfile, AppSettings } from '../../types';
import { SupabaseSqlEditorModal } from '../common/SupabaseSqlEditorModal';

interface ProfileAndSettingsViewProps {
  mode: 'profile' | 'settings';
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onProfileUpdated?: (name: string) => void;
}

type BackupExportScope =
  | 'all'
  | 'nilai'
  | 'absensi'
  | 'jurnal'
  | 'siswa_kelas'
  | 'ekinerja';

export const ProfileAndSettingsView: React.FC<ProfileAndSettingsViewProps> = ({
  mode,
  showToast,
  onProfileUpdated
}) => {
  const [profile, setProfile] = useState<TeacherProfile>(StorageService.getTeacherProfile());
  const [settings, setSettings] = useState<AppSettings>(StorageService.getAppSettings());
  const [resetModalMode, setResetModalMode] = useState<'fresh_empty' | 'demo_default' | null>(null);
  const [isResettingData, setIsResettingData] = useState(false);

  // State Fitur Ekspor Cadangan Lokal (JSON / Excel) sebelum Reset Total
  const [exportScope, setExportScope] = useState<BackupExportScope>('all');
  const [lastBackupStatus, setLastBackupStatus] = useState<{
    format: 'JSON' | 'Excel (.xlsx)';
    scopeLabel: string;
    timestamp: string;
  } | null>(null);

  const [supaConfig, setSupaConfig] = useState(() => SupabaseService.getConfig());
  const [isSyncingSupa, setIsSyncingSupa] = useState(false);
  const [isCleaningDemo, setIsCleaningDemo] = useState(false);
  const [showSqlHelper, setShowSqlHelper] = useState(false);
  const [idbStatus, setIdbStatus] = useState<OfflineSyncStatus>(() => IndexedDbService.getSyncStatus());
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() =>
    SupabaseService.getLastSyncTime()
  );

  const handleCleanDemoDataNow = async () => {
    setIsCleaningDemo(true);
    try {
      const res = await StorageService.cleanDemoDataKeepRealData();
      setProfile(StorageService.getTeacherProfile());
      setSettings(StorageService.getAppSettings());
      setLastSyncTime(SupabaseService.getLastSyncTime());
      showToast(res.message, 'success');
    } finally {
      setIsCleaningDemo(false);
    }
  };

  const handleSyncSupabaseNow = async () => {
    setIsSyncingSupa(true);
    try {
      SupabaseService.saveConfig(supaConfig);
      await StorageService.flushOfflineQueue();
      const res = await StorageService.syncAllToSupabase();
      await StorageService.pullAllFromSupabase();
      setProfile(StorageService.getTeacherProfile());
      setSettings(StorageService.getAppSettings());
      setLastSyncTime(SupabaseService.getLastSyncTime());
      showToast(res.message, 'success');
    } finally {
      setIsSyncingSupa(false);
    }
  };

  const backupSummary = useMemo(() => {
    const payload = StorageService.buildFullDatabaseBackupPayload();
    return payload.metadata.summaryCounts;
  }, [resetModalMode, lastBackupStatus]);

  React.useEffect(() => {
    const unsub = IndexedDbService.subscribeSyncStatus(status => {
      setIdbStatus(status);
    });
    IndexedDbService.refreshCounts().catch(() => {});
    return unsub;
  }, []);

  const getScopeLabel = (scope: BackupExportScope): string => {
    switch (scope) {
      case 'nilai':
        return 'Database Nilai Evaluasi Siswa';
      case 'absensi':
        return 'Database Absensi & Kehadiran Siswa';
      case 'jurnal':
        return 'Database Jurnal Mengajar Harian';
      case 'siswa_kelas':
        return 'Database Siswa & Rombel Kelas';
      case 'ekinerja':
        return 'Database Laporan E-Kinerja Harian';
      default:
        return 'Seluruh Database Lengkap (Nilai, Absensi, Jurnal, Siswa, Soal, E-Kinerja)';
    }
  };

  /**
   * Ekspor Cadangan Lokal ke Format File JSON (.json)
   */
  const handleExportBackupJson = (overrideScope?: BackupExportScope) => {
    const targetScope = overrideScope || exportScope;
    const fullPayload = StorageService.buildFullDatabaseBackupPayload();
    const dateStamp = new Date().toISOString().split('T')[0];

    let exportData: any = fullPayload;
    let fileSuffix = 'Lengkap';

    if (targetScope === 'nilai') {
      fileSuffix = 'Database_Nilai';
      exportData = {
        metadata: { ...fullPayload.metadata, exportScope: 'Database Nilai Siswa' },
        nilaiSiswa: fullPayload.enrichedViews.nilaiSiswa,
        rawStorageCollections: {
          lms_scores: fullPayload.rawStorageCollections.lms_scores,
          lms_quiz_attempts: fullPayload.rawStorageCollections.lms_quiz_attempts,
          lms_quizzes: fullPayload.rawStorageCollections.lms_quizzes
        }
      };
    } else if (targetScope === 'absensi') {
      fileSuffix = 'Database_Absensi';
      exportData = {
        metadata: { ...fullPayload.metadata, exportScope: 'Database Absensi & Kehadiran' },
        absensiKehadiran: fullPayload.enrichedViews.absensiKehadiran,
        rawStorageCollections: {
          lms_attendance: fullPayload.rawStorageCollections.lms_attendance,
          lms_teaching_journals: fullPayload.rawStorageCollections.lms_teaching_journals
        }
      };
    } else if (targetScope === 'jurnal') {
      fileSuffix = 'Database_Jurnal_Mengajar';
      exportData = {
        metadata: { ...fullPayload.metadata, exportScope: 'Database Jurnal Mengajar' },
        jurnalMengajar: fullPayload.enrichedViews.jurnalMengajar,
        rawStorageCollections: {
          lms_teaching_journals: fullPayload.rawStorageCollections.lms_teaching_journals
        }
      };
    } else if (targetScope === 'siswa_kelas') {
      fileSuffix = 'Database_Siswa_dan_Kelas';
      exportData = {
        metadata: { ...fullPayload.metadata, exportScope: 'Database Siswa & Kelas' },
        rawStorageCollections: {
          lms_classes: fullPayload.rawStorageCollections.lms_classes,
          lms_students: fullPayload.rawStorageCollections.lms_students
        }
      };
    } else if (targetScope === 'ekinerja') {
      fileSuffix = 'Database_EKinerja_Harian';
      exportData = {
        metadata: { ...fullPayload.metadata, exportScope: 'Database E-Kinerja Harian' },
        rawStorageCollections: {
          lms_e_kinerja_periods: fullPayload.rawStorageCollections.lms_e_kinerja_periods,
          lms_e_kinerja_activities: fullPayload.rawStorageCollections.lms_e_kinerja_activities
        }
      };
    }

    const jsonString = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Cadangan_LMS_PAI_${fileSuffix}_${dateStamp}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    setLastBackupStatus({
      format: 'JSON',
      scopeLabel: getScopeLabel(targetScope),
      timestamp: nowStr
    });
    showToast(
      `Cadangan lokal (${getScopeLabel(targetScope)}) berhasil diekspor ke file JSON!`,
      'success'
    );
  };

  /**
   * Ekspor Cadangan Lokal ke Format File Excel (.xlsx)
   */
  const handleExportBackupExcel = (overrideScope?: BackupExportScope) => {
    const targetScope = overrideScope || exportScope;
    const fullPayload = StorageService.buildFullDatabaseBackupPayload();
    const dateStamp = new Date().toISOString().split('T')[0];
    const wb = XLSX.utils.book_new();

    const addNilaiSheet = () => {
      const rows = fullPayload.enrichedViews.nilaiSiswa.map(item => ({
        No: item.no,
        Tanggal: item.tanggal,
        NIS: item.nis,
        'Nama Siswa': item.namaSiswa,
        Kelas: item.kelas,
        'Judul Kuis / Evaluasi': item.judulEvaluasi,
        'Skor Mentah': item.skorMentah,
        'Skor Maksimal': item.skorMaksimal,
        'Nilai Akhir (0-100)': item.nilaiAkhir,
        'Status Ketuntasan KKTP': item.statusKKTP
      }));
      const ws =
        rows.length > 0
          ? XLSX.utils.json_to_sheet(rows)
          : XLSX.utils.aoa_to_sheet([
              [
                'No',
                'Tanggal',
                'NIS',
                'Nama Siswa',
                'Kelas',
                'Judul Kuis / Evaluasi',
                'Skor Mentah',
                'Skor Maksimal',
                'Nilai Akhir (0-100)',
                'Status Ketuntasan KKTP'
              ],
              ['-', '-', '-', 'Belum ada data nilai evaluasi', '-', '-', 0, 0, 0, '-']
            ]);
      XLSX.utils.book_append_sheet(wb, ws, 'Database_Nilai');
    };

    const addAbsensiSheet = () => {
      const rows = fullPayload.enrichedViews.absensiKehadiran.map((item, idx) => ({
        No: idx + 1,
        Tanggal: item.tanggal,
        Kelas: item.kelas,
        NIS: item.nis,
        'Nama Siswa / Catatan Presensi': item.namaSiswa,
        'Status Kehadiran': item.statusKehadiran,
        Keterangan: item.keterangan,
        'Sumber Rekaman': item.sumberData
      }));
      const ws =
        rows.length > 0
          ? XLSX.utils.json_to_sheet(rows)
          : XLSX.utils.aoa_to_sheet([
              [
                'No',
                'Tanggal',
                'Kelas',
                'NIS',
                'Nama Siswa',
                'Status Kehadiran',
                'Keterangan',
                'Sumber Rekaman'
              ],
              ['-', '-', '-', '-', 'Belum ada rekaman absensi', '-', '-', '-']
            ]);
      XLSX.utils.book_append_sheet(wb, ws, 'Database_Absensi');
    };

    const addJurnalSheet = () => {
      const rows = fullPayload.enrichedViews.jurnalMengajar.map((j, idx) => ({
        No: idx + 1,
        Tanggal: j.date,
        Kelas: j.className,
        'Topik / Materi Pokok': j.topic,
        'Tujuan Pembelajaran': j.learningObjective,
        'Refleksi & Tindak Lanjut': j.reflection,
        'Siswa Tidak Hadir':
          j.absentStudents && j.absentStudents.length > 0
            ? j.absentStudents.join(', ')
            : 'Nihil (Hadir Semua)',
        Status: j.status,
        'Nama Guru PAI': j.teacherName,
        'Satuan Pendidikan': j.schoolName
      }));
      const ws =
        rows.length > 0
          ? XLSX.utils.json_to_sheet(rows)
          : XLSX.utils.aoa_to_sheet([
              [
                'No',
                'Tanggal',
                'Kelas',
                'Topik / Materi Pokok',
                'Tujuan Pembelajaran',
                'Refleksi & Tindak Lanjut',
                'Siswa Tidak Hadir',
                'Status',
                'Nama Guru PAI',
                'Satuan Pendidikan'
              ],
              ['-', '-', '-', 'Belum ada jurnal mengajar', '-', '-', '-', '-', '-', '-']
            ]);
      XLSX.utils.book_append_sheet(wb, ws, 'Jurnal_Mengajar');
    };

    const addSiswaKelasSheet = () => {
      const students = (fullPayload.rawStorageCollections.lms_students as any[]) || [];
      const classes = (fullPayload.rawStorageCollections.lms_classes as any[]) || [];
      const studentRows = students.map((s: any, idx: number) => ({
        No: idx + 1,
        NIS: s.nis,
        'Nama Lengkap Siswa': s.fullName,
        Kelas: s.className || '-',
        Username: s.username,
        Password: s.password || '-'
      }));
      const wsStudents =
        studentRows.length > 0
          ? XLSX.utils.json_to_sheet(studentRows)
          : XLSX.utils.aoa_to_sheet([
              ['No', 'NIS', 'Nama Lengkap Siswa', 'Kelas', 'Username', 'Password'],
              ['-', '-', 'Belum ada data siswa', '-', '-', '-']
            ]);
      XLSX.utils.book_append_sheet(wb, wsStudents, 'Data_Siswa');

      const classRows = classes.map((c: any, idx: number) => ({
        No: idx + 1,
        'Nama Kelas / Rombel': c.className,
        'Wali Kelas': c.homeroom,
        'Tahun Ajaran': c.academicYear,
        'Jumlah Siswa': c.studentCount || 0
      }));
      const wsClasses =
        classRows.length > 0
          ? XLSX.utils.json_to_sheet(classRows)
          : XLSX.utils.aoa_to_sheet([
              ['No', 'Nama Kelas / Rombel', 'Wali Kelas', 'Tahun Ajaran', 'Jumlah Siswa'],
              ['-', 'Belum ada data kelas', '-', '-', 0]
            ]);
      XLSX.utils.book_append_sheet(wb, wsClasses, 'Data_Kelas');
    };

    const addEKinerjaSheet = () => {
      const periods = (fullPayload.rawStorageCollections.lms_e_kinerja_periods as any[]) || [];
      const activities = (fullPayload.rawStorageCollections.lms_e_kinerja_activities as any[]) || [];
      const rows = activities.map((act: any, idx: number) => {
        const per = periods.find((p: any) => p.id === act.periodId);
        return {
          No: idx + 1,
          Periode: per ? `${per.month} ${per.year}` : '-',
          'Tanggal Kegiatan': act.date,
          'RKH Terkait': act.rkhText || '-',
          'Jenis Kegiatan (Rencana Aksi)': act.rencanaAksiText,
          'Tindak Lanjut':
            act.tindakLanjutList && act.tindakLanjutList.length > 0
              ? act.tindakLanjutList.join(' • ')
              : act.tindakLanjutText || '-',
          Output: act.outputText || '-',
          'Jumlah Foto': (act.photos || []).length,
          'Jumlah Dokumen Lampiran': (act.documents || []).length,
          'Nama Dokumen Lampiran':
            (act.documents || []).map((d: any) => d.fileName).join(', ') || '-'
        };
      });
      const ws =
        rows.length > 0
          ? XLSX.utils.json_to_sheet(rows)
          : XLSX.utils.aoa_to_sheet([
              [
                'No',
                'Periode',
                'Tanggal Kegiatan',
                'RKH Terkait',
                'Jenis Kegiatan (Rencana Aksi)',
                'Tindak Lanjut',
                'Output',
                'Jumlah Foto',
                'Jumlah Dokumen Lampiran'
              ],
              ['-', '-', '-', '-', 'Belum ada kegiatan E-Kinerja', '-', '-', 0, 0]
            ]);
      XLSX.utils.book_append_sheet(wb, ws, 'E_Kinerja_Harian');
    };

    const addBankSoalSheet = () => {
      const questions = (fullPayload.rawStorageCollections.lms_questions as any[]) || [];
      const rows = questions.map((q: any, idx: number) => ({
        No: idx + 1,
        'Tingkat Kelas': q.className || q.classId,
        Semester: q.semester,
        'Jenis Soal': q.questionType,
        'Elemen / Domain': q.domain || '-',
        Pertanyaan: q.question,
        'Kunci Jawaban': Array.isArray(q.correctAnswer)
          ? q.correctAnswer.join(', ')
          : String(q.correctAnswer || ''),
        'Bobot Skor': q.scoreWeight
      }));
      if (rows.length > 0) {
        const ws = XLSX.utils.json_to_sheet(rows);
        XLSX.utils.book_append_sheet(wb, ws, 'Bank_Soal_PAI');
      }
    };

    let fileSuffix = 'Lengkap';
    if (targetScope === 'nilai') {
      fileSuffix = 'Database_Nilai';
      addNilaiSheet();
    } else if (targetScope === 'absensi') {
      fileSuffix = 'Database_Absensi';
      addAbsensiSheet();
    } else if (targetScope === 'jurnal') {
      fileSuffix = 'Database_Jurnal_Mengajar';
      addJurnalSheet();
    } else if (targetScope === 'siswa_kelas') {
      fileSuffix = 'Database_Siswa_Kelas';
      addSiswaKelasSheet();
    } else if (targetScope === 'ekinerja') {
      fileSuffix = 'Database_EKinerja';
      addEKinerjaSheet();
    } else {
      addNilaiSheet();
      addAbsensiSheet();
      addJurnalSheet();
      addSiswaKelasSheet();
      addEKinerjaSheet();
      addBankSoalSheet();
    }

    XLSX.writeFile(wb, `Cadangan_Database_LMS_PAI_${fileSuffix}_${dateStamp}.xlsx`);

    const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    setLastBackupStatus({
      format: 'Excel (.xlsx)',
      scopeLabel: getScopeLabel(targetScope),
      timestamp: nowStr
    });
    showToast(
      `Cadangan lokal (${getScopeLabel(targetScope)}) berhasil diekspor ke file Excel (.xlsx)!`,
      'success'
    );
  };

  /**
   * Pulihkan Database dari File Cadangan JSON (.json)
   */
  const handleRestoreFromJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async evt => {
      try {
        const parsed = JSON.parse(String(evt.target?.result || '{}'));
        const res = await StorageService.restoreFromBackupPayload(parsed);
        setProfile(StorageService.getTeacherProfile());
        setSettings(StorageService.getAppSettings());
        showToast(res.message, 'success');
        setTimeout(() => window.location.reload(), 900);
      } catch (err: any) {
        showToast(err?.message || 'Gagal membaca file cadangan JSON.', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile.fullName.trim() || !profile.schoolName.trim()) {
      showToast('Nama Guru dan Nama Sekolah wajib diisi!', 'error');
      return;
    }
    StorageService.saveTeacherProfile(profile);
    if (onProfileUpdated) onProfileUpdated(profile.fullName);
    showToast('Profil Pendidik PAI berhasil diperbarui!', 'success');
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings.principalName.trim()) {
      showToast('Nama Kepala Sekolah wajib diisi untuk tanda tangan dokumen resmi!', 'error');
      return;
    }
    StorageService.saveAppSettings(settings);
    showToast('Pengaturan sistem & Kepala Sekolah berhasil disimpan!', 'success');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const dataUrl = evt.target?.result as string;
      setSettings(prev => ({ ...prev, appLogoUrl: dataUrl }));
      showToast('Logo berhasil diunggah. Klik Simpan Pengaturan.', 'info');
    };
    reader.readAsDataURL(file);
  };

  const resetLogoToDefault = () => {
    setSettings(prev => ({
      ...prev,
      appLogoUrl: 'https://jhlryjdhotxtndavacpd.supabase.co/storage/v1/object/public/logo/logo.png'
    }));
    showToast('Logo dikembalikan ke default.', 'info');
  };

  const confirmResetDatabase = async () => {
    if (!resetModalMode) return;
    setIsResettingData(true);
    try {
      if (resetModalMode === 'fresh_empty') {
        const res = await StorageService.resetToFreshEmptyData();
        setResetModalMode(null);
        showToast(res.message, 'success');
      } else {
        const res = await StorageService.resetAllToDefaults();
        setProfile(StorageService.getTeacherProfile());
        setSettings(StorageService.getAppSettings());
        setResetModalMode(null);
        showToast(res.message, 'info');
      }
      setTimeout(() => window.location.reload(), 900);
    } finally {
      setIsResettingData(false);
    }
  };

  if (mode === 'profile') {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="glass rounded-3xl p-6 sm:p-8 border border-white/10 shadow-2xl space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-white/10">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white font-display">
                Profil Pendidik Agama Islam & Satuan Pendidikan
              </h3>
              <p className="text-xs text-slate-400">
                Informasi ini otomatis tercantum pada Cetak Kisi-Kisi dan Jurnal Mengajar
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Nama Lengkap & Gelar Guru PAI <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={profile.fullName}
                onChange={e => setProfile({ ...profile, fullName: e.target.value })}
                placeholder="Contoh: Drs. H. Ahmad Syarifuddin, M.Pd.I."
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Nomor Induk Pegawai (NIP)
              </label>
              <input
                type="text"
                value={profile.nip}
                onChange={e => setProfile({ ...profile, nip: e.target.value })}
                placeholder="197908152006041008"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Jabatan Pegawai (Otomatis untuk E-Kinerja Harian)
              </label>
              <input
                type="text"
                value={profile.jabatan || ''}
                onChange={e => setProfile({ ...profile, jabatan: e.target.value })}
                placeholder="Contoh: Guru Ahli Pertama / Guru PAI & Budi Pekerti"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Unit Kerja / Satuan Pendidikan <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={profile.schoolName}
                onChange={e => setProfile({ ...profile, schoolName: e.target.value })}
                placeholder="SDN Ciketing Udik 2 Bantargebang"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Mata Pelajaran yang Diampu
              </label>
              <input
                type="text"
                value={profile.subject}
                onChange={e => setProfile({ ...profile, subject: e.target.value })}
                placeholder="Pendidikan Agama Islam & Budi Pekerti"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="pt-4 border-t border-white/10 flex justify-end">
              <button
                type="submit"
                className="w-full sm:w-auto px-7 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Save className="w-4 h-4" /> Simpan Profil Pendidik
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Panel Aksi Cepat Penyimpanan Cloud Supabase (Dipindahkan dari Dashboard) */}
      <div className="glass rounded-3xl p-4 sm:p-5 border border-emerald-500/25 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-300 flex-wrap">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <Cloud className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            Penyimpanan Cloud Supabase Aktif:{' '}
            <code className="text-cyan-300 font-mono text-[11px]">{supaConfig.url || DEFAULT_SUPABASE_URL}</code>
          </span>
          {lastSyncTime && (
            <span className="text-[11px] text-slate-400">
              &bull; Sinkron terakhir: {new Date(lastSyncTime).toLocaleTimeString('id-ID')}
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setShowSqlHelper(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all shadow-sm"
          >
            <Terminal className="w-3.5 h-3.5 text-cyan-300" />
            SQL Editor Supabase
          </button>
          <button
            type="button"
            onClick={handleCleanDemoDataNow}
            disabled={isCleaningDemo}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/35 text-amber-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            {isCleaningDemo ? 'Membersihkan...' : 'Bersihkan Sisa Data Demo'}
          </button>
          <button
            type="button"
            onClick={() => setResetModalMode('fresh_empty')}
            className="px-3.5 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/35 text-rose-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Reset / Kosongkan Data
          </button>
          <button
            type="button"
            onClick={handleSyncSupabaseNow}
            disabled={isSyncingSupa}
            className="px-3.5 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingSupa ? 'animate-spin' : ''}`} />
            {isSyncingSupa ? 'Menyinkronkan ke Supabase...' : 'Sinkronkan Data Supabase'}
          </button>
        </div>
      </div>

      <div className="glass rounded-3xl p-6 sm:p-8 border border-white/10 shadow-2xl space-y-6">
        <div className="flex items-center gap-3 pb-4 border-b border-white/10">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-white font-display">
              Pengaturan Sistem & Pengesahan Kepala Sekolah
            </h3>
            <p className="text-xs text-slate-400">
              Konfigurasi Kepala Sekolah, Kop Dokumen, dan Logo Aplikasi
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveSettings} className="space-y-6">
          {/* Section 1: Kepala Sekolah */}
          <div className="space-y-3.5 pb-5 border-b border-white/10">
            <h4 className="font-bold text-xs uppercase tracking-wider text-emerald-400">
              1. Pengesahan Kepala Sekolah
            </h4>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Nama Lengkap Kepala Sekolah <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={settings.principalName}
                onChange={e => setSettings({ ...settings, principalName: e.target.value })}
                placeholder="Contoh: Hj. Siti Rohmah, M.Pd."
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                NIP Kepala Sekolah
              </label>
              <input
                type="text"
                value={settings.principalNip}
                onChange={e => setSettings({ ...settings, principalNip: e.target.value })}
                placeholder="Contoh: 197405101998022001"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Alamat Satuan Pendidikan
              </label>
              <input
                type="text"
                value={settings.schoolAddress}
                onChange={e => setSettings({ ...settings, schoolAddress: e.target.value })}
                placeholder="Jl. Raya Ciketing Udik No. 2, Bantargebang, Kota Bekasi"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1.5">
                Tahun Ajaran Aktif
              </label>
              <input
                type="text"
                value={settings.academicYear}
                onChange={e => setSettings({ ...settings, academicYear: e.target.value })}
                placeholder="2026/2027"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          {/* Section 2: Logo Sekolah */}
          <div className="space-y-3.5 pb-5 border-b border-white/10">
            <h4 className="font-bold text-xs uppercase tracking-wider text-cyan-400">
              2. Logo Aplikasi & Dokumen Cetak
            </h4>

            <div className="flex flex-col sm:flex-row items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/10">
              <img
                src={settings.appLogoUrl || 'https://jhlryjdhotxtndavacpd.supabase.co/storage/v1/object/public/logo/logo.png'}
                alt="Logo Preview"
                className="w-16 h-16 object-contain rounded-xl bg-black/30 p-1 border border-white/10"
                onError={e => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="flex-1 space-y-2 w-full">
                <label className="text-xs font-bold text-slate-300 uppercase block">
                  Pilih Berkas Gambar Logo Baru:
                </label>
                <div className="flex gap-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="w-full text-xs text-slate-300 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-cyan-500/20 file:text-cyan-300 hover:file:bg-cyan-500/30 cursor-pointer"
                  />
                  <button
                    type="button"
                    onClick={resetLogoToDefault}
                    className="px-3 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-xs font-bold shrink-0 cursor-pointer transition-colors"
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="w-full sm:w-auto px-7 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Save className="w-4 h-4" /> Simpan Pengaturan Sistem
            </button>
          </div>
        </form>

        {/* Section 3: Penyimpanan Cloud Supabase & Cache Offline-First IndexedDB */}
        <div className="pt-6 border-t border-white/10 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h4 className="font-bold text-xs uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <Cloud className="w-4 h-4" /> 3. Sinkronisasi Otomatis Offline-First (IndexedDB ↔ Supabase)
            </h4>
            <span
              className={`px-2.5 py-0.5 rounded-full border text-[10px] font-bold ${
                idbStatus.isOnline
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
              }`}
            >
              {idbStatus.isOnline
                ? `● Online — ${idbStatus.cachedKeysCount} Koleksi di IndexedDB`
                : `● Offline Mode — ${idbStatus.pendingCount} Antrean Outbox IndexedDB`}
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/70 border border-white/10 space-y-3 text-xs">
            {/* Status Panel IndexedDB Local Cache Layer */}
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="space-y-0.5">
                <p className="font-bold text-emerald-300 flex items-center gap-1.5 text-xs">
                  <Database className="w-3.5 h-3.5" /> Lapisan Cache Lokal IndexedDB (`lms_pai_offline_db`)
                </p>
                <p className="text-[11px] text-slate-300">
                  {idbStatus.lastMessage}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0 text-[11px]">
                <span className="px-2.5 py-1 rounded-lg bg-black/40 border border-white/10 text-cyan-300 font-mono">
                  Cache: {idbStatus.cachedKeysCount} tabel
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-black/40 border border-white/10 text-amber-300 font-mono">
                  Outbox: {idbStatus.pendingCount} item
                </span>
              </div>
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                Supabase API URL
              </label>
              <input
                type="text"
                value={supaConfig.url}
                onChange={e => setSupaConfig({ ...supaConfig, url: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-cyan-300 font-mono text-xs"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                Supabase Anon Public Key
              </label>
              <input
                type="text"
                value={supaConfig.anonKey}
                onChange={e => setSupaConfig({ ...supaConfig, anonKey: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 font-mono text-[11px]"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowSqlHelper(true)}
                  className="px-3.5 py-2 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Terminal className="w-3.5 h-3.5 text-cyan-300" />
                  Buka SQL Editor &amp; Cek Tabel Supabase
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const def = {
                      url: DEFAULT_SUPABASE_URL,
                      anonKey: DEFAULT_SUPABASE_ANON_KEY,
                      enabled: true
                    };
                    setSupaConfig(def);
                    SupabaseService.saveConfig(def);
                    showToast('Kredensial Supabase dikembalikan ke konfigurasi utama!', 'info');
                  }}
                  className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs cursor-pointer"
                >
                  Default Key
                </button>
                <button
                  type="button"
                  onClick={() => setResetModalMode('fresh_empty')}
                  className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Reset / Kosongkan Data (Supabase &amp; IndexedDB)
                </button>
                <button
                  type="button"
                  disabled={isSyncingSupa}
                  onClick={async () => {
                    SupabaseService.saveConfig(supaConfig);
                    setIsSyncingSupa(true);
                    const pullRes = await StorageService.pullAllFromSupabase();
                    setProfile(StorageService.getTeacherProfile());
                    setSettings(StorageService.getSettings());
                    setIsSyncingSupa(false);
                    showToast(pullRes.message, pullRes.ok ? 'success' : 'info');
                  }}
                  className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isSyncingSupa ? 'animate-spin' : ''}`} />
                  Tarik Data dari Perangkat Lain
                </button>
                <button
                  type="button"
                  disabled={isSyncingSupa}
                  onClick={async () => {
                    SupabaseService.saveConfig(supaConfig);
                    setIsSyncingSupa(true);
                    await StorageService.flushOfflineQueue();
                    const res = await StorageService.syncAllToSupabase();
                    await StorageService.pullAllFromSupabase();
                    setProfile(StorageService.getTeacherProfile());
                    setSettings(StorageService.getSettings());
                    setIsSyncingSupa(false);
                    showToast(res.message, 'success');
                  }}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingSupa ? 'animate-spin' : ''}`} />
                  Simpan &amp; Sinkronkan ke Supabase
                </button>
              </div>
            </div>

            {showSqlHelper && (
              <div className="mt-3 p-3 rounded-xl bg-black/50 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-amber-300 font-bold">
                    Opsional: Jalankan di SQL Editor Supabase untuk tabel cloud:
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(SupabaseService.getSqlSetupScript());
                      showToast('Skrip SQL disalin ke clipboard!', 'success');
                    }}
                    className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[10px] text-white font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" /> Salin SQL
                  </button>
                </div>
                <pre className="text-[10px] font-mono text-emerald-300 overflow-x-auto whitespace-pre-wrap">
                  {SupabaseService.getSqlSetupScript()}
                </pre>
              </div>
            )}
          </div>
        </div>

        {/* Section 4: Konfigurasi Build Desktop Windows (.EXE Electron) */}
        <div className="pt-6 border-t border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
              <Monitor className="w-4 h-4" /> 4. Paket Distribusi Desktop Windows (.EXE / Electron)
            </h4>
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
              Siap Build (x64 NSIS &amp; Portable)
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/70 border border-white/10 space-y-2.5 text-xs">
            <p className="text-slate-300 leading-relaxed">
              Aplikasi ini telah dilengkapi konfigurasi <b>Electron (`electron/main.cjs`, `electron/preload.cjs`)</b> dan <b>`electron-builder.json`</b> untuk dikemas menjadi berkas instalasi <b>`.exe` Windows</b>:
            </p>
            <div className="p-3 rounded-xl bg-black/40 border border-white/10 font-mono text-[11px] text-cyan-300 flex items-center justify-between">
              <span>npm run dist:exe</span>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText('npm run dist:exe');
                  showToast('Perintah build .exe berhasil disalin!', 'success');
                }}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[10px] font-sans font-bold flex items-center gap-1 cursor-pointer"
              >
                <Copy className="w-3 h-3" /> Salin Perintah
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              Output installer akan tersedia di folder <code className="text-amber-300">release-exe/LMS PAI SDN Ciketing Udik 2-Setup-1.0.0.exe</code>.
            </p>
          </div>
        </div>

        {/* Section 5: Cadangan Lokal & Ekspor Database (JSON / Excel) Sebelum Reset Total */}
        <div className="pt-6 border-t border-white/10 space-y-4 text-xs">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h4 className="font-bold text-xs uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> 5. Cadangan Lokal &amp; Ekspor Database (JSON / Excel) Sebelum Reset Total
            </h4>
            {lastBackupStatus ? (
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Terakhir Diekspor: {lastBackupStatus.format} ({lastBackupStatus.timestamp})
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                Disarankan Sebelum Reset Total
              </span>
            )}
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-amber-500/25 space-y-4">
            <p className="text-slate-300 leading-relaxed text-[11.5px]">
              Unduh cadangan lokal seluruh database aplikasi (termasuk <b>Database Nilai</b>, <b>Database Absensi / Kehadiran</b>, <b>Jurnal Mengajar</b>, <b>Data Siswa &amp; Kelas</b>, serta <b>Laporan E-Kinerja Harian</b>) ke dalam format file <b>Excel (`.xlsx`)</b> atau <b>JSON (`.json`)</b> sebelum melakukan Reset Total.
            </p>

            {/* Ringkasan Jumlah Data Saat Ini */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-sm font-extrabold text-emerald-400">{backupSummary.scores}</div>
                <div className="text-[10px] text-slate-400 font-semibold">Data Nilai</div>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-sm font-extrabold text-cyan-400">
                  {backupSummary.attendanceRecords + backupSummary.journalAttendanceEntries}
                </div>
                <div className="text-[10px] text-slate-400 font-semibold">Data Absensi</div>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-sm font-extrabold text-amber-400">{backupSummary.journals}</div>
                <div className="text-[10px] text-slate-400 font-semibold">Jurnal Mengajar</div>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-sm font-extrabold text-purple-400">
                  {backupSummary.students} / {backupSummary.classes}
                </div>
                <div className="text-[10px] text-slate-400 font-semibold">Siswa / Kelas</div>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center col-span-2 sm:col-span-1">
                <div className="text-sm font-extrabold text-teal-400">
                  {backupSummary.eKinerjaActivities}
                </div>
                <div className="text-[10px] text-slate-400 font-semibold">E-Kinerja</div>
              </div>
            </div>

            {/* Pilihan Cakupan Database yang Akan Diekspor */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-300 uppercase block">
                Pilih Data yang Ingin Diekspor:
              </label>
              <select
                value={exportScope}
                onChange={e => setExportScope(e.target.value as BackupExportScope)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/15 text-white text-xs font-semibold focus:outline-none focus:border-amber-500"
              >
                <option value="all">
                  📦 Semua Database Lengkap (Nilai, Absensi, Jurnal, Siswa, Soal, &amp; E-Kinerja)
                </option>
                <option value="nilai">
                  📊 Khusus Database Nilai Evaluasi Siswa ({backupSummary.scores} Nilai)
                </option>
                <option value="absensi">
                  📋 Khusus Database Absensi &amp; Kehadiran Siswa (
                  {backupSummary.attendanceRecords + backupSummary.journalAttendanceEntries} Rekaman)
                </option>
                <option value="jurnal">
                  📖 Khusus Database Jurnal Mengajar Harian ({backupSummary.journals} Jurnal)
                </option>
                <option value="siswa_kelas">
                  👥 Khusus Database Siswa &amp; Rombel Kelas ({backupSummary.students} Siswa)
                </option>
                <option value="ekinerja">
                  📑 Khusus Database Laporan E-Kinerja Harian ({backupSummary.eKinerjaActivities} Kegiatan)
                </option>
              </select>
            </div>

            {/* Tombol Ekspor Format Excel (.xlsx) & Format JSON (.json) + Pulihkan JSON */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => handleExportBackupExcel()}
                className="px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Ekspor Cadangan ke Excel (.xlsx)</span>
              </button>

              <button
                type="button"
                onClick={() => handleExportBackupJson()}
                className="px-4 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer transition-all"
              >
                <FileJson className="w-4 h-4" />
                <span>Ekspor Cadangan ke File JSON (.json)</span>
              </button>
            </div>

            {/* Tombol Cepat Per Kategori (Nilai, Absensi, Jurnal) & Pulihkan dari File JSON */}
            <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase mr-1">
                  Unduh Cepat:
                </span>
                <button
                  type="button"
                  onClick={() => handleExportBackupExcel('nilai')}
                  className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-emerald-500/20 border border-white/10 text-emerald-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Download className="w-3 h-3" /> Excel Nilai
                </button>
                <button
                  type="button"
                  onClick={() => handleExportBackupExcel('absensi')}
                  className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-cyan-500/20 border border-white/10 text-cyan-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Download className="w-3 h-3" /> Excel Absensi
                </button>
                <button
                  type="button"
                  onClick={() => handleExportBackupExcel('jurnal')}
                  className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-amber-500/20 border border-white/10 text-amber-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Download className="w-3 h-3" /> Excel Jurnal
                </button>
              </div>

              <label className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/15 text-slate-200 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-colors">
                <Upload className="w-3.5 h-3.5 text-cyan-400" />
                <span>Pulihkan dari Cadangan JSON</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleRestoreFromJsonFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Section 6: Reset & Kosongkan Database (Supabase, IndexedDB & Lokal) */}
        <div className="pt-5 border-t border-white/10 space-y-3 text-xs">
          <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="font-bold text-rose-300 flex items-center gap-1.5 text-sm">
                <Trash2 className="w-4 h-4 text-rose-400" /> Kosongkan Seluruh Data (Fresh / 0 Data)
              </p>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Menghapus seluruh data guru, siswa, kelas, soal, kuis, materi, nilai, absensi, jurnal, e-kinerja, dan forum dari <b>Supabase Cloud</b>, <b>IndexedDB</b>, dan <b>LocalStorage</b> supaya aplikasi benar-benar kosong/fresh. Pastikan Anda telah mengekspor cadangan <b>JSON / Excel</b> di atas terlebih dahulu.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setResetModalMode('fresh_empty')}
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-rose-600/25 shrink-0 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" /> Kosongkan Data (Fresh)
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="font-bold text-slate-300">Pulihkan Data Contoh Bawaan (Demo)</p>
              <p className="text-slate-400 text-[11px]">
                Kembalikan contoh data simulasi awal ke IndexedDB &amp; Supabase jika dibutuhkan
              </p>
            </div>
            <button
              type="button"
              onClick={() => setResetModalMode('demo_default')}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shrink-0 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Pulihkan Data Contoh
            </button>
          </div>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {resetModalMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-lg w-full shadow-2xl animate-in zoom-in-95 duration-200 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto border border-rose-500/30 shadow-lg shadow-rose-500/10">
              {resetModalMode === 'fresh_empty' ? (
                <Trash2 className="w-7 h-7" />
              ) : (
                <RotateCcw className="w-7 h-7" />
              )}
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              {resetModalMode === 'fresh_empty'
                ? 'Kosongkan Seluruh Data (Supabase & IndexedDB)?'
                : 'Pulihkan Data Contoh Bawaan?'}
            </h3>
            <p className="text-xs text-slate-300 text-center leading-relaxed">
              {resetModalMode === 'fresh_empty'
                ? 'Tindakan ini akan menghapus seluruh data guru, siswa, rombel, nilai, soal, kuis, materi, absensi, jurnal, e-kinerja, dan forum dari Supabase Cloud, IndexedDB, serta penyimpanan lokal sehingga aplikasi benar-benar kosong/fresh (0 data).'
                : 'Tindakan ini akan memuat kembali data contoh simulasi awal ke penyimpanan lokal, IndexedDB, dan Supabase Cloud.'}
            </p>

            {/* Panel Cadangan Lokal Cepat sebelum eksekusi Reset Total */}
            {resetModalMode === 'fresh_empty' && (
              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2.5">
                <div className="flex items-start gap-2 text-[11px] text-amber-200">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    <b>Cadangkan Data Sebelum Reset Total:</b> Unduh salinan lokal database Nilai, Absensi, dan Jurnal Mengajar ke komputer Anda terlebih dahulu:
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleExportBackupExcel('all')}
                    className="py-2 px-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" /> Backup Excel (.xlsx)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleExportBackupJson('all')}
                    className="py-2 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                  >
                    <FileJson className="w-3.5 h-3.5" /> Backup JSON (.json)
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                disabled={isResettingData}
                onClick={() => setResetModalMode(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isResettingData}
                onClick={confirmResetDatabase}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                {isResettingData ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" /> Memproses...
                  </>
                ) : resetModalMode === 'fresh_empty' ? (
                  <>
                    <Trash2 className="w-4 h-4" /> Ya, Kosongkan Semua
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-4 h-4" /> Ya, Pulihkan Contoh
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      <SupabaseSqlEditorModal
        isOpen={showSqlHelper}
        onClose={() => setShowSqlHelper(false)}
        showToast={showToast}
        onDataCleaned={() => {
          setProfile(StorageService.getTeacherProfile());
          setSettings(StorageService.getAppSettings());
        }}
      />
    </div>
  );
};
