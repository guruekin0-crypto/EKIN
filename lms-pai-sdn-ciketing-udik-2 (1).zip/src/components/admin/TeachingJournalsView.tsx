import React, { useState } from 'react';
import {
  NotebookPen,
  Plus,
  Sparkles,
  Calendar,
  Printer,
  FileSpreadsheet,
  Edit2,
  Trash2,
  X,
  RefreshCw,
  UserCheck,
  Building2,
  CheckCircle2,
  AlertCircle,
  Maximize2,
  ExternalLink,
  ArrowLeft
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { TeachingJournal, ClassItem } from '../../types';
import { StorageService } from '../../services/storageService';
import { FocusReaderModal } from '../common/FocusReaderModal';
import { openJournalPrintInNewTab } from '../../utils/printDocumentHelper';

interface TeachingJournalsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const TeachingJournalsView: React.FC<TeachingJournalsViewProps> = ({ showToast }) => {
  const [journals, setJournals] = useState<TeachingJournal[]>(StorageService.getJournals());
  const classes = StorageService.getClasses();
  const teacherProfile = StorageService.getTeacherProfile();
  const appSettings = StorageService.getAppSettings();

  const [filterDate, setFilterDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [filterClass, setFilterClass] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingJournal, setEditingJournal] = useState<TeachingJournal | null>(null);

  // Form states
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [formClassId, setFormClassId] = useState<string>(classes[0]?.id || '');
  const [formStatus, setFormStatus] = useState<'Tuntas' | 'Belum Tuntas'>('Tuntas');
  const [formTopic, setFormTopic] = useState('');
  const [formObjective, setFormObjective] = useState('');
  const [formReflection, setFormReflection] = useState('');
  const [formAbsentStudents, setFormAbsentStudents] = useState<string[]>([]);

  // Absent student selector inside modal
  const [selectedStudentForAbsent, setSelectedStudentForAbsent] = useState('');
  const [selectedAbsentReason, setSelectedAbsentReason] = useState('Sakit');

  // Print modal state & Focus Reader state
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [focusJournal, setFocusJournal] = useState<TeachingJournal | null>(null);

  // Delete Confirmation Modal
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  const selectedClassObj = classes.find(c => c.id === formClassId);
  const selectedGrade = selectedClassObj?.className ? selectedClassObj.className.replace(/\D/g, '') || selectedClassObj.className.charAt(0) : '5';
  const availableTopics = StorageService.getClassTopics(selectedGrade);

  const refreshJournals = () => {
    setJournals(StorageService.getJournals());
  };

  const formatHariTanggalIndo = (dateStr: string) => {
    if (!dateStr) return '-';
    try {
      const [y, m, d] = dateStr.split('-').map(Number);
      const dt = new Date(y, (m || 1) - 1, d || 1);
      return dt.toLocaleDateString('id-ID', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });
    } catch (e) {
      return dateStr;
    }
  };

  const openAddModal = () => {
    setEditingJournal(null);
    setFormDate(filterDate || new Date().toISOString().split('T')[0]);
    setFormClassId(filterClass || (classes[0]?.id || ''));
    setFormStatus('Tuntas');
    setFormTopic('');
    setFormObjective('');
    setFormReflection('');
    setFormAbsentStudents([]);
    setSelectedStudentForAbsent('');
    setModalOpen(true);
  };

  const openEditModal = (j: TeachingJournal) => {
    setEditingJournal(j);
    setFormDate(j.date);
    setFormClassId(j.classId);
    setFormStatus(j.status);
    setFormTopic(j.topic);
    setFormObjective(j.learningObjective);
    setFormReflection(j.reflection);
    setFormAbsentStudents([...j.absentStudents]);
    setSelectedStudentForAbsent('');
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formDate || !formClassId || !formTopic.trim() || !formObjective.trim()) {
      showToast('Harap lengkapi Tanggal, Kelas, Materi Pokok, dan Tujuan Pembelajaran!', 'error');
      return;
    }

    const cls = classes.find(c => c.id === formClassId);
    StorageService.saveJournal({
      id: editingJournal ? editingJournal.id : undefined,
      date: formDate,
      classId: formClassId,
      className: cls ? cls.className : '',
      topic: formTopic.trim(),
      learningObjective: formObjective.trim(),
      reflection: formReflection.trim() || 'Pembelajaran terlaksana dengan baik dan lancar.',
      absentStudents: formAbsentStudents,
      status: formStatus,
      teacherName: teacherProfile.fullName,
      schoolName: teacherProfile.schoolName
    });

    setModalOpen(false);
    refreshJournals();
    showToast(editingJournal ? 'Jurnal mengajar berhasil diperbarui' : 'Jurnal mengajar baru disimpan');
  };

  const handleDelete = (id: string) => {
    setDeleteTargetId(id);
  };

  const confirmDelete = () => {
    if (!deleteTargetId) return;
    StorageService.deleteJournal(deleteTargetId);
    refreshJournals();
    showToast('Catatan jurnal berhasil dihapus', 'info');
    setDeleteTargetId(null);
  };

  // AI Generator helper for learning objectives & reflections
  const generateAIField = (mode: 'objective' | 'reflection') => {
    const topic = formTopic.trim() || 'Pendidikan Agama Islam dan Budi Pekerti';
    const cls = classes.find(c => c.id === formClassId);
    const className = cls ? cls.className : 'SD';

    if (mode === 'objective') {
      const suggestions = [
        `Melalui pendekatan saintifik berbasis diskusi kelompok dan pengamatan kisah teladan pada materi "${topic}", peserta didik kelas ${className} mampu memahami esensi materi dengan benar, menunjukkan sikap santun dan tanggung jawab, serta membiasakan akhlak mulia dalam kehidupan sehari-hari di rumah dan sekolah.`,
        `Setelah menyimak paparan materi dan praktik terbimbing tentang "${topic}", peserta didik kelas ${className} diharapkan mampu menjelaskan makna pokok materi secara runtut dan mengamalkannya dalam ibadah dan pergaulan sesama teman.`,
        `Melalui model pembelajaran Problem Based Learning berbantuan media interaktif mengenai "${topic}", peserta didik kelas ${className} dapat mengidentifikasi hikmah serta mengimplementasikan nilai-nilai terpuji secara konsisten.`
      ];
      setFormObjective(suggestions[Math.floor(Math.random() * suggestions.length)]);
      showToast('Tujuan Pembelajaran berhasil dirumuskan oleh AI ✨', 'success');
    } else {
      const suggestions =
        formStatus === 'Tuntas'
          ? [
              `Pembelajaran materi "${topic}" di kelas ${className} berlangsung sangat kondusif, aktif, dan menyenangkan. Sebagian besar peserta didik antusias menjawab pertanyaan pemantik dan dapat menyimpulkan materi secara mandiri. Tindak lanjut: memberikan pengayaan hafalan dan pembiasaan shalih di rumah.`,
              `Alhamdulillah kegiatan pembelajaran materi "${topic}" tuntas sesuai alokasi waktu. Siswa menunjukkan pemahaman konsep yang kuat dan saling membantu saat diskusi kelompok. Tindak lanjut: asesmen berkala pada pertemuan berikutnya.`
            ]
          : [
              `Sebagian peserta didik kelas ${className} sudah memahami materi "${topic}", namun beberapa siswa masih memerlukan bimbingan remedial dalam pelafalan dan penerapan praktisnya. Tindak lanjut: bimbingan kelompok kecil dan latihan mandiri terbimbing.`,
              `Target pembelajaran materi "${topic}" belum sepenuhnya tuntas karena keterbatasan waktu dan terdapat kendala pemahaman awal pada sebagian siswa. Tindak lanjut: mengulang sub-materi pokok pada pertemuan berikutnya.`
            ];
      setFormReflection(suggestions[Math.floor(Math.random() * suggestions.length)]);
      showToast('Refleksi Pembelajaran berhasil dirumuskan oleh AI ✨', 'success');
    }
  };

  // Sync absent students from daily attendance
  const syncFromDailyAttendance = () => {
    if (!formClassId || !formDate) {
      showToast('Pilih kelas dan tanggal terlebih dahulu!', 'error');
      return;
    }
    const attRecords = StorageService.getAttendance(formClassId, formDate);
    const students = StorageService.getStudents();
    const studentMap = new Map(students.map(s => [s.id, s.fullName]));

    const absent = attRecords
      .filter(a => a.status !== 'Hadir')
      .map(a => `${studentMap.get(a.studentId) || 'Siswa'} (${a.status})`);

    setFormAbsentStudents(absent);
    showToast(
      absent.length
        ? `Tersinkron ${absent.length} siswa tidak hadir dari Absensi Harian!`
        : 'Semua siswa tercatat Hadir pada tanggal ini',
      'info'
    );
  };

  const addAbsentManual = () => {
    if (!selectedStudentForAbsent) return;
    const item = `${selectedStudentForAbsent} (${selectedAbsentReason})`;
    if (!formAbsentStudents.includes(item)) {
      setFormAbsentStudents([...formAbsentStudents, item]);
    }
    setSelectedStudentForAbsent('');
  };

  const removeAbsentItem = (index: number) => {
    setFormAbsentStudents(formAbsentStudents.filter((_, idx) => idx !== index));
  };

  // Filter journals
  const filteredJournals = journals.filter(j => {
    const matchDate = !filterDate || j.date === filterDate;
    const matchClass = !filterClass || j.classId === filterClass;
    const matchStatus = !filterStatus || j.status === filterStatus;
    return matchDate && matchClass && matchStatus;
  });

  const exportExcel = () => {
    if (journals.length === 0) {
      showToast('Tidak ada data jurnal untuk diekspor', 'error');
      return;
    }
    const exportData = journals.map((j, idx) => ({
      'No': idx + 1,
      'Hari/Tanggal': formatHariTanggalIndo(j.date),
      'Kelas': `Kelas ${j.className}`,
      'Materi Pokok': j.topic,
      'Tujuan Pembelajaran': j.learningObjective,
      'Refleksi Pembelajaran': j.reflection,
      'Siswa Tidak Hadir': j.absentStudents.length ? j.absentStudents.join(', ') : 'Nihil',
      'Status': j.status
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Jurnal_Mengajar');
    XLSX.writeFile(wb, 'Jurnal_Mengajar_PAI_SDN_Ciketing_Udik_2.xlsx');
  };

  const currentClassStudents = StorageService.getStudents()
    .filter(s => s.classId === formClassId)
    .sort((a, b) => a.fullName.localeCompare(b.fullName));

  return (
    <div className="space-y-5">
      {/* Teacher Profile & Date Banner */}
      <div className="glass-strong rounded-3xl p-5 border border-emerald-500/25 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          <div className="flex items-center gap-3.5 bg-white/5 p-3.5 rounded-2xl border border-white/10">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white shrink-0 shadow">
              <UserCheck className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                Pendidik PAI (Otomatis)
              </p>
              <p className="font-bold text-white text-sm truncate">{teacherProfile.fullName}</p>
              <p className="text-[11px] text-slate-400 font-mono">NIP: {teacherProfile.nip || '-'}</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5 bg-white/5 p-3.5 rounded-2xl border border-white/10">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shrink-0 shadow">
              <Building2 className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">
                Satuan Pendidikan
              </p>
              <p className="font-bold text-white text-sm truncate">{teacherProfile.schoolName}</p>
              <p className="text-[11px] text-slate-400">Mata Pelajaran: PAI & Budi Pekerti</p>
            </div>
          </div>

          <div className="bg-white/5 p-3.5 rounded-2xl border border-amber-500/30">
            <label className="text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5 mb-1">
              <Calendar className="w-3.5 h-3.5" /> Hari / Tanggal Jurnal
            </label>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={filterDate}
                onChange={e => setFilterDate(e.target.value)}
                className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-white/15 text-xs font-bold text-white cursor-pointer"
              />
              <button
                onClick={() => setFilterDate('')}
                className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] text-slate-200 font-semibold cursor-pointer"
                title="Tampilkan Semua Tanggal"
              >
                Semua
              </button>
            </div>
            <p className="text-[11px] text-amber-300 font-semibold mt-1 truncate">
              {filterDate ? formatHariTanggalIndo(filterDate) : 'Menampilkan Seluruh Catatan'}
            </p>
          </div>
        </div>
      </div>

      {/* Control Actions Bar */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-3 border border-white/10">
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={filterClass}
            onChange={e => setFilterClass(e.target.value)}
            className="px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs font-semibold text-white cursor-pointer"
          >
            <option value="">Semua Rombel Kelas</option>
            {classes.map(c => (
              <option key={c.id} value={c.id}>
                Kelas {c.className}
              </option>
            ))}
          </select>

          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs font-semibold text-white cursor-pointer"
          >
            <option value="">Semua Status</option>
            <option value="Tuntas">Tuntas</option>
            <option value="Belum Tuntas">Belum Tuntas</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              const opened = openJournalPrintInNewTab(
                filteredJournals,
                appSettings,
                teacherProfile,
                formatHariTanggalIndo
              );
              if (opened) {
                showToast('Pratinjau Cetak Jurnal Resmi dibuka pada tab baru!', 'success');
              } else {
                setPrintModalOpen(true);
              }
            }}
            className="px-3.5 py-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <ExternalLink className="w-4 h-4" /> Cetak Jurnal (Tab Baru)
          </button>

          <button
            onClick={() => {
              if (filteredJournals.length > 0) {
                setFocusJournal(filteredJournals[0]);
              } else {
                showToast('Belum ada catatan jurnal untuk dibaca', 'info');
              }
            }}
            className="px-3.5 py-2.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Maximize2 className="w-4 h-4" /> Focus Reader
          </button>

          <button
            onClick={exportExcel}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" /> Export Excel
          </button>

          <button
            onClick={openAddModal}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4" /> + Isi Jurnal Mengajar
          </button>
        </div>
      </div>

      {/* Teaching Journals Table */}
      <div className="glass rounded-2xl border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs min-w-[950px]">
            <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-300 font-bold border-b border-white/10">
              <tr>
                <th className="py-3.5 px-3 w-12 text-center">No</th>
                <th className="py-3.5 px-3 w-36">Hari / Tanggal</th>
                <th className="py-3.5 px-3 w-20 text-center">Kelas</th>
                <th className="py-3.5 px-4 w-48">Materi Pembelajaran</th>
                <th className="py-3.5 px-4">Tujuan Pembelajaran</th>
                <th className="py-3.5 px-4">Refleksi Pembelajaran</th>
                <th className="py-3.5 px-3 w-40">Siswa Tidak Hadir</th>
                <th className="py-3.5 px-3 w-24 text-center">Status</th>
                <th className="py-3.5 px-3 w-20 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredJournals.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-10 text-slate-400 italic">
                    Belum ada catatan jurnal pada filter ini. Klik <b>"+ Isi Jurnal Mengajar"</b> untuk menambahkan catatan baru.
                  </td>
                </tr>
              ) : (
                filteredJournals.map((j, index) => {
                  const isTuntas = j.status === 'Tuntas';
                  return (
                    <tr key={j.id} className="hover:bg-white/5 transition-colors align-top">
                      <td className="py-3.5 px-3 text-center font-mono text-slate-400">
                        {index + 1}
                      </td>
                      <td className="py-3.5 px-3 font-semibold text-amber-300">
                        {formatHariTanggalIndo(j.date)}
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                          {j.className || '-'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-bold text-white leading-snug">
                        {j.topic}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300 leading-relaxed whitespace-pre-line text-[11px]">
                        {j.learningObjective}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300 leading-relaxed whitespace-pre-line text-[11px]">
                        {j.reflection}
                      </td>
                      <td className="py-3.5 px-3">
                        {j.absentStudents && j.absentStudents.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {j.absentStudents.map((abs, idx) => (
                              <span
                                key={idx}
                                className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px]"
                              >
                                {abs}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-emerald-400 text-[11px] font-semibold">
                            NIHIL (Semua Hadir)
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            isTuntas
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                              : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          }`}
                        >
                          {j.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-right whitespace-nowrap">
                        <button
                          onClick={() => setFocusJournal(j)}
                          className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/30 transition-colors mr-1 cursor-pointer"
                          title="Baca di Focus Reader (Layar Penuh)"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openEditModal(j)}
                          className="p-1.5 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 transition-colors mr-1 cursor-pointer"
                          title="Edit Catatan"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(j.id)}
                          className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 transition-colors cursor-pointer"
                          title="Hapus Catatan"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Journal Entry */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <NotebookPen className="w-5 h-5 text-emerald-400" />
                {editingJournal ? 'Edit Catatan Jurnal Mengajar' : 'Isi Jurnal Mengajar Baru (Kurikulum Merdeka)'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 overflow-y-auto flex-1 space-y-4">
              {/* Header Info Pill */}
              <div className="bg-emerald-500/10 border border-emerald-500/25 p-3 rounded-2xl text-xs space-y-1">
                <div>
                  <span className="text-slate-400">Guru PAI:</span>{' '}
                  <b className="text-white">{teacherProfile.fullName}</b> &bull; NIP: {teacherProfile.nip || '-'}
                </div>
                <div>
                  <span className="text-slate-400">Satuan Pendidikan:</span>{' '}
                  <b className="text-white">{teacherProfile.schoolName}</b>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Hari & Tanggal <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={e => setFormDate(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Rombel Kelas <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={formClassId}
                    onChange={e => {
                      setFormClassId(e.target.value);
                      setSelectedStudentForAbsent('');
                    }}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                    required
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        Kelas {c.className}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Keterangan Ketercapaian
                  </label>
                  <select
                    value={formStatus}
                    onChange={e => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Tuntas">Tuntas</option>
                    <option value="Belum Tuntas">Belum Tuntas</option>
                  </select>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300 uppercase">
                    Materi Pokok / Pembelajaran <span className="text-rose-400">*</span>
                  </label>
                  {availableTopics.length > 0 && (
                    <span className="text-[10px] text-emerald-400 font-medium">
                      Tersedia {availableTopics.length} materi di Silabus Kelas {selectedGrade}
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  list="class-topics-list"
                  value={formTopic}
                  onChange={e => {
                    const val = e.target.value;
                    setFormTopic(val);
                    const matched = availableTopics.find(
                      t => `Bab ${t.chapterNo}: ${t.chapterTitle}` === val || t.chapterTitle === val
                    );
                    if (matched && matched.learningObjective && !formObjective) {
                      setFormObjective(matched.learningObjective);
                    }
                  }}
                  placeholder="Ketik materi atau pilih dari silabus kelas..."
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500"
                  required
                />
                <datalist id="class-topics-list">
                  {availableTopics.map(t => (
                    <option key={t.id} value={`Bab ${t.chapterNo}: ${t.chapterTitle}`}>
                      {t.domain} &bull; Semester {t.semester}
                    </option>
                  ))}
                </datalist>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300 uppercase">
                    Tujuan Pembelajaran <span className="text-rose-400">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => generateAIField('objective')}
                    className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" /> ✨ Buatkan dengan AI
                  </button>
                </div>
                <textarea
                  rows={3}
                  value={formObjective}
                  onChange={e => setFormObjective(e.target.value)}
                  placeholder="Tuliskan tujuan pembelajaran atau klik 'Buatkan dengan AI'..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500 leading-relaxed"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300 uppercase">
                    Refleksi & Catatan Guru PAI <span className="text-rose-400">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => generateAIField('reflection')}
                    className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" /> ✨ Buatkan Refleksi AI
                  </button>
                </div>
                <textarea
                  rows={3}
                  value={formReflection}
                  onChange={e => setFormReflection(e.target.value)}
                  placeholder="Catatan pelaksanaan belajar, respon siswa, dan rencana tindak lanjut..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500 leading-relaxed"
                />
              </div>

              {/* Absent Students Section */}
              <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-white/10 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="text-xs font-bold text-rose-300 uppercase flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-rose-400" /> Siswa Tidak Hadir
                  </label>
                  <button
                    type="button"
                    onClick={syncFromDailyAttendance}
                    className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" /> Sinkron dari Absensi Harian
                  </button>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <select
                    value={selectedStudentForAbsent}
                    onChange={e => setSelectedStudentForAbsent(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-white/15 text-xs text-white"
                  >
                    <option value="">-- Pilih Nama Siswa di Kelas Ini --</option>
                    {currentClassStudents.map(s => (
                      <option key={s.id} value={s.fullName}>
                        {s.fullName}
                      </option>
                    ))}
                  </select>
                  <select
                    value={selectedAbsentReason}
                    onChange={e => setSelectedAbsentReason(e.target.value)}
                    className="sm:w-28 px-2.5 py-2 rounded-xl bg-slate-950 border border-white/15 text-xs text-white"
                  >
                    <option value="Sakit">Sakit</option>
                    <option value="Izin">Izin</option>
                    <option value="Alpa">Alpa</option>
                  </select>
                  <button
                    type="button"
                    onClick={addAbsentManual}
                    className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/30 text-xs font-bold transition-colors cursor-pointer"
                  >
                    + Tambah
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {formAbsentStudents.length === 0 ? (
                    <span className="text-xs text-emerald-400 italic">
                      Nihil — Seluruh siswa hadir mengikuti pembelajaran.
                    </span>
                  ) : (
                    formAbsentStudents.map((item, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-200 border border-rose-500/30 text-xs font-medium"
                      >
                        {item}
                        <button
                          type="button"
                          onClick={() => removeAbsentItem(idx)}
                          className="text-rose-400 hover:text-white font-bold ml-1"
                        >
                          &times;
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
                >
                  Simpan Jurnal Mengajar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Print Modal with Kop & Dual Signature Block (Scrollable & Never Trapped) */}
      {printModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md overflow-y-auto block p-3 sm:p-6">
          <div className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border border-white/15 px-4 py-3 rounded-2xl mb-6 shadow-2xl flex flex-wrap items-center justify-between gap-3 max-w-4xl mx-auto no-print">
            <button
              type="button"
              onClick={() => setPrintModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> &larr; Kembali ke Menu Utama
            </button>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  openJournalPrintInNewTab(
                    filteredJournals,
                    appSettings,
                    teacherProfile,
                    formatHariTanggalIndo
                  );
                }}
                className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" /> Buka di Tab Baru
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer"
              >
                <Printer className="w-4 h-4" /> Cetak Dokumen
              </button>
            </div>
          </div>

          <div className="w-full max-w-4xl mx-auto rounded-2xl shadow-2xl overflow-hidden">
            {/* Printable Paper Document Container */}
            <div className="p-6 sm:p-10 bg-white text-black font-serif text-sm">
              <div className="text-center pb-4 border-b-2 border-black mb-5">
                <h3 className="text-sm font-bold tracking-wider uppercase">
                  PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN
                </h3>
                <h2 className="text-base font-extrabold uppercase">
                  {teacherProfile.schoolName || 'SDN CIKETING UDIK 2 BANTARGEBANG'}
                </h2>
                <p className="text-xs italic text-gray-700">
                  {appSettings.schoolAddress || 'Jl. Raya Ciketing Udik No. 2, Bantargebang, Kota Bekasi'}
                </p>
                <div className="mt-3 py-1 border-t border-b border-black text-center font-bold text-xs uppercase tracking-widest">
                  JURNAL PELAKSANAAN PEMBELAJARAN PAI & BUDI PEKERTI
                </div>
              </div>

              {/* Identity Block */}
              <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                <div>
                  <p><strong>Nama Guru:</strong> {teacherProfile.fullName}</p>
                  <p><strong>NIP Guru:</strong> {teacherProfile.nip || '-'}</p>
                </div>
                <div className="text-right">
                  <p><strong>Mata Pelajaran:</strong> Pendidikan Agama Islam & Budi Pekerti</p>
                  <p><strong>Tahun Ajaran:</strong> {appSettings.academicYear || '2026/2027'}</p>
                </div>
              </div>

              {/* Table */}
              <table className="w-full border-collapse border border-black text-xs mb-8">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border border-black p-2 text-center w-8">No</th>
                    <th className="border border-black p-2 w-32">Hari/Tanggal</th>
                    <th className="border border-black p-2 text-center w-16">Kelas</th>
                    <th className="border border-black p-2 w-44">Materi Pokok</th>
                    <th className="border border-black p-2">Tujuan Pembelajaran</th>
                    <th className="border border-black p-2">Refleksi Guru</th>
                    <th className="border border-black p-2 w-28">Ketidakhadiran</th>
                    <th className="border border-black p-2 text-center w-16">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredJournals.map((j, idx) => (
                    <tr key={j.id} className="align-top">
                      <td className="border border-black p-2 text-center">{idx + 1}</td>
                      <td className="border border-black p-2">{formatHariTanggalIndo(j.date)}</td>
                      <td className="border border-black p-2 text-center">Kelas {j.className}</td>
                      <td className="border border-black p-2 font-bold">{j.topic}</td>
                      <td className="border border-black p-2">{j.learningObjective}</td>
                      <td className="border border-black p-2">{j.reflection}</td>
                      <td className="border border-black p-2 text-[10px]">
                        {j.absentStudents.length ? j.absentStudents.join(', ') : 'Nihil'}
                      </td>
                      <td className="border border-black p-2 text-center font-bold">{j.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Dual Official Signature Block */}
              <div className="grid grid-cols-2 text-xs pt-4 break-inside-avoid">
                <div className="text-center">
                  <p>Mengetahui,</p>
                  <p>Kepala SDN Ciketing Udik 2</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{appSettings.principalName || 'Hj. Siti Rohmah, M.Pd.'}</p>
                  <p>NIP. {appSettings.principalNip || '-'}</p>
                </div>
                <div className="text-center">
                  <p>Bekasi, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                  <p>Guru Pendidikan Agama Islam</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{teacherProfile.fullName}</p>
                  <p>NIP. {teacherProfile.nip || '-'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTargetId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Catatan Jurnal?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus catatan pelaksanaan jurnal mengajar ini? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTargetId(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Catatan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Focus Reader for Teaching Journals */}
      <FocusReaderModal
        isOpen={!!focusJournal}
        onClose={() => setFocusJournal(null)}
        title={focusJournal?.topic || ''}
        subtitle={
          focusJournal
            ? `Jurnal Mengajar PAI • Kelas ${focusJournal.className} • ${formatHariTanggalIndo(focusJournal.date)}`
            : ''
        }
        badgeText={focusJournal ? `Status: ${focusJournal.status}` : ''}
        extraSections={
          focusJournal
            ? [
                {
                  label: 'I. Tujuan Pembelajaran (Pedoman BKPDM No. 020 Th 2026 KBC)',
                  content: focusJournal.learningObjective
                },
                {
                  label: 'II. Refleksi Pelaksanaan & Tindak Lanjut Guru PAI',
                  content: focusJournal.reflection
                },
                {
                  label: 'III. Catatan Kehadiran Siswa',
                  content:
                    focusJournal.absentStudents && focusJournal.absentStudents.length > 0
                      ? `Siswa Tidak Hadir: ${focusJournal.absentStudents.join(', ')}`
                      : 'Nihil — Seluruh siswa hadir mengikuti pembelajaran dengan antusias.'
                }
              ]
            : []
        }
      />
    </div>
  );
};
