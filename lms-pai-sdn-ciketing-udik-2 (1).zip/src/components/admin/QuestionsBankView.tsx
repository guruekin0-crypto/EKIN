import React, { useState } from 'react';
import {
  Sparkles,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  Printer,
  FileQuestion,
  X,
  Check,
  CheckCircle2,
  Wand2,
  Type
} from 'lucide-react';
import { Question, QuestionType } from '../../types';
import { StorageService } from '../../services/storageService';
import { generateAiQuestions } from '../../services/aiQuestionService';

interface QuestionsBankViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onNavigateToCreate?: () => void;
}

export const QuestionsBankView: React.FC<QuestionsBankViewProps> = ({ showToast, onNavigateToCreate }) => {
  const [questions, setQuestions] = useState<Question[]>(StorageService.getQuestions());
  const [search, setSearch] = useState('');
  const [filterClass, setFilterClass] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('');
  const [filterSemester, setFilterSemester] = useState<string>('');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);

  // Form states
  const [formType, setFormType] = useState<QuestionType>('pg_standar');
  const [formClassId, setFormClassId] = useState('5');
  const [formSemester, setFormSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [formScoreWeight, setFormScoreWeight] = useState(10);
  const [formStimulus, setFormStimulus] = useState('');
  const [formDomain, setFormDomain] = useState('Al-Qur\'an & Hadis');
  const [formApproach, setFormApproach] = useState('Kurikulum Berbasis Cinta (KBC)');
  const [formQuestion, setFormQuestion] = useState('');
  const [formArabic, setFormArabic] = useState('');
  const [formOptions, setFormOptions] = useState<string[]>(['', '', '', '']);
  const [formMatchingPairs, setFormMatchingPairs] = useState<Array<{ left: string; right: string }>>([
    { left: '', right: '' },
    { left: '', right: '' },
    { left: '', right: '' }
  ]);
  const [formCorrectSingle, setFormCorrectSingle] = useState('');
  const [formCorrectMulti, setFormCorrectMulti] = useState<string[]>([]);
  const [formExplanation, setFormExplanation] = useState('');

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; question: string } | null>(null);

  // AI Generator Modal
  const [aiModalOpen, setAiModalOpen] = useState(false);
  const [aiTopic, setAiTopic] = useState('Surah Al-Ma\'un & Kepedulian Sosial');
  const [aiCustomTopic, setAiCustomTopic] = useState('');
  const [aiGrade, setAiGrade] = useState('5');
  const [aiSemester, setAiSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [aiQuestionType, setAiQuestionType] = useState('all');
  const [aiCount, setAiCount] = useState(3);
  const [aiGenerating, setAiGenerating] = useState(false);

  // Print Modal & Multi-format tabs (Kisi-Kisi, Soal Siswa, Kunci & Pembahasan)
  const [printBlueprintModalOpen, setPrintBlueprintModalOpen] = useState(false);
  const [printModalTab, setPrintModalTab] = useState<'blueprint' | 'questions' | 'rubric'>('blueprint');
  const [singlePrintQuestion, setSinglePrintQuestion] = useState<Question | null>(null);

  const teacherProfile = StorageService.getTeacherProfile();
  const appSettings = StorageService.getAppSettings();

  const activeSchoolName = appSettings.schoolName || teacherProfile.schoolName || 'SDN Ciketing Udik 2 Bantargebang';

  const refreshQuestions = () => {
    setQuestions(StorageService.getQuestions());
  };

  const openAddModal = () => {
    setEditingQuestion(null);
    setFormType('pg_standar');
    setFormClassId(filterClass || '5');
    setFormSemester('Ganjil');
    setFormScoreWeight(10);
    setFormStimulus('');
    setFormDomain('Al-Qur\'an & Hadis');
    setFormApproach('Kurikulum Berbasis Cinta (KBC)');
    setFormQuestion('');
    setFormArabic('');
    setFormOptions(['', '', '', '']);
    setFormMatchingPairs([
      { left: '', right: '' },
      { left: '', right: '' },
      { left: '', right: '' }
    ]);
    setFormCorrectSingle('');
    setFormCorrectMulti([]);
    setFormExplanation('');
    setModalOpen(true);
  };

  const openEditModal = (q: Question) => {
    setEditingQuestion(q);
    setFormType(q.questionType);
    setFormClassId(q.classId);
    setFormSemester(q.semester);
    setFormScoreWeight(q.scoreWeight);
    setFormStimulus(q.stimulus || '');
    setFormDomain(q.domain || 'Al-Qur\'an & Hadis');
    setFormApproach(q.approach || 'Kurikulum Berbasis Cinta (KBC)');
    setFormQuestion(q.question);
    setFormArabic(q.arabicText || '');
    setFormOptions(q.options.length ? [...q.options] : ['', '', '', '']);
    if (q.questionType === 'menjodohkan') {
      setFormMatchingPairs(
        q.matchingPairs && q.matchingPairs.length >= 2
          ? q.matchingPairs.map(p => ({ ...p }))
          : [
              { left: '', right: '' },
              { left: '', right: '' },
              { left: '', right: '' }
            ]
      );
    } else if (q.questionType === 'pg_kompleks') {
      setFormCorrectMulti(Array.isArray(q.correctAnswer) ? q.correctAnswer : [q.correctAnswer]);
      setFormCorrectSingle('');
    } else {
      setFormCorrectSingle(typeof q.correctAnswer === 'string' ? q.correctAnswer : q.correctAnswer[0] || '');
      setFormCorrectMulti([]);
    }
    setFormExplanation(q.explanation || '');
    setModalOpen(true);
  };

  const insertArabicSnippet = (snippet: string) => {
    setFormArabic(prev => (prev ? prev + ' ' + snippet : snippet));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formQuestion.trim()) {
      showToast('Butir soal pertanyaan wajib diisi!', 'error');
      return;
    }

    let correctAnswer: string | string[] = '';
    let finalOptions = formOptions.filter(o => o.trim() !== '');
    let finalMatchingPairs: Array<{ left: string; right: string }> | undefined = undefined;

    if (formType === 'pg_standar' || formType === 'benar_salah') {
      if (!formCorrectSingle.trim()) {
        showToast('Pilih kunci jawaban yang benar!', 'error');
        return;
      }
      correctAnswer = formCorrectSingle.trim();
      if (formType === 'benar_salah') {
        finalOptions = ['Benar', 'Salah'];
      }
    } else if (formType === 'pg_kompleks') {
      if (formCorrectMulti.length === 0) {
        showToast('Pilih minimal 1 opsi jawaban yang benar untuk PG Kompleks!', 'error');
        return;
      }
      correctAnswer = formCorrectMulti;
    } else if (formType === 'menjodohkan') {
      const validPairs = formMatchingPairs.filter(
        p => p.left.trim() !== '' && p.right.trim() !== ''
      );
      if (validPairs.length < 2) {
        showToast('Isi minimal 2 pasangan pernyataan & jawaban untuk soal Menjodohkan!', 'error');
        return;
      }
      finalMatchingPairs = validPairs.map(p => ({
        left: p.left.trim(),
        right: p.right.trim()
      }));
      finalOptions = finalMatchingPairs.map(p => `${p.left} ➔ ${p.right}`);
      correctAnswer = finalMatchingPairs.map(p => `${p.left} = ${p.right}`);
    } else if (formType === 'isian_singkat') {
      if (!formCorrectSingle.trim()) {
        showToast('Isi kunci jawaban singkat terlebih dahulu!', 'error');
        return;
      }
      correctAnswer = formCorrectSingle.trim();
      finalOptions = [];
    } else {
      correctAnswer = formCorrectSingle.trim() || 'Rubrik penilaian guru';
      finalOptions = [];
    }

    const className = ['1', '2', '3', '4', '5', '6'].includes(formClassId)
      ? `Tingkat Kelas ${formClassId}`
      : `Kelas ${formClassId}`;

    StorageService.saveQuestion({
      id: editingQuestion ? editingQuestion.id : undefined,
      questionType: formType,
      classId: formClassId,
      className,
      semester: formSemester,
      domain: formDomain,
      approach: formApproach,
      scoreWeight: Number(formScoreWeight) || 10,
      stimulus: formStimulus.trim() || undefined,
      question: formQuestion.trim(),
      arabicText: formArabic.trim() || undefined,
      options: finalOptions,
      matchingPairs: finalMatchingPairs,
      correctAnswer,
      explanation: formExplanation.trim() || undefined
    });

    setModalOpen(false);
    refreshQuestions();
    showToast(editingQuestion ? 'Soal berhasil diperbarui' : 'Butir soal berhasil ditambahkan ke Bank Soal');
  };

  const handleDelete = (id: string, question: string) => {
    setDeleteTarget({ id, question });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    StorageService.deleteQuestion(deleteTarget.id);
    refreshQuestions();
    showToast('Soal berhasil dihapus dari Bank Soal', 'info');
    setDeleteTarget(null);
  };

  // Automated AI Generator with Kurikulum Merdeka, Pendekatan KBC, TKA Stimulus, Khat Naskh, and Dynamic School Name
  const handleGenerateAI = async () => {
    setAiGenerating(true);
    const chosenTopic = aiCustomTopic.trim() || aiTopic;

    try {
      const result = await generateAiQuestions({
        topic: chosenTopic,
        grade: aiGrade,
        semester: aiSemester,
        count: aiCount,
        schoolName: activeSchoolName,
        questionType: aiQuestionType
      });

      result.questions.forEach(q => StorageService.saveQuestion(q));
      refreshQuestions();
      setAiModalOpen(false);
      showToast(
        result.source === 'gemini'
          ? `Berhasil merumuskan ${result.questions.length} butir soal AI (Gemini 3.8 Flash) berpendekatan KBC & TKA! ✨`
          : `Berhasil merumuskan ${result.questions.length} butir soal model TKA berpendekatan KBC & Khat Naskh untuk ${activeSchoolName}! ✨`,
        'success'
      );
    } catch (err: any) {
      showToast('Gagal merumuskan soal: ' + (err?.message || 'Terjadi kesalahan sistem'), 'error');
    } finally {
      setAiGenerating(false);
    }
  };

  const filtered = questions.filter(q => {
    const matchSearch =
      q.question.toLowerCase().includes(search.toLowerCase()) ||
      (q.arabicText || '').includes(search) ||
      (q.explanation || '').toLowerCase().includes(search.toLowerCase());
    const matchClass = !filterClass || q.classId === filterClass;
    const matchType = !filterType || q.questionType === filterType;
    const matchSemester = !filterSemester || q.semester === filterSemester;
    return matchSearch && matchClass && matchType && matchSemester;
  });

  return (
    <div className="space-y-5">
      {/* Search & Actions Bar */}
      <div className="glass rounded-2xl p-4 sm:p-5 flex flex-col xl:flex-row items-center justify-between gap-3 border border-white/10">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full xl:w-auto flex-1">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Cari materi soal / ayat..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <select
            value={filterClass}
            onChange={e => setFilterClass(e.target.value)}
            className="w-full sm:w-40 px-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs text-white"
          >
            <option value="">Semua Tingkat</option>
            <option value="1">Tingkat Kelas 1</option>
            <option value="2">Tingkat Kelas 2</option>
            <option value="3">Tingkat Kelas 3</option>
            <option value="4">Tingkat Kelas 4</option>
            <option value="5">Tingkat Kelas 5</option>
            <option value="6">Tingkat Kelas 6</option>
          </select>

          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="w-full sm:w-40 px-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-xs text-white"
          >
            <option value="">Semua Tipe Soal</option>
            <option value="pg_standar">Pilihan Ganda</option>
            <option value="pg_kompleks">PG Kompleks</option>
            <option value="benar_salah">Benar / Salah</option>
            <option value="menjodohkan">Menjodohkan</option>
            <option value="isian_singkat">Isian Singkat</option>
            <option value="essay">Uraian / Esai</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto justify-end">
          <button
            onClick={() => {
              setSinglePrintQuestion(null);
              setPrintBlueprintModalOpen(true);
            }}
            className="px-3.5 py-2.5 rounded-xl bg-blue-500/15 hover:bg-blue-500/25 border border-blue-500/30 text-blue-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" /> Cetak Soal &amp; Kisi-Kisi ({filtered.length})
          </button>

          <button
            onClick={openAddModal}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" /> + Tambah Soal Manual
          </button>

          {onNavigateToCreate && (
            <button
              onClick={onNavigateToCreate}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-600 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-lg shadow-cyan-500/20 cursor-pointer transition-all"
            >
              <Sparkles className="w-4 h-4 text-amber-200" /> Studio Buat Soal AI
            </button>
          )}
        </div>
      </div>

      {/* Questions List Cards */}
      <div className="space-y-3.5">
        {filtered.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center text-slate-400 italic border border-white/10">
            Belum ada butir soal pada filter ini. Klik <b>"+ Tambah Soal Manual"</b> atau gunakan <b>"Studio Buat Soal AI"</b>.
          </div>
        ) : (
          filtered.map((q, index) => {
            const typeLabel = {
              pg_standar: 'Pilihan Ganda (Tunggal)',
              pg_kompleks: 'Pilihan Ganda Kompleks (Jamak)',
              benar_salah: 'Benar / Salah',
              menjodohkan: 'Menjodohkan (Pasangan)',
              isian_singkat: 'Isian Singkat',
              essay: 'Uraian / Esai Singkat'
            }[q.questionType] || q.questionType;

            return (
              <div
                key={q.id}
                className="glass rounded-2xl p-4 sm:p-5 border border-white/10 hover:border-emerald-500/30 transition-all shadow-md space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/5 pb-2.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
                      {index + 1}
                    </span>
                    <span className="text-xs font-bold text-slate-300">
                      Tingkat Kelas {q.classId} &bull; Semester {q.semester}
                    </span>
                    <span className="text-slate-500 text-xs">&bull;</span>
                    <span className="text-[11px] font-semibold text-cyan-300">
                      {typeLabel}
                    </span>
                    {q.domain && (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/25 text-[10px] font-bold">
                        {q.domain}
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-300 border border-rose-500/25 text-[10px] font-bold flex items-center gap-1">
                      ❤️ Pendekatan KBC
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-300 px-2 py-0.5 rounded-md bg-amber-500/10 border border-amber-500/20 font-mono">
                      Bobot: {q.scoreWeight} Poin
                    </span>
                    <button
                      onClick={() => {
                        setSinglePrintQuestion(q);
                        setPrintBlueprintModalOpen(true);
                      }}
                      className="p-1.5 rounded-lg bg-blue-500/15 text-blue-300 hover:bg-blue-500/30 transition-colors cursor-pointer"
                      title="Cetak Butir Soal Ini"
                    >
                      <Printer className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => openEditModal(q)}
                      className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/30 transition-colors cursor-pointer"
                      title="Edit Soal"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(q.id, q.question)}
                      className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 transition-colors cursor-pointer"
                      title="Hapus Soal"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* TKA Stimulus Box if any */}
                {q.stimulus && (
                  <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-1.5 shadow-inner">
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-cyan-300 uppercase tracking-wider">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>Stimulus Soal (Model TKA Kontekstual Anak SD)</span>
                    </div>
                    <p className="text-xs sm:text-[13px] text-slate-200 leading-relaxed font-medium">
                      {q.stimulus}
                    </p>
                  </div>
                )}

                {/* Arabic Verse with Khat Naskh */}
                {q.arabicText && (
                  <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 text-right space-y-1 shadow-sm">
                    <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block text-left">
                      Teks Arab (Khat Naskh Berharakat):
                    </span>
                    <p className="khat-naskh text-emerald-300 leading-loose font-arabic text-xl sm:text-2xl pt-1">
                      {q.arabicText}
                    </p>
                  </div>
                )}

                {/* Question Statement */}
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    Pertanyaan Pemantik:
                  </span>
                  <p className="text-sm font-bold text-white leading-relaxed">
                    {q.question}
                  </p>
                </div>

                {/* Options / Answer Preview */}
                {q.questionType === 'menjodohkan' && q.matchingPairs && q.matchingPairs.length > 0 ? (
                  <div className="rounded-xl border border-emerald-500/30 overflow-hidden text-xs">
                    <div className="grid grid-cols-2 bg-emerald-500/15 font-bold text-emerald-300 p-2 border-b border-emerald-500/30">
                      <span>Lajur Kiri (Pernyataan)</span>
                      <span>Lajur Kanan (Pasangan Kunci)</span>
                    </div>
                    {q.matchingPairs.map((pair, pi) => (
                      <div
                        key={pi}
                        className="grid grid-cols-2 p-2 border-b border-white/5 last:border-b-0 bg-white/5 text-slate-200 gap-2"
                      >
                        <span>
                          {pi + 1}. {pair.left}
                        </span>
                        <span className="text-emerald-300 font-semibold">➔ {pair.right}</span>
                      </div>
                    ))}
                  </div>
                ) : q.questionType === 'isian_singkat' || q.questionType === 'essay' ? (
                  <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-200">
                    <span className="font-bold text-emerald-400">Kunci Jawaban: </span>
                    {Array.isArray(q.correctAnswer) ? q.correctAnswer.join(', ') : q.correctAnswer}
                  </div>
                ) : (
                  q.options.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      {q.options.map((opt, optIdx) => {
                        const letter = String.fromCharCode(65 + optIdx);
                        const isCorrect = Array.isArray(q.correctAnswer)
                          ? q.correctAnswer.includes(opt)
                          : q.correctAnswer === opt;
                        return (
                          <div
                            key={optIdx}
                            className={`p-2.5 rounded-xl text-xs flex items-center gap-2 border transition-colors ${
                              isCorrect
                                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 font-bold'
                                : 'bg-white/5 border-white/5 text-slate-300'
                            }`}
                          >
                            <span
                              className={`w-5 h-5 rounded-md flex items-center justify-center font-bold text-[10px] shrink-0 ${
                                isCorrect ? 'bg-emerald-500 text-white' : 'bg-white/10 text-slate-400'
                              }`}
                            >
                              {letter}
                            </span>
                            <span className="flex-1">{opt}</span>
                            {isCorrect && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                        );
                      })}
                    </div>
                  )
                )}

                {/* Explanation */}
                {q.explanation && (
                  <div className="text-[11px] text-slate-400 bg-white/5 p-2.5 rounded-xl border border-white/5">
                    <span className="font-bold text-slate-300">Penjelasan/Kunci:</span>{' '}
                    {q.explanation}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Modal Add / Edit Question */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
          <div className="glass-strong rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <FileQuestion className="w-5 h-5 text-emerald-400" />
                {editingQuestion ? 'Edit Butir Soal' : 'Buat Butir Soal Baru (PAI)'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 overflow-y-auto flex-1 space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Tipe Soal
                  </label>
                  <select
                    value={formType}
                    onChange={e => setFormType(e.target.value as QuestionType)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="pg_standar">PG Standar (Tunggal)</option>
                    <option value="pg_kompleks">PG Kompleks (Jamak)</option>
                    <option value="benar_salah">Benar / Salah</option>
                    <option value="menjodohkan">Menjodohkan (Pasangan)</option>
                    <option value="isian_singkat">Isian Singkat</option>
                    <option value="essay">Uraian / Esai</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Tingkat Kelas
                  </label>
                  <select
                    value={formClassId}
                    onChange={e => setFormClassId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="1">Kelas 1</option>
                    <option value="2">Kelas 2</option>
                    <option value="3">Kelas 3</option>
                    <option value="4">Kelas 4</option>
                    <option value="5">Kelas 5</option>
                    <option value="6">Kelas 6</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Semester
                  </label>
                  <select
                    value={formSemester}
                    onChange={e => setFormSemester(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Bobot Nilai
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={formScoreWeight}
                    onChange={e => setFormScoreWeight(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold font-mono"
                  />
                </div>
              </div>

              {/* Arabic Helper Inserter */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300 uppercase flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-emerald-400" /> Teks Ayat / Kaligrafi Arab (Opsional)
                  </label>
                </div>
                {/* Fast Arabic Snippet Buttons */}
                <div className="flex flex-wrap gap-1.5 mb-2">
                  <button
                    type="button"
                    onClick={() => insertArabicSnippet('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')}
                    className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-emerald-300 text-[11px] font-arabic border border-white/10"
                  >
                    Basmalah
                  </button>
                  <button
                    type="button"
                    onClick={() => insertArabicSnippet('أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ')}
                    className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-emerald-300 text-[11px] font-arabic border border-white/10"
                  >
                    Al-Ma'un: 1
                  </button>
                  <button
                    type="button"
                    onClick={() => insertArabicSnippet('فَذَٰلِكَ الَّذِي يَدُعُّ الْيَتِيمَ')}
                    className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-emerald-300 text-[11px] font-arabic border border-white/10"
                  >
                    Al-Ma'un: 2
                  </button>
                  <button
                    type="button"
                    onClick={() => insertArabicSnippet('قُلْ هُوَ اللَّهُ أَحَدٌ')}
                    className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-emerald-300 text-[11px] font-arabic border border-white/10"
                  >
                    Al-Ikhlas: 1
                  </button>
                  <button
                    type="button"
                    onClick={() => insertArabicSnippet('إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ')}
                    className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-emerald-300 text-[11px] font-arabic border border-white/10"
                  >
                    Al-Kautsar: 1
                  </button>
                  <button
                    type="button"
                    onClick={() => insertArabicSnippet('الْقَوِيُّ')}
                    className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-emerald-300 text-[11px] font-arabic border border-white/10"
                  >
                    Al-Qawiyyu
                  </button>
                </div>
                <textarea
                  rows={2}
                  dir="rtl"
                  value={formArabic}
                  onChange={e => setFormArabic(e.target.value)}
                  placeholder="Ketik atau tempel ayat Al-Qur'an / tulisan Arab di sini..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-emerald-300 font-arabic text-base leading-loose focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Elemen Kurikulum Merdeka
                  </label>
                  <select
                    value={formDomain}
                    onChange={e => setFormDomain(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Al-Qur'an & Hadis">Al-Qur'an & Hadis</option>
                    <option value="Akidah">Akidah</option>
                    <option value="Akhlak">Akhlak</option>
                    <option value="Fikih">Fikih</option>
                    <option value="Sejarah Peradaban Islam">Sejarah Peradaban Islam</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Pendekatan Pembelajaran
                  </label>
                  <input
                    type="text"
                    value={formApproach}
                    onChange={e => setFormApproach(e.target.value)}
                    placeholder="Kurikulum Berbasis Cinta (KBC)"
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold"
                  />
                </div>
              </div>

              {/* TKA Stimulus Field */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300 uppercase flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Stimulus Soal (Model TKA Kontekstual Anak SD)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setFormStimulus(prev =>
                        prev
                          ? `${prev} di ${activeSchoolName}`
                          : `Saat jam istirahat di ${activeSchoolName}, anak-anak kelas ${formClassId} sedang bermain bersama di halaman sekolah...`
                      );
                    }}
                    className="text-[10px] text-cyan-300 hover:text-cyan-200 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20 font-bold cursor-pointer"
                  >
                    + Sisipkan "{activeSchoolName.substring(0, 18)}..."
                  </button>
                </div>
                <textarea
                  rows={2}
                  value={formStimulus}
                  onChange={e => setFormStimulus(e.target.value)}
                  placeholder={`Contoh narasi kontekstual: "Saat piket kebersihan kelas di ${activeSchoolName}, Ahmad melihat Salman membantu mengangkat ember air..."`}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-cyan-950/20 border border-cyan-500/30 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-400 leading-relaxed"
                />
              </div>

              {/* Question Body */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Butir Pertanyaan Pemantik <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={3}
                  value={formQuestion}
                  onChange={e => setFormQuestion(e.target.value)}
                  placeholder="Tuliskan pertanyaan soal PAI..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-emerald-500 leading-relaxed"
                  required
                />
              </div>

              {/* Answer Options Configuration */}
              {formType === 'pg_standar' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase block">
                    Pilihan Jawaban (Pilih 1 Kunci yang Benar):
                  </label>
                  {formOptions.map((opt, idx) => {
                    const letter = String.fromCharCode(65 + idx);
                    return (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="correctSingle"
                          checked={formCorrectSingle === opt && opt !== ''}
                          onChange={() => setFormCorrectSingle(opt)}
                          className="accent-emerald-500 w-4 h-4 cursor-pointer"
                        />
                        <span className="w-6 text-center font-bold text-xs text-slate-400">
                          {letter}.
                        </span>
                        <input
                          type="text"
                          value={opt}
                          onChange={e => {
                            const updated = [...formOptions];
                            updated[idx] = e.target.value;
                            setFormOptions(updated);
                            if (formCorrectSingle === opt) setFormCorrectSingle(e.target.value);
                          }}
                          placeholder={`Pilihan ${letter}`}
                          className="flex-1 px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white"
                          required
                        />
                      </div>
                    );
                  })}
                </div>
              )}

              {formType === 'pg_kompleks' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase block">
                    Pilihan Jawaban (Centang Semua Kunci yang Benar):
                  </label>
                  {formOptions.map((opt, idx) => {
                    const letter = String.fromCharCode(65 + idx);
                    const isChecked = formCorrectMulti.includes(opt) && opt !== '';
                    return (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={e => {
                            if (e.target.checked) {
                              setFormCorrectMulti([...formCorrectMulti, opt]);
                            } else {
                              setFormCorrectMulti(formCorrectMulti.filter(item => item !== opt));
                            }
                          }}
                          className="accent-emerald-500 w-4 h-4 cursor-pointer"
                        />
                        <span className="w-6 text-center font-bold text-xs text-slate-400">
                          {letter}.
                        </span>
                        <input
                          type="text"
                          value={opt}
                          onChange={e => {
                            const updated = [...formOptions];
                            const oldVal = updated[idx];
                            updated[idx] = e.target.value;
                            setFormOptions(updated);
                            if (formCorrectMulti.includes(oldVal)) {
                              setFormCorrectMulti(
                                formCorrectMulti.map(x => (x === oldVal ? e.target.value : x))
                              );
                            }
                          }}
                          placeholder={`Pilihan ${letter}`}
                          className="flex-1 px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white"
                          required
                        />
                      </div>
                    );
                  })}
                </div>
              )}

              {formType === 'benar_salah' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase block">
                    Kunci Pernyataan yang Benar:
                  </label>
                  <div className="flex gap-4">
                    {['Benar', 'Salah'].map(val => (
                      <label
                        key={val}
                        className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer"
                      >
                        <input
                          type="radio"
                          name="correctBS"
                          checked={formCorrectSingle === val}
                          onChange={() => setFormCorrectSingle(val)}
                          className="accent-emerald-500 w-4 h-4"
                        />
                        <span>{val}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {formType === 'menjodohkan' && (
                <div className="space-y-2.5 p-3.5 rounded-2xl bg-slate-900/70 border border-emerald-500/30">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-emerald-300 uppercase">
                      Pasangan Pernyataan &amp; Jawaban (Menjodohkan)
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        setFormMatchingPairs(prev => [...prev, { left: '', right: '' }])
                      }
                      className="text-[11px] font-bold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                    >
                      + Tambah Baris Pasangan
                    </button>
                  </div>
                  {formMatchingPairs.map((pair, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-1.5 items-center">
                      <span className="col-span-1 text-[11px] font-mono text-slate-400 font-bold">
                        {idx + 1}.
                      </span>
                      <input
                        type="text"
                        value={pair.left}
                        onChange={e => {
                          const updated = [...formMatchingPairs];
                          updated[idx] = { ...updated[idx], left: e.target.value };
                          setFormMatchingPairs(updated);
                        }}
                        placeholder="Lajur Kiri (Pernyataan)"
                        className="col-span-5 px-2.5 py-1.5 rounded-lg bg-white/5 border border-white/15 text-white text-xs"
                      />
                      <span className="col-span-1 text-center text-emerald-400 font-bold text-xs">
                        ➔
                      </span>
                      <input
                        type="text"
                        value={pair.right}
                        onChange={e => {
                          const updated = [...formMatchingPairs];
                          updated[idx] = { ...updated[idx], right: e.target.value };
                          setFormMatchingPairs(updated);
                        }}
                        placeholder="Lajur Kanan (Pasangan)"
                        className="col-span-4 px-2.5 py-1.5 rounded-lg bg-white/5 border border-emerald-500/30 text-emerald-200 text-xs"
                      />
                      <button
                        type="button"
                        disabled={formMatchingPairs.length <= 2}
                        onClick={() =>
                          setFormMatchingPairs(prev => prev.filter((_, i) => i !== idx))
                        }
                        className="col-span-1 text-slate-400 hover:text-rose-400 disabled:opacity-30 flex justify-center cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {formType === 'isian_singkat' && (
                <div>
                  <label className="text-xs font-bold text-amber-300 uppercase block mb-1">
                    Kunci Jawaban Isian Singkat <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={formCorrectSingle}
                    onChange={e => setFormCorrectSingle(e.target.value)}
                    placeholder="Contoh: Al-Amin / Dapat dipercaya (pisahkan dengan / jika ada alternatif)"
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-amber-500/40 text-white text-xs font-bold"
                  />
                </div>
              )}

              {formType === 'essay' && (
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                    Pedoman / Kunci Jawaban Uraian
                  </label>
                  <textarea
                    rows={2}
                    value={formCorrectSingle}
                    onChange={e => setFormCorrectSingle(e.target.value)}
                    placeholder="Kunci jawaban atau kata kunci esai..."
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white"
                  />
                </div>
              )}

              {/* Explanation */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Pembahasan / Penjelasan Soal (Opsional)
                </label>
                <input
                  type="text"
                  value={formExplanation}
                  onChange={e => setFormExplanation(e.target.value)}
                  placeholder="Penjelasan ringkas materi untuk review siswa..."
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white"
                />
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition-all"
                >
                  Simpan Butir Soal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Generator Soal AI (Kurikulum Merdeka & Pendekatan KBC) */}
      {aiModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="glass-strong rounded-3xl w-full max-w-lg border border-cyan-500/30 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-cyan-950/40 via-emerald-950/20 to-transparent">
              <div>
                <h3 className="font-bold text-base text-white flex items-center gap-2 font-display">
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  Generator Soal AI PAI & Budi Pekerti
                </h3>
                <p className="text-[11px] text-cyan-300 mt-0.5">
                  Kurikulum Merdeka &bull; Pendekatan KBC &bull; Model Soal TKA Berbasis Stimulus
                </p>
              </div>
              <button
                onClick={() => setAiModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              {/* Dynamic School Badge */}
              <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>Latar Sekolah (Dinamis):</span>
                </div>
                <span className="font-bold text-emerald-300 truncate max-w-xs font-display">
                  {activeSchoolName}
                </span>
              </div>

              {/* Guiding Tenets Badge Grid */}
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <p className="font-bold text-cyan-300 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Model Soal TKA
                  </p>
                  <p className="text-slate-400 text-[10px] leading-tight">
                    Dilengkapi stimulus cerita nyata dan pengalaman anak SD.
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <p className="font-bold text-rose-300 flex items-center gap-1">
                    ❤️ Pendekatan KBC
                  </p>
                  <p className="text-slate-400 text-[10px] leading-tight">
                    Cinta Allah/Rasul, empati, tolong-menolong & budi pekerti.
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <p className="font-bold text-emerald-300 flex items-center gap-1">
                    🕌 Khat Naskh Rapi
                  </p>
                  <p className="text-slate-400 text-[10px] leading-tight">
                    Tulisan Arab berharakat lengkap standar mushaf Al-Qur'an.
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <p className="font-bold text-amber-300 flex items-center gap-1">
                    🏫 Konteks SD Nyata
                  </p>
                  <p className="text-slate-400 text-[10px] leading-tight">
                    Piket kelas, wudhu musholla, berbagi bekal di {activeSchoolName.substring(0, 15)}...
                  </p>
                </div>
              </div>

              {/* Topic Selection */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                  Pilih Topik Silabus / Elemen PAI
                </label>
                <select
                  value={aiTopic}
                  onChange={e => {
                    setAiTopic(e.target.value);
                    if (e.target.value !== 'custom') setAiCustomTopic('');
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                >
                  <option value="Surah Al-Ma'un & Kepedulian Sosial">Surah Al-Ma'un & Kepedulian Kasih Sayang (Al-Qur'an & Hadis)</option>
                  <option value="Asmaul Husna (Al-Qawiyyu, Al-Qayyum)">Asmaul Husna: Al-Qawiyyu & Al-Qayyum (Akidah)</option>
                  <option value="Tata Cara Berwudhu & Shalat Fardhu">Adab Wudhu & Shalat Berjamaah di Musholla (Fikih)</option>
                  <option value="Kisah Teladan 25 Nabi & Rasul">Kisah Keteladanan Nabi Muhammad SAW & Sahabat (Sejarah)</option>
                  <option value="Akhlak Terpuji (Ta'awun, Kejujuran, Birrul Walidain)">Akhlak Mulia: Ta'awun, Kejujuran & Hormat Orang Tua (Akhlak)</option>
                  <option value="custom">-- Ketik Topik / Silabus Khusus Sendiri --</option>
                </select>
              </div>

              {/* Custom Topic Input if selected */}
              {aiTopic === 'custom' && (
                <div>
                  <label className="text-xs font-bold text-cyan-300 uppercase block mb-1">
                    Ketik Topik / Materi Khusus
                  </label>
                  <input
                    type="text"
                    value={aiCustomTopic}
                    onChange={e => setAiCustomTopic(e.target.value)}
                    placeholder="Contoh: Rukun Iman & Perilaku Amanah di Sekolah..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-cyan-950/30 border border-cyan-500/40 text-white text-xs font-bold focus:outline-none focus:border-cyan-400"
                    autoFocus
                  />
                </div>
              )}

              {/* Grade, Semester & Question Type */}
              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Tingkat Kelas
                  </label>
                  <select
                    value={aiGrade}
                    onChange={e => setAiGrade(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="1">Kelas 1</option>
                    <option value="2">Kelas 2</option>
                    <option value="3">Kelas 3</option>
                    <option value="4">Kelas 4</option>
                    <option value="5">Kelas 5</option>
                    <option value="6">Kelas 6</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Semester
                  </label>
                  <select
                    value={aiSemester}
                    onChange={e => setAiSemester(e.target.value as any)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                  >
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                    Jumlah Butir
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    value={aiCount}
                    onChange={e => setAiCount(Math.max(1, Math.min(5, Number(e.target.value))))}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold font-mono text-center"
                  />
                </div>
              </div>

              {/* Question Type Selection */}
              <div>
                <label className="text-[10px] font-bold text-slate-300 uppercase block mb-1">
                  Format / Ragam Soal
                </label>
                <select
                  value={aiQuestionType}
                  onChange={e => setAiQuestionType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-white text-xs font-bold cursor-pointer"
                >
                  <option value="all">Campuran (PG Standar, PG Kompleks & Benar-Salah)</option>
                  <option value="pg_standar">Khusus Pilihan Ganda (PG Standar)</option>
                  <option value="pg_kompleks">Khusus Pilihan Ganda Kompleks (Jamak)</option>
                  <option value="benar_salah">Khusus Benar / Salah (Menalar Pernyataan)</option>
                </select>
              </div>

              <div className="bg-gradient-to-r from-cyan-500/10 to-emerald-500/10 border border-cyan-500/20 p-3 rounded-2xl text-[11px] text-cyan-200 leading-relaxed">
                ✨ Setiap butir soal akan otomatis dibuat dengan <b>stimulus cerita keseharian di {activeSchoolName}</b>, nilai cinta kasih (KBC), potongan ayat berharakat khat naskh, kunci jawaban, dan rubrik pembahasan.
              </div>

              <div className="pt-3 border-t border-white/10 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setAiModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  disabled={aiGenerating}
                  onClick={handleGenerateAI}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-600 hover:from-cyan-600 hover:to-emerald-700 text-white text-xs font-bold shadow-lg shadow-cyan-500/25 flex items-center gap-2 cursor-pointer disabled:opacity-50 transition-all"
                >
                  {aiGenerating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Menyusun Soal TKA KBC...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-4 h-4" /> Rumuskan Soal Otomatis (AI)
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Cetak Soal & Kisi-Kisi Resmi */}
      {printBlueprintModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="glass-strong rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col border border-white/20 shadow-2xl overflow-hidden my-auto">
            <div className="p-4 sm:p-5 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
              <div>
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Printer className="w-5 h-5 text-indigo-400" /> Cetak Dokumen Asesmen PAI &amp; Budi Pekerti
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {singlePrintQuestion ? 'Mencetak 1 butir soal terpilih' : `Mencetak ${filtered.length} butir soal`} &bull; Format resmi Dinas Pendidikan &amp; KBC
                </p>
              </div>

              {/* Tab Selector */}
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-white/10">
                <button
                  type="button"
                  onClick={() => setPrintModalTab('blueprint')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    printModalTab === 'blueprint' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  1. Kisi-Kisi
                </button>
                <button
                  type="button"
                  onClick={() => setPrintModalTab('questions')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    printModalTab === 'questions' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  2. Lembar Soal Siswa
                </button>
                <button
                  type="button"
                  onClick={() => setPrintModalTab('rubric')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    printModalTab === 'rubric' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  3. Kunci &amp; Pembahasan
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> Cetak Sekarang
                </button>
                <button
                  onClick={() => {
                    setPrintBlueprintModalOpen(false);
                    setSinglePrintQuestion(null);
                  }}
                  className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 sm:p-10 overflow-y-auto flex-1 bg-white text-black font-serif text-sm">
              {/* KOP RESMI SEKOLAH */}
              <div className="text-center pb-4 border-b-2 border-black mb-5">
                <h3 className="text-sm font-bold tracking-wider uppercase">
                  PEMERINTAH KOTA BEKASI &bull; DINAS PENDIDIKAN
                </h3>
                <h2 className="text-base font-extrabold uppercase">
                  {activeSchoolName}
                </h2>
                <p className="text-xs italic text-gray-700">
                  {appSettings.schoolAddress || 'Jl. Raya Ciketing Udik No. 2, Bantargebang, Kota Bekasi'}
                </p>
                <div className="mt-3 py-1 border-t border-b border-black text-center font-bold text-xs uppercase tracking-widest">
                  {printModalTab === 'blueprint' && 'KISI-KISI PENULISAN SOAL ASESMEN SUMATIF PAI & BUDI PEKERTI'}
                  {printModalTab === 'questions' && 'NASKAH LEMBAR ASESMEN PESERTA DIDIK PAI & BUDI PEKERTI'}
                  {printModalTab === 'rubric' && 'KUNCI JAWABAN & PEMBAHASAN ASESMEN (PEGANGAN GURU)'}
                </div>
              </div>

              {/* IDENTITAS */}
              <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                <div>
                  <p><strong>Satuan Pendidikan:</strong> {activeSchoolName}</p>
                  <p><strong>Mata Pelajaran:</strong> Pendidikan Agama Islam &amp; Budi Pekerti</p>
                </div>
                <div className="text-right">
                  <p><strong>Tahun Ajaran:</strong> {appSettings.academicYear || '2026/2027'}</p>
                  <p><strong>Penyusun:</strong> {teacherProfile.fullName || 'Guru PAI'}</p>
                </div>
              </div>

              {/* KONTEN TAB 1: KISI-KISI ASESMEN */}
              {printModalTab === 'blueprint' && (
                <table className="w-full border-collapse border border-black text-xs mb-8">
                  <thead>
                    <tr className="bg-gray-100 font-bold">
                      <th className="border border-black p-2 text-center w-8">No</th>
                      <th className="border border-black p-2 w-48">Capaian Pembelajaran / Materi</th>
                      <th className="border border-black p-2">Indikator Butir Soal</th>
                      <th className="border border-black p-2 text-center w-20">Level Kognitif</th>
                      <th className="border border-black p-2 text-center w-28">Bentuk Soal</th>
                      <th className="border border-black p-2 text-center w-12">Bobot</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(singlePrintQuestion ? [singlePrintQuestion] : filtered).map((q, idx) => (
                      <tr key={q.id} className="align-top">
                        <td className="border border-black p-2 text-center">{idx + 1}</td>
                        <td className="border border-black p-2 font-bold">
                          Tingkat Kelas {q.classId} - Semester {q.semester}
                        </td>
                        <td className="border border-black p-2">
                          {q.stimulus && <span className="italic block mb-0.5 text-slate-700">Stimulus: {q.stimulus.substring(0, 80)}...</span>}
                          {q.question.substring(0, 90)}...
                        </td>
                        <td className="border border-black p-2 text-center">HOTS / Nalar</td>
                        <td className="border border-black p-2 text-center uppercase font-mono text-[10px]">
                          {q.questionType.replace('_', ' ')}
                        </td>
                        <td className="border border-black p-2 text-center font-bold">{q.scoreWeight}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {/* KONTEN TAB 2: NASKAH LEMBAR SOAL SISWA */}
              {printModalTab === 'questions' && (
                <div className="space-y-5 text-xs mb-8">
                  <div className="border border-black p-3 rounded flex justify-between">
                    <div>
                      <p><b>Nama Siswa :</b> ..............................................................</p>
                      <p className="mt-1"><b>Kelas :</b> Kelas {singlePrintQuestion?.classId || filterClass || '5'} ({activeSchoolName})</p>
                    </div>
                    <div>
                      <p><b>No. Absen :</b> ................</p>
                      <p className="mt-1"><b>Hari/Tgl :</b> ....................................</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {(singlePrintQuestion ? [singlePrintQuestion] : filtered).map((q, idx) => (
                      <div key={q.id} className="space-y-2">
                        <div className="flex items-start gap-2">
                          <span className="font-bold">{idx + 1}.</span>
                          <div className="flex-1 space-y-2">
                            {q.stimulus && (
                              <div className="border border-black/40 p-2.5 bg-slate-50 italic rounded text-justify">
                                <b>Bacalah cerita di bawah ini dengan teliti!</b>
                                <p className="mt-0.5">{q.stimulus}</p>
                              </div>
                            )}

                            {q.arabicText && (
                              <div className="text-right p-2 font-serif text-base leading-loose" dir="rtl">
                                {q.arabicText}
                              </div>
                            )}

                            <p className="font-semibold">{q.question}</p>

                            {q.options && q.options.length > 0 && (
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-2 pt-1">
                                {q.options.map((opt, oi) => (
                                  <div key={oi}>
                                    <b>{String.fromCharCode(65 + oi)}.</b> {opt}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* KONTEN TAB 3: KUNCI JAWABAN & PEMBAHASAN */}
              {printModalTab === 'rubric' && (
                <table className="w-full border-collapse border border-black text-xs mb-8">
                  <thead>
                    <tr className="bg-gray-100 font-bold">
                      <th className="border border-black p-2 text-center w-8">No</th>
                      <th className="border border-black p-2 w-28">Bentuk Soal</th>
                      <th className="border border-black p-2 w-44">Kunci Jawaban</th>
                      <th className="border border-black p-2">Pembahasan Hikmah KBC</th>
                      <th className="border border-black p-2 text-center w-12">Bobot</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(singlePrintQuestion ? [singlePrintQuestion] : filtered).map((q, idx) => (
                      <tr key={q.id} className="align-top">
                        <td className="border border-black p-2 text-center font-bold">{idx + 1}</td>
                        <td className="border border-black p-2 capitalize">{q.questionType.replace('_', ' ')}</td>
                        <td className="border border-black p-2 font-bold text-emerald-800">
                          {Array.isArray(q.correctAnswer) ? q.correctAnswer.join(', ') : q.correctAnswer}
                        </td>
                        <td className="border border-black p-2 text-slate-700">
                          {q.explanation || 'Jawaban mencerminkan pengamalan ajaran budi pekerti dan empati kepada sesama.'}
                        </td>
                        <td className="border border-black p-2 text-center font-bold">{q.scoreWeight}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {/* DUAL SIGNATURE BLOCK */}
              <div className="grid grid-cols-2 text-xs pt-4 break-inside-avoid">
                <div className="text-center">
                  <p>Mengetahui,</p>
                  <p>Kepala {activeSchoolName}</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{appSettings.principalName || 'Hj. Siti Aminah, M.Pd.'}</p>
                  <p>NIP. {appSettings.principalNip || '-'}</p>
                </div>
                <div className="text-center">
                  <p>Bekasi, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                  <p>Guru Pendidikan Agama Islam</p>
                  <div className="h-16"></div>
                  <p className="font-bold underline uppercase">{teacherProfile.fullName || 'Guru PAI'}</p>
                  <p>NIP. {teacherProfile.nip || '-'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="glass-strong border border-rose-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
              <Trash2 className="w-7 h-7" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white text-center font-display">
              Hapus Butir Soal?
            </h3>
            <p className="text-xs text-slate-300 text-center mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus butir soal{' '}
              <span className="text-white font-bold">"{deleteTarget.question.substring(0, 60)}..."</span> dari Bank Soal? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" /> Ya, Hapus Soal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
